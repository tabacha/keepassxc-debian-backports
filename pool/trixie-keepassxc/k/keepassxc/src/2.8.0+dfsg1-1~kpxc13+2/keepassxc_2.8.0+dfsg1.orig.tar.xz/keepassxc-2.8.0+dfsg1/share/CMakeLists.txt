#  Copyright (C) 2011 Felix Geyer <debfx@fobos.de>
#  Copyright (C) 2017 KeePassXC Team <team@keepassxc.org>
#
#  This program is free software: you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation, either version 2 or (at your option)
#  version 3 of the License.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program.  If not, see <http://www.gnu.org/licenses/>.

add_subdirectory(translations)

file(GLOB wordlists_files "wordlists/*.wordlist")
install(FILES ${wordlists_files} DESTINATION ${DATA_INSTALL_DIR}/wordlists)

# Copy wordlists to build dir for use in tests
file(COPY "wordlists" DESTINATION ${CMAKE_CURRENT_BINARY_DIR})

if(UNIX AND NOT APPLE AND NOT HAIKU)
    # Flatpak requires all host accessible files to use filenames based upon the app id
    if(KEEPASSXC_DIST_FLATPAK)
        set(APP_ICON_NAME "${APP_ID}")
        set(MIME_ICON "${APP_ID}-application-x-keepassxc")
        configure_file(linux/keepassxc.xml.in ${CMAKE_CURRENT_BINARY_DIR}/linux/${APP_ID}.xml @ONLY)
        install(FILES ${CMAKE_CURRENT_BINARY_DIR}/linux/${APP_ID}.xml DESTINATION ${CMAKE_INSTALL_DATADIR}/mime/packages)

        file(GLOB_RECURSE ICON_FILES LIST_DIRECTORIES false
             "icons/application/*/keepassxc*.png"
             "icons/application/*/*keepassxc*.svg")
        foreach(icon_match ${ICON_FILES})
            get_filename_component(icon_name ${icon_match} NAME)
            get_filename_component(icon_dir ${icon_match} DIRECTORY)
            # Prefix all icons with application id: "org.keepassxc.KeePassXC"
            string(REGEX REPLACE "^keepassxc(.*)?(\\.png|\\.svg)$" "${APP_ID}\\1\\2" icon_name ${icon_name})
            string(REGEX REPLACE "^(application-x-keepassxc\\.svg)$" "${APP_ID}-\\1" icon_name ${icon_name})
            # Find icon sub dir ex. "scalable/mimetypes/"
            file(RELATIVE_PATH icon_subdir ${CMAKE_CURRENT_SOURCE_DIR}/icons/application ${icon_dir})
            install(FILES ${icon_match} DESTINATION ${CMAKE_INSTALL_DATADIR}/icons/hicolor/${icon_subdir}
                    RENAME ${icon_name})
        endforeach()
    else()
        set(APP_ICON_NAME "keepassxc")
        set(MIME_ICON "application-x-keepassxc")
        configure_file(linux/keepassxc.xml.in ${CMAKE_CURRENT_BINARY_DIR}/linux/keepassxc.xml @ONLY)
        install(FILES ${CMAKE_CURRENT_BINARY_DIR}/linux/keepassxc.xml DESTINATION ${CMAKE_INSTALL_DATADIR}/mime/packages)

        install(DIRECTORY icons/application/ DESTINATION ${CMAKE_INSTALL_DATADIR}/icons/hicolor
                FILES_MATCHING PATTERN "keepassx*.png" PATTERN "keepassx*.svg"
                PATTERN "status" EXCLUDE PATTERN "actions" EXCLUDE PATTERN "categories" EXCLUDE)
        install(DIRECTORY icons/application/ DESTINATION ${CMAKE_INSTALL_DATADIR}/icons/hicolor
                FILES_MATCHING PATTERN "application-x-keepassxc.svg" PATTERN "status"
                EXCLUDE PATTERN "actions" EXCLUDE PATTERN "categories" EXCLUDE)
    endif(KEEPASSXC_DIST_FLATPAK)
    configure_file(linux/${APP_ID}.desktop.in ${CMAKE_CURRENT_BINARY_DIR}/linux/${APP_ID}.desktop @ONLY)
    configure_file(linux/${APP_ID}.policy.in ${CMAKE_CURRENT_BINARY_DIR}/linux/${APP_ID}.policy @ONLY)

    install(FILES ${CMAKE_CURRENT_BINARY_DIR}/linux/${APP_ID}.desktop DESTINATION ${CMAKE_INSTALL_DATADIR}/applications)
    if("${CMAKE_SYSTEM}" MATCHES "Linux")
      install(FILES ${CMAKE_CURRENT_BINARY_DIR}/linux/${APP_ID}.policy DESTINATION ${CMAKE_INSTALL_DATADIR}/polkit-1/actions)
    endif()
    install(FILES linux/${APP_ID}.appdata.xml DESTINATION ${CMAKE_INSTALL_DATADIR}/metainfo)
endif(UNIX AND NOT APPLE AND NOT HAIKU)

install(FILES icons/application/256x256/apps/keepassxc.png DESTINATION ${DATA_INSTALL_DIR}/icons/application/256x256/apps)

add_custom_target(icons)
add_custom_command(TARGET icons
        POST_BUILD
        COMMAND bash ./icons/minify.sh
        WORKING_DIRECTORY ${CMAKE_CURRENT_SOURCE_DIR})
if(APPLE)
    add_custom_command(TARGET icons
            POST_BUILD
            COMMAND xcrun actool share/macosx/keepassxc.icon
                --compile share/macosx
                --output-partial-info-plist /dev/null
                --app-icon keepassxc
                --include-all-app-icons
                --enable-on-demand-resources NO
                --target-device mac
                --minimum-deployment-target 11.0
                --platform macosx
                --output-format human-readable-text
            WORKING_DIRECTORY ${CMAKE_CURRENT_SOURCE_DIR})
endif()

# ICO for Windows
add_custom_command(TARGET icons
    POST_BUILD
    COMMAND bash ./windows/create-ico.sh icons/application/scalable/apps/keepassxc.svg windows/keepassxc.ico
    COMMAND bash ./windows/create-ico.sh icons/application/scalable/mimetypes/application-x-keepassxc.svg windows/keepassxc-kdbx.ico
    WORKING_DIRECTORY ${CMAKE_CURRENT_SOURCE_DIR})

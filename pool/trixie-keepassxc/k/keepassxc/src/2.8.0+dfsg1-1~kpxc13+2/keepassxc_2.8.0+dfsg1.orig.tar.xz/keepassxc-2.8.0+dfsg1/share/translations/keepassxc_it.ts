<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="it">
<context>
    <name>AboutDialog</name>
    <message>
        <source>About KeePassXC</source>
        <translation>Informazioni su KeePassXC</translation>
    </message>
    <message>
        <source>About</source>
        <translation>Info programma</translation>
    </message>
    <message>
        <source>Report bugs at: &lt;a href=&quot;https://github.com/keepassxreboot/keepassxc/issues&quot; style=&quot;text-decoration: underline;&quot;&gt;https://github.com&lt;/a&gt;</source>
        <translation>Segnala eventuali problemi su: &lt;a href=&quot;https://github.com/keepassxreboot/keepassxc/issues&quot; style=&quot;text-decoration: underline;&quot;&gt;https://github.com&lt;/a&gt;</translation>
    </message>
    <message>
        <source>KeePassXC is distributed under the terms of the GNU General Public License (GPL) version 2 or (at your option) version 3.</source>
        <translation>KeePassXC è distribuito sotto i termini della licenza GNU General Public License (GPL) versione 2 o (come opzione) versione 3.</translation>
    </message>
    <message>
        <source>Project Maintainers:</source>
        <translation>Responsabili del progetto:</translation>
    </message>
    <message>
        <source>Special thanks from the KeePassXC team go to debfx for creating the original KeePassX.</source>
        <translation>Uno speciale ringraziamento dal team di KeePassXC va a debfx per la creazione del KeePassX originale.</translation>
    </message>
    <message>
        <source>Contributors</source>
        <translation>Collaboratori</translation>
    </message>
    <message>
        <source>&lt;a href=&quot;https://github.com/keepassxreboot/keepassxc/graphs/contributors&quot;&gt;See Contributions on GitHub&lt;/a&gt;</source>
        <translation>&lt;a href=&quot;https://github.com/keepassxreboot/keepassxc/graphs/contributors&quot;&gt; Contributi su GitHub&lt;/a&gt;</translation>
    </message>
    <message>
        <source>Debug Info</source>
        <translation>Informazioni debug</translation>
    </message>
    <message>
        <source>Include the following information whenever you report a bug:</source>
        <translation>Quando segnali un problema includi le seguenti informazioni:</translation>
    </message>
    <message>
        <source>Copy to clipboard</source>
        <translation>Copia negli appunti</translation>
    </message>
</context>
<context>
    <name>AccessControlDialog</name>
    <message>
        <source>KeePassXC -  Access Request</source>
        <translation>KeePassXC - Richiesta di accesso</translation>
    </message>
    <message>
        <source>Non-existing/inaccessible executable path. Please double-check the client is legit.</source>
        <translation>Percorso eseguibile non esistente/non accessibile. 
Controlla che il client sia legittimo.</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;%1 &lt;/span&gt;is requesting access to the following entries:&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;%1 &lt;/span&gt;sta richiedendo l&apos;accesso alle seguenti voci:&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <source>PID</source>
        <translation>PID</translation>
    </message>
    <message>
        <source>Executable</source>
        <translation>Eseguibile</translation>
    </message>
    <message>
        <source>Command Line</source>
        <translation>Riga di comando</translation>
    </message>
    <message>
        <source>Details</source>
        <translation>Dettagli</translation>
    </message>
    <message>
        <source>Your decision will be remembered for the duration while both the requesting client AND KeePassXC are running.</source>
        <translation>Questa decisione verrà ricordata per tutta la durata mentre sia il client richiedente che KeePassXC sono in esecuzione.</translation>
    </message>
    <message>
        <source>Remember</source>
        <translation>Ricorda</translation>
    </message>
    <message>
        <source>Allow Selected</source>
        <translation>Consenti selezionati</translation>
    </message>
    <message>
        <source>Deny All &amp;&amp; Future</source>
        <translation>Nega tutto e futuri</translation>
    </message>
    <message>
        <source>Allow All &amp;&amp; &amp;Future</source>
        <translation>Consenti tutto e &amp;futuri</translation>
    </message>
</context>
<context>
    <name>AccessControlDialog::DenyButton</name>
    <message>
        <source>Deny for this program</source>
        <translation>Nega per questo programma</translation>
    </message>
</context>
<context>
    <name>AgentSettingsWidget</name>
    <message>
        <source>Enable SSH Agent integration</source>
        <translation>Abilita l&apos;integrazione dell&apos;agente SSH</translation>
    </message>
    <message>
        <source>Use Pageant</source>
        <translation>Usa Pageant</translation>
    </message>
    <message>
        <source>Use OpenSSH</source>
        <translation>Usa OpenSSH</translation>
    </message>
    <message>
        <source>Use both agents</source>
        <translation>Usa entrambi gli agenti</translation>
    </message>
    <message>
        <source>SSH_AUTH_SOCK override</source>
        <translation>sostituire SSH_AUTH_SOCK</translation>
    </message>
    <message>
        <source>SSH_AUTH_SOCK value</source>
        <translation>valore SSH_AUTH_SOCK</translation>
    </message>
    <message>
        <source>(empty)</source>
        <translation>(vuoto)</translation>
    </message>
    <message>
        <source>SSH_SK_PROVIDER value</source>
        <translation>SSH_SK_PROVIDER valore</translation>
    </message>
    <message>
        <source>SSH_SK_PROVIDER override</source>
        <translation>sovrascrivi SSH_SK_PROVIDER</translation>
    </message>
    <message>
        <source>No SSH Agent socket available. Either make sure SSH_AUTH_SOCK environment variable exists or set an override.</source>
        <translation>Nessun collegamento SSH disponibile. Verifica che la variabile d&apos;ambiente SSH_AUTH_SOCK esista oppure sovrascriverne il contenuto.</translation>
    </message>
    <message>
        <source>SSH Agent connection is working!</source>
        <translation>La connessione dell&apos;agente SSH sta funzionando!</translation>
    </message>
</context>
<context>
    <name>AppKit</name>
    <message>
        <source>Window</source>
        <translation>Finestra</translation>
    </message>
    <message>
        <source>Minimize</source>
        <translation>Minimizza</translation>
    </message>
    <message>
        <source>Zoom</source>
        <translation>Zoom</translation>
    </message>
    <message>
        <source>Bring All to Front</source>
        <translation>Porta tutto in primo piano</translation>
    </message>
</context>
<context>
    <name>ApplicationSettingsWidget</name>
    <message>
        <source>Application Settings</source>
        <translation>Impostazioni applicazione</translation>
    </message>
    <message>
        <source>General</source>
        <translation>Generale</translation>
    </message>
    <message>
        <source>Security</source>
        <translation>Sicurezza</translation>
    </message>
    <message>
        <source>This setting cannot be enabled when minimize on unlock is enabled.</source>
        <translation>Questa impostazione non può essere abilitata quando è abilitata la riduzione a icona con lo sblocco.</translation>
    </message>
    <message>
        <source>Access error for config file %1</source>
        <translation>Errore di accesso per il file di configurazione %1</translation>
    </message>
    <message>
        <source>Icon only</source>
        <translation>Solo icone</translation>
    </message>
    <message>
        <source>Text only</source>
        <translation>Solo testo</translation>
    </message>
    <message>
        <source>Text beside icon</source>
        <translation>Testo accanto alle icone</translation>
    </message>
    <message>
        <source>Text under icon</source>
        <translation>Testo sotto le icone</translation>
    </message>
    <message>
        <source>Follow style</source>
        <translation>Segui stile</translation>
    </message>
    <message>
        <source>Monochrome</source>
        <translation>Monocromatico</translation>
    </message>
    <message>
        <source>Monochrome (light)</source>
        <translation>Monocromatico (chiaro)</translation>
    </message>
    <message>
        <source>Monochrome (dark)</source>
        <translation>Monocromatico (scuro)</translation>
    </message>
    <message>
        <source>Colorful</source>
        <translation>Colorato</translation>
    </message>
    <message>
        <source>You must restart the application to set the new language. Would you like to restart now?</source>
        <translation>Per impostare la nuova lingua è necessario riavviare l&apos;applicazione. Vuoi riavviare ora?</translation>
    </message>
    <message>
        <source>Select backup storage directory</source>
        <translation>Seleziona cartella salvataggio backup</translation>
    </message>
    <message>
        <source>Confirm Reset</source>
        <translation>Conferma il ripristino</translation>
    </message>
    <message>
        <source>Are you sure you want to reset all settings to default?</source>
        <translation>Vuoi ripristinare tutte le impostazioni ai valori predefiniti?</translation>
    </message>
    <message>
        <source>Import KeePassXC Settings</source>
        <translation>Importa impostazioni KeePassXC</translation>
    </message>
    <message>
        <source>Failed to import settings from %1, not a valid settings file.</source>
        <translation>Impossibile importare le impostazioni da %1, non è un file di impostazioni valido.</translation>
    </message>
    <message>
        <source>Export KeePassXC Settings</source>
        <translation>Esporta impostazioni KeePassXC</translation>
    </message>
    <message>
        <source>Small</source>
        <translation>Piccolo</translation>
    </message>
    <message>
        <source>Normal</source>
        <translation>Normale</translation>
    </message>
    <message>
        <source>Medium</source>
        <translation>Medio</translation>
    </message>
    <message>
        <source>Large</source>
        <translation>Grande</translation>
    </message>
    <message>
        <source>Custom</source>
        <translation>Personalizzato</translation>
    </message>
    <message>
        <source>None</source>
        <translation>Nessuno</translation>
    </message>
    <message>
        <source>Restart KeePassXC to apply the Auto-Type desktop portals preference.</source>
        <translation>Per applicare la preferenza per inserire automaticamente i dati nei portali desktop riavvia KeePassXC .</translation>
    </message>
    <message>
        <source>This setting is managed by your organization.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>ApplicationSettingsWidgetGeneral</name>
    <message>
        <source>Basic Settings</source>
        <translation>Impostazioni di base</translation>
    </message>
    <message>
        <source>Startup</source>
        <translation>Avvio</translation>
    </message>
    <message>
        <source>Start only a single instance of KeePassXC</source>
        <translation>Avvia una sola istanza di KeePassXC</translation>
    </message>
    <message>
        <source>Automatically launch KeePassXC at system startup</source>
        <translation>Avvia automaticamente KeePassXC all&apos;avvio del sistema</translation>
    </message>
    <message>
        <source>Minimize window at application startup</source>
        <translation>Minimizza la finestra all&apos;avvio della applicazione</translation>
    </message>
    <message>
        <source>Minimize window after unlocking database</source>
        <translation>Riduci a icona la finestra dopo lo sblocco del database</translation>
    </message>
    <message>
        <source>Remember previously used databases</source>
        <translation>Ricorda i database usati in precedenza</translation>
    </message>
    <message>
        <source> recent files</source>
        <translation> file recenti</translation>
    </message>
    <message>
        <source>Load previously open databases on startup</source>
        <translation>Carica database aperti in precedenza all&apos;avvio</translation>
    </message>
    <message>
        <source>Remember database key files and security dongles</source>
        <translation>Memorizza i file chiave del database e i dongle di sicurezza</translation>
    </message>
    <message>
        <source>Check for updates at application startup once per week</source>
        <translation>Verifica la disponibilità di aggiornamenti all&apos;avvio dell&apos;applicazione una volta alla settimana</translation>
    </message>
    <message>
        <source>Include beta releases when checking for updates</source>
        <translation>Includi versioni beta durante il controllo della disponibilità di aggiornamenti</translation>
    </message>
    <message>
        <source>File Management</source>
        <translation>Gestione dei file</translation>
    </message>
    <message>
        <source>Automatically save after every change</source>
        <translation>Salva automaticamente dopo ogni modifica</translation>
    </message>
    <message>
        <source>Automatically save when locking database</source>
        <translation>Salva automaticamente durante il blocco del database</translation>
    </message>
    <message>
        <source>Automatically save non-data changes when locking database</source>
        <translation>Salva automaticamente le modifiche non apportate ai dati durante il blocco del database</translation>
    </message>
    <message>
        <source>Automatically reload the database when modified externally</source>
        <translation>Ricarica automaticamente il database quando ci sono modifiche esterne</translation>
    </message>
    <message>
        <source>Backup database file before saving</source>
        <translation>Effettua una copia di sicurezza del database prima di salvarlo</translation>
    </message>
    <message>
        <source>{DB_FILENAME}.old.kdbx</source>
        <translation>{DB_FILENAME}.old.kdbx</translation>
    </message>
    <message>
        <source>Use alternative saving method (may solve problems with Dropbox, Google Drive, GVFS, etc.)</source>
        <translation>Usa un metodo di salvataggio alternativo (può risolvere problemi con Dropbox, Google Drive, GVFS, ecc.)</translation>
    </message>
    <message>
        <source>Temporary file moved into place</source>
        <translation>File temporaneo spostato in posizione</translation>
    </message>
    <message>
        <source>Directly write to database file (dangerous)</source>
        <translation>Scrittura diretta nel file database (pericoloso)</translation>
    </message>
    <message>
        <source>Entry Management</source>
        <translation>Gestione dell&apos;elemento</translation>
    </message>
    <message>
        <source>Use group icon on entry creation</source>
        <translation>Usa icona del gruppo alla creazione di una voce</translation>
    </message>
    <message>
        <source>Minimize when opening a URL</source>
        <translation>Riduci a icona all&apos;apertura di un URL</translation>
    </message>
    <message>
        <source>Hide window when copying to clipboard</source>
        <translation>Nascondi la finestra durante la copia negli Appunti</translation>
    </message>
    <message>
        <source>Minimize</source>
        <translation>Riduci ad icona</translation>
    </message>
    <message>
        <source>Drop to background</source>
        <translation>Sposta sotto le altre finestre</translation>
    </message>
    <message>
        <source>Favicon download timeout:</source>
        <translation>Timeout scaricamento favicon:</translation>
    </message>
    <message>
        <source>Website icon download timeout in seconds</source>
        <translation>Timeout scaricamento icona sito web in secondi</translation>
    </message>
    <message>
        <source> sec</source>
        <comment>Seconds</comment>
        <translation> sec</translation>
    </message>
    <message>
        <source>User Interface</source>
        <translation>Interfaccia utente</translation>
    </message>
    <message>
        <source>Toolbar button style</source>
        <translation>Stile pulsante barra degli strumenti</translation>
    </message>
    <message>
        <source>Movable toolbar</source>
        <translation>Barra degli strumenti spostabile</translation>
    </message>
    <message>
        <source>Language selection</source>
        <translation>Selezione della lingua</translation>
    </message>
    <message>
        <source>Language:</source>
        <translation>Lingua:</translation>
    </message>
    <message>
        <source>(restart program to activate)</source>
        <translation>(per attivare riavvia il programma)</translation>
    </message>
    <message>
        <source>Toolbar button style:</source>
        <translation>Stile pulsanti della barra degli strumenti:</translation>
    </message>
    <message>
        <source>Show passwords in color</source>
        <translation>Visualizza le password a colori</translation>
    </message>
    <message>
        <source>Use monospaced font for notes</source>
        <translation>Per le note usa una font a larghezza fissa</translation>
    </message>
    <message>
        <source>Minimize instead of app exit</source>
        <translation>Minimizza invece di uscire dall&apos;applicazione</translation>
    </message>
    <message>
        <source>Show a system tray icon</source>
        <translation>Visualizza un&apos;icona nell&apos;area di notifica di sistema</translation>
    </message>
    <message>
        <source>Tray icon type</source>
        <translation>Tipo di icona vassoio</translation>
    </message>
    <message>
        <source>Tray icon type:</source>
        <translation>Tipo di icona vassoio:</translation>
    </message>
    <message>
        <source>Hide window to system tray when minimized</source>
        <translation>Nascondi la finestra nell&apos;area di notifica di sistema quando viene minimizzata</translation>
    </message>
    <message>
        <source>Reset settings to default…</source>
        <translation>Ripristina impostazioni predefinite...</translation>
    </message>
    <message>
        <source>Auto-Type</source>
        <translation>Completamento automatico</translation>
    </message>
    <message>
        <source>Use entry title to match windows for global Auto-Type</source>
        <translation>Per il completamento automatico globale per la corrispondenza con le finestre usa il titolo della voce</translation>
    </message>
    <message>
        <source>Use entry URL to match windows for global Auto-Type</source>
        <translation>Per il completamento automatico globale per la corrispondenza con le finestre usa URL della voce</translation>
    </message>
    <message>
        <source>Always ask before performing Auto-Type</source>
        <translation>Chiedi sempre prima di effettuare il completamento automatico</translation>
    </message>
    <message>
        <source>Hide expired entries from Auto-Type</source>
        <translation>Nascondi le voci scadute dalla digitazione automatica</translation>
    </message>
    <message>
        <source>Re-lock previously locked database after performing Auto-Type</source>
        <translation>Blocca nuovamente un database precedentemente bloccato dopo aver completato l&apos;Auto-Type</translation>
    </message>
    <message>
        <source>Auto-Type start delay:</source>
        <translation>Ritardo avvio auto-completamento:</translation>
    </message>
    <message>
        <source>Global Auto-Type shortcut:</source>
        <translation>Scorciatoia globale completamento automatico:</translation>
    </message>
    <message>
        <source>Auto-type start delay milliseconds</source>
        <translation>Ritardo di avvio in millisecondi dell completamento automatico</translation>
    </message>
    <message>
        <source> ms</source>
        <comment>Milliseconds</comment>
        <translation> ms</translation>
    </message>
    <message>
        <source>Auto-Type typing delay:</source>
        <translation>Ritardo completamento automatico:</translation>
    </message>
    <message>
        <source>Global auto-type shortcut</source>
        <translation>Scorciatoia globale completamento automatico</translation>
    </message>
    <message>
        <source>Auto-type character typing delay milliseconds</source>
        <translation>Ritardo in millisecondi del completamento automatico dei caratteri</translation>
    </message>
    <message>
        <source>Remember last typed entry for:</source>
        <translation>Ricorda l&apos;ultima voce digitata per:</translation>
    </message>
    <message>
        <source>On database unlock, show entries that will expire within</source>
        <translation>Allo sblocco del database, visualizza le voci che scadranno entro</translation>
    </message>
    <message>
        <source>On database unlock, show entries that will expire within </source>
        <translation>Allo sblocco del database, visualizza le voci che scadranno entro </translation>
    </message>
    <message>
        <source> days</source>
        <comment>number of days warning for password expiration</comment>
        <translation> Giorni</translation>
    </message>
    <message>
        <source>Destination format:</source>
        <translation>Formato destinazione:</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;{DB_FILENAME}&lt;/span&gt; is replaced with the filename of the saved database without extension&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;{TIME:&amp;lt;format&amp;gt;}&lt;/span&gt; is replaced with the specified time format (default: dd_MM_yyyy_hh-mm-ss)&lt;/p&gt;&lt;p&gt;See the User Guide for more details&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;{DB_FILENAME}&lt;/span&gt;verrà sostituito con il nome del file del database salvato senza estensione&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;{TIME:&amp;lt;format&amp;gt;}&lt;/span&gt; verrà sostituito con il formato orario specificato (predefinito: gg_MM_aaaa_oo-mm-ss)&lt;/p&gt;&lt;p&gt;Per maggiori dettagli consulta la Guida utente &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Choose folder...</source>
        <translation>Scegli cartella...</translation>
    </message>
    <message>
        <source>Show confirmation before moving entries to recycle bin</source>
        <translation>Visualizza la conferma prima di spostare le voci nel cestino</translation>
    </message>
    <message>
        <source>Copy data on double clicking field in entry view</source>
        <translation>Copia i dati facendo doppio clic sul campo nella vista della voce</translation>
    </message>
    <message>
        <source>Show toolbar</source>
        <translation>Visualizza barra strumenti</translation>
    </message>
    <message>
        <source>Show the menu bar by pressing the Alt key</source>
        <translation>Visualizza la barra dei menu premendo il tasto Alt</translation>
    </message>
    <message>
        <source>Show menubar</source>
        <translation>Visualizza barra menu</translation>
    </message>
    <message>
        <source>Import settings…</source>
        <translation>Importa impostazioni...</translation>
    </message>
    <message>
        <source>Export settings…</source>
        <translation>Esporta impostazioni...</translation>
    </message>
    <message>
        <source>Font size:</source>
        <translation>Dimensione font:</translation>
    </message>
    <message>
        <source>Font size selection</source>
        <translation>Selezione dimensione font</translation>
    </message>
    <message>
        <source>Skip confirmation for main window Auto-Type actions</source>
        <translation>Salta conferma per il completamento automatico nella finestra principale</translation>
    </message>
    <message>
        <source>Double-click action for URL:</source>
        <translation>Azione doppio clic per URL:</translation>
    </message>
    <message>
        <source>Double-click action for URL field</source>
        <translation>Azione doppio clic per campo URL</translation>
    </message>
    <message>
        <source>Edit entry</source>
        <translation>Modifica voce</translation>
    </message>
    <message>
        <source>Open entry URL in browser</source>
        <translation>Apri l&apos;URL voce nel browser</translation>
    </message>
    <message>
        <source>Copy entry URL to clipboard</source>
        <translation>Copia l&apos;URL voce negli appunti</translation>
    </message>
    <message>
        <source>Auto-generate password for new entries</source>
        <translation>Genera automaticamente password per le nuove voci</translation>
    </message>
    <message>
        <source>Keep remote desktop connection open after performing Auto-Type</source>
        <translation>Dopo aver eseguito il completamento automatico mantieni aperta la connessione desktop remoto</translation>
    </message>
    <message>
        <source>Remote desktop mode:</source>
        <translation>Modalità desktop remoto:</translation>
    </message>
    <message>
        <source>Never remember session</source>
        <translation>Non salvare mai la sessione</translation>
    </message>
    <message>
        <source>Remember session until exit</source>
        <translation>Salva la sessione fino all&apos;uscita</translation>
    </message>
    <message>
        <source>Remember session until revoked by desktop</source>
        <translation>Salva la sessione finché non viene revocata dal desktop</translation>
    </message>
    <message>
        <source>None</source>
        <translation>Nessuno</translation>
    </message>
    <message>
        <source>Configure...</source>
        <translation>Configura...</translation>
    </message>
    <message>
        <source>Use remote desktop for clipboard access</source>
        <translation>Per l&apos;accesso agli appunti usa desktop remoto</translation>
    </message>
    <message>
        <source>Experimental: Prefer desktop portals (Wayland implementation)</source>
        <translation>Sperimentale: preferisci i portali desktop (implementazione Wayland)</translation>
    </message>
    <message>
        <source>Show autocomplete suggestions for username and additional attributes</source>
        <translation>Visualizza i suggerimenti di completamento automatico per il nome utente e gli attributi aggiuntivi</translation>
    </message>
</context>
<context>
    <name>ApplicationSettingsWidgetSecurity</name>
    <message>
        <source>Timeouts</source>
        <translation>Timeout</translation>
    </message>
    <message>
        <source>Database lock timeout seconds</source>
        <translation>Secondi timeout blocco database</translation>
    </message>
    <message>
        <source> sec</source>
        <comment>Seconds</comment>
        <translation> sec</translation>
    </message>
    <message>
        <source>Clear clipboard after</source>
        <translation>Svuota gli appunti dopo</translation>
    </message>
    <message>
        <source>Clear search query after</source>
        <translation>Cancella query di ricerca dopo</translation>
    </message>
    <message>
        <source> min</source>
        <comment>Minutes</comment>
        <translation> min</translation>
    </message>
    <message>
        <source>Clipboard clear seconds</source>
        <translation>Secondi cancellazione appunti</translation>
    </message>
    <message>
        <source>Lock databases after inactivity of</source>
        <translation>Blocca i database dopo un&apos;inattività di</translation>
    </message>
    <message>
        <source>Convenience</source>
        <translation>Comodità</translation>
    </message>
    <message>
        <source>Enable database quick unlock (Touch ID / Windows Hello)</source>
        <translation>Abilita lo sblocco rapido del database (Touch ID / Windows Hello)</translation>
    </message>
    <message>
        <source>Lock databases when session is locked or lid is closed</source>
        <translation>Blocca i database quando la sessione è bloccata o il coperchio è chiuso</translation>
    </message>
    <message>
        <source>Lock databases after minimizing the window</source>
        <translation>Blocca il database dopo la minimizzazione della finestra</translation>
    </message>
    <message>
        <source>Hide passwords when editing them</source>
        <translation>Nascondi la password quando viene modificata</translation>
    </message>
    <message>
        <source>Use placeholder for empty password fields</source>
        <translation>Usa segnaposti per campi password vuoti</translation>
    </message>
    <message>
        <source>Hide passwords in the entry preview panel</source>
        <translation>Nascondi la password nel pannello di anteprima della voce</translation>
    </message>
    <message>
        <source>Privacy</source>
        <translation>Riservatezza</translation>
    </message>
    <message>
        <source>Use DuckDuckGo service to download website icons</source>
        <translation>Usa il servizio DuckDuckGo per scaricare le icone dei siti</translation>
    </message>
    <message>
        <source>Hide TOTP in the entry preview panel</source>
        <translation>Nascondi TOTP nel pannello di anteprima della voce</translation>
    </message>
    <message>
        <source>Lock databases when switching user</source>
        <translation>Quando si cambia utente blocca il database</translation>
    </message>
    <message>
        <source>Lock Options</source>
        <translation>Opzioni di blocco</translation>
    </message>
    <message>
        <source>Hide notes in the entry preview panel</source>
        <translation>Nascondi le note nel pannello di anteprima della voce</translation>
    </message>
</context>
<context>
    <name>AttachmentWidget</name>
    <message>
        <source>Attachment Viewer</source>
        <translation>Visualizzatore allegati</translation>
    </message>
    <message>
        <source>Unknown attachment type</source>
        <translation>Tipo di allegato sconosciuto</translation>
    </message>
</context>
<context>
    <name>AutoType</name>
    <message>
        <source>The requested Auto-Type sequence cannot be used due to an error:</source>
        <translation>Impossibile usare la sequenza automatica richiesta a causa di un errore:</translation>
    </message>
    <message>
        <source>Auto-Type Error</source>
        <translation>Errore di digitazione automatica</translation>
    </message>
    <message>
        <source>Permission Required</source>
        <translation>Permesso richiesto</translation>
    </message>
    <message>
        <source>KeePassXC requires the Accessibility permission in order to perform entry level Auto-Type. If you already granted permission, you may have to restart KeePassXC.</source>
        <translation>Per effettuare il completamento automatico di livello base KeePassXC richiede il permesso di Accessibilità. 
Se hai già concesso il permesso, riavvia KeePassXC.</translation>
    </message>
    <message>
        <source>KeePassXC requires the Accessibility and Screen Recorder permission in order to perform global Auto-Type. Screen Recording is necessary to use the window title to find entries. If you already granted permission, you may have to restart KeePassXC.</source>
        <translation>Per effettuare il completamento automatico globale KeePassXC richiede il permesso di Accessibilità e di Registrazione Schermo. Per usare il titolo della finestra al fine di trovare le voci corrispondenti è necessaria la registrazione dello schermo. Se hai già concesso il permesso, riavvia KeePassXC.</translation>
    </message>
    <message>
        <source>Invalid entry provided</source>
        <translation>Fornita voce non valida</translation>
    </message>
    <message>
        <source>Bracket imbalance detected, found extra { or }</source>
        <translation>Rilevato squilibrio tra parentesi quadre, trovato { o } di troppo</translation>
    </message>
    <message>
        <source>Too many repetitions detected, max is %1: %2</source>
        <translation>Troppe ripetizioni rilevate, max è %1: %2</translation>
    </message>
    <message>
        <source>Very slow key press detected, max is %1: %2</source>
        <translation>Rilevata pressione tasto molto lenta, max è %1: %2</translation>
    </message>
    <message>
        <source>Very long delay detected, max is %1: %2</source>
        <translation>Ritardo molto lungo rilevato, max è %1: %2</translation>
    </message>
    <message>
        <source>Entry does not have attribute for PICKCHARS: %1</source>
        <translation>La voce non ha l&apos;attributo per PICKCHARS: %1</translation>
    </message>
    <message>
        <source>Invalid placeholder: %1</source>
        <translation>Segnaposto non valido: %1</translation>
    </message>
    <message>
        <source>Entry has invalid TOTP settings</source>
        <translation>La voce ha impostazioni TOTP non valide</translation>
    </message>
</context>
<context>
    <name>AutoTypeAssociationsModel</name>
    <message>
        <source>Window</source>
        <translation>Finestra</translation>
    </message>
    <message>
        <source>Sequence</source>
        <translation>Sequenza</translation>
    </message>
    <message>
        <source>(empty)</source>
        <translation>(vuoto)</translation>
    </message>
    <message>
        <source>Default sequence</source>
        <translation>Sequenza predefinita</translation>
    </message>
</context>
<context>
    <name>AutoTypeMatchModel</name>
    <message>
        <source>Group</source>
        <translation>Gruppo</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>Titolo</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>Nome utente</translation>
    </message>
    <message>
        <source>Sequence</source>
        <translation>Sequenza</translation>
    </message>
</context>
<context>
    <name>AutoTypePlatformWayland</name>
    <message>
        <source>No symbol found for key: &apos;%1&apos;</source>
        <translation>Nessun simbolo trovato per il tasto: &apos;%1&apos;</translation>
    </message>
    <message>
        <source>No symbol found for character: &apos;%1&apos;</source>
        <translation>Nessun simbolo trovato per il carattere: &apos;%1&apos;</translation>
    </message>
</context>
<context>
    <name>AutoTypePlatformX11</name>
    <message>
        <source>Sequence aborted: Caps Lock is on</source>
        <translation>Sequenza interrotta: blocco MAIUSCOLO attivo</translation>
    </message>
    <message>
        <source>Sequence aborted: Modifier keys held by user</source>
        <translation>Sequenza interrotta: tasti di modifica ritenuti dall&apos;utente</translation>
    </message>
    <message>
        <source>Unable to get valid keycode for key: </source>
        <translation>Impossibile ottenere un codice chiave valido per la chiave: </translation>
    </message>
    <message>
        <source>Trying to send invalid keyboard symbol.</source>
        <translation>Tentativo di invio di un simbolo non valido.</translation>
    </message>
</context>
<context>
    <name>AutoTypeSelectDialog</name>
    <message>
        <source>Auto-Type - KeePassXC</source>
        <translation>KeePassXC - Completamento automatico</translation>
    </message>
    <message>
        <source>Double click a row to perform Auto-Type or find an entry using the search:</source>
        <translation>Doppio clic su una riga per eseguire la digitazione automatica o trovare una voce usando la ricerca:</translation>
    </message>
    <message>
        <source>Search all open databases</source>
        <translation>Cerca in tutti i database aperti</translation>
    </message>
    <message>
        <source>Search…</source>
        <translation>Cerca…</translation>
    </message>
    <message>
        <source>Type Sequence</source>
        <translation>Digita la sequenza</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Annulla</translation>
    </message>
    <message>
        <source>Type {USERNAME}</source>
        <translation>Digita {USERNAME}</translation>
    </message>
    <message>
        <source>Type {PASSWORD}</source>
        <translation>Digita {PASSWORD}</translation>
    </message>
    <message>
        <source>Type {TOTP}</source>
        <translation>Digita {TOTP}</translation>
    </message>
    <message>
        <source>Copy Username</source>
        <translation>Copia nome utente</translation>
    </message>
    <message>
        <source>Copy Password</source>
        <translation>Copia password</translation>
    </message>
    <message>
        <source>Copy TOTP</source>
        <translation>Copia TOTP</translation>
    </message>
    <message>
        <source>Use Virtual Keyboard</source>
        <translation>Usa tastiera virtuale</translation>
    </message>
    <message>
        <source>Type {URL}</source>
        <translation>Digita {URL}</translation>
    </message>
    <message>
        <source>Copy URL</source>
        <translation>Copia URL</translation>
    </message>
    <message>
        <source>&lt;p&gt;The following shortcuts are available:&lt;br/&gt;
Ctrl+F - Focus search&lt;br/&gt;
Ctrl+1 - Type username&lt;br/&gt;
Ctrl+2 - Type password&lt;br/&gt;
Ctrl+3 - Type TOTP&lt;br/&gt;
Ctrl+4 - Type URL&lt;br/&gt;
Ctrl+5 - Use Virtual Keyboard (Windows Only)&lt;br/&gt;
Ctrl+Shift+1 - Copy username&lt;br/&gt;
Ctrl+Shift+2 - Copy password&lt;br/&gt;
Ctrl+Shift+3 - Copy TOTP&lt;br/&gt;
Ctrl+Shift+4 - Copy URL&lt;br/&gt;
&lt;/p&gt;</source>
        <translation>&lt;p&gt;Sono disponibili le seguenti scorciatoie:&lt;br/&gt;Ctrl+F - Attiva ricerca&lt;br/&gt;Ctrl+1 - Digita nome utente&lt;br/&gt;Ctrl+2 - Digita password&lt;br/&gt;Ctrl+3 - Digita TOTP&lt;br/&gt;Ctrl+4 - Digita URL&lt;br/&gt;Ctrl+5 - Usa tastiera virtuale (Solo Windows)&lt;br/&gt;Ctrl+Shift+1 - Copia nome utente&lt;br/&gt;Ctrl+Shift+2 - Copia password&lt;br/&gt;Ctrl+Shift+3 - Copia TOTP&lt;br/&gt;Ctrl+Shift+4 - Copia URL&lt;br/&gt;&lt;/p&gt;</translation>
    </message>
    <message>
        <source>You can use advanced search queries to find any entry in your open databases.</source>
        <translation>Per individuare qualsiasi voce nei database aperti puoi usare query di ricerca avanzate.</translation>
    </message>
</context>
<context>
    <name>BinaryStream</name>
    <message>
        <source>Failed to read string data: %1</source>
        <translation>Impossibile leggere i dati della stringa: %1</translation>
    </message>
    <message>
        <source>String length exceeds 10 MiB limit (requested %1)</source>
        <translation>La lunghezza della stringa supera il limite di 10 MiB (richiesto %1)</translation>
    </message>
</context>
<context>
    <name>BrowserAccessControlDialog</name>
    <message>
        <source>KeePassXC - Browser Access Request</source>
        <translation>Richiesta di accesso KeePassXC - Browser</translation>
    </message>
    <message>
        <source>%1 is requesting access to the following entries:</source>
        <translation>%1 sta chiedendo l&apos;accesso alle seguenti voci:</translation>
    </message>
    <message>
        <source>Remember access to checked entries</source>
        <translation>Ricorda le impostazioni di accesso per le voci selezionate</translation>
    </message>
    <message>
        <source>Remember</source>
        <translation>Ricorda</translation>
    </message>
    <message>
        <source>Allow access to entries</source>
        <translation>Permetti di accedere alle voci</translation>
    </message>
    <message>
        <source>Allow Selected</source>
        <translation>Consenti selezionati</translation>
    </message>
    <message>
        <source>Deny All</source>
        <translation>Nega tutto</translation>
    </message>
    <message>
        <source>Disable for this site</source>
        <translation>Disabilita per questo sito</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation>Annulla azione</translation>
    </message>
</context>
<context>
    <name>BrowserEntrySaveDialog</name>
    <message>
        <source>Ok</source>
        <translation>Ok</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Annulla</translation>
    </message>
    <message>
        <source>You have multiple databases open.
Please select the correct database for saving credentials.</source>
        <translation>C&apos;è più di un database aperto. 
Seleziona il database corretto dove salvare le credenziali.</translation>
    </message>
    <message>
        <source>KeePassXC - Select Database</source>
        <translation>KeePassXC - Selezione database</translation>
    </message>
</context>
<context>
    <name>BrowserPasskeysConfirmationDialog</name>
    <message>
        <source>Cancel</source>
        <translation>Annulla</translation>
    </message>
    <message>
        <source>Update</source>
        <translation>Aggiorna</translation>
    </message>
    <message>
        <source>Authenticate</source>
        <translation>Autentica</translation>
    </message>
    <message>
        <source>Register new</source>
        <translation>Registra nuovo</translation>
    </message>
    <message>
        <source>Register</source>
        <translation>Registra</translation>
    </message>
    <message numerus="yes">
        <source>Timeout in &lt;b&gt;%n&lt;/b&gt; seconds...</source>
        <translation><numerusform>Timeout in &lt;b&gt;%n&lt;/b&gt; secondo…</numerusform><numerusform>Timeout in &lt;b&gt;%n&lt;/b&gt; secondi…</numerusform><numerusform>Timeout in &lt;b&gt;%n&lt;/b&gt; secondi...</numerusform></translation>
    </message>
    <message>
        <source>Relying Party: %1</source>
        <translation>Relying party: %1</translation>
    </message>
    <message>
        <source>Username: %1</source>
        <translation>Nome utente: %1</translation>
    </message>
    <message>
        <source>KeePassXC - Passkey credentials</source>
        <translation>KeePassXC - Credenziali passkey</translation>
    </message>
    <message>
        <source>Add to existing entry</source>
        <translation>Aggiungi a voce esistente</translation>
    </message>
    <message>
        <source>Existing passkey found.
Do you want to register a new passkey for:</source>
        <translation>Trovata una passkey esistente.
Vuoi registrare una nuova passkey per:</translation>
    </message>
    <message>
        <source>Select the existing passkey and press Update to replace it.</source>
        <translation>Seleziona la passkey esistente e Aggiorna per sostituirla.</translation>
    </message>
    <message>
        <source>Authenticate passkey credentials for:</source>
        <translation>Autentica credenziali passkey per:</translation>
    </message>
    <message>
        <source>Do you want to register a passkey for:</source>
        <translation>Vuoi registrare una passkey per:</translation>
    </message>
</context>
<context>
    <name>BrowserService</name>
    <message>
        <source>A request for creating a new group &quot;%1&quot; has been received.
Do you want to create this group?
</source>
        <translation>È stata ricevuta una richiesta di creazione di un nuovo gruppo &quot;%1&quot;.
Vuoi creare questo gruppo?
</translation>
    </message>
    <message>
        <source>You have received an association request for the following database:
%1

Give the connection a unique name or ID, for example:
chrome-laptop.</source>
        <translation>Hai ricevuto una richiesta di associazione per il seguente database:
%1

Assegnagli un nome univoco o un ID, per esempio:
laptop-chrome.</translation>
    </message>
    <message>
        <source>Save and allow access</source>
        <translation>Salva e permetti l&apos;accesso</translation>
    </message>
    <message>
        <source>A shared encryption key with the name &quot;%1&quot; already exists.
Do you want to overwrite it?</source>
        <translation>Esiste già una chiave di cifratura condivisa con il nome &quot;%1&quot;- Vuoi sovrascriverla?</translation>
    </message>
    <message>
        <source>Do you want to update the information in %1 - %2?</source>
        <translation>Vuoi aggiornare le informazioni in %1 - %2?</translation>
    </message>
    <message>
        <source>A request for deleting entry &quot;%1&quot; has been received.
Do you want to delete the entry?
</source>
        <translation>Una richiesta di eliminazione della voce &quot;%1&quot; è stato ricevuta.
Vuoi eliminare questa voce?
</translation>
    </message>
    <message>
        <source>%1 (Passkey)</source>
        <translation>%1 (passkey)</translation>
    </message>
    <message>
        <source>KeePassXC - Create a new group</source>
        <translation>KeePassXC - Crea un nuovo gruppo</translation>
    </message>
    <message>
        <source>Disable</source>
        <translation>Disabilita</translation>
    </message>
    <message>
        <source>KeePassXC - Overwrite existing key?</source>
        <translation>KeePassXC - Vuoi sovrascrivere la chiave esistente?</translation>
    </message>
    <message>
        <source>KeePassXC - Update Entry</source>
        <translation>KeePassXC - Aggiorna voce</translation>
    </message>
    <message>
        <source>KeePassXC - Delete entry</source>
        <translation>KeePassXC - Elimina voce</translation>
    </message>
    <message>
        <source>KeePassXC - New key association request</source>
        <translation>KeePassXC - Richiesta nuova associazione chiave</translation>
    </message>
    <message>
        <source>Passkey</source>
        <translation>Passkey</translation>
    </message>
    <message>
        <source>KeePassXC - Passkey credentials</source>
        <translation>KeePassXC - Credenziali passkey</translation>
    </message>
    <message>
        <source>Register a new passkey to this entry:</source>
        <translation>Registra una nuova passkey per questa voce:</translation>
    </message>
    <message>
        <source>KeePassXC - Update passkey</source>
        <translation>KeePassXC - Aggiorna passkey</translation>
    </message>
    <message>
        <source>Entry already has a passkey.
Do you want to overwrite the passkey in %1 - %2?</source>
        <translation>La voce possiede già una passkey.
Vuoi sovrascrivere la passkey in %1 - %2?</translation>
    </message>
    <message>
        <source>Register</source>
        <translation>Registra</translation>
    </message>
</context>
<context>
    <name>BrowserSettingsWidget</name>
    <message>
        <source>Dialog</source>
        <translation>Finestra</translation>
    </message>
    <message>
        <source>This is required for accessing your databases with KeePassXC-Browser</source>
        <translation>Questo è necessario per accedere al database con KeePassXC-Browser</translation>
    </message>
    <message>
        <source>Enable browser integration</source>
        <translation>Abilita l&apos;integrazione del browser</translation>
    </message>
    <message>
        <source>General</source>
        <translation>Generale</translation>
    </message>
    <message>
        <source>Enable integration for these browsers:</source>
        <translation>Abilita integrazione per i seguenti browser:</translation>
    </message>
    <message>
        <source>Vivaldi</source>
        <translation>Vivaldi</translation>
    </message>
    <message>
        <source>&amp;Edge</source>
        <translation>&amp;Edge</translation>
    </message>
    <message>
        <source>Firefox</source>
        <translation>Firefox</translation>
    </message>
    <message>
        <source>Tor Browser</source>
        <translation>Tor Browser</translation>
    </message>
    <message>
        <source>Brave</source>
        <translation>Brave</translation>
    </message>
    <message>
        <source>Google Chrome</source>
        <translation>Google Chrome</translation>
    </message>
    <message>
        <source>Chromium</source>
        <translation>Chromium</translation>
    </message>
    <message>
        <source>Show a notification when credentials are requested</source>
        <extracomment>Credentials mean login data requested via browser extension</extracomment>
        <translation>Visualizza una notifica quando le credenziali sono richieste</translation>
    </message>
    <message>
        <source>Request to unlock the database if it is locked</source>
        <translation>Richiedi di sbloccare il database se è bloccato</translation>
    </message>
    <message>
        <source>Only entries with the same scheme (http://, https://, …) are returned.</source>
        <translation>Vengono restituite solo le voci con lo stesso http:// (https://, https://, ...).</translation>
    </message>
    <message>
        <source>Match URL scheme (e.g., https://example.com)</source>
        <translation>Corrispondenza dello schema URL (ad es., https://esempio.com)</translation>
    </message>
    <message>
        <source>Only returns the best matches for a specific URL instead of all entries for the whole domain.</source>
        <translation>Restituisci solo le corrispondenze migliori per una URL specifica invece di tutte le voci per l&apos;intero dominio.</translation>
    </message>
    <message>
        <source>Return only best-matching credentials</source>
        <translation>Restituisci solo le credenziali che corrispondono maggiormente</translation>
    </message>
    <message>
        <source>Returns expired credentials. String [expired] is added to the title.</source>
        <translation>Restituisce le credenziali scadute. La stringa [scaduto] viene aggiunta al titolo.</translation>
    </message>
    <message>
        <source>Allow returning expired credentials</source>
        <translation>Restituisci le credenziali scadute</translation>
    </message>
    <message>
        <source>All databases connected to the extension will return matching credentials.</source>
        <translation>Tutti i database connessi all&apos;estensione restituiranno le credenziali corrispondenti.</translation>
    </message>
    <message>
        <source>Search in all opened databases for matching credentials</source>
        <extracomment>Credentials mean login data requested via browser extension</extracomment>
        <translation>Cerca le credenziali corrispondenti in tutti i database aperti</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>Avanzate</translation>
    </message>
    <message>
        <source>Never ask before accessing credentials</source>
        <extracomment>Credentials mean login data requested via browser extension</extracomment>
        <translation>Non chiedere conferma prima di accedere alle credenziali</translation>
    </message>
    <message>
        <source>Never ask before updating credentials</source>
        <extracomment>Credentials mean login data requested via browser extension</extracomment>
        <translation>Non chiedere conferma prima di aggiornare le credenziali</translation>
    </message>
    <message>
        <source>Do not ask permission for HTTP Basic Auth</source>
        <extracomment>An extra HTTP Basic Auth setting</extracomment>
        <translation>Non chiedere l&apos;autorizzazione per l&apos;autenticazione semplice HTTP</translation>
    </message>
    <message>
        <source>Automatically creating or updating string fields is not supported.</source>
        <translation>La creazione o l&apos;aggiornamento automatico dei campi stringa non è supportato.</translation>
    </message>
    <message>
        <source>Return advanced string fields which start with &quot;KPH: &quot;</source>
        <translation>Restituisci campi di stringa avanzati che iniziano per &quot;KPH:&quot;</translation>
    </message>
    <message>
        <source>Don&apos;t display the popup suggesting migration of legacy KeePassHTTP settings.</source>
        <translation>Non visualizzare la finestra a comparsa che suggerisce la migrazione delle impostazioni KeePassHTTP obsolete.</translation>
    </message>
    <message>
        <source>Do not prompt for KeePassHTTP settings migration.</source>
        <translation>Non richiedere la migrazione delle impostazioni KeePassHTTP.</translation>
    </message>
    <message>
        <source>Updates KeePassXC or keepassxc-proxy binary path automatically to native messaging scripts on startup.</source>
        <translation>Aggiorna automaticamente all&apos;avvio il percorso dei binari di KeePassXC o keepassxc-proxy per gli script di messaggistica nativa.</translation>
    </message>
    <message>
        <source>Update native messaging manifest files at startup</source>
        <translation>Aggiorna all&apos;avvio il manifesto della messaggeria nativa</translation>
    </message>
    <message>
        <source>Use a custom proxy location if you installed a proxy manually.</source>
        <translation>Usa un indirizzo proxy personalizzato se hai installato manualmente un proxy.</translation>
    </message>
    <message>
        <source>Use a custom proxy location:</source>
        <comment>Meant is the proxy for KeePassXC-Browser</comment>
        <translation>Usa un proxy personalizzato:</translation>
    </message>
    <message>
        <source>Custom proxy location field</source>
        <translation>Campo percorso proxy personalizzato</translation>
    </message>
    <message>
        <source>Browser for custom proxy file</source>
        <translation>Browser per file proxy personalizzato</translation>
    </message>
    <message>
        <source>Browse…</source>
        <extracomment>Button for opening file dialog</extracomment>
        <translation>Sfoglia…</translation>
    </message>
    <message>
        <source>Use a custom browser configuration location:</source>
        <translation>Usa percorso personalizzato configurazione browser:</translation>
    </message>
    <message>
        <source>Browser type:</source>
        <translation>Tipologia di browser:</translation>
    </message>
    <message>
        <source>Toolbar button style</source>
        <translation>Stile pulsante barra strumenti</translation>
    </message>
    <message>
        <source>Config Location:</source>
        <translation>Percorso di configurazione:</translation>
    </message>
    <message>
        <source>Custom browser location field</source>
        <translation>Campo percorso browser personalizzato</translation>
    </message>
    <message>
        <source>Browse for custom browser path</source>
        <translation>Seleziona percorso personalizzato browser</translation>
    </message>
    <message>
        <source>Custom extension ID:</source>
        <translation>ID estensione personalizzata:</translation>
    </message>
    <message>
        <source>Custom extension ID</source>
        <translation>ID estensione personalizzata</translation>
    </message>
    <message>
        <source>Executable Files</source>
        <translation>File eseguibili</translation>
    </message>
    <message>
        <source>All Files</source>
        <translation>Tutti i file</translation>
    </message>
    <message>
        <source>Select custom proxy location</source>
        <translation>Seleziona una posizione personalizzata per il proxy</translation>
    </message>
    <message>
        <source>Select native messaging host folder location</source>
        <translation>Seleziona il percorso per la cartella principale della messaggistica</translation>
    </message>
    <message>
        <source>Allow keepassxc-proxy to list all entries with their title, URL and UUID in connected databases.</source>
        <translation>Consenti a keepassxc-proxy di elencare tutte le voci con il loro titolo, URL e UUID nei database collegati.</translation>
    </message>
    <message>
        <source>Allow limited access to all entries in connected databases (ignores site access restrictions)</source>
        <translation>Consenti accesso limitato a tutte le voci nei database connessi (ignora le restrizioni di accesso al sito)</translation>
    </message>
    <message>
        <source>&lt;b&gt;Warning:&lt;/b&gt; Only adjust these settings if necessary.</source>
        <translation>&lt;b&gt;Avviso:&lt;/b&gt; modifica queste impostazioni solo se necessario.</translation>
    </message>
    <message>
        <source>The custom proxy location does not exist.</source>
        <translation>Il percorso proxy personalizzato non esiste.</translation>
    </message>
    <message>
        <source>&lt;b&gt;Error:&lt;/b&gt; The custom proxy location does not exist. Correct this in the advanced settings tab.</source>
        <translation>&lt;b&gt;Errore:&lt;/b&gt; Il percorso proxy personalizzato non esiste. Correggi questo problema nella scheda Impostazioni avanzate.</translation>
    </message>
    <message>
        <source>&lt;b&gt;Error:&lt;/b&gt; The installed proxy executable is missing from the expected location: %1&lt;br/&gt;Please set a custom proxy location in the advanced settings or reinstall the application.</source>
        <translation>&lt;b&gt;Errore:&lt;/b&gt; L&apos;eseguibile proxy installato non è presente nel percorso previsto: %1&lt;br/&gt;Imposta una posizione proxy personalizzata nelle impostazioni avanzate o reinstallare l&apos;applicazione.</translation>
    </message>
    <message>
        <source>Allows using insecure http://localhost with passkeys for testing purposes.</source>
        <translation>Per fini di test permetti di usare http://localhost (insicuro) con le passkeys.</translation>
    </message>
    <message>
        <source>Allow using localhost with passkeys</source>
        <translation>Permetti di usare localhost con le passkeys</translation>
    </message>
    <message>
        <source>KeePassXC-Browser is needed for the browser integration to work. &lt;br /&gt;Download it for %1 and %2 and %3.</source>
        <translation>Affinché l&apos;integrazione del browser funzioni  necessario KeePassXC-Browser. &lt;br /&gt;Scaricalo per %1 e %2 e %3.</translation>
    </message>
    <message>
        <source>Browsers installed using Snap or Flatpak are not supported with exception to Firefox installed using Snap.</source>
        <translation>I browser installati tramite Snap o Flatpak non sono supportati, ad eccezione di Firefox installato tramite Snap.</translation>
    </message>
</context>
<context>
    <name>CloneDialog</name>
    <message>
        <source>Clone Entry Options</source>
        <translation>Opzioni voci clone</translation>
    </message>
    <message>
        <source>Append &apos; - Clone&apos; to title</source>
        <translation>Aggiungi &apos; - Clone&apos; al titolo</translation>
    </message>
    <message>
        <source>Replace username and password with references</source>
        <translation>Sostituisci nome utente e password con riferimenti</translation>
    </message>
    <message>
        <source>Copy history</source>
        <translation>Copia cronologia</translation>
    </message>
</context>
<context>
    <name>CsvImportWidget</name>
    <message>
        <source>size, rows, columns</source>
        <translation>dimensione, righe, colonne</translation>
    </message>
    <message>
        <source>Column Association</source>
        <translation>Associazione colonne</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Password</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>Nome utente</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>Titolo</translation>
    </message>
    <message>
        <source>Group</source>
        <translation>Gruppo</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>Notes</source>
        <translation>Note</translation>
    </message>
    <message>
        <source>TOTP</source>
        <translation>TOTP</translation>
    </message>
    <message>
        <source>Created</source>
        <translation>Creazione</translation>
    </message>
    <message>
        <source>Last Modified</source>
        <translation>Ultima modifica</translation>
    </message>
    <message>
        <source>Icon</source>
        <translation>Icona</translation>
    </message>
    <message>
        <source>Encoding</source>
        <translation>Codifica</translation>
    </message>
    <message>
        <source>Codec</source>
        <translation>Codec</translation>
    </message>
    <message>
        <source>Text is qualified by</source>
        <translation>Il testo è qualificato da</translation>
    </message>
    <message>
        <source>Text qualification</source>
        <translation>Qualifica del testo</translation>
    </message>
    <message>
        <source>Fields are separated by</source>
        <translation>I campi sono separati da</translation>
    </message>
    <message>
        <source>Field separation</source>
        <translation>Separazione dei campi</translation>
    </message>
    <message>
        <source>Comments start with</source>
        <translation>I commenti iniziano con</translation>
    </message>
    <message>
        <source>Header lines skipped</source>
        <translation>Righe di intestazione ignorate</translation>
    </message>
    <message>
        <source>Number of header lines to discard</source>
        <translation>Numero di righe di intestazione da eliminare</translation>
    </message>
    <message>
        <source>First line has field names</source>
        <translation>La prima riga ha nomi di campo</translation>
    </message>
    <message>
        <source>Consider &apos;\&apos; an escape character</source>
        <translation>Considera &apos;\&apos; un carattere escape</translation>
    </message>
    <message>
        <source>Preview</source>
        <translation>Anteprima</translation>
    </message>
    <message>
        <source>CSV import preview</source>
        <translation>Anteprima importazione CSV</translation>
    </message>
    <message>
        <source>Not Present</source>
        <translation>Non presente</translation>
    </message>
    <message>
        <source>Column %1</source>
        <translation>Colonna %1</translation>
    </message>
    <message numerus="yes">
        <source>[%n more message(s) skipped]</source>
        <translation><numerusform>[%n altro messaggio saltato]</numerusform><numerusform>[altri %n messaggi saltati]</numerusform><numerusform>[altri %n messaggi saltati]</numerusform></translation>
    </message>
    <message>
        <source>Failed to parse CSV file: %1</source>
        <translation>Impossibile analizzare il file CSV: %1</translation>
    </message>
    <message>
        <source>Imported from CSV file: %1</source>
        <translation>Importato da file CSV: %1</translation>
    </message>
    <message>
        <source>No Title Selected</source>
        <translation>Nessun titolo selezionato</translation>
    </message>
    <message>
        <source>No title column was selected, entries will be hard to tell apart.
Are you sure you want to import?</source>
        <translation>Non è stata selezionata alcuna colonna del titolo, le voci saranno difficili da distinguere.
Confermi di voler proseguire nell&apos;importazione?</translation>
    </message>
    <message>
        <source>Tags</source>
        <translation>Etichette</translation>
    </message>
</context>
<context>
    <name>CsvParserModel</name>
    <message numerus="yes">
        <source>%n row(s)</source>
        <comment>CSV row count</comment>
        <translation><numerusform>righe: %n</numerusform><numerusform>%n riga(e)</numerusform><numerusform>%n riga/e</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>%n column(s)</source>
        <comment>CSV column count</comment>
        <translation><numerusform>%n colonna</numerusform><numerusform>%n colonne</numerusform><numerusform>%n colonne</numerusform></translation>
    </message>
</context>
<context>
    <name>Database</name>
    <message>
        <source>Passwords</source>
        <comment>Root group name</comment>
        <translation>Password</translation>
    </message>
    <message>
        <source>File %1 does not exist.</source>
        <translation>File %1 non esiste.</translation>
    </message>
    <message>
        <source>Unable to open file %1.</source>
        <translation>Impossibile aprire il file &apos;%1&apos;.</translation>
    </message>
    <message>
        <source>Error while reading the database: %1</source>
        <translation>Errore durante la lettura del database: %1</translation>
    </message>
    <message>
        <source>Could not save, database does not point to a valid file.</source>
        <translation>Impossibile salvare, il database non punta a un file valido.</translation>
    </message>
    <message>
        <source>Database save is already in progress.</source>
        <translation>Salvataggio del database già avviato.</translation>
    </message>
    <message>
        <source>Could not save, database has not been initialized!</source>
        <translation>Impossibile salvare, il database non è stato inizializzato!</translation>
    </message>
    <message>
        <source>Database file has unmerged changes.</source>
        <translation>Il file database ha modifiche non unite.</translation>
    </message>
    <message>
        <source>%1
Backup database located at %2</source>
        <translation>%1
Database di backup che si trova in %2</translation>
    </message>
    <message>
        <source>Key not transformed. This is a bug, please report it to the developers.</source>
        <translation>Chiave non trasformata. Questo è un bug, segnalalo agli sviluppatori.</translation>
    </message>
    <message>
        <source>Recycle Bin</source>
        <translation>Cestino</translation>
    </message>
    <message>
        <source>Database file read error.</source>
        <translation>Errore di lettura del file database.</translation>
    </message>
    <message>
        <source>No file path was provided.</source>
        <translation>Non è stato fornito alcun percorso del file.</translation>
    </message>
</context>
<context>
    <name>DatabaseOpenDialog</name>
    <message>
        <source>Unlock Database - KeePassXC</source>
        <translation>Sblocca database - KeePassXC</translation>
    </message>
</context>
<context>
    <name>DatabaseOpenWidget</name>
    <message>
        <source>Unlock KeePassXC Database</source>
        <translation>Sblocca il database KeePassXC</translation>
    </message>
    <message>
        <source>Enter Password:</source>
        <translation>Inserisci password:</translation>
    </message>
    <message>
        <source>Password field</source>
        <translation>Campo password</translation>
    </message>
    <message>
        <source>Hardware key slot selection</source>
        <translation>Selezione degli slot dei tasti hardware</translation>
    </message>
    <message>
        <source>Key file to unlock the database</source>
        <translation>File chiave per sbloccare il database</translation>
    </message>
    <message>
        <source>Browse for key file</source>
        <translation>Seleziona file chiave</translation>
    </message>
    <message>
        <source>Browse…</source>
        <translation>Sfoglia…</translation>
    </message>
    <message>
        <source>Unlock Database</source>
        <translation>Sblocca database</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Annulla</translation>
    </message>
    <message>
        <source>Unlock</source>
        <translation>Sblocca</translation>
    </message>
    <message>
        <source>Please present or touch your YubiKey to continue…</source>
        <translation>Per continuare presenta o tocca la YubiKey ...</translation>
    </message>
    <message>
        <source>Database Version Mismatch</source>
        <translation>Versione database non corrispondente</translation>
    </message>
    <message>
        <source>The database you are trying to open was most likely
created by a newer version of KeePassXC.

You can try to open it anyway, but it may be incomplete
and saving any changes may incur data loss.

We recommend you update your KeePassXC installation.</source>
        <translation>Il database che stai cercando di aprire è stato molto probabilmente
creato da una versione più recente di KeePassXC.

Puoi provare ad aprirlo comunque, ma potrebbe essere incompleto
e il salvataggio di qualsiasi modifica può comportare una perdita di dati.

Ti consigliamo di aggiornare questa installazione di KeePassXC.</translation>
    </message>
    <message>
        <source>Open database anyway</source>
        <translation>Apri comunque il database</translation>
    </message>
    <message>
        <source>Database unlock canceled.</source>
        <translation>Sblocco del database annullato.</translation>
    </message>
    <message>
        <source>Unlock failed and no password given</source>
        <translation>Sblocco non riuscito e nessuna password specificata</translation>
    </message>
    <message>
        <source>Unlocking the database failed and you did not enter a password.
Do you want to retry with an &quot;empty&quot; password instead?

To prevent this error from appearing, you must go to &quot;Database Settings / Security&quot; and reset your password.</source>
        <translation>Sblocco del database non riuscito e non è stata immessa una password.
Vuoi riprovare con una password &quot;vuota&quot;?

Per evitare che questo errore venga visualizzato, è necessario andare alle &quot;Impostazioni database / Sicurezza&quot; e reimpostare la password.</translation>
    </message>
    <message>
        <source>Retry with empty password</source>
        <translation>Riprova con password vuota</translation>
    </message>
    <message>
        <source>Failed to open key file: %1</source>
        <translation>Impossibile aprire il file chiave: %1</translation>
    </message>
    <message>
        <source>Old key file format</source>
        <translation>Vecchio formato di file chiave</translation>
    </message>
    <message>
        <source>You are using an old key file format which KeePassXC may&lt;br&gt;stop supporting in the future.&lt;br&gt;&lt;br&gt;Please consider generating a new key file by going to:&lt;br&gt;&lt;strong&gt;Database &amp;gt; Database Security &amp;gt; Change Key File.&lt;/strong&gt;&lt;br&gt;</source>
        <translation>Stai usando un vecchio formato di file chiave che KeePassXC può&lt;br&gt;smettere di supportare in futuro.&lt;br&gt;&lt;br&gt;Prendi in considerazione la possibilità di generare un nuovo file chiave andando in:&lt;br&gt;&lt;strong&gt;Database &amp;gt; Sicurezza database &amp;gt; Modifica file chiave.&lt;/strong&gt;&lt;br&gt;</translation>
    </message>
    <message>
        <source>Don&apos;t show this warning again</source>
        <translation>Non visualizzare nuovamente questo avviso</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>Tutti i file</translation>
    </message>
    <message>
        <source>Key files</source>
        <translation>File chiave</translation>
    </message>
    <message>
        <source>Select key file</source>
        <translation>Seleziona file chiave</translation>
    </message>
    <message>
        <source>Cannot use database file as key file</source>
        <translation>Impossibile usare il file database come file chiave</translation>
    </message>
    <message>
        <source>authenticate to access the database</source>
        <translation>per accedere al database esegui l&apos;autenticazione </translation>
    </message>
    <message>
        <source>Failed to authenticate with Quick Unlock: %1</source>
        <translation>Autenticazione con sblocco rapido fallita: %1</translation>
    </message>
    <message>
        <source>Select Key File:</source>
        <translation>Seleziona il file chiave:</translation>
    </message>
    <message>
        <source>&lt;p&gt;In addition to a password, you can use a secret file to enhance the security of your database. This file can be generated in your database&apos;s security settings.&lt;/p&gt;&lt;p&gt;This is &lt;strong&gt;not&lt;/strong&gt; your *.kdbx database file!&lt;/p&gt;</source>
        <translation>&lt;p&gt;Oltre ad una password,  per migliorare la sicurezza del database puoi usare un file segreto. Questo file può essere generato nelle impostazioni di sicurezza del database.&lt;/p&gt;&lt;p&gt;Questo&lt;strong&gt;non&lt;/strong&gt;è il file database *.kdbx!&lt;/p&gt;</translation>
    </message>
    <message>
        <source>Use hardware key [Serial: %1]</source>
        <translation>Usa chiave hardware [seriale: %1]</translation>
    </message>
    <message>
        <source>Use hardware key</source>
        <translation>Usa chiave hardware</translation>
    </message>
    <message>
        <source>Your database file is NOT a key file!
If you don&apos;t have a key file or don&apos;t know what that is, you don&apos;t have to select one.</source>
        <translation>Il database non è un file chiave!
Se non hai un file chiave o non sai cosa sia, non selezionarlo.</translation>
    </message>
    <message>
        <source>KeePassXC database file selected</source>
        <translation>Database KeePassXC selezionato</translation>
    </message>
    <message>
        <source>The file you selected looks like a database file.
A database file is NOT a key file!

Are you sure you want to continue with this file?.</source>
        <translation>Il file selezionato sembra essere un file database.
Un file database NON è un file chiave.

Sei sicuro di voler continuare con questo file?</translation>
    </message>
    <message>
        <source>No hardware keys found.</source>
        <translation>Nessuna chiave hardware trovata.</translation>
    </message>
    <message>
        <source>Refresh Hardware Keys</source>
        <translation>Aggiorna chiavi hardware</translation>
    </message>
    <message>
        <source>Click to add a key file.</source>
        <translation>Clic per aggiungere un file chiave.</translation>
    </message>
    <message>
        <source>Hardware keys found, but no slots are configured.</source>
        <translation>Chiave hardware trovata, ma non è configurato nessuno slot.</translation>
    </message>
    <message>
        <source>Press ESC again to close this database</source>
        <translation>Premi nuovamente &apos;ESC&apos; per chiudere questo database</translation>
    </message>
    <message>
        <source>I have a key file</source>
        <translation>Ho un file chiave</translation>
    </message>
</context>
<context>
    <name>DatabaseSettingWidgetMetaData</name>
    <message>
        <source>Passwords</source>
        <translation>Password</translation>
    </message>
</context>
<context>
    <name>DatabaseSettingsDialog</name>
    <message>
        <source>General</source>
        <translation>Generale</translation>
    </message>
    <message>
        <source>Security</source>
        <translation>Sicurezza</translation>
    </message>
    <message>
        <source>Database Credentials</source>
        <translation>Credenziali database</translation>
    </message>
    <message>
        <source>Encryption Settings</source>
        <translation>Impostazioni di cifratura</translation>
    </message>
    <message>
        <source>Browser Integration</source>
        <translation>Integrazione browser</translation>
    </message>
    <message>
        <source>Maintenance</source>
        <translation>Manutenzione</translation>
    </message>
    <message>
        <source>KeeShare</source>
        <translation>KeeShare</translation>
    </message>
    <message>
        <source>Secret Service Integration</source>
        <translation>Integrazione Secret Service</translation>
    </message>
    <message>
        <source>Remote Sync</source>
        <translation>Sincronizzazione remota</translation>
    </message>
    <message>
        <source>Database Settings: %1</source>
        <translation>Impostazioni database: %1</translation>
    </message>
</context>
<context>
    <name>DatabaseSettingsWidgetBrowser</name>
    <message>
        <source>KeePassXC-Browser settings</source>
        <translation>Impostazioni di KeePassXC-Browser</translation>
    </message>
    <message>
        <source>Disconnect all browsers</source>
        <translation>Scollega tutti i browser</translation>
    </message>
    <message>
        <source>Forget all site-specific settings on entries</source>
        <translation>Dimenticare tutte le impostazioni specifiche dei siti nelle voci</translation>
    </message>
    <message>
        <source>Refresh database root group ID</source>
        <translation>Aggiorna l&apos;ID gruppo radice del database</translation>
    </message>
    <message>
        <source>Stored keys</source>
        <translation>Chiavi memorizzate</translation>
    </message>
    <message>
        <source>Stored browser keys</source>
        <translation>Chiavi del browser archiviate</translation>
    </message>
    <message>
        <source>Remove selected key</source>
        <translation>Rimuovi chiave selezionata</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Rimuovi</translation>
    </message>
    <message>
        <source>Delete the selected key?</source>
        <translation>Vuoi eliminare la chiave selezionata?</translation>
    </message>
    <message>
        <source>Do you really want to delete the selected key?
This may prevent connection to the browser plugin.</source>
        <translation>Vuoi eliminare la chiave selezionata?
Questo potrebbe impedire la connessione al plugin del browser.</translation>
    </message>
    <message>
        <source>Key</source>
        <translation>Chiave</translation>
    </message>
    <message>
        <source>Value</source>
        <translation>Valore</translation>
    </message>
    <message>
        <source>Created</source>
        <translation>Creazione</translation>
    </message>
    <message>
        <source>Enable Browser Integration to access these settings.</source>
        <translation>Per accedere a queste impostazioni abilita l&apos;integrazione browser.</translation>
    </message>
    <message>
        <source>Do you really want to disconnect all browsers?
This may prevent connection to the browser plugin.</source>
        <translation>Vuoi scollegare tutti i browser?
Questo potrebbe impedire la connessione al plugin del browser.</translation>
    </message>
    <message>
        <source>No shared encryption keys found in KeePassXC settings.</source>
        <translation>Nessuna chiave di cifratura condivisa trovata nelle impostazioni KeePassXC.</translation>
    </message>
    <message numerus="yes">
        <source>Successfully removed %n encryption key(s) from KeePassXC settings.</source>
        <translation><numerusform> Rimossa con successo %n chiave di cifratura dalle impostazioni di KeePassXC. </numerusform><numerusform> Rimosse con successo %n chiavi di cifratura dalle impostazioni di KeePassXC. </numerusform><numerusform> Rimosse con successo %n chiavi di cifratura dalle impostazioni di KeePassXC. </numerusform></translation>
    </message>
    <message>
        <source>Do you really want forget all site-specific settings on every entry?
Permissions to access entries will be revoked.</source>
        <translation>Vuoi davvero dimenticare tutte le impostazioni specifiche del sito su ogni voce?
Verranno revocate le autorizzazioni per accedere alle voci.</translation>
    </message>
    <message>
        <source>Removing stored permissions…</source>
        <translation>Rimozione dei permessi salvati...</translation>
    </message>
    <message>
        <source>Abort</source>
        <translation>Interrompi</translation>
    </message>
    <message numerus="yes">
        <source>Successfully removed permissions from %n entry(s).</source>
        <translation><numerusform>Permessi rimossi con successo da %n voce.</numerusform><numerusform>Permessi rimossi con successo da %n voci.</numerusform><numerusform>Permessi rimossi con successo da %n voci.</numerusform></translation>
    </message>
    <message>
        <source>The active database does not contain an entry with permissions.</source>
        <translation>Il database attivo non contiene una voce con permessi.</translation>
    </message>
    <message>
        <source>Refresh database ID</source>
        <translation>Aggiorna ID database</translation>
    </message>
    <message>
        <source>Do you really want refresh the database ID?
This is only necessary if your database is a copy of another and the browser extension cannot connect.</source>
        <translation>Vuoi davvero aggiornare l&apos;ID del database? 
Questo è necessario solo se il database è una copia e l&apos;estensione del browser non riesce a connettersi.</translation>
    </message>
    <message>
        <source>Convert legacy KeePassHTTP attributes to KeePassXC-Browser compatible custom data</source>
        <translation>Convertire gli attributi KeePassHTTP obsoleti in dati personalizzati compatibili con KeePassXC-Browser</translation>
    </message>
    <message>
        <source>No keys found</source>
        <translation>Nessuna chiave trovata</translation>
    </message>
    <message>
        <source>Removed keys from database</source>
        <translation>Chiavi rimosse dal database</translation>
    </message>
    <message>
        <source>Removed permissions</source>
        <translation>Permessi rimossi</translation>
    </message>
    <message>
        <source>No entry with permissions found!</source>
        <translation>Nessuna voce con permessi trovata!</translation>
    </message>
</context>
<context>
    <name>DatabaseSettingsWidgetDatabaseKey</name>
    <message>
        <source>Add additional protection…</source>
        <translation>Aggiungi ulteriore protezione...</translation>
    </message>
    <message>
        <source>No password set</source>
        <translation>Nessuna password impostata</translation>
    </message>
    <message>
        <source>WARNING! You have not set a password. Using a database without a password is strongly discouraged!

Are you sure you want to continue without a password?</source>
        <translation>ATTENZIONE! Non è stata impostata una password. Usare un database senza password è fortemente sconsigliato!

Vuoi continuare senza password?</translation>
    </message>
    <message>
        <source>Continue without password</source>
        <translation>Continua senza password</translation>
    </message>
    <message>
        <source>No encryption key added</source>
        <translation>Nessuna chiave di cifratura aggiunta</translation>
    </message>
    <message>
        <source>You must add at least one encryption key to secure your database!</source>
        <translation>Per rendere sicuro il database devi aggiungere almeno un&apos;altra chiave di cifratura!</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation>Errore sconosciuto</translation>
    </message>
    <message>
        <source>Failed to change database credentials</source>
        <translation>Impossibile modificare le credenziali del database</translation>
    </message>
    <message>
        <source>Weak password</source>
        <translation>Password debole</translation>
    </message>
    <message>
        <source>This is a weak password! For better protection of your secrets, you should choose a stronger password.</source>
        <translation>Questa è una password debole! Per una maggiore protezione dei segreti, dovresti scegliere una password più forte.</translation>
    </message>
    <message>
        <source>The provided password does not meet the minimum quality requirement.</source>
        <translation>La password fornita non rispetta i requisiti qualitativi minimi.</translation>
    </message>
</context>
<context>
    <name>DatabaseSettingsWidgetEncryption</name>
    <message>
        <source>Decryption Time:</source>
        <translation>Tempo di decifratura:</translation>
    </message>
    <message>
        <source>Decryption time in seconds</source>
        <translation>Tempo di decifratura in secondi</translation>
    </message>
    <message>
        <source>Higher values offer more protection, but opening the database will take longer.</source>
        <translation>I valori più elevati offrono una maggiore protezione, ma l&apos;apertura del database richiederà più tempo.</translation>
    </message>
    <message>
        <source>Database format:</source>
        <translation>Formato database:</translation>
    </message>
    <message>
        <source>Database format</source>
        <translation>Formato del database</translation>
    </message>
    <message>
        <source>Format cannot be changed: Your database uses KDBX 4 features</source>
        <translation>Il formato non può essere cambiato: il database usa le caratteristiche di KDBX 4</translation>
    </message>
    <message>
        <source>Unless you need to open your database with other programs, always use the latest format.</source>
        <translation>A meno che non abbia bisogno di aprire il database con altri programmi, usa sempre l&apos;ultimo formato.</translation>
    </message>
    <message>
        <source>Encryption Algorithm:</source>
        <translation>Algoritmo di cifratura:</translation>
    </message>
    <message>
        <source>Encryption algorithm</source>
        <translation>Algoritmo di cifratura</translation>
    </message>
    <message>
        <source>AES:  256 Bit   (default)</source>
        <translation>AES: 256 Bit (predefinito)</translation>
    </message>
    <message>
        <source>Twofish:  256 Bit</source>
        <translation>Twofish: 256 Bit</translation>
    </message>
    <message>
        <source>Key Derivation Function:</source>
        <translation>Funzione di derivazione di chiave:</translation>
    </message>
    <message>
        <source>Key derivation function</source>
        <translation>Funzione di derivazione della chiave</translation>
    </message>
    <message>
        <source>Transform rounds:</source>
        <translation>Arrotondamenti trasformazione:</translation>
    </message>
    <message>
        <source>Transform rounds</source>
        <translation>Giri di trasformazione</translation>
    </message>
    <message>
        <source>Memory Usage:</source>
        <translation>Uso della memoria:</translation>
    </message>
    <message>
        <source>Memory usage</source>
        <translation>Utilizzo della memoria</translation>
    </message>
    <message>
        <source>Parallelism:</source>
        <translation>Parallelismo:</translation>
    </message>
    <message>
        <source>Parallelism</source>
        <translation>Parallelismo</translation>
    </message>
    <message>
        <source>KDBX 4 (recommended)</source>
        <translation>KDBX 4 (consigliato)</translation>
    </message>
    <message>
        <source>KDBX 3</source>
        <translation>KDBX 3</translation>
    </message>
    <message>
        <source>Number of rounds too high</source>
        <comment>Key transformation rounds</comment>
        <translation>Numero di giri troppo elevato</translation>
    </message>
    <message>
        <source>You are using a very high number of key transform rounds with Argon2.

If you keep this number, your database may take hours, days, or even longer to open.</source>
        <translation>Con Argon2 si usa un numero molto elevato di turni di trasformazione chiave.

Se si mantiene questo numero, l&apos;apertura del database potrebbe richiedere ore, giorni o anche più tempo.</translation>
    </message>
    <message>
        <source>Understood, keep number</source>
        <translation>D&apos;accordo, mantieni il valore</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Annulla</translation>
    </message>
    <message>
        <source>Number of rounds too low</source>
        <comment>Key transformation rounds</comment>
        <translation>Numero di giri troppo basso</translation>
    </message>
    <message>
        <source>You are using a very low number of key transform rounds with AES-KDF.

If you keep this number, your database will not be protected from brute force attacks.</source>
        <translation>Con AES-KDF si usa un numero molto basso di turni di trasformazione chiave.

Se si mantiene questo numero, il database non sarà protetto da attacchi di forza bruta.</translation>
    </message>
    <message>
        <source>KDF unchanged</source>
        <translation>KDF invariato</translation>
    </message>
    <message>
        <source>Failed to transform key with new KDF parameters; KDF unchanged.</source>
        <translation>La trasformazione della chiave con i nuovi parametri KDF non è riuscita; KDF immutato.</translation>
    </message>
    <message numerus="yes">
        <source> MiB</source>
        <comment>Abbreviation for Mebibytes (KDF settings)</comment>
        <translation><numerusform> MiB</numerusform><numerusform> MiB</numerusform><numerusform> MiB</numerusform></translation>
    </message>
    <message numerus="yes">
        <source> thread(s)</source>
        <comment>Threads for parallel execution (KDF settings)</comment>
        <translation><numerusform> thread</numerusform><numerusform> thread</numerusform><numerusform> thread</numerusform></translation>
    </message>
    <message>
        <source>Encryption Settings:</source>
        <translation>Impostazioni di crittografia:</translation>
    </message>
    <message>
        <source>Basic</source>
        <translation>Base</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>Avanzate</translation>
    </message>
</context>
<context>
    <name>DatabaseSettingsWidgetFdoSecrets</name>
    <message>
        <source>Exposed Entries</source>
        <translation>Voci esposte</translation>
    </message>
    <message>
        <source>Don&apos;t expose this database</source>
        <translation>Non esporre questo database</translation>
    </message>
    <message>
        <source>Expose entries under this group:</source>
        <translation>Esporre le voci in questo gruppo:</translation>
    </message>
    <message>
        <source>Enable Secret Service to access these settings.</source>
        <translation>Consenti ai servizi segreti di accedere a queste impostazioni.</translation>
    </message>
</context>
<context>
    <name>DatabaseSettingsWidgetGeneral</name>
    <message>
        <source>Database Metadata</source>
        <translation>Metadati del database</translation>
    </message>
    <message>
        <source>Database name:</source>
        <translation>Nome database:</translation>
    </message>
    <message>
        <source>Database name field</source>
        <translation>Campo nome database</translation>
    </message>
    <message>
        <source>Database description:</source>
        <translation>Descrizione database:</translation>
    </message>
    <message>
        <source>Database description field</source>
        <translation>Campo descrizione database</translation>
    </message>
    <message>
        <source>Default username:</source>
        <translation>Nome utente predefinito:</translation>
    </message>
    <message>
        <source>Default username field</source>
        <translation>Campo nome utente predefinito</translation>
    </message>
    <message>
        <source>History Settings</source>
        <translation>Impostazioni cronologia</translation>
    </message>
    <message>
        <source>Maximum number of history items per entry</source>
        <translation>Numero massimo di elementi della cronologia per voce</translation>
    </message>
    <message>
        <source>Maximum size of history per entry</source>
        <translation>Dimensione massima della cronologia per voce</translation>
    </message>
    <message>
        <source> MiB</source>
        <translation> MB</translation>
    </message>
    <message>
        <source>Use recycle bin</source>
        <translation>Usa il cestino</translation>
    </message>
    <message>
        <source>Additional Database Settings</source>
        <translation>Ulteriori impostazioni del database</translation>
    </message>
    <message>
        <source>Enable compression (recommended)</source>
        <translation>Abilita compressione (consigliato)</translation>
    </message>
    <message>
        <source>Delete Recycle Bin</source>
        <translation>Elimina Cestino</translation>
    </message>
    <message>
        <source>Do you want to delete the current recycle bin and all its contents?
This action is not reversible.</source>
        <translation>Vuoi eliminare il cestino attuale e tutto il suo contenuto?
Questa azione non è reversibile.</translation>
    </message>
    <message>
        <source> (old)</source>
        <translation> (vecchio)</translation>
    </message>
    <message>
        <source>When saving this setting or editing an entry
the oldest history items of an entry will be
removed such that only the specified amount
of entries remain at most.</source>
        <translation>Quando si salva questa impostazione o si modifica una voce
gli elementi della cronologia più vecchi di una voce saranno
rimossi in modo tale che solo il numero specificato
delle voci rimanga.</translation>
    </message>
    <message>
        <source>Limit the amount of history items per entry to:</source>
        <translation>Limita la quantità elementi cronologia per voce a:</translation>
    </message>
    <message>
        <source>When saving this setting or editing an entry
the oldest history items of an entry will be
removed such that the remaining history items
add up to the specified amount at most.</source>
        <translation>Quando si salva questa impostazione o si modifica una voce
gli elementi della cronologia più vecchi di una voce saranno
rimossi in modo tale che gli elementi rimanenti della cronologia
si accumulino fino al numero specificato.</translation>
    </message>
    <message>
        <source>Limit the total size of history items per entry to:</source>
        <translation>Limita la dimensione totale elementi cronologia per voce a:</translation>
    </message>
    <message>
        <source>Move entries to a recycle bin group
instead of deleting them from the database.
Entries deleted from the recycle bin are
removed from the database.</source>
        <translation>Sposta le voci in un gruppo Cestino
invece di eliminarli dal database.
Le voci eliminate dal cestino sono
rimosse dal database.</translation>
    </message>
    <message>
        <source>Autosave delay since last change</source>
        <translation>Intervallo di salvataggio automatico dall&apos;ultimo cambiamento</translation>
    </message>
    <message>
        <source>Autosave delay</source>
        <translation>Intervallo di salvataggio automatico</translation>
    </message>
    <message>
        <source>Autosave delay since last change in minutes</source>
        <translation>Intervallo di salvataggio automatico dall&apos;ultimo cambiamento in minuti</translation>
    </message>
    <message>
        <source> min</source>
        <translation>min</translation>
    </message>
    <message>
        <source>Autosave delay since last change checkbox</source>
        <translation>Casella di controllo per l&apos;intervallo di salvataggio automatico dall&apos;ultimo cambiamento</translation>
    </message>
    <message>
        <source>Public Database Metadata</source>
        <translation>Metadati database pubblico</translation>
    </message>
    <message>
        <source>Warning: the following settings are not encrypted.</source>
        <translation>Attenzione: le seguenti impostazioni non sono crittografate.</translation>
    </message>
    <message>
        <source>Display name:</source>
        <translation>Nome visualizzato:</translation>
    </message>
    <message>
        <source>Database public display name</source>
        <translation>Nome pubblico database visualizzato</translation>
    </message>
    <message>
        <source>Display color:</source>
        <translation>Colore visualizzazione:</translation>
    </message>
    <message>
        <source>Database public display color chooser</source>
        <translation>Selettore colore visualizzazione database pubblico</translation>
    </message>
    <message>
        <source>Clear</source>
        <translation>Azzera</translation>
    </message>
    <message>
        <source>Display icon:</source>
        <translation>Icona visualizzata:</translation>
    </message>
    <message>
        <source>Select Database Icon</source>
        <translation>Seleziona l&apos;icona del database</translation>
    </message>
    <message>
        <source>Publicly visible display name used on the unlock dialog</source>
        <translation>Nome visibile pubblicamente nella finestra di sblocco</translation>
    </message>
    <message>
        <source>Publicly visible color used on the unlock dialog</source>
        <translation>Colore visibile pubblicamente nella finestra di sblocco</translation>
    </message>
</context>
<context>
    <name>DatabaseSettingsWidgetKeeShare</name>
    <message>
        <source>Sharing</source>
        <translation>Condivisione</translation>
    </message>
    <message>
        <source>Breadcrumb</source>
        <translation>Percorso di navigazione</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <source>Path</source>
        <translation>Percorso</translation>
    </message>
    <message>
        <source>Last Signer</source>
        <translation>Ultimo firmatario</translation>
    </message>
    <message>
        <source>Certificates</source>
        <translation>Certificati</translation>
    </message>
    <message>
        <source> &gt; </source>
        <comment>Breadcrumb separator</comment>
        <translation> &gt; </translation>
    </message>
</context>
<context>
    <name>DatabaseSettingsWidgetMaintenance</name>
    <message>
        <source>Manage Custom Icons</source>
        <translation>Gestire icone personalizzate</translation>
    </message>
    <message>
        <source>Delete selected icon(s)</source>
        <translation>Elimina icone selezionate</translation>
    </message>
    <message>
        <source>Delete all custom icons not in use by any entry or group</source>
        <translation>Elimina tutte le icone personalizzate non usate da alcuna voce o gruppo</translation>
    </message>
    <message>
        <source>Purge unused icons</source>
        <translation>Elimina icone non usate</translation>
    </message>
    <message>
        <source>Confirm Deletion</source>
        <translation>Conferma eliminazione</translation>
    </message>
    <message>
        <source>At least one of the selected icons is currently in use by at least one entry or group. The icons of all affected entries and groups will be replaced by the default icon. Are you sure you want to delete icons that are currently in use?</source>
        <translation>Almeno una delle icone selezionate è attualmente in uso da almeno una voce o gruppo. Le icone di tutte le voci e i gruppi interessati verranno sostituite dall&apos;icona predefinita. Vuoi eliminare le icone attualmente in uso?</translation>
    </message>
    <message>
        <source>Custom Icons Are In Use</source>
        <translation>Icone personalizzate in uso</translation>
    </message>
    <message>
        <source>All custom icons are in use by at least one entry or group.</source>
        <translation>Tutte le icone personalizzate sono usate da almeno una voce o gruppo.</translation>
    </message>
    <message>
        <source>Purged Unused Icons</source>
        <translation>Icone non usate eliminate</translation>
    </message>
    <message numerus="yes">
        <source>Purged %n icon(s) from the database.</source>
        <translation><numerusform>Eliminata %n icona dal database.</numerusform><numerusform>Eliminate %n icone dal database.</numerusform><numerusform>Eliminate %n icone dal database.</numerusform></translation>
    </message>
</context>
<context>
    <name>DatabaseSettingsWidgetMetaDataSimple</name>
    <message>
        <source>Database Name:</source>
        <translation>Nome del database:</translation>
    </message>
    <message>
        <source>Database name field</source>
        <translation>Campo nome database</translation>
    </message>
    <message>
        <source>Description:</source>
        <translation>Descrizione:</translation>
    </message>
    <message>
        <source>Database description field</source>
        <translation>Campo descrizione database</translation>
    </message>
</context>
<context>
    <name>DatabaseSettingsWidgetRemote</name>
    <message>
        <source>Sync Commands</source>
        <translation>Comandi sincronizzazione</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Rimuovi</translation>
    </message>
    <message>
        <source>Command Settings</source>
        <translation>Impostazioni comando</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>Salva</translation>
    </message>
    <message>
        <source>Download</source>
        <translation>Download</translation>
    </message>
    <message>
        <source>Command:</source>
        <translation>Comando:</translation>
    </message>
    <message>
        <source>Download command field</source>
        <translation>Campo comando download</translation>
    </message>
    <message>
        <source>e.g.: &quot;sftp user@hostname&quot; or &quot;scp user@hostname:DatabaseOnRemote.kdbx {TEMP_DATABASE}&quot;</source>
        <translation>es.: &quot;sftp user@hostname&quot; o &quot;scp user@hostname:DatabaseOnRemote.kdbx {TEMP_DATABASE}&quot;</translation>
    </message>
    <message>
        <source>Input:</source>
        <translation>Input:</translation>
    </message>
    <message>
        <source>Download input field</source>
        <translation>Campo input download</translation>
    </message>
    <message>
        <source>Upload</source>
        <translation>Carica</translation>
    </message>
    <message>
        <source>Upload command field</source>
        <translation>Campo comando carica</translation>
    </message>
    <message>
        <source>e.g.: &quot;sftp user@hostname&quot; or &quot;scp {TEMP_DATABASE} user@hostname:DatabaseOnRemote.kdbx&quot;</source>
        <translation>Ad esempio.: &quot;sftp user@hostname&quot; o &quot;scp {TEMP_DATABASE} user@hostname:DatabaseOnRemote.kdbx&quot;</translation>
    </message>
    <message>
        <source>Upload input field</source>
        <translation>Campo input carica</translation>
    </message>
    <message>
        <source>Name cannot be empty.</source>
        <translation>Il nome non può essere vuoto.</translation>
    </message>
    <message>
        <source>Test</source>
        <translation>Test</translation>
    </message>
    <message>
        <source>Download command cannot be empty.</source>
        <translation>Il comando download non può essere vuoto.</translation>
    </message>
    <message>
        <source>Download failed with error: %1</source>
        <translation>Download non riuscito con errore: %1</translation>
    </message>
    <message>
        <source>Download finished, but file %1 could not be found.</source>
        <translation>Download completato, ma il file %1 non è stato trovato.</translation>
    </message>
    <message>
        <source>Download successful.</source>
        <translation>Download completato correttamente.</translation>
    </message>
    <message>
        <source>Save Remote Settings</source>
        <translation>Salva impostazioni remote</translation>
    </message>
    <message>
        <source>You have unsaved changes. Do you want to save them?</source>
        <translation>Ci sono delle modifiche non salvate.  Vuoi salvarle?</translation>
    </message>
    <message>
        <source>e.g.:
get DatabaseOnRemote.kdbx {TEMP_DATABASE}
exit
---
{TEMP_DATABASE} is used as placeholder to store the database in a temporary location
The command has to exit. In case of `sftp` as last command `exit` has to be sent
            </source>
        <translation>ad es.:
get DatabaseOnRemote.kdbx {TEMP_DATABASE}
exit
---
{TEMP_DATABASE} è usato come segnaposto per memorizzare il database in una posizione temporanea
Il comando deve uscire.  In caso di `sftp` come ultimo comando deve essere inviato `exit`.
            </translation>
    </message>
    <message>
        <source>e.g.:
put {TEMP_DATABASE} DatabaseOnRemote.kdbx
exit
---
{TEMP_DATABASE} is used as placeholder to store the database in a temporary location
The command has to exit. In case of `sftp` as last command `exit` has to be sent
            </source>
        <translation>ad es.:
put {TEMP_DATABASE} DatabaseOnRemote.kdbx
exit
---
{TEMP_DATABASE} è usato come segnaposto per memorizzare il database in una posizione temporanea
Il comando deve uscire.  In caso di `sftp` come ultimo comando deve essere inviato `exit`.
            </translation>
    </message>
    <message>
        <source>Timeout:</source>
        <translation>Timeout:</translation>
    </message>
    <message>
        <source> seconds</source>
        <translation> secondi</translation>
    </message>
</context>
<context>
    <name>DatabaseTabWidget</name>
    <message>
        <source>Database creation error</source>
        <translation>Errore di creazione del database</translation>
    </message>
    <message>
        <source>The created database has no key or KDF, refusing to save it.
This is definitely a bug, please report it to the developers.</source>
        <translation>Il database creato non ha chiave o KDF, rifiutando di salvarlo.
Questo è sicuramente un bug, segnalalo agli sviluppatori.</translation>
    </message>
    <message>
        <source>KeePass 2 Database</source>
        <translation>Database KeePass 2</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>Tutti i file</translation>
    </message>
    <message>
        <source>Open database</source>
        <translation>Apri database</translation>
    </message>
    <message>
        <source>Failed to open %1. It either does not exist or is not accessible.</source>
        <translation>Impossibile aprire &apos;%1&apos;. Non esiste o non è accessibile.</translation>
    </message>
    <message>
        <source>CSV file</source>
        <translation>File CSV</translation>
    </message>
    <message>
        <source>Merge database</source>
        <translation>Unisci database</translation>
    </message>
    <message>
        <source>Export database to CSV file</source>
        <translation>Esporta database come file CSV</translation>
    </message>
    <message>
        <source>Writing the CSV file failed.</source>
        <translation>Scrittura file CSV non riuscita.</translation>
    </message>
    <message>
        <source>Writing the HTML file failed.</source>
        <translation>Scrittura del file HTML non riuscita.</translation>
    </message>
    <message>
        <source>Export database to XML file</source>
        <translation>Esporta il database in un file XML</translation>
    </message>
    <message>
        <source>XML file</source>
        <translation>File XML</translation>
    </message>
    <message>
        <source>Writing the XML file failed</source>
        <translation>Scrittura del file XML non riuscita</translation>
    </message>
    <message>
        <source>Export Confirmation</source>
        <translation>Conferma esportazione</translation>
    </message>
    <message>
        <source>You are about to export your database to an unencrypted file. This will leave your passwords and sensitive information vulnerable! Are you sure you want to continue?</source>
        <translation>Stai per esportare il database in un file non cifrato. Questo lascerà le password e le informazioni sensibili vulnerabili! Sei sicuro di voler continuare?</translation>
    </message>
    <message>
        <source>%1 [Locked]</source>
        <comment>Database tab name modifier</comment>
        <translation>%1 [bloccato]</translation>
    </message>
    <message>
        <source>%1 [Temporary]</source>
        <comment>Database tab name modifier</comment>
        <translation>%1 [temporaneo]</translation>
    </message>
</context>
<context>
    <name>DatabaseWidget</name>
    <message>
        <source>Searches and Tags</source>
        <translation>Ricerche ed etichette</translation>
    </message>
    <message>
        <source>Searching…</source>
        <translation>Ricerca...</translation>
    </message>
    <message>
        <source>Shared group…</source>
        <translation>Gruppo condiviso...</translation>
    </message>
    <message>
        <source>Confirm Auto-Type</source>
        <translation>Conferma digitazione automatica</translation>
    </message>
    <message>
        <source>Perform Auto-Type into the previously active window?</source>
        <translation>Eseguire la digitazione automatica nella finestra precedentemente attiva?</translation>
    </message>
    <message>
        <source>Execute command?</source>
        <translation>Vuoi eseguire il comando?</translation>
    </message>
    <message>
        <source>Do you really want to execute the following command?&lt;br&gt;&lt;br&gt;%1&lt;br&gt;</source>
        <translation>Sei sicuro di voler eseguire il seguente comando?&lt;br&gt;&lt;br&gt;%1&lt;br&gt;</translation>
    </message>
    <message>
        <source>Remember my choice</source>
        <translation>Ricorda la mia scelta</translation>
    </message>
    <message>
        <source>Do you really want to move the group &quot;%1&quot; to the recycle bin?</source>
        <translation>Vuoi davvero spostare il gruppo &quot;%1&quot; nel cestino?</translation>
    </message>
    <message>
        <source>Expired entries</source>
        <translation>Voci scadute</translation>
    </message>
    <message numerus="yes">
        <source>Entries expiring within %1 day(s)</source>
        <translation><numerusform>Voci che scadono entro %1 giorno(i)</numerusform><numerusform>Voci che scadono entro %1 giorno(i)</numerusform><numerusform>Voci che scadono entro %1 giorno(i)</numerusform></translation>
    </message>
    <message>
        <source>No current database.</source>
        <translation>Nessun database attuale.</translation>
    </message>
    <message>
        <source>No source database, nothing to do.</source>
        <translation>Nessun database sorgente. Nessuna operazione da fare.</translation>
    </message>
    <message>
        <source>Search Results (%1)</source>
        <translation>Risultati ricerca (%1)</translation>
    </message>
    <message>
        <source>No Results</source>
        <translation>Nessun risultato</translation>
    </message>
    <message>
        <source>Enter a unique name or overwrite an existing search from the list:</source>
        <translation>Inserisci un nome univoco o sovrascrivi una ricerca esistente dall&apos;elenco:</translation>
    </message>
    <message>
        <source>Save Search</source>
        <translation>Salva ricerca</translation>
    </message>
    <message>
        <source>Lock Database?</source>
        <translation>Vuoi bloccare il database?</translation>
    </message>
    <message>
        <source>You are editing an entry. Discard changes and lock anyway?</source>
        <translation>Sta modificando una voce. Vuoi eliminare le modifiche e bloccare comunque?</translation>
    </message>
    <message>
        <source>&quot;%1&quot; was modified.
Save changes?</source>
        <translation>&quot;%1&quot; è stata modificato.
Vuoi salvare le modifiche?</translation>
    </message>
    <message>
        <source>Database was modified.
Save changes?</source>
        <translation>Il database è stato modificato.
Vuoi salvare le modifiche?</translation>
    </message>
    <message>
        <source>Save changes?</source>
        <translation>Vuoi salvare le modifiche?</translation>
    </message>
    <message>
        <source>File has changed</source>
        <translation>Il file è stato modificato</translation>
    </message>
    <message>
        <source>Disable safe saves?</source>
        <translation>Disabilita i salvataggi sicuri?</translation>
    </message>
    <message>
        <source>KeePassXC has failed to save the database multiple times. This is likely caused by file sync services holding a lock on the save file.
Disable safe saves and try again?</source>
        <translation>Nonostante ripetuti tentativi, KeePassXC non è riuscito a salvare il database. Probabilmente la causa risiede in un file bloccato da qualche servizio di sincronizzazione file.
Vuoi disabilitare i salvataggi sicuri e riprovare?</translation>
    </message>
    <message>
        <source>Writing the database failed: %1</source>
        <translation>Scrittura del database non riuscita: %1</translation>
    </message>
    <message>
        <source>Passwords</source>
        <translation>Password</translation>
    </message>
    <message>
        <source>Save database as</source>
        <translation>Salva database come</translation>
    </message>
    <message>
        <source>KeePass 2 Database</source>
        <translation>Database KeePass 2</translation>
    </message>
    <message>
        <source>Empty recycle bin?</source>
        <translation>Vuoi svuotare il cestino?</translation>
    </message>
    <message>
        <source>Are you sure you want to permanently delete everything from your recycle bin?</source>
        <translation>Sei sicuro di voler eliminare definitivamente tutto dal cestino?</translation>
    </message>
    <message>
        <source>Could not find database file: %1</source>
        <translation>Impossibile trovare il file database: %1</translation>
    </message>
    <message>
        <source>New Database</source>
        <translation>Nuovo Database</translation>
    </message>
    <message>
        <source>%1 [New Database]</source>
        <comment>Database tab name modifier</comment>
        <translation>%1 [Nuovo Database]</translation>
    </message>
    <message>
        <source>Remote Sync did not contain any download or upload commands.</source>
        <translation>La sincronizzazione remota non conteneva alcun comando di download o upload.</translation>
    </message>
    <message>
        <source>Remote sync &apos;%1&apos; completed successfully!</source>
        <translation>Sincronizzazione remota &apos;%1&apos; completata!</translation>
    </message>
    <message>
        <source>Downloading...</source>
        <translation>Download...</translation>
    </message>
    <message>
        <source>Uploading...</source>
        <translation>Upload...</translation>
    </message>
    <message>
        <source>Remote sync &apos;%1&apos; failed: %2</source>
        <translation>Sincronizzazione remota &apos;%1&apos; fallita: %2</translation>
    </message>
    <message>
        <source>Syncing...</source>
        <translation>Sincronizzazione...</translation>
    </message>
    <message>
        <source>Error while saving database %1: %2</source>
        <translation>Errore durante il salvataggio del database %1: %2</translation>
    </message>
    <message>
        <source>Remove passkey from entry</source>
        <translation>Rimuovi passkey dalla voce</translation>
    </message>
    <message>
        <source>Do you want to remove the passkey from this entry?</source>
        <translation>Vuoi rimuovere la passkey da questa voce?</translation>
    </message>
    <message>
        <source>The database file &quot;%1&quot; was modified externally</source>
        <translation>Il file di database &quot;%1&quot; è stato modificato esternamente</translation>
    </message>
    <message>
        <source>Do you want to load the changes?</source>
        <translation>Vuoi caricare le modifiche?</translation>
    </message>
    <message>
        <source>Reloading database…</source>
        <translation>Ricaricamento del database…</translation>
    </message>
    <message>
        <source>Reload canceled</source>
        <translation>Ricaricamento annullato</translation>
    </message>
    <message>
        <source>Reload successful</source>
        <translation>Ricaricamento completato</translation>
    </message>
    <message>
        <source>Reload pending user action…</source>
        <translation>Ricaricamento in attesa di azione dell&apos;utente...</translation>
    </message>
    <message>
        <source>The database file &quot;%1&quot; was modified externally.&lt;br&gt;How would you like to proceed?&lt;br&gt;&lt;br&gt;Merge all changes&lt;br&gt;Ignore the changes on disk until save&lt;br&gt;Discard unsaved changes</source>
        <translation>Il file database &quot;%1&quot; è stato modificato esternamente.&lt;br&gt;Come vuoi  procedere?&lt;br&gt;&lt;br&gt;Unisci tutte le modifiche&lt;br&gt;Ignora le modifiche nel disco fino al salvataggio&lt;br&gt;Ignora le modifiche non salvate</translation>
    </message>
    <message>
        <source>The database file &quot;%1&quot; was modified externally.&lt;br&gt;How would you like to proceed?&lt;br&gt;&lt;br&gt;Merge all changes then save&lt;br&gt;Overwrite the changes on disk&lt;br&gt;Discard unsaved changes</source>
        <translation>Il file database &quot;%1&quot; è stato modificato esternamente.&lt;br&gt;Come vuoi procedere?&lt;br&gt;&lt;br&gt;Unisci tutte le modifiche, quindi salva&lt;br&gt;Sovrascrivi le modifiche nel disco&lt;br&gt;Ignora le modifiche non salvate</translation>
    </message>
    <message>
        <source>Reload database</source>
        <translation>Ricarica il database</translation>
    </message>
    <message>
        <source>Database file overwritten.</source>
        <translation>File database sovrascritto.</translation>
    </message>
    <message>
        <source>Database file on disk cannot be unlocked with current credentials.&lt;br&gt;Enter new credentials and/or present hardware key to continue.</source>
        <translation>Il file database nel disco non può essere sbloccato con le credenziali attuali.&lt;br&gt; Per continuare inserisci le nuove credenziali e/o collega la chiave hardware.</translation>
    </message>
    <message>
        <source>Failed to save backup database: %1</source>
        <translation>Impossibile salvare il backup del database: %1</translation>
    </message>
    <message>
        <source>Confirm Delete Group</source>
        <translation>Conferma eliminazione gruppo</translation>
    </message>
    <message>
        <source>Do you really want to permanently delete the group &quot;%1&quot;?</source>
        <translation>Vuoi eliminare definitivamente il gruppo &quot;%1&quot;?</translation>
    </message>
    <message>
        <source>Confirm Recycle Group</source>
        <translation>Conferma cancellazione gruppo</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>Salva</translation>
    </message>
    <message>
        <source>Save Database Backup</source>
        <translation>Salva backup database</translation>
    </message>
    <message>
        <source>Successfully merged the selected database.</source>
        <translation>Unione database selezionato completata.</translation>
    </message>
    <message>
        <source>No changes were made by the merge operation.</source>
        <translation>L&apos;operazione di unione non ha apportato alcuna modifica.</translation>
    </message>
    <message>
        <source>Merge canceled, no changes were made.</source>
        <translation>Unione annullata, nessuna modifica apportata.</translation>
    </message>
</context>
<context>
    <name>EditEntryAttachmentsDialog</name>
    <message>
        <source>Edit: %1</source>
        <translation>Modifica: %1</translation>
    </message>
</context>
<context>
    <name>EditEntryWidget</name>
    <message>
        <source>Entry</source>
        <translation>Voce</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>Avanzate</translation>
    </message>
    <message>
        <source>Icon</source>
        <translation>Icona</translation>
    </message>
    <message>
        <source>Auto-Type</source>
        <translation>Completamento automatico</translation>
    </message>
    <message>
        <source>Browser Integration</source>
        <translation>Integrazione browser</translation>
    </message>
    <message>
        <source>&lt;empty URL&gt;</source>
        <translation>&lt;empty URL&gt;</translation>
    </message>
    <message>
        <source>Confirm Removal</source>
        <translation>Conferma rimozione</translation>
    </message>
    <message>
        <source>Are you sure you want to remove this URL?</source>
        <translation>Sei sicuro di voler rimuovere questo URL?</translation>
    </message>
    <message>
        <source>Properties</source>
        <translation>Proprietà</translation>
    </message>
    <message>
        <source>History</source>
        <translation>Cronologia</translation>
    </message>
    <message>
        <source>SSH Agent</source>
        <translation>Agente SSH</translation>
    </message>
    <message>
        <source>n/a</source>
        <translation>n/a</translation>
    </message>
    <message>
        <source>Select private key</source>
        <translation>Seleziona chiave privata</translation>
    </message>
    <message>
        <source>Entry history</source>
        <translation>Cronologia voce</translation>
    </message>
    <message>
        <source>Add entry</source>
        <translation>Aggiungi voce</translation>
    </message>
    <message>
        <source>Edit entry</source>
        <translation>Modifica voce</translation>
    </message>
    <message>
        <source>Some Browser Integration settings are overridden by group settings.</source>
        <translation>Alcune impostazioni di integrazione del browser vengono sovrascritte dalle impostazioni del gruppo.</translation>
    </message>
    <message>
        <source>Invalid Entry</source>
        <translation>Voce non valida</translation>
    </message>
    <message>
        <source>An external merge operation has invalidated this entry.
Unfortunately, any changes made have been lost.</source>
        <translation>Questa voce è stata invalidata da un&apos;operazione di unione esterna.
Purtroppo, le modifiche apportate sono state perse.</translation>
    </message>
    <message>
        <source>Auto-Type Validation Error</source>
        <translation>Errore di convalida della digitazione automatica</translation>
    </message>
    <message>
        <source>An error occurred while validating the custom Auto-Type sequence:
%1
Would you like to correct it?</source>
        <translation>Errore durante la convalida della sequenza di tipo automatico personalizzata:
%1
Vuoi correggerla?</translation>
    </message>
    <message>
        <source>An error occurred while validating the Auto-Type sequence for &quot;%1&quot;:
%2
Would you like to correct it?</source>
        <translation>Errore durante la convalida della sequenza di tipo automatico per &quot;%1&quot;:
%2
Vuoi correggerla?</translation>
    </message>
    <message>
        <source>Entry updated successfully.</source>
        <translation>Voce aggiornata correttamente.</translation>
    </message>
    <message>
        <source>Unsaved Changes</source>
        <translation>Modifiche non salvate</translation>
    </message>
    <message>
        <source>Would you like to save changes to this entry?</source>
        <translation>Vuoi salvare le modifiche a questa voce?</translation>
    </message>
    <message>
        <source>New attribute</source>
        <translation>Nuovo attributo</translation>
    </message>
    <message>
        <source>New attribute %1</source>
        <translation>Nuovo attributo %1</translation>
    </message>
    <message>
        <source>Are you sure you want to remove this attribute?</source>
        <translation>Sei sicuro di voler rimuovere questo attributo?</translation>
    </message>
    <message>
        <source>Reveal</source>
        <translation>Rivela</translation>
    </message>
    <message>
        <source>[PROTECTED] Press Reveal to view or edit</source>
        <translation>[PROTETTO] Seleziona &apos;Visualizza&apos; per visualizzare o modificare</translation>
    </message>
    <message>
        <source>Hide</source>
        <translation>Nascondi</translation>
    </message>
    <message numerus="yes">
        <source>%n hour(s)</source>
        <translation><numerusform>%n ora(e)</numerusform><numerusform>%n ora(e)</numerusform><numerusform>%n ora(e)</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>%n week(s)</source>
        <translation><numerusform>%n settimana</numerusform><numerusform>%n settimane</numerusform><numerusform>%n settimane</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>%n month(s)</source>
        <translation><numerusform>%n mese</numerusform><numerusform>%n mesi</numerusform><numerusform>%n mesi</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>%n year(s)</source>
        <translation><numerusform>%n anno</numerusform><numerusform>%n anni</numerusform><numerusform>%n anni</numerusform></translation>
    </message>
    <message>
        <source>Failed to decrypt SSH key, ensure password is correct.</source>
        <translation>Impossibile decriptare la chiave SSH, assicurati che la password sia corretta.</translation>
    </message>
</context>
<context>
    <name>EditEntryWidgetAdvanced</name>
    <message>
        <source>Additional attributes</source>
        <translation>Attributi aggiuntivi</translation>
    </message>
    <message>
        <source>Attribute selection</source>
        <translation>Selezione degli attributi</translation>
    </message>
    <message>
        <source>Attribute value</source>
        <translation>Valore attributo</translation>
    </message>
    <message>
        <source>Add a new attribute</source>
        <translation>Aggiungi un nuovo attributo</translation>
    </message>
    <message>
        <source>Add</source>
        <translation>Aggiungi</translation>
    </message>
    <message>
        <source>Remove selected attribute</source>
        <translation>Rimuovi attributo selezionato</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Rimuovi</translation>
    </message>
    <message>
        <source>Edit attribute name</source>
        <translation>Modifica nome attributo</translation>
    </message>
    <message>
        <source>Edit Name</source>
        <translation>Modifica nome</translation>
    </message>
    <message>
        <source>Toggle attribute protection</source>
        <translation>Attiva/disattiva la protezione attributi</translation>
    </message>
    <message>
        <source>Protect</source>
        <translation>Proteggi</translation>
    </message>
    <message>
        <source>Show a protected attribute</source>
        <translation>Visualizza un attributo protetto</translation>
    </message>
    <message>
        <source>Reveal</source>
        <translation>Rivela</translation>
    </message>
    <message>
        <source>Attachments</source>
        <translation>Allegati</translation>
    </message>
    <message>
        <source>If checked, the entry will not appear in reports like Health Check and HIBP even if it doesn&apos;t match the quality requirements.</source>
        <translation>Se selezionata, la voce non verrà visualizzata nel rapporto come Controllo salute e HIBP anche se non corrisponde ai requisiti di qualità.</translation>
    </message>
    <message>
        <source>Exclude from database reports</source>
        <translation>Escludi dal rapporto del database</translation>
    </message>
    <message>
        <source>Foreground Color:</source>
        <translation>Colore di primo piano:</translation>
    </message>
    <message>
        <source>Foreground color selection</source>
        <translation>Selezione del colore di primo piano</translation>
    </message>
    <message>
        <source>Background Color:</source>
        <translation>Colore di sfondo:</translation>
    </message>
    <message>
        <source>Background color selection</source>
        <translation>Selezione del colore di sfondo</translation>
    </message>
</context>
<context>
    <name>EditEntryWidgetAutoType</name>
    <message>
        <source>Enable Auto-Type for this entry</source>
        <translation>Abilita completamento automatico per questa voce</translation>
    </message>
    <message>
        <source>Inherit default Auto-Type sequence from the group</source>
        <translation>Eredita la sequenza predefinita di auto-completamento dal gruppo</translation>
    </message>
    <message>
        <source>Use custom Auto-Type sequence:</source>
        <translation>Usa sequenza personalizzata di auto-completamento:</translation>
    </message>
    <message>
        <source>Custom Auto-Type sequence</source>
        <translation>Sequenza personalizzata di completamento automatico</translation>
    </message>
    <message>
        <source>Open Auto-Type help webpage</source>
        <translation>Apri la pagina web di aiuto per i completamenti automatici</translation>
    </message>
    <message>
        <source>Window Associations</source>
        <translation>Associazioni finestra</translation>
    </message>
    <message>
        <source>Existing window associations</source>
        <translation>Associazioni delle finestre esistenti</translation>
    </message>
    <message>
        <source>Add new window association</source>
        <translation>Aggiungi nuova associazione finestra</translation>
    </message>
    <message>
        <source>+</source>
        <comment>Add item</comment>
        <translation>+</translation>
    </message>
    <message>
        <source>Remove selected window association</source>
        <translation>Rimuovi associazione finestra selezionata</translation>
    </message>
    <message>
        <source>-</source>
        <comment>Remove item</comment>
        <translation>-</translation>
    </message>
    <message>
        <source>Window title:</source>
        <translation>Titolo finestra:</translation>
    </message>
    <message>
        <source>You can use an asterisk (*) to match everything</source>
        <translation>È possibile usare un asterisco (*) per abbinare tutto</translation>
    </message>
    <message>
        <source>Set the window association title</source>
        <translation>Imposta il titolo dell&apos;associazione finestra</translation>
    </message>
    <message>
        <source>You can use an asterisk to match everything</source>
        <translation>È possibile usare un asterisco per abbinare tutto</translation>
    </message>
    <message>
        <source>Use a specific sequence for this association:</source>
        <translation>Usa una sequenza specifica per questa associazione:</translation>
    </message>
    <message>
        <source>Custom Auto-Type sequence for this window</source>
        <translation>Sequenza personalizzata del completamento automatico per questa finestra</translation>
    </message>
</context>
<context>
    <name>EditEntryWidgetBrowser</name>
    <message>
        <source>General</source>
        <translation>Generale</translation>
    </message>
    <message>
        <source>Hide this entry from the browser extension</source>
        <translation>Nascondi questa voce dall&apos;estensione del browser</translation>
    </message>
    <message>
        <source>Skip Auto-Submit for this entry</source>
        <translation>Ignora invio automatico per questa voce</translation>
    </message>
    <message>
        <source>Use this entry only with HTTP Basic Auth</source>
        <translation>Usa questa voce solo con l&apos;autenticazione semplice HTTP</translation>
    </message>
    <message>
        <source>Do not use this entry with HTTP Basic Auth</source>
        <translation>Non usare questa voce con l&apos;autenticazione semplice HTTP</translation>
    </message>
    <message>
        <source>Add</source>
        <translation>Aggiungi</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Rimuovi</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Modifica</translation>
    </message>
    <message>
        <source>These settings affect the entry&apos;s behaviour with the browser extension.</source>
        <translation>Queste impostazioni influenzano il comportamento della voce con l&apos;estensione browser.</translation>
    </message>
    <message>
        <source>Additional URLs</source>
        <translation>URL aggiuntive</translation>
    </message>
    <message>
        <source>Only send this entry to the browser for HTTP Auth dialogs. If enabled, normal login forms will not show this entry for selection.</source>
        <translation>Invia questa voce esclusivamente per finestre HTTP Auth. Se abilitato, le form di login normali non mostreranno questa voce come voce selezionabile.</translation>
    </message>
    <message>
        <source>Do not send this entry to the browser for HTTP Auth dialogs. If enabled, HTTP Auth dialogs will not show this entry for selection.</source>
        <translation>Non inviare questa voce al browser per finestre HTTP Auth. Se abilitato, le finestre HTTP Auth non mostreranno questa voce come voce selezionabile.</translation>
    </message>
</context>
<context>
    <name>EditEntryWidgetHistory</name>
    <message>
        <source>Entry history selection</source>
        <translation>Selezione della cronologia delle voci</translation>
    </message>
    <message>
        <source>Show entry at selected history state</source>
        <translation>Visualizza voce nello stato della cronologia selezionato</translation>
    </message>
    <message>
        <source>Show</source>
        <translation>Visualizza</translation>
    </message>
    <message>
        <source>Restore entry to selected history state</source>
        <translation>Ripristina la voce allo stato cronologia selezionato</translation>
    </message>
    <message>
        <source>Restore</source>
        <translation>Ripristina</translation>
    </message>
    <message>
        <source>Delete selected history state</source>
        <translation>Elimina lo stato cronologia selezionato</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Elimina</translation>
    </message>
    <message>
        <source>Delete all history</source>
        <translation>Elimina tutta la cronologia</translation>
    </message>
    <message>
        <source>Delete all</source>
        <translation>Elimina tutti</translation>
    </message>
</context>
<context>
    <name>EditEntryWidgetMain</name>
    <message>
        <source>Edit Entry</source>
        <translation>Modifica voce</translation>
    </message>
    <message>
        <source>Notes field</source>
        <translation>Campo note</translation>
    </message>
    <message>
        <source>Username field</source>
        <translation>Campo nome utente</translation>
    </message>
    <message>
        <source>Expiration field</source>
        <translation>Campo scadenza</translation>
    </message>
    <message>
        <source>Expiration Presets</source>
        <translation>Scadenza delle preimpostazioni</translation>
    </message>
    <message>
        <source>Expiration presets</source>
        <translation>Scadenza delle preimpostazioni</translation>
    </message>
    <message>
        <source>Presets</source>
        <translation>Preimpostazioni</translation>
    </message>
    <message>
        <source>Url field</source>
        <translation>Campo Url</translation>
    </message>
    <message>
        <source>Download favicon for URL</source>
        <translation>Scarica favicon per URL</translation>
    </message>
    <message>
        <source>Title field</source>
        <translation>Campo del titolo</translation>
    </message>
    <message>
        <source>Password field</source>
        <translation>Campo password</translation>
    </message>
    <message>
        <source>Toggle expiration</source>
        <translation>Attiva/disattiva scadenza</translation>
    </message>
    <message>
        <source>Tags list</source>
        <translation>Elenco delle etichette</translation>
    </message>
    <message>
        <source>&amp;Username:</source>
        <translation>&amp;Nome utente:</translation>
    </message>
    <message>
        <source>&amp;Title:</source>
        <translation>&amp;Titolo:</translation>
    </message>
    <message>
        <source>&amp;Password:</source>
        <translation>&amp;Password:</translation>
    </message>
    <message>
        <source>UR&amp;L:</source>
        <translation>UR&amp;L:</translation>
    </message>
    <message>
        <source>&amp;Notes:</source>
        <translation>&amp;Note:</translation>
    </message>
    <message>
        <source>Toggle notes visibility</source>
        <translation>Visualizza/nascondi note</translation>
    </message>
    <message>
        <source>T&amp;ags:</source>
        <translation>E&amp;tichette:</translation>
    </message>
    <message>
        <source>&amp;Expires:</source>
        <translation>&amp;Scadenza:</translation>
    </message>
</context>
<context>
    <name>EditEntryWidgetSSHAgent</name>
    <message>
        <source>Form</source>
        <translation>Modulo</translation>
    </message>
    <message>
        <source>Remove key from agent when database is closed/locked</source>
        <translation>Rimuovi chiave dall&apos;agente quando il database viene chiuso/bloccato</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>Commento</translation>
    </message>
    <message>
        <source>Add key to agent when database is opened/unlocked</source>
        <translation>Aggiungi chiave all&apos;agente quando il database viene aperto/sbloccato</translation>
    </message>
    <message>
        <source>Decrypt</source>
        <translation>Decifra</translation>
    </message>
    <message>
        <source>Fingerprint</source>
        <translation>Impronta digitale</translation>
    </message>
    <message>
        <source>Copy to clipboard</source>
        <translation>Copia negli Appunti</translation>
    </message>
    <message>
        <source>Public key</source>
        <translation>Chiave pubblica</translation>
    </message>
    <message>
        <source>Private key</source>
        <translation>Chiave privata</translation>
    </message>
    <message>
        <source>Attachment</source>
        <translation>Allegato</translation>
    </message>
    <message>
        <source>External key file</source>
        <translation>File chiave esterno</translation>
    </message>
    <message>
        <source>Add to agent</source>
        <translation>Aggiungi all&apos;agente</translation>
    </message>
    <message>
        <source>Remove from agent</source>
        <translation>Rimuovi dall&apos;agente</translation>
    </message>
    <message>
        <source>External file</source>
        <translation>File esterno</translation>
    </message>
    <message>
        <source>Browser for key file</source>
        <translation>Selezione file chiave</translation>
    </message>
    <message>
        <source>Browse…</source>
        <extracomment>Button for opening file dialog</extracomment>
        <translation>Sfoglia…</translation>
    </message>
    <message>
        <source>Generate</source>
        <translation>Genera</translation>
    </message>
    <message>
        <source>Select attachment file</source>
        <translation>Seleziona file allegato</translation>
    </message>
    <message>
        <source>Require user confirmation when this key is used</source>
        <translation>Richiesta conferma dell&apos;utente quando questa chiave è usata</translation>
    </message>
    <message>
        <source>n/a</source>
        <translation>n/a</translation>
    </message>
    <message>
        <source>Remove key from agent after</source>
        <translation>Rimuovi chiave dall&apos;agente dopo</translation>
    </message>
    <message>
        <source>Remove key from agent after specified seconds</source>
        <translation>Rimuovi chiave dall&apos;agente dopo i secondi specificati</translation>
    </message>
    <message>
        <source> seconds</source>
        <translation> secondi</translation>
    </message>
    <message>
        <source>Clear agent</source>
        <translation>Cancella agent</translation>
    </message>
</context>
<context>
    <name>EditGroupWidget</name>
    <message>
        <source>Group</source>
        <translation>Gruppo</translation>
    </message>
    <message>
        <source>Icon</source>
        <translation>Icona</translation>
    </message>
    <message>
        <source>Properties</source>
        <translation>Proprietà</translation>
    </message>
    <message>
        <source>Add group</source>
        <translation>Aggiungi gruppo</translation>
    </message>
    <message>
        <source>Edit group</source>
        <translation>Modifica gruppo</translation>
    </message>
    <message>
        <source>Group has unsaved changes</source>
        <translation>Il gruppo ha modifiche non salvate</translation>
    </message>
    <message>
        <source>Browser Integration</source>
        <translation>Integrazione browser</translation>
    </message>
    <message>
        <source>Enable</source>
        <translation>Abilita</translation>
    </message>
    <message>
        <source>Disable</source>
        <translation>Disabilita</translation>
    </message>
    <message>
        <source>Inherit from parent group (%1)</source>
        <translation>Eredita dal gruppo genitore (%1)</translation>
    </message>
</context>
<context>
    <name>EditGroupWidgetBrowser</name>
    <message>
        <source>These settings affect to the group&apos;s behaviour with the browser extension.</source>
        <translation>Queste impostazioni influiscono sul comportamento del gruppo con l&apos;estensione del browser.</translation>
    </message>
    <message>
        <source>Hide entries from browser extension:</source>
        <translation>Nascondi le voci dall&apos;estensione del browser:</translation>
    </message>
    <message>
        <source>Hide entries from browser extension toggle for this and sub groups</source>
        <translation>Nascondi le voci dall&apos;interruttore dell&apos;estensione del browser per questo e sottogruppi</translation>
    </message>
    <message>
        <source>Skip Auto-Submit for entries:</source>
        <translation>Salta l&apos;invio automatico per le voci:</translation>
    </message>
    <message>
        <source>Skip Auto-Submit toggle for this and sub groups</source>
        <translation>Salta l&apos;interruttore invio automatico per questo e sottogruppi</translation>
    </message>
    <message>
        <source>Use entries only with HTTP Basic Auth:</source>
        <translation>Usa le voci solo con l&apos;autenticazione semplice HTTP:</translation>
    </message>
    <message>
        <source>Only HTTP Auth toggle for this and sub groups</source>
        <translation>Solo l&apos;interruttore di autenticazione HTTP per questo e sottogruppi</translation>
    </message>
    <message>
        <source>Do not use entries with HTTP Basic Auth:</source>
        <translation>Non usare voci con autenticazione semplice HTTP:</translation>
    </message>
    <message>
        <source>Do not use HTTP Auth toggle for this and sub groups</source>
        <translation>Non usare l&apos;interruttore di autenticazione HTTP per questo e sottogruppi</translation>
    </message>
    <message>
        <source>Omit WWW subdomain from matching:</source>
        <translation>Ometti il sottodominio WWW dalla corrispondenza:</translation>
    </message>
    <message>
        <source>Omit WWW subdomain from matching toggle for this and sub groups</source>
        <translation>Ometti il sottodominio WWW dal selettore corrispondente per questo e sottogruppi</translation>
    </message>
    <message>
        <source>Restrict matching to given browser key:</source>
        <translation>Restringi corrispondenza alla chiave browser fornita:</translation>
    </message>
    <message>
        <source>Restrict matching to given browser key toggle for this and sub groups</source>
        <translation>Limita la corrispondenza ad un determinato tasto del browser per questo e sottogruppi</translation>
    </message>
</context>
<context>
    <name>EditGroupWidgetKeeShare</name>
    <message>
        <source>Sharing mode field</source>
        <translation>Campo modalità di condivisione</translation>
    </message>
    <message>
        <source>Password field</source>
        <translation>Campo password</translation>
    </message>
    <message>
        <source>Type:</source>
        <translation>Tipo:</translation>
    </message>
    <message>
        <source>Password:</source>
        <translation>Password:</translation>
    </message>
    <message>
        <source>Path:</source>
        <translation>Percorso:</translation>
    </message>
    <message>
        <source>Path to share file field</source>
        <translation>Campo percorso per condividere il file</translation>
    </message>
    <message>
        <source>Browse for share file</source>
        <translation>Cerca file per condivisione</translation>
    </message>
    <message>
        <source>Browse…</source>
        <translation>Sfoglia…</translation>
    </message>
    <message>
        <source>Clear fields</source>
        <translation>Azzera campi</translation>
    </message>
    <message>
        <source>Clear</source>
        <translation>Azzera</translation>
    </message>
    <message>
        <source>Inactive</source>
        <translation>Inattivo</translation>
    </message>
    <message>
        <source>Import</source>
        <translation>Importa</translation>
    </message>
    <message>
        <source>Export</source>
        <translation>Esporta</translation>
    </message>
    <message>
        <source>Synchronize</source>
        <translation>Sincronizzare</translation>
    </message>
    <message>
        <source>Your KeePassXC version does not support sharing this container type.
Supported extensions are: %1.</source>
        <translation>Questa versione di KeePassXC non supporta la condivisione di questo tipo di contenitore.
Le estensioni supportate sono: &apos;%1&apos;.</translation>
    </message>
    <message>
        <source>%1 is already being exported by this database.</source>
        <translation>%1 è già stato esportato da questo database.</translation>
    </message>
    <message>
        <source>%1 is already being imported by this database.</source>
        <translation>%1 è già stato importato da questo database.</translation>
    </message>
    <message>
        <source>%1 is being imported and exported by different groups in this database.</source>
        <translation>%1 viene importato ed esportato da gruppi diversi in questo database.</translation>
    </message>
    <message>
        <source>KeeShare is currently disabled. You can enable import/export in the application settings.</source>
        <comment>KeeShare is a proper noun</comment>
        <translation>KeeShare è attualmente disabilitato. È possibile abilitare l&apos;importazione/esportazione nelle impostazioni dell&apos;applicazione.</translation>
    </message>
    <message>
        <source>Database export is currently disabled by application settings.</source>
        <translation>L&apos;esportazione del database è attualmente disabilitata dalle impostazioni dell&apos;applicazione.</translation>
    </message>
    <message>
        <source>Database import is currently disabled by application settings.</source>
        <translation>L&apos;importazione del database è attualmente disabilitata dalle impostazioni dell&apos;applicazione.</translation>
    </message>
    <message>
        <source>KeeShare container</source>
        <translation>Contenitore KeeShare</translation>
    </message>
    <message>
        <source>KeeShare signed container</source>
        <translation>Contenitore firmato KeeShare</translation>
    </message>
    <message>
        <source>Select import source</source>
        <translation>Seleziona sorgente importazione</translation>
    </message>
    <message>
        <source>Select export target</source>
        <translation>Seleziona destinazione di esportazione</translation>
    </message>
    <message>
        <source>Select import/export file</source>
        <translation>Seleziona file importazione/esportazione</translation>
    </message>
    <message>
        <source>Maintain group structure with shared database</source>
        <translation>Mantieni la struttura del gruppo nel database condiviso</translation>
    </message>
    <message>
        <source>Keep Group Structure</source>
        <translation>Mantieni struttura gruppo</translation>
    </message>
</context>
<context>
    <name>EditGroupWidgetMain</name>
    <message>
        <source>Edit Group</source>
        <translation>Modifica gruppo</translation>
    </message>
    <message>
        <source>Toggle expiration</source>
        <translation>Attiva/disattiva scadenza</translation>
    </message>
    <message>
        <source>Expires:</source>
        <translation>Scade:</translation>
    </message>
    <message>
        <source>Name field</source>
        <translation>Campo nome</translation>
    </message>
    <message>
        <source>Expiration field</source>
        <translation>Campo scadenza</translation>
    </message>
    <message>
        <source>Use default Auto-Type sequence of parent group</source>
        <translation>Usa la sequenza di completamento automatico predefinita del gruppo genitore</translation>
    </message>
    <message>
        <source>Auto-Type:</source>
        <translation>Completamento automatico:</translation>
    </message>
    <message>
        <source>Search:</source>
        <translation>Ricerca:</translation>
    </message>
    <message>
        <source>Auto-Type toggle for this and sub groups</source>
        <translation>Attiva/disattiva il completamento automatico per questo e i sottogruppi</translation>
    </message>
    <message>
        <source>Notes:</source>
        <translation>Note:</translation>
    </message>
    <message>
        <source>Default auto-type sequence field</source>
        <translation>Campo della sequenza del completamento automatico predefinito</translation>
    </message>
    <message>
        <source>Notes field</source>
        <translation>Campo note</translation>
    </message>
    <message>
        <source>Name:</source>
        <translation>Nome:</translation>
    </message>
    <message>
        <source>Set default Auto-Type sequence</source>
        <translation>Imposta sequenza predefinita completamento automatico</translation>
    </message>
    <message>
        <source>Search toggle for this and sub groups</source>
        <translation>Attiva/disattiva ricerca per questo e per i sottogruppi</translation>
    </message>
</context>
<context>
    <name>EditWidgetIcons</name>
    <message>
        <source>Use default icon</source>
        <translation>Usa icona predefinita</translation>
    </message>
    <message>
        <source>Use custom icon</source>
        <translation>Usa icona personalizzata</translation>
    </message>
    <message>
        <source>Choose icon…</source>
        <translation>Scegli l&apos;icona...</translation>
    </message>
    <message>
        <source>Set the URL to use to search for a favicon</source>
        <translation>Imposta l&apos;URL da usare per cercare una favicon</translation>
    </message>
    <message>
        <source>Favicon URL</source>
        <translation>URL favicon</translation>
    </message>
    <message>
        <source>Download favicon for URL</source>
        <translation>Scarica favicon per URL</translation>
    </message>
    <message>
        <source>Download favicon</source>
        <translation>Scarica favicon</translation>
    </message>
    <message>
        <source>Apply selected icon to subgroups and entries</source>
        <translation>Applica l&apos;icona selezionata a sottogruppi e voci</translation>
    </message>
    <message>
        <source>Apply icon to…</source>
        <translation>Applica l&apos;icona a...</translation>
    </message>
    <message>
        <source>Apply to this group only</source>
        <translation>Applica solo a questo gruppo</translation>
    </message>
    <message>
        <source>Also apply to child groups</source>
        <translation>Applica anche ai gruppi figli</translation>
    </message>
    <message>
        <source>Also apply to child entries</source>
        <translation>Applica alle voci figlie</translation>
    </message>
    <message>
        <source>Also apply to all children</source>
        <translation>Applica anche a tutti i figli</translation>
    </message>
    <message>
        <source>Unable to fetch favicon.</source>
        <translation>Impossibile scaricare favicon.</translation>
    </message>
    <message>
        <source>Existing icon selected.</source>
        <translation>Icona esistente selezionata.</translation>
    </message>
    <message>
        <source>Images</source>
        <translation>Immagini</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>Tutti i file</translation>
    </message>
    <message>
        <source>Select Image(s)</source>
        <translation>Seleziona immagine/i</translation>
    </message>
    <message numerus="yes">
        <source>Successfully loaded %1 of %n icon(s)</source>
        <translation><numerusform>Caricate con successo %1 di %n icona.</numerusform><numerusform>Caricate con successo %1 di %n icone.</numerusform><numerusform>Caricate con successo %1 di %n icone.</numerusform></translation>
    </message>
    <message>
        <source>No icons were loaded</source>
        <translation>Nessuna icona è stata caricata</translation>
    </message>
    <message numerus="yes">
        <source>%n icon(s) already exist in the database</source>
        <translation><numerusform>%n icona esiste già nel database</numerusform><numerusform>%n icone esistono già nel database</numerusform><numerusform>%n icone esistono già nel database</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>The following icon(s) failed:</source>
        <translation><numerusform>La seguente icona presenta degli errori:</numerusform><numerusform>Le seguenti icone presentano degli errori:</numerusform><numerusform>Le seguenti icone presentano degli errori:</numerusform></translation>
    </message>
    <message>
        <source>You can enable the DuckDuckGo website icon service under Application Settings -&gt; Security</source>
        <translation>Puoi attivare il servizio di DuckDuckGo per le icone dei siti web da Impostazioni applicazione -&gt; Sicurezza</translation>
    </message>
</context>
<context>
    <name>EditWidgetProperties</name>
    <message>
        <source>Created:</source>
        <translation>Creazione:</translation>
    </message>
    <message>
        <source>Datetime created</source>
        <translation>Data e ora di creazione</translation>
    </message>
    <message>
        <source>Modified:</source>
        <translation>Modifica:</translation>
    </message>
    <message>
        <source>Datetime modified</source>
        <translation>Data/ora di modifica</translation>
    </message>
    <message>
        <source>Uuid:</source>
        <translation>UUID:</translation>
    </message>
    <message>
        <source>Unique ID</source>
        <translation>ID univoco</translation>
    </message>
    <message>
        <source>Plugin Data</source>
        <translation>Dati del plugin</translation>
    </message>
    <message>
        <source>Plugin data</source>
        <translation>Dati del plug-in</translation>
    </message>
    <message>
        <source>Remove selected plugin data</source>
        <translation>Rimuovi dati plugin selezionato</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Rimuovi</translation>
    </message>
    <message>
        <source>Delete plugin data?</source>
        <translation>Vuoi eliminare i dati del plugin?</translation>
    </message>
    <message>
        <source>Do you really want to delete the selected plugin data?
This may cause the affected plugins to malfunction.</source>
        <translation>Vuoi eliminare i dati dei plugin selezionati?
Questo potrebbe causare malfunzionamenti ai plugin interessati.</translation>
    </message>
    <message>
        <source>Key</source>
        <translation>Chiave</translation>
    </message>
    <message>
        <source>Value</source>
        <translation>Valore</translation>
    </message>
</context>
<context>
    <name>Entry</name>
    <message>
        <source>%1 - Clone</source>
        <translation>%1 - clone</translation>
    </message>
    <message>
        <source>Passkey</source>
        <translation>Passkey</translation>
    </message>
    <message>
        <source>Invalid conversion type: %1</source>
        <translation>Tipo conversione non valido: %1</translation>
    </message>
    <message>
        <source>Invalid conversion syntax: %1</source>
        <translation>Sintassi conversione non valida: %1</translation>
    </message>
    <message>
        <source>Invalid regular expression syntax %1
%2</source>
        <translation>Sintassi espressione regolare non valida %1 
%2</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>Titolo</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>Nome utente</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Password</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>Notes</source>
        <translation>Note</translation>
    </message>
    <message>
        <source>Custom Attributes</source>
        <translation>Attributi personalizzati</translation>
    </message>
    <message>
        <source>Icon</source>
        <translation>Icona</translation>
    </message>
    <message>
        <source>Color</source>
        <translation>Colore</translation>
    </message>
    <message>
        <source>Expiration</source>
        <translation>Scadenza</translation>
    </message>
    <message>
        <source>TOTP</source>
        <translation>TOTP</translation>
    </message>
    <message>
        <source>Custom Data</source>
        <translation>Dati personalizzati</translation>
    </message>
    <message>
        <source>Attachments</source>
        <translation>Allegati</translation>
    </message>
    <message>
        <source>Auto-Type</source>
        <translation>Completamento automatico</translation>
    </message>
    <message>
        <source>Tags</source>
        <translation>Etichette</translation>
    </message>
</context>
<context>
    <name>EntryAttachments</name>
    <message>
        <source>Cannot open file &quot;%1&quot;</source>
        <translation>Impossibile aprire il file &quot;%1&quot;</translation>
    </message>
</context>
<context>
    <name>EntryAttachmentsModel</name>
    <message>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Dimensione</translation>
    </message>
</context>
<context>
    <name>EntryAttachmentsWidget</name>
    <message>
        <source>Form</source>
        <translation>Modulo</translation>
    </message>
    <message>
        <source>Attachments</source>
        <translation>Allegati</translation>
    </message>
    <message>
        <source>Add new attachment</source>
        <translation>Aggiungi nuovo allegato</translation>
    </message>
    <message>
        <source>Remove selected attachment</source>
        <translation>Rimuovi allegato selezionato</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Rimuovi</translation>
    </message>
    <message>
        <source>Open selected attachment</source>
        <translation>Apri allegato selezionato</translation>
    </message>
    <message>
        <source>Open</source>
        <translation>Apri</translation>
    </message>
    <message>
        <source>Save selected attachment to disk</source>
        <translation>Salva l&apos;allegato selezionato su disco</translation>
    </message>
    <message>
        <source>Select files</source>
        <translation>Seleziona file</translation>
    </message>
    <message>
        <source>Confirm remove</source>
        <translation>Conferma rimozione</translation>
    </message>
    <message numerus="yes">
        <source>Are you sure you want to remove %n attachment(s)?</source>
        <translation><numerusform>Sei sicuro di voler rimuovere %n allegato?</numerusform><numerusform>Sei sicuro di voler rimuovere %n allegati?</numerusform><numerusform>Sei sicuro di voler rimuovere %n allegati?</numerusform></translation>
    </message>
    <message>
        <source>Save attachments</source>
        <translation>Salva allegati</translation>
    </message>
    <message>
        <source>Unable to create directory:
%1</source>
        <translation>Impossibile creare la cartella:
%1</translation>
    </message>
    <message>
        <source>Are you sure you want to overwrite the existing file &quot;%1&quot; with the attachment?</source>
        <translation>Sei sicuro di sovrascrivere il file &quot;%1&quot; esistente con l&apos;allegato?</translation>
    </message>
    <message>
        <source>Confirm overwrite</source>
        <translation>Conferma sovrascrittura</translation>
    </message>
    <message>
        <source>Unable to save attachments:
%1</source>
        <translation>Impossibile salvare l&apos;allegato:
%1</translation>
    </message>
    <message>
        <source>Unable to open attachment:
%1</source>
        <translation>Impossibile aprire l&apos;allegato:
%1</translation>
    </message>
    <message>
        <source>Unable to open attachments:
%1</source>
        <translation>Impossibile aprire gli allegati:
%1</translation>
    </message>
    <message numerus="yes">
        <source>Unable to open file(s):
%1</source>
        <translation><numerusform>Impossibile aprire il file:
%1</numerusform><numerusform>Impossibile aprire i file:
%1</numerusform><numerusform>Impossibile aprire i file:
%1</numerusform></translation>
    </message>
    <message>
        <source>Confirm Overwrite Attachment</source>
        <translation>Conferma sovrascrittura allegato</translation>
    </message>
    <message>
        <source>Confirm Attachment</source>
        <translation>Conferma l&apos;allegato </translation>
    </message>
    <message>
        <source>%1 is a big file (%2 MB).
Your database may get very large and reduce performance.

Are you sure to add this file?</source>
        <translation>%1 ha dimensioni elevate (%2 MB).
Il database potrebbe occupare più spazio e ridurre le sue performance.

Sei sicuro di voler aggiungere questo file?</translation>
    </message>
    <message>
        <source>Attachment modified</source>
        <translation>Allegato modificato</translation>
    </message>
    <message>
        <source>The attachment '%1' was modified.
Do you want to save the changes to your database?</source>
        <translation>L&apos;allegato &apos;%1&apos; è stato modificato.
Vuoi salvare le modifiche nel database?</translation>
    </message>
    <message>
        <source>Saving attachment failed</source>
        <translation>Salvataggio dell&apos;allegato non riuscito</translation>
    </message>
    <message>
        <source>Saving updated attachment failed.
Error: %1</source>
        <translation>Salvataggio allegato aggiornato non riuscito.
Errore: %1</translation>
    </message>
    <message>
        <source>Attachment &quot;%1&quot; already exists. 
Would you like to overwrite the existing attachment?</source>
        <translation>L&apos;allegato &quot;%1&quot; esiste già. 
Vuoi sovrascrivere l&apos;allegato esistente?</translation>
    </message>
    <message>
        <source>Preview</source>
        <translation>Anteprima</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Modifica</translation>
    </message>
    <message>
        <source>New Text Document</source>
        <translation>Nuovo documento testo</translation>
    </message>
    <message>
        <source>Add file…</source>
        <translation>Aggiungi file...</translation>
    </message>
    <message>
        <source>Load from Disk…</source>
        <translation>Carica da disco...</translation>
    </message>
    <message>
        <source>Save…</source>
        <translation>Salva...</translation>
    </message>
    <message>
        <source>New Attachment</source>
        <translation>Nuovo allegato</translation>
    </message>
</context>
<context>
    <name>EntryAttributesModel</name>
    <message>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
</context>
<context>
    <name>EntryHistoryModel</name>
    <message>
        <source>Current (%1)</source>
        <translation>Corrente (%1)</translation>
    </message>
    <message>
        <source>Last modified</source>
        <translation>Ultima modifica</translation>
    </message>
    <message>
        <source>Age</source>
        <translation>Età</translation>
    </message>
    <message>
        <source>Difference</source>
        <translation>Differenza</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Dimensione</translation>
    </message>
</context>
<context>
    <name>EntryModel</name>
    <message>
        <source>Ref: </source>
        <comment>Reference abbreviation</comment>
        <translation>Rif.: </translation>
    </message>
    <message>
        <source>Never</source>
        <translation>Mai</translation>
    </message>
    <message>
        <source>Group</source>
        <translation>Gruppo</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>Titolo</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>Nome utente</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Password</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>Notes</source>
        <translation>Note</translation>
    </message>
    <message>
        <source>Expires</source>
        <translation>Scade</translation>
    </message>
    <message>
        <source>Created</source>
        <translation>Creazione</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Modifica</translation>
    </message>
    <message>
        <source>Attachments</source>
        <translation>Allegati</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Dimensione</translation>
    </message>
    <message>
        <source>Group name</source>
        <translation>Nome del gruppo</translation>
    </message>
    <message>
        <source>Entry title</source>
        <translation>Titolo della voce</translation>
    </message>
    <message>
        <source>Password Strength</source>
        <translation>Sicurezza password</translation>
    </message>
    <message>
        <source>Entry notes</source>
        <translation>Note della voce</translation>
    </message>
    <message>
        <source>Entry expires at</source>
        <translation>La voce scade il</translation>
    </message>
    <message>
        <source>Creation date</source>
        <translation>Data di creazione</translation>
    </message>
    <message>
        <source>Last modification date</source>
        <translation>Ultima modifica</translation>
    </message>
    <message>
        <source>Attached files</source>
        <translation>Allegati</translation>
    </message>
    <message>
        <source>Entry size</source>
        <translation>Dimensioni della voce</translation>
    </message>
    <message>
        <source>Has attachments</source>
        <translation>Ha allegati</translation>
    </message>
    <message>
        <source>Has TOTP</source>
        <translation>Ha TOTP</translation>
    </message>
    <message>
        <source>Background Color</source>
        <translation>Colore di sfondo</translation>
    </message>
    <message>
        <source>Group Path</source>
        <translation>Percorso gruppo</translation>
    </message>
</context>
<context>
    <name>EntryPreviewWidget</name>
    <message>
        <source>Display current TOTP value</source>
        <translation>Visualizza il valore TOTP attuale</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Chiudi</translation>
    </message>
    <message>
        <source>General</source>
        <translation>Generale</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Password</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>Expiration</source>
        <translation>Scadenza</translation>
    </message>
    <message>
        <source>Tags</source>
        <translation>Etichette</translation>
    </message>
    <message>
        <source>Tags list</source>
        <translation>Elenco delle etichette</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>Nome utente</translation>
    </message>
    <message>
        <source>Notes</source>
        <translation>Note</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>Avanzate</translation>
    </message>
    <message>
        <source>Attachments</source>
        <translation>Allegati</translation>
    </message>
    <message>
        <source>Attributes</source>
        <translation>Attributi</translation>
    </message>
    <message>
        <source>Autotype</source>
        <translation>Completamento automatico</translation>
    </message>
    <message>
        <source>Default Sequence</source>
        <translation>Sequenza predefinita</translation>
    </message>
    <message>
        <source>Window</source>
        <translation>Finestra</translation>
    </message>
    <message>
        <source>Sequence</source>
        <translation>Sequenza</translation>
    </message>
    <message>
        <source>Searching</source>
        <translation>Ricerca</translation>
    </message>
    <message>
        <source>Share</source>
        <translation>Condividi</translation>
    </message>
    <message>
        <source>Search</source>
        <translation>Cerca</translation>
    </message>
    <message>
        <source>Clear</source>
        <translation>Azzera</translation>
    </message>
    <message>
        <source>Never</source>
        <translation>Mai</translation>
    </message>
    <message>
        <source>Double click to copy value</source>
        <translation>Doppio clic per copiare il valore</translation>
    </message>
    <message>
        <source>Enabled</source>
        <translation>Abilitato</translation>
    </message>
    <message>
        <source>Disabled</source>
        <translation>Disabilitato</translation>
    </message>
    <message>
        <source>Double click to copy to clipboard</source>
        <translation>Fare doppio clic per copiare negli appunti</translation>
    </message>
</context>
<context>
    <name>EntryURLModel</name>
    <message>
        <source>Invalid URL</source>
        <translation>URL non corretto</translation>
    </message>
    <message>
        <source>Duplicate URL</source>
        <translation>URL duplicato</translation>
    </message>
</context>
<context>
    <name>EntryView</name>
    <message>
        <source>Fit to window</source>
        <translation>Adatta alla finestra</translation>
    </message>
    <message>
        <source>Fit to contents</source>
        <translation>Adatta ai contenuti</translation>
    </message>
    <message>
        <source>Reset to defaults</source>
        <translation>Ripristina valori predefiniti</translation>
    </message>
    <message numerus="yes">
        <source>+ %1 entry(s)...</source>
        <translation><numerusform>+ %1 voce(i)...</numerusform><numerusform>+ %1 voce(i)...</numerusform><numerusform>+ %1 voce/i...</numerusform></translation>
    </message>
</context>
<context>
    <name>ExportDialog</name>
    <message>
        <source>Export options</source>
        <translation>Opzioni di esportazione</translation>
    </message>
    <message>
        <source>Sort entries by...</source>
        <translation>Ordina le voci per...</translation>
    </message>
    <message>
        <source>You are about to export your database to an unencrypted file.
This will leave your passwords and sensitive information vulnerable!
</source>
        <translation>Stai per esportare il database in un file non cifrato.
Questo lascerà vulnerabili le password e le informazioni sensibili!
</translation>
    </message>
    <message>
        <source>database order</source>
        <translation>ordine del database</translation>
    </message>
    <message>
        <source>name (ascending)</source>
        <translation>nome (crescente)</translation>
    </message>
    <message>
        <source>name (descending)</source>
        <translation>nome (decrescente)</translation>
    </message>
    <message>
        <source>Export database to HTML file</source>
        <translation>Esporta il database in un file HTML</translation>
    </message>
    <message>
        <source>HTML file</source>
        <translation>File HTML</translation>
    </message>
    <message>
        <source>invalid sort order</source>
        <translation>ordinamento non valido</translation>
    </message>
</context>
<context>
    <name>FdoSecrets::DBusMgr</name>
    <message>
        <source>Failed to deliver message</source>
        <translation>Impossibile recapitare il messaggio</translation>
    </message>
    <message>
        <source>Failed to send reply on DBus</source>
        <translation>Impossibile inviare la risposta su DBus</translation>
    </message>
    <message>
        <source>Unknown</source>
        <comment>Unknown PID</comment>
        <translation>Sconosciuto</translation>
    </message>
    <message>
        <source>Unknown</source>
        <comment>Unknown executable path</comment>
        <translation>Sconosciuto</translation>
    </message>
    <message>
        <source>&lt;i&gt;PID: %1, Executable: %2&lt;/i&gt;</source>
        <comment>&lt;i&gt;PID: 1234, Executable: /path/to/exe&lt;/i&gt;</comment>
        <translation>&lt;i&gt;PID: %1, Eseguibile: %2&lt;/i&gt;</translation>
    </message>
    <message>
        <source>Another secret service is running (%1).&lt;br/&gt;Please stop/remove it before re-enabling the Secret Service Integration.</source>
        <translation>Un altro servizio segreto è già in esecuzione (%1).&lt;br/&gt;Fermalo o rimuovilo prima di abilitare l&apos;integrazione dei servizi segreti.</translation>
    </message>
    <message>
        <source>Failed to register DBus service at %1.&lt;br/&gt;</source>
        <translation>Impossibile registrare il servizio DBus a %1.&lt;br/&gt;</translation>
    </message>
    <message>
        <source>Failed to register service on DBus at path &apos;%1&apos;</source>
        <translation>Impossibile registrare il servizio su DBus nel percorso &apos;%1&apos;</translation>
    </message>
    <message>
        <source>Failed to register database on DBus under the name &apos;%1&apos;</source>
        <translation>Impossibile registrare il database in DBus con il nome &apos;%1&apos;</translation>
    </message>
    <message>
        <source>Failed to register session on DBus at path &apos;%1&apos;</source>
        <translation>Impossibile registrare la sessione su DBus nel percorso &apos;%1&apos;</translation>
    </message>
    <message>
        <source>Failed to register item on DBus at path &apos;%1&apos;</source>
        <translation>Impossibile registrare l&apos;elemento in DBus nel percorso &apos;%1&apos;</translation>
    </message>
    <message>
        <source>Failed to register prompt object on DBus at path &apos;%1&apos;</source>
        <translation>Impossibile registrare l&apos;oggetto prompt su DBus nel percorso &apos;%1&apos;</translation>
    </message>
</context>
<context>
    <name>FdoSecrets::Item</name>
    <message>
        <source>Entry &quot;%1&quot; from database &quot;%2&quot; was used by %3</source>
        <translation>La voce &quot;%1&quot; dal database &quot;%2&quot; è stata usata da %3</translation>
    </message>
</context>
<context>
    <name>FdoSecrets::Service</name>
    <message numerus="yes">
        <source>%n Entry(s) was used by %1</source>
        <comment>%1 is the name of an application</comment>
        <translation><numerusform>%n voce utilizzata da %1</numerusform><numerusform>%n voci utilizzate da %1</numerusform><numerusform>%n voci utilizzate da %1</numerusform></translation>
    </message>
</context>
<context>
    <name>FdoSecrets::SettingsClientModel</name>
    <message>
        <source>Unknown</source>
        <translation>Sconosciuto</translation>
    </message>
    <message>
        <source>Non-existing/inaccessible executable path. Please double-check the client is legit.</source>
        <translation>Percorso eseguibile non esistente/inaccessibile. Ricontrolla che il client sia legittimo.</translation>
    </message>
</context>
<context>
    <name>FdoSecrets::SettingsDatabaseModel</name>
    <message>
        <source>Unlock to show</source>
        <translation>Sblocca per visualizzare</translation>
    </message>
    <message>
        <source>None</source>
        <translation>Nessuno</translation>
    </message>
</context>
<context>
    <name>FdoSecrets::UnlockPrompt</name>
    <message>
        <source>%1 (PID: %2)</source>
        <translation>%1 (PID: %2)</translation>
    </message>
</context>
<context>
    <name>FdoSecretsPlugin</name>
    <message>
        <source>&lt;b&gt;Fdo Secret Service:&lt;/b&gt; %1</source>
        <translation>&lt;b&gt;Fdo Secret Service:&lt;/b&gt; %1</translation>
    </message>
</context>
<context>
    <name>GlobalShortcutsPortal</name>
    <message>
        <source>KeePassXC - Global Shortcuts</source>
        <translation>KeePassXC - Scorciatoie globali</translation>
    </message>
    <message>
        <source>The XDG Desktop Portal for global shortcuts is not available on this system.</source>
        <translation>In questo sistema il portale desktop XDG per i collegamenti globali non è disponibile.</translation>
    </message>
    <message>
        <source>Global Auto-Type shortcut is already configured. To change it, open your system settings and navigate to the keyboard or application shortcuts section.</source>
        <translation>La scorciatoia globale per il completamento automatico è già configurata. Per modificarla, apri le impostazioni di sistema e vai alla sezione relativa alle scorciatoie da tastiera o alle applicazioni.</translation>
    </message>
    <message>
        <source>Trigger global Auto-Type</source>
        <translation>Attiva il completamento automatico globale</translation>
    </message>
</context>
<context>
    <name>Group</name>
    <message>
        <source>[empty]</source>
        <comment>group has no children</comment>
        <translation>[vuoto]</translation>
    </message>
    <message>
        <source>%1 - Clone</source>
        <translation>%1 - clone</translation>
    </message>
</context>
<context>
    <name>HibpDownloader</name>
    <message>
        <source>Online password validation failed</source>
        <translation>Validazione online della password non riuscita</translation>
    </message>
</context>
<context>
    <name>IconDownloaderDialog</name>
    <message>
        <source>Download Favicons</source>
        <translation>Scarica favicon</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Annulla</translation>
    </message>
    <message>
        <source>Having trouble downloading icons?
You can enable the DuckDuckGo website icon service in the security section of the application settings.</source>
        <translation>Hai problemi a scaricare le icone?
È possibile attivare il servizio per le icone del sito web DuckDuckGo nella sezione Sicurezza delle impostazioni dell&apos;applicazione.</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Chiudi</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Stato</translation>
    </message>
    <message>
        <source>Please wait, processing entry list…</source>
        <translation>Attendere, elaborazione della lista di immissione...</translation>
    </message>
    <message>
        <source>Downloading…</source>
        <translation>Scaricare...</translation>
    </message>
    <message>
        <source>Ok</source>
        <translation>Ok</translation>
    </message>
    <message>
        <source>Already Exists</source>
        <translation>Esiste già</translation>
    </message>
    <message>
        <source>Download Failed</source>
        <translation>Download non riuscito</translation>
    </message>
    <message>
        <source>Downloading favicons (%1/%2)…</source>
        <translation>Scaricamento delle favicon (%1/%2)...</translation>
    </message>
</context>
<context>
    <name>ImageAttachmentsWidget</name>
    <message>
        <source>Zoom:</source>
        <translation>Zoom:</translation>
    </message>
    <message>
        <source>Fit</source>
        <translation>Adatta</translation>
    </message>
</context>
<context>
    <name>ImportWizard</name>
    <message>
        <source>Import Wizard</source>
        <translation>Procedura guida importazione</translation>
    </message>
</context>
<context>
    <name>ImportWizardPageReview</name>
    <message>
        <source>WizardPage</source>
        <translation>Pagina procedura guidata</translation>
    </message>
    <message>
        <source>Entry count: %1</source>
        <translation>Numero voci: %1</translation>
    </message>
    <message>
        <source>Group</source>
        <translation>Gruppo</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>Titolo</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>Nome utente</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Password</translation>
    </message>
    <message>
        <source>Url</source>
        <translation>Url</translation>
    </message>
    <message>
        <source>Could not load key file.</source>
        <translation>Impossibile caricare file chiave.</translation>
    </message>
    <message>
        <source>Could not open remote database. Password or key file may be incorrect.</source>
        <translation>Impossibile aprire il database remoto.  La password o il file chiave potrebbero essere errati.</translation>
    </message>
</context>
<context>
    <name>ImportWizardPageSelect</name>
    <message>
        <source>Form</source>
        <translation>Modulo</translation>
    </message>
    <message>
        <source>Import File Selection</source>
        <translation>Selezione file da importare</translation>
    </message>
    <message>
        <source>Password:</source>
        <translation>Password:</translation>
    </message>
    <message>
        <source>Key File:</source>
        <translation>File chiave:</translation>
    </message>
    <message>
        <source>Browse…</source>
        <translation>Sfoglia…</translation>
    </message>
    <message>
        <source>Import Into:</source>
        <translation>Importa in:</translation>
    </message>
    <message>
        <source>New Database</source>
        <translation>Nuovo Database</translation>
    </message>
    <message>
        <source>No unlocked databases available</source>
        <translation>Nessun database sbloccato disponibile</translation>
    </message>
    <message>
        <source>Existing Database:</source>
        <translation>Database esistente:</translation>
    </message>
    <message>
        <source>Import File:</source>
        <translation>Importa file:</translation>
    </message>
    <message>
        <source>Comma Separated Values (.csv)</source>
        <translation>Valori separati da virgola (.csv)</translation>
    </message>
    <message>
        <source>1Password Export (.1pux)</source>
        <translation>Esporta 1Password (.1pux)</translation>
    </message>
    <message>
        <source>1Password Vault (.opvault)</source>
        <translation>Vault 1Password (.opvault)</translation>
    </message>
    <message>
        <source>Bitwarden (.json)</source>
        <translation>Bitwarden (.json)</translation>
    </message>
    <message>
        <source>KeePass 1 Database (.kdb)</source>
        <translation>Database KeePass 1 (.kdb)</translation>
    </message>
    <message>
        <source>Open OPVault</source>
        <translation>Apri OPVault</translation>
    </message>
    <message>
        <source>Select import file</source>
        <translation>Seleziona il file da importare</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>Tutti i file</translation>
    </message>
    <message>
        <source>Key files</source>
        <translation>File chiave</translation>
    </message>
    <message>
        <source>Select key file</source>
        <translation>Seleziona file chiave</translation>
    </message>
    <message>
        <source>Comma Separated Values</source>
        <translation>Valori separati da virgola</translation>
    </message>
    <message>
        <source>1Password Export</source>
        <translation>Esporta 1Password</translation>
    </message>
    <message>
        <source>Bitwarden JSON Export</source>
        <translation>Esportazione JSON Bitwarden</translation>
    </message>
    <message>
        <source>1Password Vault</source>
        <translation>Cassaforte 1Password</translation>
    </message>
    <message>
        <source>KeePass1 Database</source>
        <translation>Database KeePass1</translation>
    </message>
    <message>
        <source>Proton Pass (.json)</source>
        <translation>Proton Pass (.json)</translation>
    </message>
    <message>
        <source>Proton Pass JSON Export</source>
        <translation>Esporta Proton Pass JSON</translation>
    </message>
    <message>
        <source>Temporary Database</source>
        <translation>Database temporaneo</translation>
    </message>
    <message>
        <source>Command:</source>
        <translation>Comando:</translation>
    </message>
    <message>
        <source>e.g.: &quot;sftp user@hostname&quot; or &quot;scp user@hostname:DatabaseOnRemote.kdbx {TEMP_DATABASE}&quot;</source>
        <translation>es.: &quot;sftp user@hostname&quot; o &quot;scp user@hostname:DatabaseOnRemote.kdbx {TEMP_DATABASE}&quot;</translation>
    </message>
    <message>
        <source>Input:</source>
        <translation>Input:</translation>
    </message>
    <message>
        <source>e.g.:
get DatabaseOnRemote.kdbx {TEMP_DATABASE}
exit
---
{TEMP_DATABASE} is used as placeholder to store the database in a temporary location
The command has to exit. In case of `sftp` as last commend `exit` has to be sent
         </source>
        <translation>ad es.:
get DatabaseOnRemote.kdbx {TEMP_DATABASE}
exit
---
{TEMP_DATABASE} è usato come segnaposto per memorizzare il database in una posizione temporanea
Il comando deve uscire.  In caso di `sftp` come ultimo comando deve essere inviato `exit`.
            </translation>
    </message>
    <message>
        <source>Remote Database (.kdbx)</source>
        <translation>Database remoto (.kdbx)</translation>
    </message>
</context>
<context>
    <name>KMessageWidget</name>
    <message>
        <source>&amp;Close</source>
        <translation>&amp;Chiudi</translation>
    </message>
    <message>
        <source>Close message</source>
        <translation>Chiudi messaggio</translation>
    </message>
</context>
<context>
    <name>Kdbx3Reader</name>
    <message>
        <source>Missing database headers</source>
        <translation>Intestazioni database mancanti</translation>
    </message>
    <message>
        <source>Unable to calculate database key</source>
        <translation>Impossibile calcolare la chiave del database</translation>
    </message>
    <message>
        <source>Unable to issue challenge-response: %1</source>
        <translation>Impossibile stabilire un collegamento challenge-response: %1</translation>
    </message>
    <message>
        <source>Invalid credentials were provided, please try again.
If this reoccurs, then your database file may be corrupt.</source>
        <translation>Sono state fornite credenziali non valide, riprova.
Se il problema si ripresenta, il file database potrebbe essere danneggiato.</translation>
    </message>
    <message>
        <source>Header doesn&apos;t match hash</source>
        <translation>L&apos;intestazione non corrisponde all&apos;hash</translation>
    </message>
    <message>
        <source>Invalid header id size</source>
        <translation>Dimensione dell&apos;id dell&apos;intestazione non valida</translation>
    </message>
    <message>
        <source>Invalid header field length: field %1</source>
        <translation>Lunghezza campo intestazione non valida: campo %1</translation>
    </message>
    <message>
        <source>Invalid header data length: field %1, %2 expected, %3 found</source>
        <translation>Lunghezza dei dati dell&apos;intestazione non valida: campo %1, %2 previsto, %3 trovato</translation>
    </message>
</context>
<context>
    <name>Kdbx3Writer</name>
    <message>
        <source>Invalid symmetric cipher IV size.</source>
        <comment>IV = Initialization Vector for symmetric cipher</comment>
        <translation>Dimensione non valida del vettore di inizializzazione dell&apos;algoritmo di cifratura simmetrica.</translation>
    </message>
    <message>
        <source>Unable to issue challenge-response: %1</source>
        <translation>Impossibile stabilire un collegamento challenge-response: %1</translation>
    </message>
    <message>
        <source>Unable to calculate database key</source>
        <translation>Impossibile calcolare la chiave del database</translation>
    </message>
</context>
<context>
    <name>Kdbx4Reader</name>
    <message>
        <source>missing database headers</source>
        <translation>intestazioni del database mancanti</translation>
    </message>
    <message>
        <source>Unable to calculate database key: %1</source>
        <translation>Impossibile calcolare la chiave del database: %1</translation>
    </message>
    <message>
        <source>Invalid header checksum size</source>
        <translation>Dimensione di checksum dell&apos;intestazione non valida</translation>
    </message>
    <message>
        <source>Header SHA256 mismatch</source>
        <translation>Corrispondenza errata dell&apos;intestazione SHA256</translation>
    </message>
    <message>
        <source>Invalid credentials were provided, please try again.
If this reoccurs, then your database file may be corrupt.</source>
        <translation>Sono state fornite credenziali non valide, riprova.
Se il problema si ripresenta, il file database potrebbe essere danneggiato.</translation>
    </message>
    <message>
        <source>(HMAC mismatch)</source>
        <translation>(mancata corrispondenza HMAC)</translation>
    </message>
    <message>
        <source>Unknown cipher</source>
        <translation>Cifrario sconosciuto</translation>
    </message>
    <message>
        <source>Invalid header id size</source>
        <translation>Dimensione dell&apos;id dell&apos;intestazione non valida</translation>
    </message>
    <message>
        <source>Invalid header field length: field %1</source>
        <translation>Lunghezza campo intestazione non valida: campo %1</translation>
    </message>
    <message>
        <source>Invalid header data length: field %1, %2 expected, %3 found</source>
        <translation>Lunghezza dei dati dell&apos;intestazione non valida: campo %1, %2 previsto, %3 trovato</translation>
    </message>
    <message>
        <source>Failed to open buffer for KDF parameters in header</source>
        <translation>Fallimento dell&apos;apertura del buffer per i parametri KDF nell&apos;intestazione</translation>
    </message>
    <message>
        <source>Unsupported key derivation function (KDF) or invalid parameters</source>
        <translation>Funzione di derivazione della chiave (KDF) non supportata o parametri non validi</translation>
    </message>
    <message>
        <source>Legacy header fields found in KDBX4 file.</source>
        <translation>Campi di intestazione obsoleti trovati nel file KDBX4.</translation>
    </message>
    <message>
        <source>Invalid inner header id size</source>
        <translation>Dimensione dell&apos;id dell&apos;intestazione interna non valida</translation>
    </message>
    <message>
        <source>Invalid inner header field length: field %1</source>
        <translation>Lunghezza campo interno intestazione non valida: campo %1</translation>
    </message>
    <message>
        <source>Invalid inner header data length: field %1, %2 expected, %3 found</source>
        <translation>Lunghezza dati intestazione interna non valida: campo %1, %2 previsto, %3 trovato</translation>
    </message>
    <message>
        <source>Invalid inner header binary size</source>
        <translation>Dimensione binaria dell&apos;intestazione interna non valida</translation>
    </message>
    <message>
        <source>Unsupported KeePass variant map version.</source>
        <extracomment>Translation: variant map = data structure for storing meta data</extracomment>
        <translation>Variante di mappa KeePass non supportata.</translation>
    </message>
    <message>
        <source>Invalid variant map entry name length</source>
        <extracomment>Translation: variant map = data structure for storing meta data</extracomment>
        <translation>Lunghezza nome voce della mappa variante non valida</translation>
    </message>
    <message>
        <source>Invalid variant map entry name data</source>
        <extracomment>Translation: variant map = data structure for storing meta data</extracomment>
        <translation>Il nome della voce per la mappa di variazione presenta dati non validi</translation>
    </message>
    <message>
        <source>Invalid variant map entry value length</source>
        <extracomment>Translation: variant map = data structure for storing meta data</extracomment>
        <translation>Lunghezza valore voce mappa variante non valida</translation>
    </message>
    <message>
        <source>Invalid variant map entry value data</source>
        <extracomment>Translation comment: variant map = data structure for storing meta data</extracomment>
        <translation>Il valore della voce per la mappa di variazione presenta dati non validi</translation>
    </message>
    <message>
        <source>Invalid variant map Bool entry value length</source>
        <extracomment>Translation: variant map = data structure for storing meta data</extracomment>
        <translation>Il valore della voce Bool per la mappa di variazione ha una lunghezza non valida</translation>
    </message>
    <message>
        <source>Invalid variant map Int32 entry value length</source>
        <extracomment>Translation: variant map = data structure for storing meta data</extracomment>
        <translation>Il valore della voce Int32 per la mappa di variazione ha una lunghezza non valida</translation>
    </message>
    <message>
        <source>Invalid variant map UInt32 entry value length</source>
        <extracomment>Translation: variant map = data structure for storing meta data</extracomment>
        <translation>Il valore della voce UInt32 per la mappa di variazione ha una lunghezza non valida</translation>
    </message>
    <message>
        <source>Invalid variant map Int64 entry value length</source>
        <extracomment>Translation: variant map = data structure for storing meta data</extracomment>
        <translation>Il valore della voce Int64 per la mappa di variazione ha una lunghezza non valida</translation>
    </message>
    <message>
        <source>Invalid variant map UInt64 entry value length</source>
        <extracomment>Translation: variant map = data structure for storing meta data</extracomment>
        <translation>Il valore della voce UInt64 per la mappa di variazione ha una lunghezza non valida</translation>
    </message>
    <message>
        <source>Invalid variant map entry type</source>
        <extracomment>Translation: variant map = data structure for storing meta data</extracomment>
        <translation>Il tipo della voce per la mappa di variazione non è valido</translation>
    </message>
    <message>
        <source>Invalid variant map field type size</source>
        <extracomment>Translation: variant map = data structure for storing meta data</extracomment>
        <translation>Dimensione tipo campo mappa variante non valida</translation>
    </message>
</context>
<context>
    <name>Kdbx4Writer</name>
    <message>
        <source>Invalid symmetric cipher algorithm.</source>
        <translation>Algoritmo di cifratura simmetrica non valido.</translation>
    </message>
    <message>
        <source>Invalid symmetric cipher IV size.</source>
        <comment>IV = Initialization Vector for symmetric cipher</comment>
        <translation>Dimensione non valida del vettore di inizializzazione dell&apos;algoritmo di cifratura simmetrica.</translation>
    </message>
    <message>
        <source>Unable to calculate database key: %1</source>
        <translation>Impossibile calcolare la chiave del database: %1</translation>
    </message>
    <message>
        <source>Failed to serialize KDF parameters variant map</source>
        <extracomment>Translation comment: variant map = data structure for storing meta data</extracomment>
        <translation>Serializzazione della mappa di variazione dei parametri KDF non riuscita</translation>
    </message>
</context>
<context>
    <name>KdbxReader</name>
    <message>
        <source>Invalid cipher uuid length: %1 (length=%2)</source>
        <translation>Lunghezza dell&apos;uuid cifrato non valida: %1 (lunghezza=%2)</translation>
    </message>
    <message>
        <source>Unable to parse UUID: %1</source>
        <translation>Impossibile analizzare UUID: %1</translation>
    </message>
    <message>
        <source>Unsupported cipher</source>
        <translation>Cifrario non supportato</translation>
    </message>
    <message>
        <source>Invalid compression flags length</source>
        <translation>Lunghezza dei flag di compressione non valida</translation>
    </message>
    <message>
        <source>Unsupported compression algorithm</source>
        <translation>Algoritmo di compressione non supportato</translation>
    </message>
    <message>
        <source>Invalid master seed size</source>
        <translation>Dimensione del seme principale non valido</translation>
    </message>
    <message>
        <source>Invalid transform seed size</source>
        <translation>Dimensione non valida del seme di trasformazione</translation>
    </message>
    <message>
        <source>Invalid transform rounds size</source>
        <translation>Dimensione non valida del numero di ripetizioni per la trasformazione</translation>
    </message>
    <message>
        <source>Invalid start bytes size</source>
        <translation>Dimensione non valida del byte di inizio</translation>
    </message>
    <message>
        <source>Invalid random stream id size</source>
        <translation>Dimensione non valida dell&apos;ID per il flusso di dati casuale</translation>
    </message>
    <message>
        <source>Invalid inner random stream cipher</source>
        <translation>Cifrario non valido per il flusso interno di dati casuale</translation>
    </message>
    <message>
        <source>Failed to read database file.</source>
        <translation>Impossibile leggere il file database.</translation>
    </message>
    <message>
        <source>The selected file is an old KeePass 1 database (.kdb).

You can import it by clicking on Database &gt; 'Import KeePass 1 database…'.
This is a one-way migration. You won&apos;t be able to open the imported database with the old KeePassX 0.4 version.</source>
        <translation>Il file selezionato è un vecchio database KeePass 1 (kdb).

È possibile importarlo facendo clic su Database &gt; &apos;Import KeePass 1 database...&apos;.
Questa è una migrazione a senso unico. Non sarà possibile aprire il database importato con la vecchia versione di KeePassX 0.4.</translation>
    </message>
    <message>
        <source>Not a KeePass database.</source>
        <translation>Non è un database KeePass.</translation>
    </message>
    <message>
        <source>Unsupported KeePass 2 database version.</source>
        <translation>Versione database KeePass 2 non supportata.</translation>
    </message>
</context>
<context>
    <name>KdbxXmlReader</name>
    <message>
        <source>XML parsing failure: %1</source>
        <translation>Errore nell&apos;analisi XML: %1</translation>
    </message>
    <message>
        <source>No root group</source>
        <translation>Nessun gruppo radice</translation>
    </message>
    <message>
        <source>XML error:
%1
Line %2, column %3</source>
        <translation>Errore XML:
%1
Riga %2, colonna %3</translation>
    </message>
    <message>
        <source>Missing icon uuid or data</source>
        <translation>UUID mancante per l&apos;icona o dati</translation>
    </message>
    <message>
        <source>Missing custom data key or value</source>
        <translation>Chiave individuale o valore mancante</translation>
    </message>
    <message>
        <source>Multiple group elements</source>
        <translation>Elementi appartenenti a gruppi diversi</translation>
    </message>
    <message>
        <source>Null group uuid</source>
        <translation>UUID di gruppo nullo</translation>
    </message>
    <message>
        <source>Invalid group icon number</source>
        <translation>Numero di gruppo di icone non valido</translation>
    </message>
    <message>
        <source>Invalid EnableAutoType value</source>
        <translation>Valore di EnableAutoType non valido</translation>
    </message>
    <message>
        <source>Invalid EnableSearching value</source>
        <translation>Valore EnableSearching non valido</translation>
    </message>
    <message>
        <source>No group uuid found</source>
        <translation>UUID di gruppo non trovato</translation>
    </message>
    <message>
        <source>Null DeleteObject uuid</source>
        <translation>DeleteObject: UUID nullo</translation>
    </message>
    <message>
        <source>Missing DeletedObject uuid or time</source>
        <translation>DeleteObject: UUID o marca temporale mancante</translation>
    </message>
    <message>
        <source>Null entry uuid</source>
        <translation>UUID nulla per la voce</translation>
    </message>
    <message>
        <source>Invalid entry icon number</source>
        <translation>Numero non valido per l&apos;icona della voce</translation>
    </message>
    <message>
        <source>History element in history entry</source>
        <translation>Elemento della cronistoria nella voce della cronistoria</translation>
    </message>
    <message>
        <source>No entry uuid found</source>
        <translation>Nessun UUID trovato per la voce</translation>
    </message>
    <message>
        <source>History element with different uuid</source>
        <translation>Elemento della cronistoria con diverso UUID</translation>
    </message>
    <message>
        <source>Duplicate custom attribute found</source>
        <translation>Trovato attributo personalizzato duplicato</translation>
    </message>
    <message>
        <source>Entry string key or value missing</source>
        <translation>Chiave alfanumerica o valore mancante per la voce</translation>
    </message>
    <message>
        <source>Entry binary key or value missing</source>
        <translation>Chiave binaria o valore mancante per la voce</translation>
    </message>
    <message>
        <source>Auto-type association window or sequence missing</source>
        <translation>Finestra associata al completamento automatico o sequenza mancante</translation>
    </message>
    <message>
        <source>Invalid bool value</source>
        <translation>Valore booleano non valido</translation>
    </message>
    <message>
        <source>Invalid date time value</source>
        <translation>Valore di data e tempo non valido</translation>
    </message>
    <message>
        <source>Invalid color value</source>
        <translation>Valore di colore non valido</translation>
    </message>
    <message>
        <source>Invalid color rgb part</source>
        <translation>Colore RGB non valido</translation>
    </message>
    <message>
        <source>Invalid number value</source>
        <translation>Valore numerico non valido</translation>
    </message>
    <message>
        <source>Invalid uuid value</source>
        <translation>Valore non valido per UUID</translation>
    </message>
    <message>
        <source>Unable to decompress binary</source>
        <extracomment>Translator meant is a binary data inside an entry</extracomment>
        <translation>Impossibile decomprimere il file binario</translation>
    </message>
</context>
<context>
    <name>KeeAgentSettings</name>
    <message>
        <source>Invalid KeeAgent settings file structure.</source>
        <translation>KeeAgent non valido nel file.</translation>
    </message>
    <message>
        <source>Private key is an attachment but no attachments provided.</source>
        <translation>La chiave privata è un allegato ma nessun allegato è stato inserito.</translation>
    </message>
    <message>
        <source>Private key is empty</source>
        <translation>La chiave privata è vuota</translation>
    </message>
    <message>
        <source>File too large to be a private key</source>
        <translation>File troppo grande per essere una chiave privata</translation>
    </message>
    <message>
        <source>Failed to open private key</source>
        <translation>Impossibile aprire la chiave privata</translation>
    </message>
</context>
<context>
    <name>KeePass1Reader</name>
    <message>
        <source>Unable to read keyfile.</source>
        <translation>Impossibile leggere il file chiave.</translation>
    </message>
    <message>
        <source>Not a KeePass database.</source>
        <translation>Non è un database KeePass.</translation>
    </message>
    <message>
        <source>Unsupported encryption algorithm.</source>
        <translation>Algoritmo di cifratura non supportato.</translation>
    </message>
    <message>
        <source>Unsupported KeePass database version.</source>
        <translation>Versione database KeePass non supportata.</translation>
    </message>
    <message>
        <source>Unable to read encryption IV</source>
        <comment>IV = Initialization Vector for symmetric cipher</comment>
        <translation>Impossibile leggere il vettore di inizializzazione per la cifratura</translation>
    </message>
    <message>
        <source>Invalid number of groups</source>
        <translation>Numero di gruppi non valido</translation>
    </message>
    <message>
        <source>Invalid number of entries</source>
        <translation>Numero di voci non valido</translation>
    </message>
    <message>
        <source>Invalid content hash size</source>
        <translation>Dimensione dell&apos;hash non valida per questo contenuto</translation>
    </message>
    <message>
        <source>Invalid transform seed size</source>
        <translation>Dimensione non valida del seme di trasformazione</translation>
    </message>
    <message>
        <source>Invalid number of transform rounds</source>
        <translation>Numero di cicli di trasformazione non valido</translation>
    </message>
    <message>
        <source>Unable to construct group tree</source>
        <translation>Impossibile costruire la struttura ad albero dei gruppi</translation>
    </message>
    <message>
        <source>Root</source>
        <translation>Radice</translation>
    </message>
    <message>
        <source>Unable to calculate database key</source>
        <translation>Impossibile calcolare la chiave del database</translation>
    </message>
    <message>
        <source>unable to seek to content position</source>
        <translation>Non in grado di cercare nella posizione del contenuto</translation>
    </message>
    <message>
        <source>Invalid credentials were provided, please try again.
If this reoccurs, then your database file may be corrupt.</source>
        <translation>Sono state fornite credenziali non valide, riprova.
Se il problema si ripresenta, il file database potrebbe essere danneggiato.</translation>
    </message>
    <message>
        <source>Key transformation failed</source>
        <translation>Trasformazione della chiave non riuscita</translation>
    </message>
    <message>
        <source>Invalid group field type number</source>
        <translation>Numero del tipo di gruppo non valido</translation>
    </message>
    <message>
        <source>Invalid group field size</source>
        <translation>Dimensione del campo di gruppo non valida</translation>
    </message>
    <message>
        <source>Read group field data doesn&apos;t match size</source>
        <translation>I dati letti non coincidono con la dimensione del gruppo</translation>
    </message>
    <message>
        <source>Incorrect group id field size</source>
        <translation>Dimensione dell&apos;ID di gruppo non corretta</translation>
    </message>
    <message>
        <source>Incorrect group creation time field size</source>
        <translation>Dimensione della data di creazione del gruppo non corretta</translation>
    </message>
    <message>
        <source>Incorrect group modification time field size</source>
        <translation>Dimensione della data di modifica del gruppo non corretta</translation>
    </message>
    <message>
        <source>Incorrect group access time field size</source>
        <translation>Dimensione della data di accesso del gruppo non corretta</translation>
    </message>
    <message>
        <source>Incorrect group expiry time field size</source>
        <translation>Dimensione della data di scadenza del gruppo non corretta</translation>
    </message>
    <message>
        <source>Incorrect group icon field size</source>
        <translation>Dimensione dell&apos;icona del gruppo non corretta</translation>
    </message>
    <message>
        <source>Incorrect group level field size</source>
        <translation>Dimensione del livello del gruppo non corretta</translation>
    </message>
    <message>
        <source>Invalid group field type</source>
        <translation>Tipo di gruppo non corretto</translation>
    </message>
    <message>
        <source>Missing group id or level</source>
        <translation>ID di gruppo o livello mancante</translation>
    </message>
    <message>
        <source>Missing entry field type number</source>
        <translation>Numero mancante per il tipo della voce attuale</translation>
    </message>
    <message>
        <source>Invalid entry field size</source>
        <translation>Dimensione del campo di immissione non valida</translation>
    </message>
    <message>
        <source>Read entry field data doesn&apos;t match size</source>
        <translation>I dati letti per la voce attuale non coincidono con la dimensione</translation>
    </message>
    <message>
        <source>Invalid entry UUID field size</source>
        <translation>Dimensione campo UUID non valida</translation>
    </message>
    <message>
        <source>Invalid entry group id field size</source>
        <translation>Dimensione dell&apos;ID di gruppo della voce attuale non valida</translation>
    </message>
    <message>
        <source>Invalid entry icon field size</source>
        <translation>Dimensione dell&apos;icona della voce attuale non valida</translation>
    </message>
    <message>
        <source>Invalid entry creation time field size</source>
        <translation>Dimensione della data di creazione della voce attuale non valida</translation>
    </message>
    <message>
        <source>Invalid entry modification time field size</source>
        <translation>Dimensione della data di modifica della voce attuale non valida</translation>
    </message>
    <message>
        <source>Invalid entry expiry time field size</source>
        <translation>Dimensione della data di scadenza della voce attuale non valida</translation>
    </message>
    <message>
        <source>Invalid entry field type</source>
        <translation>Tipo di dato non valido</translation>
    </message>
</context>
<context>
    <name>KeeShare</name>
    <message>
        <source>Invalid sharing reference</source>
        <translation>Riferimento di condivisione non valido</translation>
    </message>
    <message>
        <source>Inactive share %1</source>
        <translation>Condivisione inattiva %1</translation>
    </message>
    <message>
        <source>Imported from %1</source>
        <translation>Importato da %1</translation>
    </message>
    <message>
        <source>Exported to %1</source>
        <translation>Esportato in %1</translation>
    </message>
    <message>
        <source>Synchronized with %1</source>
        <translation>Sincronizzato con %1</translation>
    </message>
    <message>
        <source>Import is disabled in settings</source>
        <translation>L&apos;importazione è disabilitata nelle impostazioni</translation>
    </message>
    <message>
        <source>Export is disabled in settings</source>
        <translation>L&apos;esportazione è disabilitata nelle impostazioni</translation>
    </message>
    <message>
        <source>Inactive share</source>
        <translation>Condivisione inattiva</translation>
    </message>
    <message>
        <source>Imported from</source>
        <translation>Importato da</translation>
    </message>
    <message>
        <source>Exported to</source>
        <translation>Esportato in</translation>
    </message>
    <message>
        <source>Synchronized with</source>
        <translation>Sincronizzato con</translation>
    </message>
</context>
<context>
    <name>KeyComponentWidget</name>
    <message>
        <source>Key Component</source>
        <translation>Componente chiave</translation>
    </message>
    <message>
        <source>Key Component Description</source>
        <translation>Descrizione del componente chiave</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Annulla</translation>
    </message>
    <message>
        <source>Key Component set, click to change or remove</source>
        <translation>Set di componenti chiave, fai clic per modificare/rimuovere</translation>
    </message>
</context>
<context>
    <name>KeyFileEditWidget</name>
    <message>
        <source>Generate a new key file</source>
        <translation>Genera un nuovo file chiave</translation>
    </message>
    <message>
        <source>Generate</source>
        <translation>Genera</translation>
    </message>
    <message>
        <source>Generate a new key file or choose an existing one to protect your database.</source>
        <translation>Genera un nuovo file chiave o scegline uno esistente per proteggere il database.</translation>
    </message>
    <message>
        <source>Note: Do NOT use a file that may change as that will prevent you from unlocking your database.</source>
        <translation>Nota: NON usare un file che potrebbe essere modificato in quanto ciò ti impedirà di sbloccare il database.</translation>
    </message>
    <message>
        <source>Browse for key file</source>
        <translation>Seleziona file chiave</translation>
    </message>
    <message>
        <source>Browse…</source>
        <translation>Sfoglia…</translation>
    </message>
    <message>
        <source>Old key file format</source>
        <translation>Vecchio formato di file chiave</translation>
    </message>
    <message>
        <source>You selected a key file in an old format which KeePassXC&lt;br&gt;may stop supporting in the future.&lt;br&gt;&lt;br&gt;Please consider generating a new key file instead.</source>
        <translation>È stato selezionato un file chiave in un vecchio formato che KeePassXC&lt;br&gt;potrebbe smettere di supportare in futuro.&lt;br&gt;&lt;br&gt;Prendi in considerazione la possibilità di generare un nuovo file chiave.</translation>
    </message>
    <message>
        <source>Error loading the key file '%1'
Message: %2</source>
        <translation>Errore nel caricamento del file chiave &apos;%1&apos;
Messaggio: %2</translation>
    </message>
    <message>
        <source>Key File</source>
        <translation>File chiave</translation>
    </message>
    <message>
        <source>Add Key File</source>
        <translation>Aggiungi file chiave</translation>
    </message>
    <message>
        <source>Change Key File</source>
        <translation>Cambia file chiave</translation>
    </message>
    <message>
        <source>Remove Key File</source>
        <translation>Rimuovi file chiave</translation>
    </message>
    <message>
        <source>Key File set, click to change or remove</source>
        <translation>File chiave impostato, fai clic per modificare/rimuovere</translation>
    </message>
    <message>
        <source>&lt;p&gt;You can add a key file containing random bytes for additional security.&lt;/p&gt;&lt;p&gt;You must keep it secret and never lose it or you will be locked out.&lt;/p&gt;</source>
        <translation>&lt;p&gt;Per una maggiore sicurezza è possibile aggiungere un file chiave contenente byte casuali.&lt;/p&gt;&lt;p&gt;Devi tenere la chiave segreta e non perderla mai o non potrai accedere.&lt;/p&gt;</translation>
    </message>
    <message>
        <source>Key files</source>
        <translation>File chiave</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>Tutti i file</translation>
    </message>
    <message>
        <source>Create Key File…</source>
        <translation>Crea file chiave…</translation>
    </message>
    <message>
        <source>Error creating key file</source>
        <translation>Errore nella creazione del file chiave</translation>
    </message>
    <message>
        <source>Unable to create key file: %1</source>
        <translation>Impossibile creare il file chiave: %1</translation>
    </message>
    <message>
        <source>Select a key file</source>
        <translation>Seleziona un file chiave</translation>
    </message>
    <message>
        <source>Invalid Key File</source>
        <translation>File chiave non valido</translation>
    </message>
    <message>
        <source>You cannot use the current database as its own keyfile. Please choose a different file or generate a new key file.</source>
        <translation>Non è possibile usare il database attuale come proprio file chiave. Scegli un file diverso o generare un nuovo file chiave.</translation>
    </message>
    <message>
        <source>Suspicious Key File</source>
        <translation>File chiave sospetto</translation>
    </message>
    <message>
        <source>The chosen key file looks like a password database file. A key file must be a static file that never changes or you will lose access to your database forever.
Are you sure you want to continue with this file?</source>
        <translation>Il file chiave scelto ha l&apos;aspetto di un file database delle password. Un file chiave deve essere un file statico che non cambia mai o si perderà l&apos;accesso al database per sempre.
Sei sicuro di voler continuare con questo file?</translation>
    </message>
</context>
<context>
    <name>MacUtils</name>
    <message>
        <source>Invalid key code</source>
        <translation>Codice chiave non valido</translation>
    </message>
    <message>
        <source>Global shortcut already registered to %1</source>
        <translation>Scorciatoia globale già registrata a %1</translation>
    </message>
    <message>
        <source>Could not register global shortcut</source>
        <translation>Impossibile registrare la scorciatoia globale</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>&amp;Database</source>
        <translation>&amp;Database</translation>
    </message>
    <message>
        <source>&amp;Recent Databases</source>
        <translation>&amp;Database recenti</translation>
    </message>
    <message>
        <source>&amp;Export</source>
        <translation>&amp;Esporta</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>&amp;Aiuto</translation>
    </message>
    <message>
        <source>&amp;Entries</source>
        <translation>&amp;Voci</translation>
    </message>
    <message>
        <source>Copy Att&amp;ribute</source>
        <translation>Copia att&amp;ributo</translation>
    </message>
    <message>
        <source>TOTP</source>
        <translation>TOTP</translation>
    </message>
    <message>
        <source>Tags</source>
        <translation>Etichette</translation>
    </message>
    <message>
        <source>&amp;Groups</source>
        <translation>&amp;Gruppi</translation>
    </message>
    <message>
        <source>&amp;Tools</source>
        <translation>S&amp;trumenti</translation>
    </message>
    <message>
        <source>View</source>
        <translation>Visualizza</translation>
    </message>
    <message>
        <source>Theme</source>
        <translation>Tema</translation>
    </message>
    <message>
        <source>&amp;Quit</source>
        <translation>&amp;Esci</translation>
    </message>
    <message>
        <source>&amp;About</source>
        <translation>&amp;Informazioni</translation>
    </message>
    <message>
        <source>&amp;Check for Updates</source>
        <translation>&amp;Controlla aggiornamenti</translation>
    </message>
    <message>
        <source>&amp;Open Database…</source>
        <translation>&amp;Apri database…</translation>
    </message>
    <message>
        <source>&amp;Save Database</source>
        <translation>&amp;Salva database</translation>
    </message>
    <message>
        <source>&amp;Close Database</source>
        <translation>&amp;Chiudi database</translation>
    </message>
    <message>
        <source>&amp;New Database…</source>
        <translation>&amp;Nuovo database...</translation>
    </message>
    <message>
        <source>&amp;Merge From Database…</source>
        <translation>&amp;Unire dal database...</translation>
    </message>
    <message>
        <source>&amp;New Entry…</source>
        <translation>&amp;Nuova voce...</translation>
    </message>
    <message>
        <source>&amp;Edit Entry…</source>
        <translation>&amp;Modifica voce...</translation>
    </message>
    <message>
        <source>&amp;New Group…</source>
        <translation>&amp;Nuovo gruppo...</translation>
    </message>
    <message>
        <source>&amp;Edit Group…</source>
        <translation>&amp;Modifica gruppo...</translation>
    </message>
    <message>
        <source>&amp;Delete Group…</source>
        <translation>&amp;Elimina gruppo...</translation>
    </message>
    <message>
        <source>Download All &amp;Favicons…</source>
        <translation>Scarica tutte le &amp;Favicon...</translation>
    </message>
    <message>
        <source>Sort &amp;A-Z</source>
        <translation>Ordina &amp;A-Z</translation>
    </message>
    <message>
        <source>Sort &amp;Z-A</source>
        <translation>Ordina &amp;Z-A</translation>
    </message>
    <message>
        <source>Sa&amp;ve Database As…</source>
        <translation>Sal&amp;va database come...</translation>
    </message>
    <message>
        <source>Database &amp;Security…</source>
        <translation>&amp;Sicurezza database...</translation>
    </message>
    <message>
        <source>Database &amp;Reports…</source>
        <translation>&amp;Rapporti del database...</translation>
    </message>
    <message>
        <source>&amp;Database Settings…</source>
        <translation>Impostazioni &amp;database...</translation>
    </message>
    <message>
        <source>&amp;Clone Entry…</source>
        <translation>&amp;Clona voce...</translation>
    </message>
    <message>
        <source>Move u&amp;p</source>
        <translation>Sposta in s&amp;u</translation>
    </message>
    <message>
        <source>Move do&amp;wn</source>
        <translation>Sposta in gi&amp;ù</translation>
    </message>
    <message>
        <source>Copy &amp;Username</source>
        <translation>Copia &amp;nome utente</translation>
    </message>
    <message>
        <source>Copy &amp;Password</source>
        <translation>Copia &amp;password</translation>
    </message>
    <message>
        <source>&amp;Settings</source>
        <translation>&amp;Impostazioni</translation>
    </message>
    <message>
        <source>&amp;Password Generator</source>
        <translation>Generatore &amp;password</translation>
    </message>
    <message>
        <source>Perform &amp;Auto-Type</source>
        <translation>Eseguire completamento &amp;automatico</translation>
    </message>
    <message>
        <source>Download &amp;Favicon</source>
        <translation>Scarica &amp;favicon</translation>
    </message>
    <message>
        <source>Open &amp;URL</source>
        <translation>Apri &amp;URL</translation>
    </message>
    <message>
        <source>&amp;Lock Database</source>
        <translation>&amp;Blocca database</translation>
    </message>
    <message>
        <source>Lock &amp;All Databases</source>
        <translation>Blocca &amp;tutti i database</translation>
    </message>
    <message>
        <source>&amp;Title</source>
        <translation>&amp;Titolo</translation>
    </message>
    <message>
        <source>Copy &amp;URL</source>
        <translation>Copia &amp;URL</translation>
    </message>
    <message>
        <source>&amp;Notes</source>
        <translation>&amp;Note</translation>
    </message>
    <message>
        <source>&amp;CSV File…</source>
        <translation>&amp;File CSV...</translation>
    </message>
    <message>
        <source>&amp;HTML File…</source>
        <translation>File &amp;HTML...</translation>
    </message>
    <message>
        <source>KeePass 1 Database…</source>
        <translation>Database KeePass 1...</translation>
    </message>
    <message>
        <source>1Password Vault…</source>
        <translation>1Password Vault...</translation>
    </message>
    <message>
        <source>CSV File…</source>
        <translation>File CSV...</translation>
    </message>
    <message>
        <source>Show TOTP</source>
        <translation>Visualizza TOTP</translation>
    </message>
    <message>
        <source>Show QR Code</source>
        <translation>Visualizza codice QR</translation>
    </message>
    <message>
        <source>Set up TOTP…</source>
        <translation>Configura TOTP...</translation>
    </message>
    <message>
        <source>Copy &amp;TOTP</source>
        <translation>Copia &amp;TOTP</translation>
    </message>
    <message>
        <source>Copy Password and TOTP</source>
        <translation>Copia password e TOTP</translation>
    </message>
    <message>
        <source>E&amp;mpty recycle bin</source>
        <translation>Svuota il cesti&amp;no</translation>
    </message>
    <message>
        <source>&amp;Donate</source>
        <translation>&amp;Dona</translation>
    </message>
    <message>
        <source>Report a &amp;Bug</source>
        <translation>Segnala un &amp;bug</translation>
    </message>
    <message>
        <source>&amp;Getting Started</source>
        <translation>&amp;Guida introduttiva</translation>
    </message>
    <message>
        <source>Open Getting Started Guide</source>
        <translation>Apri la guida introduttiva</translation>
    </message>
    <message>
        <source>&amp;Online Help</source>
        <translation>&amp;Guida in linea</translation>
    </message>
    <message>
        <source>&amp;User Guide</source>
        <translation>&amp;Guida per l&apos;utente</translation>
    </message>
    <message>
        <source>Open User Guide</source>
        <translation>Apri il manuale dell&apos;utente</translation>
    </message>
    <message>
        <source>&amp;Keyboard Shortcuts</source>
        <translation>&amp;Tasti scelta rapida</translation>
    </message>
    <message>
        <source>Save Database Backup…</source>
        <translation>Salva backup database in...</translation>
    </message>
    <message>
        <source>Add key to SSH Agent</source>
        <translation>Aggiungi chiave all&apos;agente SSH</translation>
    </message>
    <message>
        <source>Remove key from SSH Agent</source>
        <translation>Rimuovi chiave dall&apos;agente SSH</translation>
    </message>
    <message>
        <source>Compact Mode</source>
        <translation>Modalità compatta</translation>
    </message>
    <message>
        <source>Automatic</source>
        <translation>Automatico</translation>
    </message>
    <message>
        <source>Light</source>
        <translation>Chiaro</translation>
    </message>
    <message>
        <source>Dark</source>
        <translation>Scuro</translation>
    </message>
    <message>
        <source>Classic (Platform-native)</source>
        <translation>Classico (nativo della piattaforma)</translation>
    </message>
    <message>
        <source>Show Menubar</source>
        <translation>Mostra barra dei menù</translation>
    </message>
    <message>
        <source>Show Toolbar</source>
        <translation>Visualizza barra strumenti</translation>
    </message>
    <message>
        <source>Show Preview Panel</source>
        <translation>Visualizza pannello anteprima</translation>
    </message>
    <message>
        <source>Always on Top</source>
        <translation>Sempre in primo piano</translation>
    </message>
    <message>
        <source>Hide Usernames</source>
        <translation>Nascondi nome utente</translation>
    </message>
    <message>
        <source>Hide Passwords</source>
        <translation>Nascondi password</translation>
    </message>
    <message>
        <source>Clone Group...</source>
        <translation>Clona gruppo...</translation>
    </message>
    <message>
        <source>&amp;XML File…</source>
        <translation>File &amp;XML...</translation>
    </message>
    <message>
        <source>Clear history</source>
        <translation>Azzera cronologia</translation>
    </message>
    <message>
        <source>Access error for config file %1</source>
        <translation>Errore di accesso al file di configurazione &apos;%1&apos;</translation>
    </message>
    <message>
        <source>Don&apos;t show again for this version</source>
        <translation>Non visualizzare più per questa versione</translation>
    </message>
    <message>
        <source>No Tags</source>
        <translation>Nessuna etichetta</translation>
    </message>
    <message numerus="yes">
        <source>Restore Entry(s)</source>
        <translation><numerusform>Ripristina voce</numerusform><numerusform>Ripristina voci</numerusform><numerusform>Ripristina voci</numerusform></translation>
    </message>
    <message>
        <source>Settings</source>
        <translation>Impostazioni</translation>
    </message>
    <message>
        <source>Check for updates on startup?</source>
        <translation>Vuoi controllare gli aggiornamenti all&apos;avvio?</translation>
    </message>
    <message>
        <source>Would you like KeePassXC to check for updates on startup?</source>
        <translation>Volete che KeePassXC controlli eventuali aggiornamenti all&apos;avvio?</translation>
    </message>
    <message>
        <source>You can always check for updates manually from the application menu.</source>
        <translation>È sempre possibile controllare gli aggiornamenti manualmente tramite i menu dell&apos;applicazione.</translation>
    </message>
    <message>
        <source>Toggle window</source>
        <translation>Abilita/disabilita finestra</translation>
    </message>
    <message>
        <source>Quit KeePassXC</source>
        <translation>Esci da KeePassXC</translation>
    </message>
    <message numerus="yes">
        <source>%1 Entry(s)</source>
        <translation><numerusform>%1 voce</numerusform><numerusform>%1 voci</numerusform><numerusform>%1 voci</numerusform></translation>
    </message>
    <message>
        <source>Please present or touch your YubiKey to continue…</source>
        <translation>Per continuare presenta o tocca la YubiKey...</translation>
    </message>
    <message>
        <source>Restart Application?</source>
        <translation>Vuoi riavviare l&apos;applicazione?</translation>
    </message>
    <message>
        <source>You must restart the application to apply this setting. Would you like to restart now?</source>
        <translation>Per applicare questa impostazione è necessario riavviare l&apos;applicazione. Vuoi riavviarla ora?</translation>
    </message>
    <message>
        <source>Allow Screen Capture</source>
        <translation>Consenti cattura schermo</translation>
    </message>
    <message>
        <source>1Password 1PUX...</source>
        <translation>1Password 1PUX...</translation>
    </message>
    <message>
        <source>Import a 1Password 1PUX file</source>
        <translation>Importa un file 1Password 1PUX</translation>
    </message>
    <message>
        <source>Import…</source>
        <translation>Importa...</translation>
    </message>
    <message>
        <source>Passkeys…</source>
        <translation>Passkeys...</translation>
    </message>
    <message>
        <source>Import Passkey</source>
        <translation>Importa Passkey</translation>
    </message>
    <message>
        <source>Remote S&amp;ync…</source>
        <translation>S&amp;incronizzazione remota...</translation>
    </message>
    <message>
        <source>Quit Application</source>
        <translation>Esci dall&apos;applicazione</translation>
    </message>
    <message>
        <source>Open About Dialog</source>
        <translation>Apri finestra Informazioni</translation>
    </message>
    <message>
        <source>Open Database</source>
        <translation>Apri database</translation>
    </message>
    <message>
        <source>Create Database</source>
        <translation>Crea database</translation>
    </message>
    <message>
        <source>Merge From Database</source>
        <translation>Unisci da database</translation>
    </message>
    <message>
        <source>Edit Entry</source>
        <translation>Modifica voce</translation>
    </message>
    <message>
        <source>Delete Entry</source>
        <translation>Elimina voce</translation>
    </message>
    <message>
        <source>Create Group</source>
        <translation>Crea gruppo</translation>
    </message>
    <message>
        <source>Edit Group</source>
        <translation>Modifica gruppo</translation>
    </message>
    <message>
        <source>Delete Group</source>
        <translation>Elimina gruppo</translation>
    </message>
    <message>
        <source>Download All Favicons</source>
        <translation>Download di tutte le favicon</translation>
    </message>
    <message>
        <source>Sort Groups A-Z</source>
        <translation>Ordina gruppi A-Z</translation>
    </message>
    <message>
        <source>Sort Groups Z-A</source>
        <translation>Ordina gruppi Z-A</translation>
    </message>
    <message>
        <source>Save Database As</source>
        <translation>Salva database con nome</translation>
    </message>
    <message>
        <source>Show Database Security</source>
        <translation>Visualizza sicurezza database</translation>
    </message>
    <message>
        <source>Show Database Reports</source>
        <translation>Visualizza rapporti database</translation>
    </message>
    <message>
        <source>Show Database Settings</source>
        <translation>Visualizza impostazioni database</translation>
    </message>
    <message>
        <source>Show Passkeys</source>
        <translation>Visualizza passkey</translation>
    </message>
    <message>
        <source>Clone Entry</source>
        <translation>Clona voce</translation>
    </message>
    <message>
        <source>Move Entry Up</source>
        <translation>Sposta voce su</translation>
    </message>
    <message>
        <source>Move Entry Down</source>
        <translation>Sposta voce giù</translation>
    </message>
    <message>
        <source>Copy Username</source>
        <translation>Copia nome utente</translation>
    </message>
    <message>
        <source>Copy Password</source>
        <translation>Copia password</translation>
    </message>
    <message>
        <source>Show Application Settings</source>
        <translation>Visualizza impostazioni applicazione</translation>
    </message>
    <message>
        <source>Show Password Generator</source>
        <translation>Visualizza generatore password</translation>
    </message>
    <message>
        <source>Remove Passkey From Entry</source>
        <translation>Rimuovi Passkey Dalla Voce</translation>
    </message>
    <message>
        <source>Perform Auto-Type: {USERNAME}</source>
        <translation>Esegui completamento automatico: {USERNAME}</translation>
    </message>
    <message>
        <source>Perform Auto-Type: {USERNAME}{ENTER}</source>
        <translation>Esegui digitazione automatica: {USERNAME}{ENTER}</translation>
    </message>
    <message>
        <source>Perform Auto-Type: {PASSWORD}</source>
        <translation>Esegui digitazione automatica: {PASSWORD}</translation>
    </message>
    <message>
        <source>Perform Auto-Type: {PASSWORD}{ENTER}</source>
        <translation>Esegui digitazione automatica: {PASSWORD}{ENTER}</translation>
    </message>
    <message>
        <source>Perform Auto-Type: {TOTP}</source>
        <translation>Esegui digitazione automatica: {TOTP}</translation>
    </message>
    <message>
        <source>Copy Title</source>
        <translation>Copia titolo</translation>
    </message>
    <message>
        <source>Copy URL</source>
        <translation>Copia URL</translation>
    </message>
    <message>
        <source>Copy Notes</source>
        <translation>Copia note</translation>
    </message>
    <message>
        <source>Export to CSV</source>
        <translation>Esporta in CSV</translation>
    </message>
    <message>
        <source>Export to HTML</source>
        <translation>Esporta in HTML</translation>
    </message>
    <message>
        <source>Import KeePass1 Database</source>
        <translation>Importa database KeePass1</translation>
    </message>
    <message>
        <source>Import 1Password Vault</source>
        <translation>Importa 1Password Vault</translation>
    </message>
    <message>
        <source>Import CSV File</source>
        <translation>Importa file CSV</translation>
    </message>
    <message>
        <source>Show TOTP QR Code</source>
        <translation>Visualizza codice QR TOTP...</translation>
    </message>
    <message>
        <source>Set up TOTP</source>
        <translation>Configura TOTP</translation>
    </message>
    <message>
        <source>Empty Recycle Bin</source>
        <translation>Svuota cestino</translation>
    </message>
    <message>
        <source>Open Donation Website</source>
        <translation>Apri sito donazione</translation>
    </message>
    <message>
        <source>Open Bug Report</source>
        <translation>Apri segnalazione bug</translation>
    </message>
    <message>
        <source>Open Online Documentation</source>
        <translation>Apri documentazione online</translation>
    </message>
    <message>
        <source>Open Keyboard Shortcuts Guide</source>
        <translation>Apri guida scorciatoie tastiera</translation>
    </message>
    <message>
        <source>Save Database Backup</source>
        <translation>Salva backup database</translation>
    </message>
    <message>
        <source>SSH Agent: Add Key</source>
        <translation>Agent SSH: aggiungi chiave</translation>
    </message>
    <message>
        <source>SSH Agent: Remove Key</source>
        <translation>Agent SSH: rimuovi chiave</translation>
    </message>
    <message>
        <source>Toggle Compact Mode</source>
        <translation>Modalità compatta</translation>
    </message>
    <message>
        <source>Set Theme: Automatic</source>
        <translation>Imposta tema: automatico</translation>
    </message>
    <message>
        <source>Set Theme: Light</source>
        <translation>Imposta tema: chiaro</translation>
    </message>
    <message>
        <source>Set Theme: Dark</source>
        <translation>Imposta tema: scuro</translation>
    </message>
    <message>
        <source>Set Theme: Classic</source>
        <translation>Imposta tema: classico</translation>
    </message>
    <message>
        <source>Toggle Show Menubar</source>
        <translation>Abilita Mostra la barra dei menù</translation>
    </message>
    <message>
        <source>Toggle Show Toolbar</source>
        <translation>Visualizza barra strumenti</translation>
    </message>
    <message>
        <source>Toggle Show Preview Panel</source>
        <translation>Visualizza pannello anteprima</translation>
    </message>
    <message>
        <source>Toggle Always on Top</source>
        <translation>Sempre in primo piano</translation>
    </message>
    <message>
        <source>Toggle Hide Usernames</source>
        <translation>Nascondi nome utente</translation>
    </message>
    <message>
        <source>Toggle Hide Passwords</source>
        <translation>Nascondi password</translation>
    </message>
    <message>
        <source>Export to XML</source>
        <translation>Esporta in XML</translation>
    </message>
    <message>
        <source>Toggle Allow Screen Capture</source>
        <translation>Attiva/disattiva consenti cattura schermo</translation>
    </message>
    <message>
        <source>Show Group Panel</source>
        <translation>Mostra pannello del gruppo</translation>
    </message>
    <message>
        <source>Toggle Show Group Panel</source>
        <translation>Attiva/disattiva &apos;Visualizza pannello gruppo&apos;</translation>
    </message>
    <message>
        <source>Setup Remote Sync…</source>
        <translation>Imposta sincronizzazione remota...</translation>
    </message>
    <message>
        <source>WARNING: You are using a development snapshot build of KeePassXC.
Maintain a backup of your databases in the event of unknown bugs.
This version is not meant for production use.</source>
        <translation>ATTENZIONE: stai usando uno snapshot di sviluppo di KeePassXC. Ti consigliamo di mantenere un backup dei database. Questa versione non è destinata all&apos;uso in produzione.</translation>
    </message>
    <message>
        <source>Clear SSH Agent</source>
        <translation>Cancella SSH Agent</translation>
    </message>
    <message>
        <source>Clear all identities in ssh-agent</source>
        <translation>Cancella tutte le identità in ssh-agent</translation>
    </message>
    <message>
        <source>New Entry</source>
        <translation>Nuova voce</translation>
    </message>
    <message>
        <source>Password Generator</source>
        <translation>Genera password</translation>
    </message>
    <message>
        <source>Edit Entry…</source>
        <translation>Modifica voce...</translation>
    </message>
    <message>
        <source>E&amp;xpire Entry</source>
        <translation>Sca&amp;denza voce</translation>
    </message>
    <message>
        <source>Expire Entry</source>
        <translation>Scadenza voce</translation>
    </message>
    <message>
        <source>&amp;Delete Entry</source>
        <translation>&amp;Elimina voce</translation>
    </message>
    <message numerus="yes">
        <source>Move selected entry(s) to the recycle bin</source>
        <translation><numerusform>Sposta voce selezionata nel cestino</numerusform><numerusform>Sposta voci selezionate nel cestino</numerusform><numerusform>Sposta voci selezionate nel cestino</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>Permanently delete the selected entry(s)</source>
        <translation><numerusform>Elimina definitivamente la voce selezionata</numerusform><numerusform>Elimina definitivamente le voci selezionate</numerusform><numerusform>Elimina definitivamente voci selezionate</numerusform></translation>
    </message>
</context>
<context>
    <name>ManageDatabase</name>
    <message>
        <source>Database settings</source>
        <translation>Impostazioni database</translation>
    </message>
    <message>
        <source>Edit database settings</source>
        <translation>Modifica impostazioni database</translation>
    </message>
    <message>
        <source>Unlock database</source>
        <translation>Sblocca database</translation>
    </message>
    <message>
        <source>Unlock database to show more information</source>
        <translation>Per visualizzare ulteriori informazioni sblocca il database</translation>
    </message>
    <message>
        <source>Lock database</source>
        <translation>Blocca database</translation>
    </message>
</context>
<context>
    <name>ManageSession</name>
    <message>
        <source>Disconnect</source>
        <translation>Scollegare</translation>
    </message>
    <message>
        <source>Disconnect this application</source>
        <translation>Scollega questa applicazione</translation>
    </message>
    <message>
        <source>Reset</source>
        <translation>Resettare</translation>
    </message>
    <message>
        <source>Reset any remembered decisions for this application</source>
        <translation>Reimposta tutte le decisioni salvate per questa applicazione</translation>
    </message>
</context>
<context>
    <name>MergeDialog</name>
    <message>
        <source>Database Merge Confirmation</source>
        <translation>Conferma unione database</translation>
    </message>
    <message>
        <source>Merge</source>
        <translation>Unisci</translation>
    </message>
    <message>
        <source>Group</source>
        <translation>Gruppo</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>Titolo</translation>
    </message>
    <message>
        <source>UUID</source>
        <translation>UUID</translation>
    </message>
    <message>
        <source>Details</source>
        <translation>Dettagli</translation>
    </message>
    <message>
        <source>Change</source>
        <translation>Modifica</translation>
    </message>
</context>
<context>
    <name>Merger</name>
    <message>
        <source>Changed deleted objects</source>
        <translation>Oggetti eliminati modificati</translation>
    </message>
    <message>
        <source>Removed custom data %1 [%2]</source>
        <translation>Dati personalizzati rimossi %1 [%2]</translation>
    </message>
    <message>
        <source>Adding custom data %1 [%2]</source>
        <translation>Aggiunta dati personalizzati %1 [%2]</translation>
    </message>
    <message>
        <source>Added</source>
        <translation>Aggiunto</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Modificato</translation>
    </message>
    <message>
        <source>Moved</source>
        <translation>Spostato</translation>
    </message>
    <message>
        <source>Deleted</source>
        <translation>Eliminato</translation>
    </message>
    <message>
        <source>Previous location: %1</source>
        <translation>Percorso precedente: %1</translation>
    </message>
    <message>
        <source>Number of entries in group: %1</source>
        <translation>Numero di voci nel gruppo: %1</translation>
    </message>
    <message>
        <source>Group name</source>
        <translation>Nome gruppo</translation>
    </message>
    <message>
        <source>Notes</source>
        <translation>Note</translation>
    </message>
    <message>
        <source>Icon (UUID)</source>
        <translation>Icona (UUID)</translation>
    </message>
    <message>
        <source>Icon (Number)</source>
        <translation>Icona (numero)</translation>
    </message>
    <message>
        <source>Expiry time</source>
        <translation>Scadenza</translation>
    </message>
    <message>
        <source>Modification time</source>
        <translation>Orario modifica</translation>
    </message>
    <message>
        <source>%1 (Add local modifications to new entry)</source>
        <translation>%1 (aggiungi le modifiche locali alla nuova voce)</translation>
    </message>
    <message>
        <source>%1 (Add new modifications to existing entry)</source>
        <translation>%1 (aggiungi le nuove modifiche alla voce esistente)</translation>
    </message>
    <message>
        <source>Explicit deletion</source>
        <translation>Eliminazione esplicita</translation>
    </message>
    <message>
        <source>Implicit deletion (e.g. removal of parent group)</source>
        <translation>Eliminazione implicita (ad es. rimozione gruppo padre)</translation>
    </message>
    <message>
        <source>Adding new icon %1</source>
        <translation>Aggiunta nuova icona %1</translation>
    </message>
</context>
<context>
    <name>NewDatabaseWizard</name>
    <message>
        <source>Create a new KeePassXC database…</source>
        <translation>Creazione di un nuovo database KeePassXC…</translation>
    </message>
    <message>
        <source>Root</source>
        <comment>Root group</comment>
        <translation>Radice</translation>
    </message>
</context>
<context>
    <name>NewDatabaseWizardPage</name>
    <message>
        <source>WizardPage</source>
        <translation>Pagina della procedura guidata</translation>
    </message>
    <message>
        <source>Encryption Settings</source>
        <translation>Impostazioni di cifratura</translation>
    </message>
    <message>
        <source>Here you can adjust the database encryption settings. Don&apos;t worry, you can change them later in the database settings.</source>
        <translation>Qui puoi modificare le impostazioni di cifratura del database. Puoi sempre modificarle dopo nelle impostazioni del database.</translation>
    </message>
</context>
<context>
    <name>NewDatabaseWizardPageDatabaseKey</name>
    <message>
        <source>Database Credentials</source>
        <translation>Credenziali database</translation>
    </message>
    <message>
        <source>A set of credentials known only to you that protects your database.</source>
        <translation>Un set di credenziali note solo a te che protegge il database.</translation>
    </message>
</context>
<context>
    <name>NewDatabaseWizardPageEncryption</name>
    <message>
        <source>Encryption Settings</source>
        <translation>Impostazioni di cifratura</translation>
    </message>
    <message>
        <source>Here you can adjust the database encryption settings. Don&apos;t worry, you can change them later in the database settings.</source>
        <translation>Qui puoi modificare le impostazioni di cifratura del database. Puoi sempre modificarle dopo nelle impostazioni del database.</translation>
    </message>
</context>
<context>
    <name>NewDatabaseWizardPageMetaData</name>
    <message>
        <source>General Database Information</source>
        <translation>Informazioni generali sul database</translation>
    </message>
    <message>
        <source>Please fill in the display name and an optional description for your new database:</source>
        <translation>Compila il nome visualizzato e una descrizione facoltativa per il nuovo database:</translation>
    </message>
</context>
<context>
    <name>NixUtils</name>
    <message>
        <source>Password Manager</source>
        <translation>Gestione password</translation>
    </message>
    <message>
        <source>Global shortcut already registered to %1</source>
        <translation>Scorciatoia globale già registrata a %1</translation>
    </message>
    <message>
        <source>Could not register global shortcut</source>
        <translation>Impossibile registrare la scorciatoia globale</translation>
    </message>
</context>
<context>
    <name>OpData01</name>
    <message>
        <source>Invalid OpData01, does not contain header</source>
        <translation>OpData01 non valido, non contiene l&apos;intestazione</translation>
    </message>
    <message>
        <source>Unable to read all IV bytes, wanted 16 but got %1</source>
        <translation>Impossibile leggere tutti i byte IV, desiderati 16 ma ottenuti %1</translation>
    </message>
    <message>
        <source>Unable to init cipher for opdata01: %1</source>
        <translation>Impossibile inizializzare la cifratura per opdata01: %1</translation>
    </message>
    <message>
        <source>Unable to read all HMAC signature bytes</source>
        <translation>Impossibile leggere tutti i byte della firma HMAC</translation>
    </message>
    <message>
        <source>Malformed OpData01 due to a failed HMAC</source>
        <translation>OpData01 non valido a causa di un HMAC non riuscito</translation>
    </message>
    <message>
        <source>Unable to process clearText in place</source>
        <translation>Impossibile elaborare clearText sul posto</translation>
    </message>
    <message>
        <source>Expected %1 bytes of clear-text, found %2</source>
        <translation>Previsto %1 byte di testo non cifrato, trovato %2</translation>
    </message>
</context>
<context>
    <name>OpVaultReader</name>
    <message>
        <source>Directory .opvault must exist</source>
        <translation>La cartella .opvault deve esistere</translation>
    </message>
    <message>
        <source>Directory .opvault must be readable</source>
        <translation>La cartella .opvault deve essere leggibile</translation>
    </message>
    <message>
        <source>Directory .opvault/default must exist</source>
        <translation>La cartella .opvault/default deve esistere</translation>
    </message>
    <message>
        <source>Directory .opvault/default must be readable</source>
        <translation>La cartella .opvault/default deve essere leggibile</translation>
    </message>
    <message>
        <source>Unable to decode masterKey: %1</source>
        <translation>Impossibile decodificare masterKey: %1</translation>
    </message>
    <message>
        <source>Unable to derive master key: %1</source>
        <translation>Impossibile derivare la chiave master: %1</translation>
    </message>
</context>
<context>
    <name>OpenSSHKey</name>
    <message>
        <source>Invalid key file, expecting an OpenSSH key</source>
        <translation>File chiave non valido, era attesa una chiave OpenSSH</translation>
    </message>
    <message>
        <source>PEM boundary mismatch</source>
        <translation>Mancata corrispondenza del margine PEM</translation>
    </message>
    <message>
        <source>Base64 decoding failed</source>
        <translation>Decodifica base64 non riuscita</translation>
    </message>
    <message>
        <source>Key file way too small.</source>
        <translation>File chiave decisamente troppo piccolo.</translation>
    </message>
    <message>
        <source>Key file magic header id invalid</source>
        <translation>Id dell&apos;intestazione magica del file chiave non valido</translation>
    </message>
    <message>
        <source>Found zero keys</source>
        <translation>Trovate zero chiavi</translation>
    </message>
    <message>
        <source>Corrupted key file, reading private key failed</source>
        <translation>File della chiave rovinato, impossibile leggere la chiave privata</translation>
    </message>
    <message>
        <source>Unsupported key type: %1</source>
        <translation>Tipo di chiave non supportato: %1</translation>
    </message>
    <message>
        <source>No private key payload to decrypt</source>
        <translation>Nessuna chiave privata da decifrare nel contenuto</translation>
    </message>
    <message>
        <source>Unknown cipher: %1</source>
        <translation>Tipo di cifrario non supportato: %1</translation>
    </message>
    <message>
        <source>AES-256/GCM is currently not supported</source>
        <translation>AES-256/GCM non è attualmente supportato</translation>
    </message>
    <message>
        <source>Passphrase is required to decrypt this key</source>
        <translation>La decifrazione di questa chiave richiede una frase segreta</translation>
    </message>
    <message>
        <source>Key derivation failed: %1</source>
        <translation>Derivazione chiave non riuscita: %1</translation>
    </message>
    <message>
        <source>Cipher IV is too short for MD5 kdf</source>
        <translation>Il vettore di inizializzazione del cifrario è troppo corto per la derivazione della chiave di cifratura tramite MD5</translation>
    </message>
    <message>
        <source>Unknown KDF: %1</source>
        <translation>KDF sconosciuto: %1</translation>
    </message>
    <message>
        <source>Failed to initialize cipher: %1</source>
        <translation>Impossibile inizializzare il cifrario: %1</translation>
    </message>
    <message>
        <source>Decryption failed: %1</source>
        <translation>Decifratura non riuscita: %1</translation>
    </message>
    <message>
        <source>Decryption failed, wrong passphrase?</source>
        <translation>Decifratura non riuscita, frase segreta non corretta?</translation>
    </message>
    <message>
        <source>Unexpected EOF while reading key</source>
        <translation>EOF imprevisto durante la lettura della chiave</translation>
    </message>
    <message>
        <source>Unsupported key part</source>
        <translation>Parte di chiave non supportata</translation>
    </message>
    <message>
        <source>Unexpected EOF while reading public key</source>
        <translation>EOF imprevisto durante la lettura della chiave pubblica</translation>
    </message>
    <message>
        <source>Unknown key type: %1</source>
        <translation>Tipo di chiave sconosciuta: %1</translation>
    </message>
    <message>
        <source>Unexpected EOF while reading private key</source>
        <translation>EOF imprevisto durante la lettura della chiave privata</translation>
    </message>
    <message>
        <source>Can&apos;t write public key as it is empty</source>
        <translation>Impossibile scrivere la chiave pubblica perché è vuota</translation>
    </message>
    <message>
        <source>Unexpected EOF when writing public key</source>
        <translation>EOF imprevisto durante la scrittura di chiave pubblica</translation>
    </message>
    <message>
        <source>Can&apos;t write private key as it is empty</source>
        <translation>Impossibile scrivere la chiave privata perché è vuota</translation>
    </message>
    <message>
        <source>Unexpected EOF when writing private key</source>
        <translation>EOF imprevisto durante la scrittura di una chiave privata</translation>
    </message>
    <message>
        <source>(encrypted)</source>
        <translation>(cifrato)</translation>
    </message>
    <message>
        <source>Failed to read key file: %1</source>
        <translation>Impossibile leggere file chiave: %1</translation>
    </message>
    <message>
        <source>Failed to read public key: %1</source>
        <translation>Impossibile leggere chiave pubblica: %1</translation>
    </message>
</context>
<context>
    <name>OpenSSHKeyGenDialog</name>
    <message>
        <source>SSH Key Generator</source>
        <translation>Generatore chiave SSH</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <source>Bits</source>
        <translation>Bit</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>Commento</translation>
    </message>
</context>
<context>
    <name>PasskeyExportDialog</name>
    <message>
        <source>KeePassXC - Passkey Export</source>
        <translation>KeePassXC - Esporta passkey</translation>
    </message>
    <message>
        <source>Filenames will be generated with title and .passkey file extension.</source>
        <translation>I nomi dei file saranno generati con titolo ed estensione file .passkey.</translation>
    </message>
    <message>
        <source>Export entries</source>
        <translation>Esporta voci</translation>
    </message>
    <message>
        <source>Export Selected</source>
        <translation>Esporta selezionate</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Annulla</translation>
    </message>
    <message>
        <source>Export to folder</source>
        <translation>Esporta su cartella</translation>
    </message>
    <message>
        <source>Export the following passkey entries.</source>
        <translation>Esporta le voci passkey seguenti.</translation>
    </message>
</context>
<context>
    <name>PasskeyExporter</name>
    <message>
        <source>File &quot;%1.passkey&quot; already exists.
Do you want to overwrite it?
</source>
        <translation>Il file &quot;%1.passkey&quot; esiste già.
Vuoi sovrascriverlo?
</translation>
    </message>
    <message>
        <source>Cannot open file</source>
        <translation>Impossibile aprire file</translation>
    </message>
    <message>
        <source>Cannot open file &quot;%1&quot; for writing.</source>
        <translation>Impossibile aprire il file &quot;%1&quot; in scrittura.</translation>
    </message>
    <message>
        <source>Cannot write to file</source>
        <translation>Impossibile scrivere su file</translation>
    </message>
    <message>
        <source>Overwrite Existing File?</source>
        <translation>Vuoi sovrascrivere il file esistente?</translation>
    </message>
</context>
<context>
    <name>PasskeyImportDialog</name>
    <message>
        <source>KeePassXC - Passkey Import</source>
        <translation>KeePassXC - Importa passkey</translation>
    </message>
    <message>
        <source>Username: %1</source>
        <translation>Nome utente: %1</translation>
    </message>
    <message>
        <source>Group</source>
        <translation>Gruppo</translation>
    </message>
    <message>
        <source>Database</source>
        <translation>Database</translation>
    </message>
    <message>
        <source>Import Passkey</source>
        <translation>Importa Passkey</translation>
    </message>
    <message>
        <source>Import</source>
        <translation>Importa</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Annulla</translation>
    </message>
    <message>
        <source>Entry</source>
        <translation>Voce</translation>
    </message>
    <message>
        <source>Create new entry</source>
        <translation>Crea nuova voce</translation>
    </message>
    <message>
        <source>Relying Party: %1</source>
        <translation>Relying Party: %1</translation>
    </message>
    <message>
        <source>Import the following passkey:</source>
        <translation>Importa la seguente passkey:</translation>
    </message>
    <message>
        <source>Import the following passkey to this entry:</source>
        <translation>Importa la passkey seguente in questa voce:</translation>
    </message>
    <message>
        <source>Default passkeys group (Imported Passkeys)</source>
        <translation>Gruppo passkeys predefinito (Passkeys Importate)</translation>
    </message>
</context>
<context>
    <name>PasskeyImporter</name>
    <message>
        <source>Passkey file</source>
        <translation>File passkey</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>Tutti i file</translation>
    </message>
    <message>
        <source>Cannot open file</source>
        <translation>Impossibile aprire file</translation>
    </message>
    <message>
        <source>Cannot open file &quot;%1&quot; for reading.</source>
        <translation>Impossibile aprire il file &quot;%1&quot; in lettura.</translation>
    </message>
    <message>
        <source>Cannot import passkey file &quot;%1&quot;. Data is missing.</source>
        <translation>Impossibile importare il file passkey &quot;%1&quot;. Mancano i dati.</translation>
    </message>
    <message>
        <source>Cannot import passkey file &quot;%1&quot;.
The following data is missing:
%2</source>
        <translation>Impossibile importare il file passkey &quot;%1&quot;.
Mancano i seguenti dati:
%2</translation>
    </message>
    <message>
        <source>Cannot import passkey file &quot;%1&quot;. Private key is missing or malformed.</source>
        <translation>Impossibile importare il file passkey &quot;%1&quot;. La chiave privata è mancante o malformata. </translation>
    </message>
    <message>
        <source>Open Passkey File</source>
        <translation>Apri file passkey</translation>
    </message>
    <message>
        <source>Passkey Import Failed</source>
        <translation>Importazione passkey non riuscita</translation>
    </message>
</context>
<context>
    <name>PasswordEditWidget</name>
    <message>
        <source>Enter password:</source>
        <translation>Inserisci password:</translation>
    </message>
    <message>
        <source>Password field</source>
        <translation>Campo password</translation>
    </message>
    <message>
        <source>Confirm password:</source>
        <translation>Conferma password:</translation>
    </message>
    <message>
        <source>Repeat password field</source>
        <translation>Campo ripeti password</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Password</translation>
    </message>
    <message>
        <source>Add Password</source>
        <translation>Aggiungi password</translation>
    </message>
    <message>
        <source>Change Password</source>
        <translation>Cambia password</translation>
    </message>
    <message>
        <source>Remove Password</source>
        <translation>Rimuovi password</translation>
    </message>
    <message>
        <source>Password set, click to change or remove</source>
        <translation>Password impostata, fai clic per modificarla/rimuoverla</translation>
    </message>
    <message>
        <source>&lt;p&gt;A password is the primary method for securing your database.&lt;/p&gt;&lt;p&gt;Good passwords are long and unique. KeePassXC can generate one for you.&lt;/p&gt;</source>
        <translation>&lt;p&gt;Una password è il metodo principale per mantenere sicuro il database.&lt;/p&gt;&lt;p&gt;Una buona password dev&apos;essere lunga ed unica. KeePassXC può generarne una per voi.&lt;/p&gt;</translation>
    </message>
    <message>
        <source>Passwords do not match.</source>
        <translation>Le password non corrispondono.</translation>
    </message>
</context>
<context>
    <name>PasswordGeneratorWidget</name>
    <message>
        <source>Generate Password</source>
        <translation>Genera password</translation>
    </message>
    <message>
        <source>strength</source>
        <comment>Password strength</comment>
        <translation>affidabilità</translation>
    </message>
    <message>
        <source>entropy</source>
        <translation>entropia</translation>
    </message>
    <message>
        <source>Generated password</source>
        <translation>Password generata</translation>
    </message>
    <message>
        <source>%p%</source>
        <translation>%p%</translation>
    </message>
    <message>
        <source>Regenerate password</source>
        <translation>Rigenera password</translation>
    </message>
    <message>
        <source>Copy password</source>
        <translation>Copia password</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Password</translation>
    </message>
    <message>
        <source>&amp;Length:</source>
        <translation>&amp;Lunghezza:</translation>
    </message>
    <message>
        <source>Password length</source>
        <translation>Lunghezza password</translation>
    </message>
    <message>
        <source>Switch to advanced mode</source>
        <translation>Passa alla modalità avanzata</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>Avanzate</translation>
    </message>
    <message>
        <source>Character Types</source>
        <translation>Tipi di carattere</translation>
    </message>
    <message>
        <source>Special characters</source>
        <translation>Caratteri speciali</translation>
    </message>
    <message>
        <source>Quotes</source>
        <translation>Citazioni</translation>
    </message>
    <message>
        <source>Punctuation</source>
        <translation>Punteggiatura</translation>
    </message>
    <message>
        <source>Dashes and Slashes</source>
        <translation>Trattini e barre</translation>
    </message>
    <message>
        <source>Upper-case letters</source>
        <translation>Lettere maiuscole</translation>
    </message>
    <message>
        <source>Numbers</source>
        <translation>Numeri</translation>
    </message>
    <message>
        <source>Lower-case letters</source>
        <translation>Lettere minuscole</translation>
    </message>
    <message>
        <source>Math Symbols</source>
        <translation>Simboli matematici</translation>
    </message>
    <message>
        <source>Extended ASCII</source>
        <translation>ASCII esteso</translation>
    </message>
    <message>
        <source>Braces</source>
        <translation>Parentesi graffe</translation>
    </message>
    <message>
        <source>Do not include:</source>
        <translation>Non includere:</translation>
    </message>
    <message>
        <source>Additional characters to use for the generated password</source>
        <translation>Caratteri aggiuntivi da usare nella generazione delle password</translation>
    </message>
    <message>
        <source>Additional characters</source>
        <translation>Caratteri aggiuntivi </translation>
    </message>
    <message>
        <source>Add non-hex letters to &quot;do not include&quot; list</source>
        <translation>Aggiungi lettere non esadecimali all&apos;elenco &quot;non includere&quot;</translation>
    </message>
    <message>
        <source>Hex Passwords</source>
        <translation>Password esadecimali</translation>
    </message>
    <message>
        <source>Hex</source>
        <translation>Hex</translation>
    </message>
    <message>
        <source>Character set to exclude from generated password</source>
        <translation>Set di caratteri da escludere dalla password generata</translation>
    </message>
    <message>
        <source>Excluded characters</source>
        <translation>Caratteri esclusi</translation>
    </message>
    <message>
        <source>Also choose from:</source>
        <translation>Scegli anche tra:</translation>
    </message>
    <message>
        <source>Exclude look-alike characters</source>
        <translation>Escludi caratteri simili</translation>
    </message>
    <message>
        <source>Pick characters from every group</source>
        <translation>Seleziona caratteri da ogni gruppo</translation>
    </message>
    <message>
        <source>Passphrase</source>
        <translation>Frase segreta</translation>
    </message>
    <message>
        <source>Word Separator:</source>
        <translation>Separatore parole:</translation>
    </message>
    <message>
        <source>Wordlist:</source>
        <translation>Elenco termini:</translation>
    </message>
    <message>
        <source>Word Count:</source>
        <translation>Conteggio parole:</translation>
    </message>
    <message>
        <source>Word Case:</source>
        <translation>Parole maiuscole/minuscole:</translation>
    </message>
    <message>
        <source>Delete selected wordlist</source>
        <translation>Elimina elenco parole selezionato</translation>
    </message>
    <message>
        <source>Add custom wordlist</source>
        <translation>Aggiungi elenco parole personalizzato</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Chiudi</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
    <message>
        <source>Apply Password</source>
        <translation>Applica password</translation>
    </message>
    <message>
        <source>Regenerate password (%1)</source>
        <translation>Rigenera password (%1)</translation>
    </message>
    <message>
        <source>lower case</source>
        <translation>carattere minuscolo</translation>
    </message>
    <message>
        <source>UPPER CASE</source>
        <translation>MAIUSCOLO</translation>
    </message>
    <message>
        <source>Title Case</source>
        <translation>Titolo maiuscolo/minuscolo</translation>
    </message>
    <message>
        <source>(SYSTEM)</source>
        <translation>(SYSTEM)</translation>
    </message>
    <message>
        <source>Entropy: %1 bit</source>
        <translation>Entropia: %1 bit</translation>
    </message>
    <message>
        <source>Password Quality: %1</source>
        <translation>Qualità password: %1</translation>
    </message>
    <message>
        <source>Poor</source>
        <comment>Password quality</comment>
        <translation>Debole</translation>
    </message>
    <message>
        <source>Weak</source>
        <comment>Password quality</comment>
        <translation>Intermedia</translation>
    </message>
    <message>
        <source>Good</source>
        <comment>Password quality</comment>
        <translation>Buona</translation>
    </message>
    <message>
        <source>Excellent</source>
        <comment>Password quality</comment>
        <translation>Eccellente</translation>
    </message>
    <message>
        <source>Failed to delete wordlist</source>
        <translation>Impossibile eliminare l&apos;elenco parole</translation>
    </message>
    <message>
        <source>Wordlists</source>
        <translation>Elenchi di parole</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>Tutti i file</translation>
    </message>
    <message>
        <source>Select Custom Wordlist</source>
        <translation>Seleziona elenco parole personalizzato</translation>
    </message>
    <message>
        <source>Overwrite Wordlist?</source>
        <translation>Vuoi sovrascrivere l&apos;elenco delle parole?</translation>
    </message>
    <message>
        <source>Wordlist &quot;%1&quot; already exists as a custom wordlist.
Do you want to overwrite it?</source>
        <translation>L&apos;elenco parole &quot;%1&quot; esiste già come elenco parole personalizzato.
Vuoi sovrascriverlo?</translation>
    </message>
    <message>
        <source>Failed to add wordlist</source>
        <translation>Impossibile aggiungere l&apos;elenco parole</translation>
    </message>
    <message>
        <source>Logograms</source>
        <translation>Logogrammi</translation>
    </message>
    <message>
        <source>Special Characters</source>
        <translation>Caratteri speciali</translation>
    </message>
    <message>
        <source>passwordLength</source>
        <translation>passwordLength</translation>
    </message>
    <message>
        <source>Characters: %1</source>
        <translation>Caratteri :%1</translation>
    </message>
    <message>
        <source>MIXED case</source>
        <translation>Lettere maiuscole e minuscole</translation>
    </message>
    <message>
        <source>Excluded characters: &quot;0&quot;, &quot;1&quot;, &quot;l&quot;, &quot;I&quot;, &quot;O&quot;, &quot;|&quot;, &quot;﹒&quot;, &quot;B&quot;, &quot;8&quot;, &quot;G&quot;, &quot;6&quot;</source>
        <translation>Caratteri esclusi: &quot;0&quot;, &quot;1&quot;, &quot;l&quot;, &quot;I&quot;, &quot;O&quot;, &quot;|&quot;, &quot;﹒&quot;, &quot;B&quot;, &quot;8&quot;, &quot;G&quot;, &quot;6&quot;</translation>
    </message>
    <message>
        <source>Warning: the chosen wordlist is smaller than the minimum recommended size!</source>
        <translation>Attenzione: l&apos;elenco parole selezionato ha una dimensione più piccola della dimensione suggerita!</translation>
    </message>
    <message>
        <source>Confirm Remove Wordlist</source>
        <translation>Conferma rimozione elenco parole</translation>
    </message>
    <message>
        <source>Do you really want to remove the wordlist &quot;%1&quot;?</source>
        <translation>Vuoi rimuovere l&apos;elenco parole &quot;%1&quot;?</translation>
    </message>
</context>
<context>
    <name>PasswordWidget</name>
    <message>
        <source>Passwords do not match</source>
        <translation>Le password non corrispondono</translation>
    </message>
    <message>
        <source>Passwords match so far</source>
        <translation>Le password corrispondono finora</translation>
    </message>
    <message>
        <source>Toggle Password (%1)</source>
        <translation>Attiva/disattiva password (%1)</translation>
    </message>
    <message>
        <source>Generate Password (%1)</source>
        <translation>Genera password (%1)</translation>
    </message>
    <message>
        <source>Warning: Caps Lock enabled!</source>
        <translation>Attenzione: Caps Lock abilitato!</translation>
    </message>
    <message>
        <source>Quality: %1</source>
        <translation>Qualità: %1</translation>
    </message>
    <message>
        <source>Poor</source>
        <comment>Password quality</comment>
        <translation>Debole</translation>
    </message>
    <message>
        <source>Weak</source>
        <comment>Password quality</comment>
        <translation>Intermedia</translation>
    </message>
    <message>
        <source>Good</source>
        <comment>Password quality</comment>
        <translation>Buona</translation>
    </message>
    <message>
        <source>Excellent</source>
        <comment>Password quality</comment>
        <translation>Eccellente</translation>
    </message>
    <message>
        <source>Toggle password visibility using Control + H. Open the password generator using Control + G.</source>
        <translation>Visualizza/nascondi password con Control + H. Apri il generatore di password con Control + G.</translation>
    </message>
</context>
<context>
    <name>PickcharsDialog</name>
    <message>
        <source>KeePassXC - Pick Characters</source>
        <translation>KeePassXC - Scegli caratteri</translation>
    </message>
    <message>
        <source>Select characters to type, navigate with arrow keys, Ctrl + S submits.</source>
        <translation>Seleziona i caratteri da digitare, spostati con i tasti di direzione, CTRL+S per inviare.</translation>
    </message>
    <message>
        <source>Press &amp;Tab between characters</source>
        <translation>Premi &amp;Tab tra i caratteri</translation>
    </message>
</context>
<context>
    <name>PreviewEntryAttachmentsDialog</name>
    <message>
        <source>Form</source>
        <translation>Modulo</translation>
    </message>
    <message>
        <source>Preview: %1</source>
        <translation>Anteprima: %1</translation>
    </message>
    <message>
        <source>Save…</source>
        <translation>Salva...</translation>
    </message>
</context>
<context>
    <name>QMessageBox</name>
    <message>
        <source>Overwrite</source>
        <translation>Sovrascrivi</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Elimina</translation>
    </message>
    <message>
        <source>Move</source>
        <translation>Sposta</translation>
    </message>
    <message>
        <source>Empty</source>
        <translation>Vuoto</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Rimuovi</translation>
    </message>
    <message>
        <source>Skip</source>
        <translation>Salta</translation>
    </message>
    <message>
        <source>Disable</source>
        <translation>Disabilita</translation>
    </message>
    <message>
        <source>Merge</source>
        <translation>Incorpora</translation>
    </message>
    <message>
        <source>Continue</source>
        <translation>continuare</translation>
    </message>
    <message>
        <source>Continue with weak password</source>
        <translation>Continua con la password debole</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Database not opened</source>
        <translation>Database non aperto</translation>
    </message>
    <message>
        <source>Database hash not available</source>
        <translation>Hash del database non disponibile</translation>
    </message>
    <message>
        <source>Client public key not received</source>
        <translation>Chiave pubblica del client non ricevuta</translation>
    </message>
    <message>
        <source>Cannot decrypt message</source>
        <translation>Impossibile decifrare il messaggio</translation>
    </message>
    <message>
        <source>Action cancelled or denied</source>
        <translation>Azione annullata o negata</translation>
    </message>
    <message>
        <source>Message encryption failed.</source>
        <translation>Cifratura del messaggio non riuscita.</translation>
    </message>
    <message>
        <source>KeePassXC association failed, try again</source>
        <translation>Associazione KeePassXC non riuscita, riprova</translation>
    </message>
    <message>
        <source>Encryption key is not recognized</source>
        <translation>Chiave di cifratura non riconosciuta</translation>
    </message>
    <message>
        <source>Incorrect action</source>
        <translation>Azione non corretta</translation>
    </message>
    <message>
        <source>Empty message received</source>
        <translation>Ricevuto un messaggio vuoto</translation>
    </message>
    <message>
        <source>No URL provided</source>
        <translation>Nessun URL fornito</translation>
    </message>
    <message>
        <source>No logins found</source>
        <translation>Nessun login trovato</translation>
    </message>
    <message>
        <source>No groups found</source>
        <translation>Nessun gruppo trovato</translation>
    </message>
    <message>
        <source>Cannot create new group</source>
        <translation>Impossibile creare un nuovo gruppo</translation>
    </message>
    <message>
        <source>No valid UUID provided</source>
        <translation>Nessun UUID valido fornito</translation>
    </message>
    <message>
        <source>Username or password cannot contain references</source>
        <translation>Nome utente e password non possono contenere riferimenti</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation>Errore sconosciuto</translation>
    </message>
    <message>
        <source>Browser Integration</source>
        <translation>Integrazione browser</translation>
    </message>
    <message>
        <source>Browser Plugin Failure</source>
        <translation>Errore del plug-in del browser</translation>
    </message>
    <message>
        <source>Could not save the native messaging script file for %1.</source>
        <translation>Impossibile salvare il file di script nativo di messaggistica per %1.</translation>
    </message>
    <message>
        <source>Username for the entry.</source>
        <translation>Nome utente della voce.</translation>
    </message>
    <message>
        <source>username</source>
        <translation>nome utente</translation>
    </message>
    <message>
        <source>URL for the entry.</source>
        <translation>URL della voce.</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>Notes for the entry.</source>
        <translation>Note per la voce.</translation>
    </message>
    <message>
        <source>Notes</source>
        <translation>Note</translation>
    </message>
    <message>
        <source>Prompt for the entry&apos;s password.</source>
        <translation>Richiedi la password della voce.</translation>
    </message>
    <message>
        <source>Generate a password for the entry.</source>
        <translation>Genera una password per questa voce.</translation>
    </message>
    <message>
        <source>Add a new entry to a database.</source>
        <translation>Aggiungi una nuova voce al database.</translation>
    </message>
    <message>
        <source>Path of the entry to add.</source>
        <translation>Percorso della voce da aggiungere.</translation>
    </message>
    <message>
        <source>Cannot generate a password and prompt at the same time.</source>
        <translation>Impossibile generare una password e chiedere conferma contemporaneamente.</translation>
    </message>
    <message>
        <source>Could not create entry with path %1.</source>
        <translation>Impossibile creare la voce con il percorso %1.</translation>
    </message>
    <message>
        <source>Enter password for new entry: </source>
        <translation>Inserisci la password per la nuova voce: </translation>
    </message>
    <message>
        <source>Writing the database failed %1.</source>
        <translation>Scrittura del database non riuscita %1.</translation>
    </message>
    <message>
        <source>Successfully added entry %1.</source>
        <translation>Aggiunta con successo la voce %1.</translation>
    </message>
    <message>
        <source>Adds a new group to a database.</source>
        <translation>Aggiunge un nuovo gruppo a un database.</translation>
    </message>
    <message>
        <source>Path of the group to add.</source>
        <translation>Percorso del gruppo da aggiungere.</translation>
    </message>
    <message>
        <source>Group %1 already exists!</source>
        <translation>Il gruppo %1 esiste già!</translation>
    </message>
    <message>
        <source>Group %1 not found.</source>
        <translation>Gruppo %1 non trovato.</translation>
    </message>
    <message>
        <source>Successfully added group %1.</source>
        <translation>Aggiunta del gruppo %1 completata.</translation>
    </message>
    <message>
        <source>Check if any passwords have been publicly leaked. FILENAME must be the path of a file listing SHA-1 hashes of leaked passwords in HIBP format, as available from https://haveibeenpwned.com/Passwords.</source>
        <translation>Verifica se le password sono state rivelate pubblicamente. FILENAME deve essere il percorso di un file che elenca gli hashe SHA-1 delle password rivelate in formato HIBP, come disponibile da https://haveibeenpwned.com/Passwords.</translation>
    </message>
    <message>
        <source>FILENAME</source>
        <translation>Filename</translation>
    </message>
    <message>
        <source>Path to okon-cli to search a formatted HIBP file</source>
        <translation>Percorso di okon-cli per la ricerca in un file HIBP formattato</translation>
    </message>
    <message>
        <source>okon-cli</source>
        <translation>okon-cli</translation>
    </message>
    <message>
        <source>Analyze passwords for weaknesses and problems.</source>
        <translation>Analizza le password per trovare punti deboli e problemi.</translation>
    </message>
    <message>
        <source>Cannot find HIBP file: %1</source>
        <translation>Impossibile trovare il file HIBP: %1</translation>
    </message>
    <message>
        <source>Evaluating database entries using okon…</source>
        <translation>Valutazione delle voci del database tramite okon...</translation>
    </message>
    <message>
        <source>Failed to open HIBP file %1: %2</source>
        <translation>Impossibile aprire il file HIBP %1: %2</translation>
    </message>
    <message>
        <source>Evaluating database entries against HIBP file, this will take a while…</source>
        <translation>Valutazione delle voci del database rispetto al file HIBP, questo prenderà un po&apos; di tempo...</translation>
    </message>
    <message numerus="yes">
        <source>Password for &apos;%1&apos; has been leaked %2 time(s)!</source>
        <translation><numerusform>La password per &apos;%1&apos; è trapelata %2 volta!</numerusform><numerusform>La password per &apos;%1&apos; è trapelata %2 volte!</numerusform><numerusform>La password per &apos;%1&apos; è trapelata %2 volte!</numerusform></translation>
    </message>
    <message>
        <source>Password for &apos;%1&apos; has been leaked!</source>
        <translation>La password per &apos;%1&apos; è trapelata!</translation>
    </message>
    <message>
        <source>Export an attachment of an entry.</source>
        <translation>Esporta l&apos; allegato di un elemento.</translation>
    </message>
    <message>
        <source>Path of the entry with the target attachment.</source>
        <translation>Percorso dell&apos;elemento con l&apos;allegato destinazione.</translation>
    </message>
    <message>
        <source>Name of the attachment to be exported.</source>
        <translation>Nome dell&apos;allegato da esportare.</translation>
    </message>
    <message>
        <source>Path to which the attachment should be exported.</source>
        <translation>Percorso in cui esportare l&apos;allegato.</translation>
    </message>
    <message>
        <source>Could not find entry with path %1.</source>
        <translation>Impossibile trovare la voce con percorso %1.</translation>
    </message>
    <message>
        <source>Could not find attachment with name %1.</source>
        <translation>Impossibile trovare l&apos;allegato con il nome %1.</translation>
    </message>
    <message>
        <source>No export target given. Please use &apos;--stdout&apos; or specify an &apos;export-file&apos;.</source>
        <translation>Nessun obiettivo esportazione assegnato. 
Usa &apos;--stdout&apos; o specifica un &apos;file-esportazione&apos;.</translation>
    </message>
    <message>
        <source>Could not open output file %1.</source>
        <translation>Impossibile aprire il file destinazione %1.</translation>
    </message>
    <message>
        <source>Successfully exported attachment %1 of entry %2 to %3.</source>
        <translation>Completata esportazione in %3 dell&apos;allegato %1 dell&apos;elemento %2.</translation>
    </message>
    <message>
        <source>Overwrite existing attachments.</source>
        <translation>Sovrascrivi allegati esistenti.</translation>
    </message>
    <message>
        <source>Imports an attachment to an entry.</source>
        <translation>Importa un allegato di un elemento.</translation>
    </message>
    <message>
        <source>Path of the entry.</source>
        <translation>Percorso di un elemento.</translation>
    </message>
    <message>
        <source>Name of the attachment to be added.</source>
        <translation>Nome dell&apos;allegato da aggiungere.</translation>
    </message>
    <message>
        <source>Path of the attachment to be imported.</source>
        <translation>Percorso dell&apos;allegato da importare.</translation>
    </message>
    <message>
        <source>Attachment %1 already exists for entry %2.</source>
        <translation>L&apos;allegato %1 esiste già per l&apos;elemento %2.</translation>
    </message>
    <message>
        <source>Could not open attachment file %1.</source>
        <translation>Impossibile aprire il file allegato %1.</translation>
    </message>
    <message>
        <source>Successfully imported attachment %1 as %2 to entry %3.</source>
        <translation>Completata importazione dell&apos;allegato %1 come %2 nell&apos;elemento %3.</translation>
    </message>
    <message>
        <source>Remove an attachment of an entry.</source>
        <translation>Rimuovi allegato di un elemento.</translation>
    </message>
    <message>
        <source>Name of the attachment to be removed.</source>
        <translation>Nome dell&apos;allegato da rimuovere.</translation>
    </message>
    <message>
        <source>Successfully removed attachment %1 from entry %2.</source>
        <translation>Completata rimozione dell&apos;allegato %1 dall&apos;elemento %2.</translation>
    </message>
    <message>
        <source>Copy the given attribute to the clipboard. Defaults to &quot;password&quot; if not specified.</source>
        <comment>Don't translate &quot;password&quot;, it refers to the attribute.</comment>
        <translation>Copia l&apos;attributo negli appunti. L&apos;impostazione predefinita è &quot;password&quot; se non specificato.</translation>
    </message>
    <message>
        <source>Copy the current TOTP to the clipboard (equivalent to &quot;-a totp&quot;).</source>
        <translation>Copia il TOTP negli appunti (analogo a &quot;-a totp&quot;).</translation>
    </message>
    <message>
        <source>Must match only one entry, otherwise a list of possible matches is shown.</source>
        <translation>Deve corrispondere a una sola voce, altrimenti viene visualizzato un elenco di possibili corrispondenze.</translation>
    </message>
    <message>
        <source>Copy an entry&apos;s attribute to the clipboard.</source>
        <translation>Copia l&apos;attributo della voce negli appunti.</translation>
    </message>
    <message>
        <source>Path of the entry to clip.</source>
        <comment>clip = copy to clipboard</comment>
        <translation>Percorso della voce da tagliare.</translation>
    </message>
    <message>
        <source>Timeout before clearing the clipboard (default is %1 seconds, set to 0 for unlimited).</source>
        <translation>Timeout prima di cancellare gli appunti (l&apos;impostazione predefinita è %1 secondi, impostata su 0 illimitato).</translation>
    </message>
    <message>
        <source>Invalid timeout value %1.</source>
        <translation>Valore di timeout %1 non valido.</translation>
    </message>
    <message>
        <source>Multiple entries matching:</source>
        <translation>Corrispondenza di più voci:</translation>
    </message>
    <message>
        <source>Using matching entry: %1</source>
        <translation>Voce corrispondente usata: %1</translation>
    </message>
    <message>
        <source>Entry %1 not found.</source>
        <translation>Voce %1 non trovata.</translation>
    </message>
    <message>
        <source>ERROR: Please specify one of --attribute or --totp, not both.</source>
        <translation>ERRORE: Specifica uno solo tra --attribute o --totp, non entrambi.</translation>
    </message>
    <message>
        <source>Entry with path %1 has no TOTP set up.</source>
        <translation>La voce con percorso %1 non ha impostato TOTP.</translation>
    </message>
    <message>
        <source>ERROR: attribute %1 is ambiguous, it matches %2.</source>
        <translation>ERRORE: l&apos;attributo %1 è ambiguo, corrisponde con %2.</translation>
    </message>
    <message>
        <source>Attribute &quot;%1&quot; not found.</source>
        <translation>Attributo &quot;%1&quot; non trovato.</translation>
    </message>
    <message>
        <source>Entry&apos;s &quot;%1&quot; attribute copied to the clipboard!</source>
        <translation>Attributo della voce &quot;%1&quot; copiato negli appunti!</translation>
    </message>
    <message numerus="yes">
        <source>Clearing the clipboard in %1 second(s)...</source>
        <translation><numerusform>Cancellazione degli Appunti in %1 secondi...</numerusform><numerusform>Cancellazione degli appunti in %1 secondo(i)...</numerusform><numerusform>Cancellazione degli appunti in %1 secondo(i)...</numerusform></translation>
    </message>
    <message>
        <source>Clipboard cleared!</source>
        <translation>Appunti cancellati!</translation>
    </message>
    <message>
        <source>Close the currently opened database.</source>
        <translation>Chiudi il database attualmente aperto.</translation>
    </message>
    <message>
        <source>Display this help.</source>
        <translation>Visualizza questa guida.</translation>
    </message>
    <message>
        <source>Silence password prompt and other secondary outputs.</source>
        <translation>Silenzia la richiesta di password e altri output secondari.</translation>
    </message>
    <message>
        <source>Key file of the database.</source>
        <translation>File chiave del database.</translation>
    </message>
    <message>
        <source>path</source>
        <translation>percorso</translation>
    </message>
    <message>
        <source>Deactivate password key for the database.</source>
        <translation>Disattiva la chiave password per il database.</translation>
    </message>
    <message>
        <source>Yubikey slot and optional serial used to access the database (e.g., 1:7370001).</source>
        <translation>Slot Yubikey e porta seriale opzionale usata per l&apos;accesso al database (es. 1:7370001).</translation>
    </message>
    <message>
        <source>slot[:serial]</source>
        <translation>slot[:serial]</translation>
    </message>
    <message>
        <source>Missing positional argument(s).</source>
        <translation>Argomento(i) posizionale(i) mancante(i).</translation>
    </message>
    <message>
        <source>Too many arguments provided.</source>
        <translation>Troppi argomenti forniti.</translation>
    </message>
    <message>
        <source>Path of the database.</source>
        <translation>Percorso del database.</translation>
    </message>
    <message>
        <source>Target decryption time in MS for the database.</source>
        <translation>Il tempo di decifratura del database in MS.</translation>
    </message>
    <message>
        <source>time</source>
        <translation>orario</translation>
    </message>
    <message>
        <source>Set the key file for the database.</source>
        <translation>Imposta un file chiave per il database.</translation>
    </message>
    <message>
        <source>Set a password for the database.</source>
        <translation>Imposta una password per il database.</translation>
    </message>
    <message>
        <source>Create a new database.</source>
        <translation>Crea un nuovo database.</translation>
    </message>
    <message>
        <source>Invalid decryption time %1.</source>
        <translation>Tempo di decifratura non valido %1.</translation>
    </message>
    <message>
        <source>Target decryption time must be between %1 and %2.</source>
        <translation>Il tempo di decifratura deve essere compreso tra %1 e %2.</translation>
    </message>
    <message>
        <source>Failed to set database password.</source>
        <translation>Impossibile salvare la password del database.</translation>
    </message>
    <message>
        <source>Loading the key file failed</source>
        <translation>Caricamento del key-file non riuscito.</translation>
    </message>
    <message>
        <source>No key is set. Aborting database creation.</source>
        <translation>Chiave non impostata. Annullamento creazione database.</translation>
    </message>
    <message>
        <source>Benchmarking key derivation function for %1ms delay.</source>
        <translation>Test delle prestazioni della funzione di derivazione della chiave per %1ms di ritardo.</translation>
    </message>
    <message>
        <source>Setting %1 rounds for key derivation function.</source>
        <translation>Imposta %1 iterazioni per la funzione di derivazione della chiave.</translation>
    </message>
    <message>
        <source>error while setting database key derivation settings.</source>
        <translation>Errore durante il salvataggio delle impostazioni della chiave di derivazione.</translation>
    </message>
    <message>
        <source>File %1 already exists.</source>
        <translation>Il file %1 esiste già.</translation>
    </message>
    <message>
        <source>Failed to save the database: %1.</source>
        <translation>Impossibile salvare il database: %1.</translation>
    </message>
    <message>
        <source>Successfully created new database.</source>
        <translation>Nuovo database creato con successo.</translation>
    </message>
    <message>
        <source>Unset the password for the database.</source>
        <translation>Rimuovi la password del database.</translation>
    </message>
    <message>
        <source>Unset the key file for the database.</source>
        <translation>Rimuovi il file chiave del database.</translation>
    </message>
    <message>
        <source>Edit a database.</source>
        <translation>Modifica un database.</translation>
    </message>
    <message>
        <source>Cannot use %1 and %2 at the same time.</source>
        <translation>Non è possibile usare contemporaneamente &apos;%1&apos; e &apos;%2&apos; .</translation>
    </message>
    <message>
        <source>Could not change the database key.</source>
        <translation>Impossibile modificare la chiave del database.</translation>
    </message>
    <message>
        <source>Database was not modified.</source>
        <translation>Il database non è stato modificato.</translation>
    </message>
    <message>
        <source>Writing the database failed: %1</source>
        <translation>Scrittura del database non riuscita: %1</translation>
    </message>
    <message>
        <source>Successfully edited the database.</source>
        <translation>Database modificato correttamente.</translation>
    </message>
    <message>
        <source>Cannot remove password: The database does not have a password.</source>
        <translation>Impossibile rimuovere la password; il database non ha una password.</translation>
    </message>
    <message>
        <source>Cannot remove file key: The database does not have a file key.</source>
        <translation>Impossibile rimuovere il file chiave; il database non ha un file chiave.</translation>
    </message>
    <message>
        <source>Loading the new key file failed: %1</source>
        <translation>Caricamento del nuovo file chiave non riuscito: %1</translation>
    </message>
    <message>
        <source>Found unexpected Key type %1</source>
        <translation>Rilevato un tipo di chiave %1 inaspettato</translation>
    </message>
    <message>
        <source>Cannot remove all the keys from a database.</source>
        <translation>Impossibile rimuovere tutte le chiavi da un database.</translation>
    </message>
    <message>
        <source>Show a database&apos;s information.</source>
        <translation>Visualizza informazioni del database.</translation>
    </message>
    <message>
        <source>UUID: </source>
        <translation>UUID: </translation>
    </message>
    <message>
        <source>Name: </source>
        <translation>Nome: </translation>
    </message>
    <message>
        <source>Description: </source>
        <translation>Descrizione: </translation>
    </message>
    <message>
        <source>Cipher: </source>
        <translation>Cifrario: </translation>
    </message>
    <message>
        <source>KDF: </source>
        <translation>KDF: </translation>
    </message>
    <message>
        <source>Recycle bin is enabled.</source>
        <translation>Il Cestino è abilitato .</translation>
    </message>
    <message>
        <source>Recycle bin is not enabled.</source>
        <translation>Il Cestino non è abilitato.</translation>
    </message>
    <message>
        <source>Location</source>
        <translation>Posizione</translation>
    </message>
    <message>
        <source>Database created</source>
        <translation>Database creato</translation>
    </message>
    <message>
        <source>Last saved</source>
        <translation>Ultimo salvataggio</translation>
    </message>
    <message>
        <source>Unsaved changes</source>
        <translation>Modifiche non salvate</translation>
    </message>
    <message>
        <source>yes</source>
        <translation>sì</translation>
    </message>
    <message>
        <source>no</source>
        <translation>no</translation>
    </message>
    <message>
        <source>Number of groups</source>
        <translation>Numero di gruppi</translation>
    </message>
    <message>
        <source>Number of entries</source>
        <translation>Numero di voci</translation>
    </message>
    <message>
        <source>Number of expired entries</source>
        <translation>Numero di voci scadute</translation>
    </message>
    <message>
        <source>Unique passwords</source>
        <translation>Password univoche</translation>
    </message>
    <message>
        <source>Non-unique passwords</source>
        <translation>Password non univoche</translation>
    </message>
    <message>
        <source>Maximum password reuse</source>
        <translation>Massimo riutilizzo password</translation>
    </message>
    <message>
        <source>Number of short passwords</source>
        <translation>Numero di password brevi</translation>
    </message>
    <message>
        <source>Number of weak passwords</source>
        <translation>Numero di password deboli</translation>
    </message>
    <message>
        <source>Entries excluded from reports</source>
        <translation>Voci escluse dal rapporto</translation>
    </message>
    <message>
        <source>Average password length</source>
        <translation>Lunghezza media password</translation>
    </message>
    <message>
        <source>Number of passkeys</source>
        <translation>Numero di passkey</translation>
    </message>
    <message>
        <source>Entries with TOTP setup</source>
        <translation>Voci con configurazione TOTP</translation>
    </message>
    <message>
        <source>Word count for the diceware passphrase.</source>
        <translation>Numero di parole per la passphrase con lancio dei dadi</translation>
    </message>
    <message>
        <source>count</source>
        <comment>CLI parameter</comment>
        <translation>conteggio</translation>
    </message>
    <message>
        <source>Wordlist for the diceware generator.
[Default: EFF English]</source>
        <translation>Lista di parole per il generatore con lancio di dadi.
[Predefinito: inglese EFF]</translation>
    </message>
    <message>
        <source>Generate a new random diceware passphrase.</source>
        <translation>Genera una nuova passphrase casuale simulando un lancio di dadi.</translation>
    </message>
    <message>
        <source>Invalid word count %1</source>
        <translation>Conteggio parole non valido %1</translation>
    </message>
    <message>
        <source>Title for the entry.</source>
        <translation>Titolo di una voce.</translation>
    </message>
    <message>
        <source>title</source>
        <translation>titolo</translation>
    </message>
    <message>
        <source>Edit an entry.</source>
        <translation>Modifica una voce.</translation>
    </message>
    <message>
        <source>Path of the entry to edit.</source>
        <translation>Percorso della voce da modificare.</translation>
    </message>
    <message>
        <source>Not changing any field for entry %1.</source>
        <translation>Non modificare nessun campo per la voce %1.</translation>
    </message>
    <message>
        <source>Enter new password for entry: </source>
        <translation>Inserisci la nuova password per la voce: </translation>
    </message>
    <message>
        <source>Successfully edited entry %1.</source>
        <translation>Voce %1 modificata correttamente.</translation>
    </message>
    <message>
        <source>Perform advanced analysis on the password.</source>
        <translation>Esegui un&apos;analisi avanzata sulla password.</translation>
    </message>
    <message>
        <source>Password for which to estimate the entropy.</source>
        <translation>Password di cui stimare l&apos;entropia.</translation>
    </message>
    <message>
        <source>Estimate the entropy of a password.</source>
        <translation>Stima l&apos;entropia di una password.</translation>
    </message>
    <message>
        <source>Length %1</source>
        <translation>Lunghezza %1</translation>
    </message>
    <message>
        <source>Entropy %1</source>
        <translation>Entropia %1</translation>
    </message>
    <message>
        <source>Log10 %1</source>
        <translation>Log10 %1</translation>
    </message>
    <message>
        <source>Multi-word extra bits %1</source>
        <translation>Multi-parola extra bit %1</translation>
    </message>
    <message>
        <source>Type: Bruteforce</source>
        <translation>Tipo: Bruteforce</translation>
    </message>
    <message>
        <source>Type: Dictionary</source>
        <translation>Tipo: dizionario</translation>
    </message>
    <message>
        <source>Type: Dict+Leet</source>
        <translation>Type: Dict+Leet</translation>
    </message>
    <message>
        <source>Type: User Words</source>
        <translation>Tipo: parole utente</translation>
    </message>
    <message>
        <source>Type: User+Leet</source>
        <translation>Tipo: Utente+Leet</translation>
    </message>
    <message>
        <source>Type: Repeated</source>
        <translation>Tipo: ripetute</translation>
    </message>
    <message>
        <source>Type: Sequence</source>
        <translation>Tipo: sequenza</translation>
    </message>
    <message>
        <source>Type: Spatial</source>
        <translation>Tipo: spaziale</translation>
    </message>
    <message>
        <source>Type: Date</source>
        <translation>Tipo: data</translation>
    </message>
    <message>
        <source>Type: Bruteforce(Rep)</source>
        <translation>Tipo: Bruteforce(Rep)</translation>
    </message>
    <message>
        <source>Type: Dictionary(Rep)</source>
        <translation>Tipo: dizionario(Rep)</translation>
    </message>
    <message>
        <source>Type: Dict+Leet(Rep)</source>
        <translation>Tipo: Dict+Leet(Rep)</translation>
    </message>
    <message>
        <source>Type: User Words(Rep)</source>
        <translation>Tipo: Parole utente (Rep)</translation>
    </message>
    <message>
        <source>Type: User+Leet(Rep)</source>
        <translation>Tipo: Utente+Leet(Rep)</translation>
    </message>
    <message>
        <source>Type: Repeated(Rep)</source>
        <translation>Tipo: Ripetuto(Rep)</translation>
    </message>
    <message>
        <source>Type: Sequence(Rep)</source>
        <translation>Tipo: Sequenza(Rep)</translation>
    </message>
    <message>
        <source>Type: Spatial(Rep)</source>
        <translation>Tipo: Spaziale(Rep)</translation>
    </message>
    <message>
        <source>Type: Date(Rep)</source>
        <translation>Tipo: Data(Rep)</translation>
    </message>
    <message>
        <source>Type: Unknown (%1)</source>
        <translation>Tipo: Sconosciuto (%1)</translation>
    </message>
    <message>
        <source>Entropy %1 (%2)</source>
        <translation>Entropia %1 (%2)</translation>
    </message>
    <message>
        <source>*** Password length (%1) != sum of length of parts (%2) ***</source>
        <translation>*** Lunghezza della password (%1) != somma della lunghezza delle parti (%2) ***</translation>
    </message>
    <message>
        <source>Exit interactive mode.</source>
        <translation>Uscire dalla modalità interattiva.</translation>
    </message>
    <message>
        <source>Exports the content of a database to standard output in the specified format.</source>
        <translation>Esporta il contenuto di un database nell&apos;output standard nel formato specificato.</translation>
    </message>
    <message>
        <source>Unable to export database to XML: %1</source>
        <translation>Impossibile esportare il database in XML: %1</translation>
    </message>
    <message>
        <source>Unsupported format %1</source>
        <translation>Formato non supportato %1</translation>
    </message>
    <message>
        <source>Length of the generated password</source>
        <translation>Lunghezza della password generata</translation>
    </message>
    <message>
        <source>length</source>
        <translation>lunghezza</translation>
    </message>
    <message>
        <source>Use lowercase characters</source>
        <translation>Usa caratteri minuscoli</translation>
    </message>
    <message>
        <source>Use uppercase characters</source>
        <translation>Usa caratteri maiuscoli</translation>
    </message>
    <message>
        <source>Use numbers</source>
        <translation>Usa i numeri</translation>
    </message>
    <message>
        <source>Use special characters</source>
        <translation>Usa caratteri speciali</translation>
    </message>
    <message>
        <source>Use extended ASCII</source>
        <translation>Usa ASCII esteso</translation>
    </message>
    <message>
        <source>Exclude character set</source>
        <translation>Escludi set caratteri</translation>
    </message>
    <message>
        <source>chars</source>
        <translation>caratteri</translation>
    </message>
    <message>
        <source>Use custom character set</source>
        <translation>Usa set caratteri personalizzato</translation>
    </message>
    <message>
        <source>Exclude similar looking characters</source>
        <translation>Escludi caratteri dall&apos;aspetto simile</translation>
    </message>
    <message>
        <source>Include characters from every selected group</source>
        <translation>Includi i caratteri da ogni gruppo selezionato</translation>
    </message>
    <message>
        <source>Generate a new random password.</source>
        <translation>Genera una nuova password casuale.</translation>
    </message>
    <message>
        <source>Invalid password length %1</source>
        <translation>Lunghezza password non valida %1</translation>
    </message>
    <message>
        <source>Invalid password generator after applying all options</source>
        <translation>Generatore password non valido dopo l&apos;applicazione di tutte le opzioni</translation>
    </message>
    <message>
        <source>Display command help.</source>
        <translation>Visualizza guida comando.</translation>
    </message>
    <message>
        <source>Available commands:</source>
        <translation>Comandi disponibili:</translation>
    </message>
    <message>
        <source>Import the contents of an XML database.</source>
        <translation>Importa il contenuto di un database XML.</translation>
    </message>
    <message>
        <source>Path of the XML database export.</source>
        <translation>Percorso dell&apos;esportazione del database XML.</translation>
    </message>
    <message>
        <source>Path of the new database.</source>
        <translation>Percorso del nuovo database.</translation>
    </message>
    <message>
        <source>Unable to import XML database: %1</source>
        <translation>Impossibile importare il database XML: %1</translation>
    </message>
    <message>
        <source>Successfully imported database.</source>
        <translation>Database importato correttamente.</translation>
    </message>
    <message>
        <source>Unknown command %1</source>
        <translation>Comando sconosciuto %1</translation>
    </message>
    <message>
        <source>

Available commands:
</source>
        <translation>

Comandi disponibili:
</translation>
    </message>
    <message>
        <source>Name of the command to execute.</source>
        <translation>Nome del comando da eseguire.</translation>
    </message>
    <message>
        <source>Displays debugging information.</source>
        <translation>Visualizza informazioni debug.</translation>
    </message>
    <message>
        <source>Invalid command %1.</source>
        <translation>Comando non valido %1.</translation>
    </message>
    <message>
        <source>Recursively list the elements of the group.</source>
        <translation>Elenca gli elementi del gruppo in modo ricorsivo.</translation>
    </message>
    <message>
        <source>Flattens the output to single lines.</source>
        <translation>Appiattisce l&apos;output su singole linee.</translation>
    </message>
    <message>
        <source>List database entries.</source>
        <translation>Elenco voci database.</translation>
    </message>
    <message>
        <source>Path of the group to list. Default is /</source>
        <translation>Percorso gruppo da elencare. L&apos;impostazione predefinita è /</translation>
    </message>
    <message>
        <source>Cannot find group %1.</source>
        <translation>Impossibile trovare gruppo %1.</translation>
    </message>
    <message>
        <source>Use the same credentials for both database files.</source>
        <translation>Usa le stesse credenziali per entrambi i file database.</translation>
    </message>
    <message>
        <source>Key file of the database to merge from.</source>
        <translation>File chiave del database da cui unire.</translation>
    </message>
    <message>
        <source>Deactivate password key for the database to merge from.</source>
        <translation>Disattiva la chiave della password per il database da unire.</translation>
    </message>
    <message>
        <source>Only print the changes detected by the merge operation.</source>
        <translation>Stampa solo le modifiche rilevate dall&apos;operazione di unione.</translation>
    </message>
    <message>
        <source>Yubikey slot for the second database.</source>
        <translation>Slot Yubikey per il secondo database.</translation>
    </message>
    <message>
        <source>slot</source>
        <translation>slot</translation>
    </message>
    <message>
        <source>Merge two databases.</source>
        <translation>Unisci due database.</translation>
    </message>
    <message>
        <source>Path of the database to merge from.</source>
        <translation>Percorso del database da cui unire.</translation>
    </message>
    <message>
        <source>Error reading merge file:
%1</source>
        <translation>Errore durante la lettura del file di unione:
%1</translation>
    </message>
    <message>
        <source>Unable to save database to file : %1</source>
        <translation>Impossibile salvare il database nel file : %1</translation>
    </message>
    <message>
        <source>Successfully merged %1 into %2.</source>
        <translation>Unione %1 in %2 completata.</translation>
    </message>
    <message>
        <source>Database was not modified by merge operation.</source>
        <translation>Il database non è stato modificato dall&apos;operazione di unione.</translation>
    </message>
    <message>
        <source>Moves an entry to a new group.</source>
        <translation>Sposta una voce in un nuovo gruppo.</translation>
    </message>
    <message>
        <source>Path of the entry to move.</source>
        <translation>Percorso della voce da spostare.</translation>
    </message>
    <message>
        <source>Path of the destination group.</source>
        <translation>Percorso del gruppo destinazione.</translation>
    </message>
    <message>
        <source>Could not find group with path %1.</source>
        <translation>Impossibile trovare il gruppo con percorso %1.</translation>
    </message>
    <message>
        <source>Entry is already in group %1.</source>
        <translation>La voce è già nel gruppo %1.</translation>
    </message>
    <message>
        <source>Successfully moved entry %1 to group %2.</source>
        <translation>Voce %1 spostata correttamente nel gruppo %2.</translation>
    </message>
    <message>
        <source>Open a database.</source>
        <translation>Apri un database.</translation>
    </message>
    <message>
        <source>Path of the entry to remove.</source>
        <translation>Percorso della voce da rimuovere.</translation>
    </message>
    <message>
        <source>Unable to save database to file: %1</source>
        <translation>Impossibile salvare il database nel file: %1</translation>
    </message>
    <message>
        <source>Successfully recycled entry %1.</source>
        <translation>Riciclata correttamente la voce %1.</translation>
    </message>
    <message>
        <source>Successfully deleted entry %1.</source>
        <translation>Eliminazione voce %1 completata.</translation>
    </message>
    <message>
        <source>Path of the group to remove.</source>
        <translation>Percorso del gruppo da rimuovere.</translation>
    </message>
    <message>
        <source>Cannot remove root group from database.</source>
        <translation>Impossibile rimuovere il gruppo radice dal database.</translation>
    </message>
    <message>
        <source>Successfully recycled group %1.</source>
        <translation>Riciclo gruppo %1 completato.</translation>
    </message>
    <message>
        <source>Successfully deleted group %1.</source>
        <translation>Eliminazione gruppo %1 completata.</translation>
    </message>
    <message>
        <source>Find entries quickly.</source>
        <translation>Cerca velocemente voci.</translation>
    </message>
    <message>
        <source>Search term.</source>
        <translation>Termine di ricerca.</translation>
    </message>
    <message>
        <source>Show the entry&apos;s current TOTP.</source>
        <translation>Visualizza TOTP attuale voce.</translation>
    </message>
    <message>
        <source>Show the protected attributes in clear text.</source>
        <translation>Visualizza gli attributi protetti in chiaro.</translation>
    </message>
    <message>
        <source>Show all the attributes of the entry.</source>
        <translation>Visualizza tutti gli attributi della voce.</translation>
    </message>
    <message>
        <source>Show the attachments of the entry.</source>
        <translation>Visualizza gli allegati della voce.</translation>
    </message>
    <message>
        <source>Names of the attributes to show. This option can be specified more than once, with each attribute shown one-per-line in the given order. If no attributes are specified, a summary of the default attributes is given.</source>
        <translation>Numero di attributi da visualizzare. Questa opzione può essere specificata più di una volta, con ogni attributo visualizzato in una riga separata nell&apos;ordine dato. Se nessun attributo è specificato verrà dato un riassunto degli attributi predefiniti.</translation>
    </message>
    <message>
        <source>attribute</source>
        <translation>attributo</translation>
    </message>
    <message>
        <source>Show an entry&apos;s information.</source>
        <translation>Visualizza la informazioni di una voce.</translation>
    </message>
    <message>
        <source>Name of the entry to show.</source>
        <translation>Nome della voce da visualizzare.</translation>
    </message>
    <message>
        <source>ERROR: unknown attribute %1.</source>
        <translation>ERRORE: attributo sconosciuto %1.</translation>
    </message>
    <message>
        <source>No attachments present.</source>
        <translation>Nessun allegato presente.</translation>
    </message>
    <message>
        <source>Attachments:</source>
        <translation>Allegati:</translation>
    </message>
    <message>
        <source>Failed to open database file %1: not found</source>
        <translation>Impossibile aprire il file database &apos;%1&apos;: file non trovato</translation>
    </message>
    <message>
        <source>Failed to open database file %1: not a plain file</source>
        <translation>Impossibile aprire il file database &apos;%1&apos;: non è un file semplice</translation>
    </message>
    <message>
        <source>Failed to open database file %1: not readable</source>
        <translation>Impossibile aprire il file database &apos;%1&apos;: file non leggibile</translation>
    </message>
    <message>
        <source>Enter password to unlock %1: </source>
        <translation>Inserisci password per sbloccare %1: </translation>
    </message>
    <message>
        <source>Failed to load key file %1: %2</source>
        <translation>Impossibile caricare file chiave %1: %2</translation>
    </message>
    <message>
        <source>WARNING: You are using an old key file format which KeePassXC may
stop supporting in the future.

Please consider generating a new key file.</source>
        <translation>ATTENZIONE: stai usando un vecchio formato di file chiave che KeePassXC potrebbe smettere di supportare in futuro.

Considera la possibilità di generare un nuovo file chiave.</translation>
    </message>
    <message>
        <source>Invalid YubiKey slot %1</source>
        <translation>Slot YubiKey non valido %1</translation>
    </message>
    <message>
        <source>Invalid YubiKey serial %1</source>
        <translation>Seriale YubiKey %1 non valido</translation>
    </message>
    <message>
        <source>Please present or touch your YubiKey to continue.</source>
        <translation>Per continuare avvicina o tocca la YubiKey.</translation>
    </message>
    <message>
        <source>Enter password to encrypt database (optional): </source>
        <translation>Inserisci password per cifrare il database (facoltativo): </translation>
    </message>
    <message>
        <source>Do you want to create a database with an empty password? [y/N]: </source>
        <translation>Vuoi creare un database senza una password? [s/N]: </translation>
    </message>
    <message>
        <source>Repeat password: </source>
        <translation>Ripeti password: </translation>
    </message>
    <message>
        <source>Error: Passwords do not match.</source>
        <translation>Errore: le password non corrispondono.</translation>
    </message>
    <message>
        <source>No program defined for clipboard manipulation</source>
        <translation>Nessun programma definito per la manipolazione degli appunti</translation>
    </message>
    <message>
        <source>All clipping programs failed. Tried %1
</source>
        <translation>Tutti i programmi di ritaglio hanno riscontrato errori. Provati %1
</translation>
    </message>
    <message>
        <source>Creating KeyFile %1 failed: %2</source>
        <translation>Creazione file chiave %1 non riuscita: %2</translation>
    </message>
    <message>
        <source>Loading KeyFile %1 failed: %2</source>
        <translation>Caricamento file chiave %1 non riuscito: %2</translation>
    </message>
    <message>
        <source>HIBP file, line %1: parse error</source>
        <translation>File HIBP, riga %1: errore di analisi</translation>
    </message>
    <message>
        <source>To use okon, you must provide a post-processed file (e.g. file.okon)</source>
        <translation>Per usare okon, è necessario fornire un file post-elaborato (es. file.okon)</translation>
    </message>
    <message>
        <source>Could not start okon process: %1</source>
        <translation>Impossibile avviare processo okon: %1</translation>
    </message>
    <message>
        <source>Error: okon process did not finish</source>
        <translation>Errore: processo okon non terminato</translation>
    </message>
    <message>
        <source>Failed to load okon processed database: %1</source>
        <translation>Impossibile caricare database elaborato con okon: %1</translation>
    </message>
    <message>
        <source>Very weak password</source>
        <translation>Password molto debole</translation>
    </message>
    <message>
        <source>Password entropy is %1 bits</source>
        <translation>L&apos;entropia della password è %1 bit</translation>
    </message>
    <message>
        <source>Weak password</source>
        <translation>Password debole</translation>
    </message>
    <message>
        <source>Used in %1/%2</source>
        <translation>Usata in %1/%2</translation>
    </message>
    <message numerus="yes">
        <source>Password is used %1 time(s)</source>
        <translation><numerusform>La password è stata utilizzata %1 volta</numerusform><numerusform>La password è stata utilizzata %1 volte</numerusform><numerusform>Password usata %1 volta/e</numerusform></translation>
    </message>
    <message>
        <source>Password has expired</source>
        <translation>La password è scaduta</translation>
    </message>
    <message>
        <source>Password expiry was %1</source>
        <translation>La password è scaduta il %1</translation>
    </message>
    <message>
        <source>Password expires on %1</source>
        <translation>La password scade il %1</translation>
    </message>
    <message>
        <source>Password is about to expire</source>
        <translation>La password è in scadenza</translation>
    </message>
    <message numerus="yes">
        <source>Password expires in %1 day(s)</source>
        <translation><numerusform>La password scade tra %1 giorno</numerusform><numerusform>La password scade tra %1 giorni</numerusform><numerusform>La password scade tra %1 giorno/i</numerusform></translation>
    </message>
    <message>
        <source>Password will expire soon</source>
        <translation>La password scadrà presto</translation>
    </message>
    <message>
        <source>Version %1</source>
        <translation>Versione %1</translation>
    </message>
    <message>
        <source>Build Type: %1</source>
        <translation>Tipo build: %1</translation>
    </message>
    <message>
        <source>Revision: %1</source>
        <translation>Revisione: %1</translation>
    </message>
    <message>
        <source>Distribution: %1</source>
        <translation>Distribuzione: %1</translation>
    </message>
    <message>
        <source>Debugging mode is disabled.</source>
        <translation>La modalità debug è disabilitata.</translation>
    </message>
    <message>
        <source>Debugging mode is enabled.</source>
        <translation>La modalità debug è abilitata.</translation>
    </message>
    <message>
        <source>Operating system: %1
CPU architecture: %2
Kernel: %3 %4</source>
        <translation>Sistema operativo: %1
Architettura CPU: %2
Kernel: %3 %4</translation>
    </message>
    <message>
        <source>Auto-Type</source>
        <translation>Completamento automatico</translation>
    </message>
    <message>
        <source>SSH Agent</source>
        <translation>Agente SSH</translation>
    </message>
    <message>
        <source>KeeShare</source>
        <translation>KeeShare</translation>
    </message>
    <message>
        <source>Quick Unlock</source>
        <translation>Sblocco rapido</translation>
    </message>
    <message>
        <source>Secret Service Integration</source>
        <translation>Integrazione Secret Service</translation>
    </message>
    <message>
        <source>Enabled extensions:</source>
        <translation>Estensioni abilitate:</translation>
    </message>
    <message numerus="yes">
        <source>over %1 year(s)</source>
        <translation><numerusform>oltre %1 anno</numerusform><numerusform>oltre %1 anni</numerusform><numerusform>oltre %1 anno/i</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>about %1 month(s)</source>
        <translation><numerusform>circa %1 mese(i)</numerusform><numerusform>circa %1 mese(i)</numerusform><numerusform>circa %1 mese(i)</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>%1 week(s)</source>
        <translation><numerusform>%1 settimana(e)</numerusform><numerusform>%1 settimana(e)</numerusform><numerusform>%1 settimana(e)</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>%1 day(s)</source>
        <translation><numerusform>%1 giorno(i)</numerusform><numerusform>%1 giorno(i)</numerusform><numerusform>%1 giorno(i)</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>%1 hour(s)</source>
        <translation><numerusform>%1 ora(e)</numerusform><numerusform>%1 ora(e)</numerusform><numerusform>%1 ora(e)</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>%1 minute(s)</source>
        <translation><numerusform>%1 minuto(i)</numerusform><numerusform>%1 minuto(i)</numerusform><numerusform>%1 minuto(i)</numerusform></translation>
    </message>
    <message>
        <source>Botan library must be at least %1, found %2.%3.%4</source>
        <translation>La libreria Botan deve essere almeno %1, trovata %2.%3.%4</translation>
    </message>
    <message>
        <source>Cryptographic libraries:</source>
        <translation>Librerie crittografiche:</translation>
    </message>
    <message>
        <source>AES (%1 rounds)</source>
        <translation>AES (%1 cicli)</translation>
    </message>
    <message>
        <source>Argon2%1 (%2 rounds, %3 KB)</source>
        <translation>Argon2%1 (%2 cicli, %3 KB)</translation>
    </message>
    <message>
        <source>SymmetricCipher::init: Invalid cipher mode.</source>
        <translation>SymmetricCipher::init: modalità cifrario non valida.</translation>
    </message>
    <message>
        <source>SymmetricCipher::init: Invalid IV size of %1 for %2.</source>
        <translation>SymmetricCipher::init: dimensione IV non valida di %1 per %2.</translation>
    </message>
    <message>
        <source>Cipher not initialized prior to use.</source>
        <translation>Cifrario non inizializzato prima dell&apos;uso.</translation>
    </message>
    <message>
        <source>Cannot process 0 length data.</source>
        <translation>Impossibile elaborare dati di lunghezza 0.</translation>
    </message>
    <message>
        <source>unknown executable (DBus address %1)</source>
        <translation>Eseguibile sconosciuto (indirizzo DBus %1)</translation>
    </message>
    <message>
        <source>%1 (invalid executable path)</source>
        <translation>%1 (percorso eseguibile non valido)</translation>
    </message>
    <message>
        <source>NULL device</source>
        <translation>Dispositivo NULL</translation>
    </message>
    <message>
        <source>error reading from device</source>
        <translation>errore lettura dal dispositivo</translation>
    </message>
    <message>
        <source>file empty</source>
        <translation>file vuoto</translation>
    </message>
    <message>
        <source>AES 256-bit</source>
        <translation>AES 256-bit</translation>
    </message>
    <message>
        <source>Twofish 256-bit</source>
        <translation>Twofish 256-bit</translation>
    </message>
    <message>
        <source>ChaCha20 256-bit</source>
        <translation>ChaCha20 256-bit</translation>
    </message>
    <message>
        <source>Argon2d (KDBX 4 – recommended)</source>
        <translation>Argon2d (KDBX 4 – consigliato)</translation>
    </message>
    <message>
        <source>Argon2id (KDBX 4)</source>
        <translation>Argon2id (KDBX 4)</translation>
    </message>
    <message>
        <source>AES-KDF (KDBX 4)</source>
        <translation>AES-KDF (KDBX 4)</translation>
    </message>
    <message>
        <source>AES-KDF (KDBX 3)</source>
        <translation>AES-KDF (KDBX 3)</translation>
    </message>
    <message>
        <source>Existing single-instance lock file is invalid. Launching new instance.</source>
        <translation>Il file di blocco singola istanza non è valido. Avvio nuova istanza.</translation>
    </message>
    <message>
        <source>The lock file could not be created. Single-instance mode disabled.</source>
        <translation>Impossibile creare il file di blocco. Modalità istanza singola disattivata.</translation>
    </message>
    <message numerus="yes">
        <source>Clearing the clipboard in %1 second(s)…</source>
        <translation><numerusform>Cancellazione degli appunti in %1 secondo…</numerusform><numerusform>Cancellazione degli appunti in %1 secondi…</numerusform><numerusform>Cancellazione appunti in %1 secondo/i…</numerusform></translation>
    </message>
    <message>
        <source>Group</source>
        <translation>Gruppo</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>Titolo</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>Nome utente</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Password</translation>
    </message>
    <message>
        <source>TOTP</source>
        <translation>TOTP</translation>
    </message>
    <message>
        <source>Icon</source>
        <translation>Icona</translation>
    </message>
    <message>
        <source>Last Modified</source>
        <translation>Ultima modifica</translation>
    </message>
    <message>
        <source>Created</source>
        <translation>Creazione</translation>
    </message>
    <message>
        <source>Benchmark %1 delay</source>
        <translation>Test prestazioni per %1 di ritardo</translation>
    </message>
    <message numerus="yes">
        <source>%1 ms</source>
        <comment>milliseconds</comment>
        <translation><numerusform>%1 ms</numerusform><numerusform>%1 ms</numerusform><numerusform>%1 ms</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>%1 s</source>
        <comment>seconds</comment>
        <translation><numerusform>%1 s</numerusform><numerusform>%1 s</numerusform><numerusform>%1 s</numerusform></translation>
    </message>
    <message>
        <source>Do you really want to move entry &quot;%1&quot; to the recycle bin?</source>
        <translation>Vuoi spostare la voce &quot;%1&quot; nel Cestino?</translation>
    </message>
    <message numerus="yes">
        <source>Do you really want to move %n entry(s) to the recycle bin?</source>
        <translation><numerusform>Vuoi davvero spostare &apos;%n&apos; voce nel cestino?</numerusform><numerusform>Vuoi davvero spostare &apos;%n&apos; voci nel cestino?</numerusform><numerusform>Vuoi spostare %n voce/i nel Cestino?</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>Entry &quot;%1&quot; has %2 reference(s). Do you want to overwrite references with values, skip this entry, or delete anyway?</source>
        <translation><numerusform>La voce &quot;%1&quot; ha %2 riferimento. Sovrascrivere i riferimenti con i valori, ignorare questa voce o eliminare comunque?</numerusform><numerusform>La voce &quot;%1&quot; ha %2 riferimenti. Sovrascrivere i riferimenti con i valori, ignorare questa voce o eliminare comunque?</numerusform><numerusform>La voce &quot;%1&quot; ha %2 riferimenti. Vuoi sovrascrivere i riferimenti con i valori, ignorare questa voce o eliminarla comunque?</numerusform></translation>
    </message>
    <message>
        <source>User name</source>
        <translation>Nome utente</translation>
    </message>
    <message>
        <source>Browser Statistics</source>
        <translation>Statistiche browser</translation>
    </message>
    <message>
        <source>Health Check</source>
        <translation>Controllo integrità</translation>
    </message>
    <message>
        <source>HIBP</source>
        <translation>HIBP</translation>
    </message>
    <message>
        <source>Statistics</source>
        <translation>Statistiche</translation>
    </message>
    <message>
        <source>Unsupported key file version: %1</source>
        <translation>Versione file chiave non supportata: %1</translation>
    </message>
    <message>
        <source>Checksum mismatch! Key file may be corrupt.</source>
        <translation>Checksum non corrispondente! Il file chiave potrebbe essere danneggiato.</translation>
    </message>
    <message>
        <source>Unexpected key file data! Key file may be corrupt.</source>
        <translation>Dati file chiave imprevisti! Il file chiave potrebbe essere danneggiato.</translation>
    </message>
    <message>
        <source>KeePassXC - cross-platform password manager</source>
        <translation>KeePassXC - gestore password multipiattaforma</translation>
    </message>
    <message>
        <source>filenames of the password databases to open (*.kdbx)</source>
        <translation>nomi file database password da aprire (*.kdbx)</translation>
    </message>
    <message>
        <source>path to a custom config file</source>
        <translation>percorso ad un file di configurazione personalizzato</translation>
    </message>
    <message>
        <source>path to a custom local config file</source>
        <translation>Percorso file configurazione locale personalizzato</translation>
    </message>
    <message>
        <source>lock all open databases</source>
        <translation>blocca tutti i database aperti</translation>
    </message>
    <message>
        <source>key file of the database</source>
        <translation>file chiave del database</translation>
    </message>
    <message>
        <source>read password of the database from stdin</source>
        <translation>leggi la password del database da stdin</translation>
    </message>
    <message>
        <source>Database failed to lock.</source>
        <translation>Impossibile bloccare il database.</translation>
    </message>
    <message>
        <source>Another instance of KeePassXC is already running.</source>
        <translation>È già in esecuzione un&apos;altra istanza di KeePassXC.</translation>
    </message>
    <message>
        <source>KeePassXC is not running. No open database to lock</source>
        <translation>KeePassXC non è in esecuzione. Nessun database aperto da bloccare.</translation>
    </message>
    <message>
        <source>Fatal error while testing the cryptographic functions.</source>
        <translation>Errore fatale durante il test delle funzioni di crittografia.</translation>
    </message>
    <message>
        <source>KeePassXC - Error</source>
        <translation>KeePassXC - Errore</translation>
    </message>
    <message>
        <source>Database password: </source>
        <translation>Password database: </translation>
    </message>
    <message>
        <source>Invalid Settings</source>
        <comment>TOTP</comment>
        <translation>Impostazioni non valide</translation>
    </message>
    <message>
        <source>Invalid Key</source>
        <comment>TOTP</comment>
        <translation>Chiave non valida</translation>
    </message>
    <message>
        <source>Failed to create Windows Hello credential.</source>
        <translation>Impossibile creare credenziale Windows Hello.</translation>
    </message>
    <message>
        <source>Failed to sign challenge using Windows Hello.</source>
        <translation>Impossibile firmare la prova usando Windows Hello.</translation>
    </message>
    <message>
        <source>Warning: Failed to block screenshot capture on a top-level window.</source>
        <translation>Attenzione: fallito il blocco acquisizione schermate in una finestra in primo piano.</translation>
    </message>
    <message>
        <source>Invalid Cipher</source>
        <translation>Cifrario non valido</translation>
    </message>
    <message>
        <source>Invalid KDF</source>
        <translation>KDF non valido</translation>
    </message>
    <message>
        <source>Access to all entries is denied</source>
        <translation>L&apos;accesso a tutte le voci è negato</translation>
    </message>
    <message>
        <source>allow screenshots and app recording (Windows/macOS)</source>
        <translation>consentire screenshot e registrazione con app (Windows / macOS)</translation>
    </message>
    <message>
        <source>Set the key file for the database.
This option is deprecated, use --set-key-file instead.</source>
        <translation>Imposta il file chiave per il database.
Questa opzione è deprecata, utilizza invece --set-key-file.</translation>
    </message>
    <message>
        <source>Databases have been locked.</source>
        <translation>I databases sono stati bloccati.</translation>
    </message>
    <message>
        <source>Attestation not supported</source>
        <translation>Attestazione non supportata</translation>
    </message>
    <message>
        <source>Credential is excluded</source>
        <translation>La credenziale è esclusa</translation>
    </message>
    <message>
        <source>Passkeys request canceled</source>
        <translation>Richiesta passkey annullata</translation>
    </message>
    <message>
        <source>Invalid user verification</source>
        <translation>Verifica utente non valida</translation>
    </message>
    <message>
        <source>Empty public key</source>
        <translation>Chiave pubblica vuota</translation>
    </message>
    <message>
        <source>Invalid URL provided</source>
        <translation>Fornita URL non valida</translation>
    </message>
    <message>
        <source>Passkeys</source>
        <translation>Passkeys</translation>
    </message>
    <message>
        <source>AES initialization failed</source>
        <translation>Inizializzazione AES non riuscita</translation>
    </message>
    <message>
        <source>AES encrypt failed</source>
        <translation>Cifratura AES non riuscita</translation>
    </message>
    <message>
        <source>Failed to store in Linux Keyring</source>
        <translation>Salvataggio in portachiavi Linux fallito</translation>
    </message>
    <message>
        <source>Polkit returned an error: %1</source>
        <translation>Polkit ha restituito un errore: %1</translation>
    </message>
    <message>
        <source>Could not locate key in keyring</source>
        <translation>Impossibile trovare una chiave nel portachiavi</translation>
    </message>
    <message>
        <source>Could not read key in keyring</source>
        <translation>Impossibile leggere la chiave nel portachiavi</translation>
    </message>
    <message>
        <source>AES decrypt failed</source>
        <translation>Decifratura AES non riuscita</translation>
    </message>
    <message>
        <source>No Polkit authentication agent was available</source>
        <translation>Non era disponibile nessun agente di autenticazione Polkit </translation>
    </message>
    <message>
        <source>Polkit authorization failed</source>
        <translation>Autenticazione Polkit non riuscita</translation>
    </message>
    <message>
        <source>No Quick Unlock provider is available</source>
        <translation>Non è disponibile nessun fornitore per sblocco rapido</translation>
    </message>
    <message>
        <source>Failed to init KeePassXC crypto.</source>
        <translation>Impossibile inizializzare la cifratura di KeePassXC.</translation>
    </message>
    <message>
        <source>Failed to encrypt key data.</source>
        <translation>Impossibile cifrare i dati chiave.</translation>
    </message>
    <message>
        <source>Failed to get Windows Hello credential.</source>
        <translation>Impossibile ottenere credenziale Windows Hello.</translation>
    </message>
    <message>
        <source>Failed to decrypt key data.</source>
        <translation>Impossibile decifrare dati chiave.</translation>
    </message>
    <message>
        <source>Origin is empty or not allowed</source>
        <translation>Origine vuota o non consentita</translation>
    </message>
    <message>
        <source>Effective domain is not a valid domain</source>
        <translation>Il dominio effettivo non è un dominio valido</translation>
    </message>
    <message>
        <source>Origin and RP ID do not match</source>
        <translation>Origin e RP ID non corrispondono</translation>
    </message>
    <message>
        <source>No supported algorithms were provided</source>
        <translation>Nessun algoritmo supportato è stato fornito</translation>
    </message>
    <message>
        <source>Wait for timer to expire</source>
        <translation>Attendi la scadenza del timer</translation>
    </message>
    <message>
        <source>Challenge is shorter than required minimum length</source>
        <translation>La sfida è inferiore alla lunghezza minima richiesta</translation>
    </message>
    <message>
        <source>user.id does not match the required length</source>
        <translation>user.id non corrisponde alla lunghezza richiesta</translation>
    </message>
    <message>
        <source>Favorite</source>
        <comment>Tag for favorite entries</comment>
        <translation>Preferito</translation>
    </message>
    <message>
        <source>File does not exist.</source>
        <translation>Il file non esiste.</translation>
    </message>
    <message>
        <source>Cannot open file: %1</source>
        <translation>Impossibile aprire il file: %1</translation>
    </message>
    <message>
        <source>Cannot parse file: %1 at position %2</source>
        <translation>Impossibile processare il file: %1 alla posizione %2</translation>
    </message>
    <message>
        <source>Failed to decrypt json file: %1</source>
        <translation>Impossibile decriptare il file json: %1</translation>
    </message>
    <message>
        <source>Invalid encKeyValidation field</source>
        <translation>Campo encKeyValidation non valido</translation>
    </message>
    <message>
        <source>Invalid cipher list within encKeyValidation field</source>
        <translation>Elenco di cifrari non valido nel campo encKeyValidation</translation>
    </message>
    <message>
        <source>Wrong password</source>
        <translation>Password errata</translation>
    </message>
    <message>
        <source>Invalid encrypted data field</source>
        <translation>Campo dati cifrati non valido</translation>
    </message>
    <message>
        <source>Invalid cipher list within encrypted data field</source>
        <translation>Elenco cifrari non valido nel campo dati cifrato</translation>
    </message>
    <message>
        <source>Cannot initialize cipher</source>
        <translation>Impossibile inizializzare il cifrario</translation>
    </message>
    <message>
        <source>Cannot decrypt data</source>
        <translation>Impossibile decriptare i dati</translation>
    </message>
    <message>
        <source>Bitwarden Import</source>
        <translation>Importa Bitwarden</translation>
    </message>
    <message>
        <source>Archived</source>
        <comment>Tag for archived entries</comment>
        <translation>Archiviati</translation>
    </message>
    <message>
        <source>Invalid 1PUX file format: Not a valid ZIP file.</source>
        <translation>Formato file 1PUX non valido. Non è un file ZIP valido.</translation>
    </message>
    <message>
        <source>Invalid 1PUX file format: Missing export.data</source>
        <translation>Formato file 1PUX non valido. Manca export.data</translation>
    </message>
    <message>
        <source>1Password Import</source>
        <translation>Importa 1Password</translation>
    </message>
    <message>
        <source>Enter Shortcut</source>
        <translation>Inserisci scorciatoia</translation>
    </message>
    <message>
        <source>Action</source>
        <translation>Azione</translation>
    </message>
    <message>
        <source>Shortcuts</source>
        <translation>Scorciatoie</translation>
    </message>
    <message>
        <source>Unknown passkeys error</source>
        <translation>Errore sconosciuto per le passkey</translation>
    </message>
    <message>
        <source>Invalid KDF iterations, cannot decrypt json file</source>
        <translation>Numero di iterazioni KDF non valido, impossibile decriptare il file json</translation>
    </message>
    <message>
        <source>Unsupported format, ensure your Bitwarden export is password-protected</source>
        <translation>Formato non supportato, assicurati che l&apos;esportazione Bitwarden sia protetta da password</translation>
    </message>
    <message>
        <source>Only PBKDF and Argon2 are supported, cannot decrypt json file</source>
        <translation>Solo PBKDF e Argon2 sono supportati, non è possibile decriptare il file json</translation>
    </message>
    <message>
        <source>Hardware Keys</source>
        <translation>Chiavi hardware</translation>
    </message>
    <message>
        <source>Passkey</source>
        <translation>Passkey</translation>
    </message>
    <message>
        <source>Reset Shortcuts</source>
        <translation>Ripristina scorciatoie</translation>
    </message>
    <message>
        <source>Double click an action to change its shortcut</source>
        <translation>Doppio clic su un&apos;azione per modificare la relativa scorciatoia</translation>
    </message>
    <message>
        <source>Filter...</source>
        <translation>Filtro...</translation>
    </message>
    <message>
        <source>Shortcut Conflict</source>
        <translation>Conflitto scorciatoie</translation>
    </message>
    <message>
        <source>Shortcut %1 conflicts with &apos;%2&apos;. Overwrite shortcut?</source>
        <translation>La scorciatoia %1 è in conflitto con &apos;%2&apos;.  Vuoi sovrascrivere la scorciatoia?</translation>
    </message>
    <message>
        <source>Format to use when exporting. Available choices are &apos;xml&apos;, &apos;csv&apos; or &apos;html&apos;. Defaults to &apos;xml&apos;.</source>
        <translation>Formato da usare per l&apos;esportazione. 
Scelte disponibili sono &apos;xml&apos;, &apos;csv&apos; o &apos;html&apos;. 
Predefinito è &apos;xml&apos;.</translation>
    </message>
    <message>
        <source>malformed string, possible unescaped delimiter</source>
        <translation>stringa non valida, delimitatore probabilmente senza escape</translation>
    </message>
    <message>
        <source>missing closing delimiter</source>
        <translation>delimitatore di chiusura mancante</translation>
    </message>
    <message>
        <source>%1, row: %2, column: %3</source>
        <translation>%1, riga: %2, colonna: %3</translation>
    </message>
    <message>
        <source>Encrypted files are not supported.</source>
        <translation>I file crittografati non sono supportati.</translation>
    </message>
    <message>
        <source>Proton Pass Import</source>
        <translation>Importa Proton Pass</translation>
    </message>
    <message>
        <source>Tags</source>
        <translation>Etichette</translation>
    </message>
    <message>
        <source>start minimized to the system tray</source>
        <translation>avvio minimizzato nell&apos;area notifiche di sistema</translation>
    </message>
    <message>
        <source>Warning: the chosen wordlist is smaller than the minimum recommended size!</source>
        <translation>Attenzione: l&apos;elenco parole selezionato ha una dimensione più piccola della dimensione suggerita!</translation>
    </message>
    <message>
        <source>Invalid Step</source>
        <comment>TOTP</comment>
        <translation>Step non valido</translation>
    </message>
    <message>
        <source>Invalid Digits</source>
        <comment>TOTP</comment>
        <translation>Cifre non valide</translation>
    </message>
    <message numerus="yes">
        <source>%1 character(s)</source>
        <translation><numerusform>%1 carattere</numerusform><numerusform>%1 caratteri</numerusform><numerusform>%1 carattere/i</numerusform></translation>
    </message>
    <message>
        <source>Do you really want to permanently delete the entry &quot;%1&quot;?</source>
        <translation>Vuoi eliminare definitivamente la voce &quot;%1&quot;?</translation>
    </message>
    <message numerus="yes">
        <source>Do you really want to permanently delete %n entry(s)?</source>
        <translation><numerusform>Vuoi davvero eliminare definitivamente %n voce?</numerusform><numerusform>Vuoi davvero eliminare definitivamente %n voci?</numerusform><numerusform>Vuoi eliminare definitivamente %n voce/i?</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>Confirm Delete Entry(s)</source>
        <translation><numerusform>Conferma eliminazione voce</numerusform><numerusform>Conferma eliminazione voci</numerusform><numerusform>Conferma eliminazione voce/i</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>Confirm Recycle Entry(s)</source>
        <translation><numerusform>Conferma riciclo voce</numerusform><numerusform>Conferma riciclo voci</numerusform><numerusform>Conferma riciclo voce/i</numerusform></translation>
    </message>
    <message>
        <source>Confirm Delete Plugin Data</source>
        <translation>Conferma eliminazione dati plugin</translation>
    </message>
    <message numerus="yes">
        <source>Delete plugin data from the selected entry(s)?</source>
        <translation><numerusform>Vuoi eliminare i dati del plugin dalla voce selezionata?</numerusform><numerusform>Vuoi eliminare i dati del plugin dalle voci selezionate?</numerusform><numerusform>Vuoi eliminare i dati del plugin dalla/e voce/i selezionata/e?</numerusform></translation>
    </message>
    <message>
        <source>Confirm Replace Entry References</source>
        <translation>Conferma sostituzione riferimento voce</translation>
    </message>
</context>
<context>
    <name>QtIOCompressor</name>
    <message>
        <source>Internal zlib error when compressing: </source>
        <translation>Errore interno di zlib durante la compressione: </translation>
    </message>
    <message>
        <source>Error writing to underlying device: </source>
        <translation>Errore durante la scrittura nel dispositivo sottostante: </translation>
    </message>
    <message>
        <source>Error opening underlying device: </source>
        <translation>Errore durante l&apos;apertura dal dispositivo sottostante: </translation>
    </message>
    <message>
        <source>Error reading data from underlying device: </source>
        <translation>Errore durante la lettura dal dispositivo sottostante: </translation>
    </message>
    <message>
        <source>Internal zlib error when decompressing: </source>
        <translation>Errore interno di zlib durante la decompressione: </translation>
    </message>
</context>
<context>
    <name>QtIOCompressor::open</name>
    <message>
        <source>The gzip format not supported in this version of zlib.</source>
        <translation>Formato gzip non supportato da questa versione di zlib.</translation>
    </message>
    <message>
        <source>Internal zlib error: </source>
        <translation>Errore interno di zlib: </translation>
    </message>
</context>
<context>
    <name>RemoteDesktopPortal</name>
    <message>
        <source>Remote desktop session is not active</source>
        <translation>La sessione desktop remoto non è attiva</translation>
    </message>
    <message>
        <source>Session closed</source>
        <translation>Sessione chiusa</translation>
    </message>
    <message>
        <source>User cancelled the interaction</source>
        <translation>L&apos;utente ha annullato l&apos;interazione</translation>
    </message>
    <message>
        <source>User interaction was canceled for unknown reason</source>
        <translation>L&apos;interazione dell&apos;utente è stata annullata per un motivo sconosciuto</translation>
    </message>
    <message>
        <source>Remote desktop session handle does not match expected path</source>
        <translation>L&apos;handle della sessione desktop remoto non corrisponde al percorso previsto</translation>
    </message>
</context>
<context>
    <name>RemoteHandler</name>
    <message>
        <source>Command `%1` did not finish in time. Process was killed.</source>
        <translation>Il comando `%1` non ha terminato nei tempi previsti. Il processo è stato terminato.</translation>
    </message>
    <message>
        <source>Failed to upload merged database. Command `%1` did not finish in time. Process was killed.</source>
        <translation>Upload del database combinato fallito. Il comando `%1` non ha terminato nei tempi previsti. Il processo è stato terminato. </translation>
    </message>
    <message>
        <source>Invalid download parameters provided.</source>
        <translation>Parametri download forniti non validi.</translation>
    </message>
    <message>
        <source>Command `%1` failed to download database.</source>
        <translation>Il comando `%1` ha fallito il download del database.</translation>
    </message>
    <message>
        <source>Invalid database pointer or upload parameters provided.</source>
        <translation>Fornito puntatore al database/parametri di upload non corretto.</translation>
    </message>
    <message>
        <source>Command `%1` exited with status code: %2</source>
        <translation>Il comando `%1` è uscito con codice di stato: %2</translation>
    </message>
    <message>
        <source>Failed to upload merged database. Command `%1` exited with status code: %2</source>
        <translation>Upload del database combinato fallito. Il comando `%1` è terminato con status code: %2</translation>
    </message>
</context>
<context>
    <name>ReportsWidgetBrowserStatistics</name>
    <message>
        <source>Double-click entries to edit.</source>
        <translation>Doppio clic sulle voci da modificare.</translation>
    </message>
    <message>
        <source>List of entry URLs</source>
        <translation>Elenco degli URL delle voci</translation>
    </message>
    <message>
        <source>Entry has no URLs set</source>
        <translation>La voce non ha una URL</translation>
    </message>
    <message>
        <source>Allowed URLs</source>
        <translation>URL consentiti</translation>
    </message>
    <message>
        <source>Entry has no Browser Integration settings</source>
        <translation>La voce non ha impostazioni di integrazione del browser</translation>
    </message>
    <message>
        <source>Denied URLs</source>
        <translation>URL negati</translation>
    </message>
    <message>
        <source> (Excluded)</source>
        <translation> (Esclusa)</translation>
    </message>
    <message>
        <source>This entry is being excluded from reports</source>
        <translation>Questa voce è esclusa dai rapporti</translation>
    </message>
    <message>
        <source>Please wait, browser statistics is being calculated…</source>
        <translation>Statistiche browser in fase di calcolo...</translation>
    </message>
    <message>
        <source>No entries with a URL, or none has browser extension settings saved.</source>
        <translation>Nessuna voce con una URL o nessuna ha impostazioni estensione browser salvate.</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>Titolo</translation>
    </message>
    <message>
        <source>Path</source>
        <translation>Percorso</translation>
    </message>
    <message>
        <source>URLs</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>Edit Entry…</source>
        <translation>Modifica voce…</translation>
    </message>
    <message numerus="yes">
        <source>Delete Entry(s)…</source>
        <translation><numerusform>Elimina voce…</numerusform><numerusform>Elimina voce…</numerusform><numerusform>Elimina voce/i…</numerusform></translation>
    </message>
    <message>
        <source>Exclude from reports</source>
        <translation>Escludi dai rapporti</translation>
    </message>
    <message numerus="yes">
        <source>Expire Entry(s)…</source>
        <translation><numerusform>Scadenza voce…</numerusform><numerusform>Scadenza voci…</numerusform><numerusform>Scadenza voce/i…</numerusform></translation>
    </message>
    <message>
        <source>Only show entries that have a URL</source>
        <translation>Mostra solo voci che hanno un URL</translation>
    </message>
    <message>
        <source>Only show entries that have been explicitly allowed or denied</source>
        <translation>Mostra solo voci esplicitamente consentite o negate</translation>
    </message>
    <message>
        <source>Show expired entries</source>
        <translation>Mostra voci scadute</translation>
    </message>
    <message>
        <source> (Expired)</source>
        <translation> (scaduta)</translation>
    </message>
    <message numerus="yes">
        <source>Delete plugin data from Entry(s)…</source>
        <translation><numerusform>Eliminare i dati del plugin dalla voce...</numerusform><numerusform>Eliminare i dati del plugin dalle voci...</numerusform><numerusform>Elimina dati plugin dalla/e voce/i...</numerusform></translation>
    </message>
</context>
<context>
    <name>ReportsWidgetHealthcheck</name>
    <message>
        <source>Show expired entries</source>
        <translation>Mostra voci scadute</translation>
    </message>
    <message>
        <source> (Expired)</source>
        <translation> (Scaduta)</translation>
    </message>
    <message>
        <source>Hover over reason to show additional details. Double-click entries to edit.</source>
        <translation>Passa il mouse sulla motivazione per visualizzare dettagli aggiuntivi. Doppio clic sulle voci per modificarle.</translation>
    </message>
    <message>
        <source>Bad — password must be changed</source>
        <translation>Pessima: la password deve essere modificata</translation>
    </message>
    <message>
        <source>Poor — password should be changed</source>
        <translation>Scadente — la password dovrebbe essere modificata</translation>
    </message>
    <message>
        <source>Weak — consider changing the password</source>
        <translation>Debole — valuta se cambiare la password</translation>
    </message>
    <message>
        <source> (Excluded)</source>
        <translation> (Esclusa)</translation>
    </message>
    <message>
        <source>This entry is being excluded from reports</source>
        <translation>Questa voce è esclusa dai rapporti</translation>
    </message>
    <message>
        <source>Please wait, health data is being calculated…</source>
        <translation>Elaborazione stato integrità...</translation>
    </message>
    <message>
        <source>Congratulations, everything is healthy!</source>
        <translation>Congratulazioni, tutto ok - nessun problema rilevato!</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>Titolo</translation>
    </message>
    <message>
        <source>Path</source>
        <translation>Percorso</translation>
    </message>
    <message>
        <source>Score</source>
        <translation>Punteggio</translation>
    </message>
    <message>
        <source>Reason</source>
        <translation>Motivo</translation>
    </message>
    <message>
        <source>Edit Entry…</source>
        <translation>Modifica voce…</translation>
    </message>
    <message numerus="yes">
        <source>Delete Entry(s)…</source>
        <translation><numerusform>Elimina voce…</numerusform><numerusform>Elimina voci…</numerusform><numerusform>Elimina voce/i…</numerusform></translation>
    </message>
    <message>
        <source>Exclude from reports</source>
        <translation>Escludi dai rapporti</translation>
    </message>
    <message numerus="yes">
        <source>Expire Entry(s)…</source>
        <translation><numerusform>Scadenza voce…</numerusform><numerusform>Scadenza voci…</numerusform><numerusform>Scadenza voce/i…</numerusform></translation>
    </message>
    <message>
        <source>Show entries that have been excluded from reports</source>
        <translation>Mostra voci che sono state escluse dai rapporti</translation>
    </message>
</context>
<context>
    <name>ReportsWidgetHibp</name>
    <message>
        <source>CAUTION: This report requires sending information to the Have I Been Pwned online service (https://haveibeenpwned.com). If you proceed, your database passwords will be cryptographically hashed and the first five characters of those hashes will be sent securely to this service. Your database remains secure and cannot be reconstituted from this information. However, the number of passwords you send and your IP address will be exposed to this service.</source>
        <translation>ATTENZIONE: questo rapporto richiede l&apos;invio di informazioni al servizio online Have I Been Pwned (https://haveibeenpwned.com). Se procedi, alle password del database sarà applicato un hash crittografico e i primi cinque caratteri saranno inviati in modo sicuro al servizio. Il database rimane sicuro e non può essere ricostruito da queste informazioni. Tuttavia il numero di password inviate e l&apos;indirizzo IP saranno esposti a questo servizio.</translation>
    </message>
    <message>
        <source>Perform Online Analysis</source>
        <translation>Esegui analisi online</translation>
    </message>
    <message>
        <source>Also show entries that have been excluded from reports</source>
        <translation>Visualizza anche le voci escluse dai rapporti</translation>
    </message>
    <message>
        <source>This build of KeePassXC does not have network functions. Networking is required to check your passwords against Have I Been Pwned databases.</source>
        <translation>Questa versione di KeePassXC non possiede funzionalità di rete. 
La funzionalità di rete è richiesta per verificare la password con i database di Have I Been Pwned.</translation>
    </message>
    <message>
        <source>Congratulations, no exposed passwords!</source>
        <translation>Congratulazioni, nessuna password esposta!</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>Titolo</translation>
    </message>
    <message>
        <source>Path</source>
        <translation>Percorso</translation>
    </message>
    <message>
        <source>Password exposed…</source>
        <translation>Password esposta...</translation>
    </message>
    <message>
        <source> (Excluded)</source>
        <translation> (Esclusa)</translation>
    </message>
    <message>
        <source>This entry is being excluded from reports</source>
        <translation>Questa voce è esclusa dai rapporti</translation>
    </message>
    <message>
        <source>once</source>
        <comment>Password exposure amount</comment>
        <translation>una volta</translation>
    </message>
    <message>
        <source>up to 10 times</source>
        <comment>Password exposure amount</comment>
        <translation>fino a 10 volte</translation>
    </message>
    <message>
        <source>up to 100 times</source>
        <comment>Password exposure amount</comment>
        <translation>fino a 100 volte</translation>
    </message>
    <message>
        <source>up to 1000 times</source>
        <comment>Password exposure amount</comment>
        <translation>fino a 1000 volte</translation>
    </message>
    <message>
        <source>up to 10,000 times</source>
        <comment>Password exposure amount</comment>
        <translation>fino a 10,000 volte</translation>
    </message>
    <message>
        <source>up to 100,000 times</source>
        <comment>Password exposure amount</comment>
        <translation>fino a 100,000 volte</translation>
    </message>
    <message>
        <source>up to a million times</source>
        <comment>Password exposure amount</comment>
        <translation>fino ad un milione di volte</translation>
    </message>
    <message>
        <source>millions of times</source>
        <comment>Password exposure amount</comment>
        <translation>milioni di volte</translation>
    </message>
    <message>
        <source>Edit Entry…</source>
        <translation>Modifica voce…</translation>
    </message>
    <message numerus="yes">
        <source>Delete Entry(s)…</source>
        <translation><numerusform>Elimina voce…</numerusform><numerusform>Elimina voci…</numerusform><numerusform>Elimina voce/i…</numerusform></translation>
    </message>
    <message>
        <source>Exclude from reports</source>
        <translation>Escludi dai rapporti</translation>
    </message>
    <message numerus="yes">
        <source>Expire Entry(s)…</source>
        <translation><numerusform>Scadenza voce…</numerusform><numerusform>Scadenza voci…</numerusform><numerusform>Scadenza voce/i…</numerusform></translation>
    </message>
</context>
<context>
    <name>ReportsWidgetPasskeys</name>
    <message>
        <source>Export</source>
        <translation>Esporta</translation>
    </message>
    <message>
        <source>Import</source>
        <translation>Importa</translation>
    </message>
    <message>
        <source>List of entry URLs</source>
        <translation>Elenco degli URL delle voci</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>Titolo</translation>
    </message>
    <message>
        <source>Path</source>
        <translation>Percorso</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>Nome utente</translation>
    </message>
    <message>
        <source>URLs</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>Edit Entry…</source>
        <translation>Modifica voce…</translation>
    </message>
    <message numerus="yes">
        <source>Delete Entry(s)…</source>
        <translation><numerusform>Elimina voce…</numerusform><numerusform>Elimina voci…</numerusform><numerusform>Elimina voce/i…</numerusform></translation>
    </message>
    <message>
        <source>Relying Party</source>
        <translation>Relying Party</translation>
    </message>
    <message>
        <source>Show expired entries</source>
        <translation>Visualizza voci scadute</translation>
    </message>
    <message>
        <source> (Expired)</source>
        <translation> (Scaduta)</translation>
    </message>
    <message>
        <source>Export Confirmation</source>
        <translation>Conferma esportazione</translation>
    </message>
    <message>
        <source>The passkey file will be vulnerable to theft and unauthorized use, if left unsecured. Are you sure you want to continue?</source>
        <translation>Il file della passkey sarà esposto a furto oppure uso non autorizzato se lasciato insicuro. Sei sicuro di voler continuare? </translation>
    </message>
    <message>
        <source>Please wait, list of entries with passkeys is being updated…</source>
        <translation>Attendi, la lista delle voci con passkey è in aggiornamento...</translation>
    </message>
    <message>
        <source>No entries with passkeys.</source>
        <translation>Nessuna voce con passkeys.</translation>
    </message>
</context>
<context>
    <name>ReportsWidgetStatistics</name>
    <message>
        <source>Hover over lines with error icons for further information.</source>
        <translation>Per ulteriori informazioni passa il mouse sulle righe con icone di errore.</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <source>Value</source>
        <translation>Valore</translation>
    </message>
    <message>
        <source>Please wait, database statistics are being calculated…</source>
        <translation>Elaborazione statistiche database...</translation>
    </message>
    <message>
        <source>Database name</source>
        <translation>Nome database</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Descrizione</translation>
    </message>
    <message>
        <source>Location</source>
        <translation>Posizione</translation>
    </message>
    <message>
        <source>Database created</source>
        <translation>Database creato</translation>
    </message>
    <message>
        <source>Last saved</source>
        <translation>Ultimo salvataggio</translation>
    </message>
    <message>
        <source>Unsaved changes</source>
        <translation>Modifiche non salvate</translation>
    </message>
    <message>
        <source>yes</source>
        <translation>sì</translation>
    </message>
    <message>
        <source>no</source>
        <translation>no</translation>
    </message>
    <message>
        <source>The database was modified, but the changes have not yet been saved to disk.</source>
        <translation>Il database è stato modificato, ma le modifiche non sono ancora state salvate su disco.</translation>
    </message>
    <message>
        <source>Number of groups</source>
        <translation>Numero di gruppi</translation>
    </message>
    <message>
        <source>Number of entries</source>
        <translation>Numero di voci</translation>
    </message>
    <message>
        <source>Number of expired entries</source>
        <translation>Numero di voci scadute</translation>
    </message>
    <message>
        <source>The database contains entries that have expired.</source>
        <translation>Il database contiene voci scadute.</translation>
    </message>
    <message>
        <source>Unique passwords</source>
        <translation>Password univoche</translation>
    </message>
    <message>
        <source>Non-unique passwords</source>
        <translation>Password non univoche</translation>
    </message>
    <message>
        <source>More than 10% of passwords are reused. Use unique passwords when possible.</source>
        <translation>Più del 10% delle password sono riusate. Usa password univoche quando possibile.</translation>
    </message>
    <message>
        <source>Maximum password reuse</source>
        <translation>Massimo riutilizzo password</translation>
    </message>
    <message>
        <source>Some passwords are used more than three times. Use unique passwords when possible.</source>
        <translation>Alcune password sono state usate più di tre volte. Usa quando possibile password univoche.</translation>
    </message>
    <message>
        <source>Number of short passwords</source>
        <translation>Numero di password brevi</translation>
    </message>
    <message>
        <source>Recommended minimum password length is at least 8 characters.</source>
        <translation>La lunghezza minima consigliata per la password è di almeno 8 caratteri.</translation>
    </message>
    <message>
        <source>Number of weak passwords</source>
        <translation>Numero di password deboli</translation>
    </message>
    <message>
        <source>Recommend using long, randomized passwords with a rating of &apos;good&apos; or &apos;excellent&apos;.</source>
        <translation>Ti consigliamo di usare password lunghe e casuali con una valutazione &quot;buona&quot; o &quot;eccellente&quot;.</translation>
    </message>
    <message>
        <source>Entries excluded from reports</source>
        <translation>Voci escluse dai rapporti</translation>
    </message>
    <message>
        <source>Excluding entries from reports, e. g. because they are known to have a poor password, isn&apos;t necessarily a problem but you should keep an eye on them.</source>
        <translation>Escludere voci dal rapporto, ad esempio perché possiedono una password scadente, non è necessariamente un problema ma dovresti tenerle sotto controllo.</translation>
    </message>
    <message>
        <source>Average password length</source>
        <translation>Lunghezza media password</translation>
    </message>
    <message>
        <source>Average password length is less than ten characters. Longer passwords provide more security.</source>
        <translation>La lunghezza media della password è inferiore a dieci caratteri. Le password più lunghe offrono maggiore sicurezza.</translation>
    </message>
    <message>
        <source>Number of passkeys</source>
        <translation>Numero passkey</translation>
    </message>
    <message>
        <source>Entries with TOTP setup</source>
        <translation>Voci con TOTP configurato</translation>
    </message>
    <message numerus="yes">
        <source>%1 character(s)</source>
        <translation><numerusform>%1 carattere</numerusform><numerusform>%1 caratteri</numerusform><numerusform>%1 carattere/i</numerusform></translation>
    </message>
</context>
<context>
    <name>SSHAgent</name>
    <message>
        <source>Agent connection failed.</source>
        <translation>Connessione con l&apos;agente non riuscita.</translation>
    </message>
    <message>
        <source>Agent protocol error.</source>
        <translation>Errore di protocollo dell&apos;agente.</translation>
    </message>
    <message>
        <source>No agent running, cannot add identity.</source>
        <translation>Nessun agente in esecuzione, impossibile aggiungere un&apos;identità.</translation>
    </message>
    <message>
        <source>Key identity ownership conflict. Refusing to add.</source>
        <translation>Identificativo del proprietario della chiave in conflitto. Aggiunta negata.</translation>
    </message>
    <message>
        <source>Agent refused this identity. Possible reasons include:</source>
        <translation>L&apos;agente ha rifiutato questa identità. Motivi possibili sono:</translation>
    </message>
    <message>
        <source>The key has already been added.</source>
        <translation>La chiave è già stata aggiunta.</translation>
    </message>
    <message>
        <source>Restricted lifetime is not supported by the agent (check options).</source>
        <translation>Durata limitata non è supportata dall&apos;agente (controlla le opzioni).</translation>
    </message>
    <message>
        <source>A confirmation request is not supported by the agent (check options).</source>
        <translation>Una richiesta di conferma non è supportata dall&apos;agente (controlla le opzioni).</translation>
    </message>
    <message>
        <source>Security keys are not supported by the agent or the security key provider is unavailable.</source>
        <translation>Le chiavi di sicurezza non sono supportate dall&apos;agente o il provider della chiave di sicurezza non è disponibile.</translation>
    </message>
    <message>
        <source>No agent running, cannot remove identity.</source>
        <translation>Nessun agente in esecuzione, non è possibile rimuovere l&apos;identità.</translation>
    </message>
    <message>
        <source>No agent running, cannot list identities.</source>
        <translation>Nessun agente in esecuzione, impossibile elencare le identità.</translation>
    </message>
    <message>
        <source>Failed to remove all SSH identities from agent.</source>
        <translation>Rimozione identità SSH dall&apos;agent non riuscita.</translation>
    </message>
    <message>
        <source>All SSH identities removed from agent.</source>
        <translation>Tutte le identità SSH rimosse dall&apos;agent.</translation>
    </message>
</context>
<context>
    <name>SearchHelpWidget</name>
    <message>
        <source>Search Help</source>
        <translation>Cerca nella Guida in linea</translation>
    </message>
    <message>
        <source>Search terms are as follows: [modifiers][field:][&quot;]term[&quot;]</source>
        <translation>I termini di ricerca sono i seguenti: [modificatori][campo:][&quot;]termine[&quot;]</translation>
    </message>
    <message>
        <source>Every search term must match (ie, logical AND)</source>
        <translation>Ogni termine di ricerca deve corrispondere (per esempio AND logico)</translation>
    </message>
    <message>
        <source>Modifiers</source>
        <translation>Modificatori</translation>
    </message>
    <message>
        <source>exclude term from results</source>
        <translation>escludi termine dai risultati</translation>
    </message>
    <message>
        <source>match term exactly</source>
        <translation>corrispondenza esatta</translation>
    </message>
    <message>
        <source>use regex in term</source>
        <translation>usa regex nel termine</translation>
    </message>
    <message>
        <source>Fields</source>
        <translation>Campi</translation>
    </message>
    <message>
        <source>Term Wildcards</source>
        <translation>Jolly termine</translation>
    </message>
    <message>
        <source>match anything</source>
        <translation>cerca qualsiasi corrispondenza</translation>
    </message>
    <message>
        <source>match one</source>
        <translation>cerca una corrispondenza</translation>
    </message>
    <message>
        <source>logical OR</source>
        <translation>OR logico</translation>
    </message>
    <message>
        <source>Examples</source>
        <translation>Esempi</translation>
    </message>
</context>
<context>
    <name>SearchWidget</name>
    <message>
        <source>Search</source>
        <translation>Cerca</translation>
    </message>
    <message>
        <source>Search Help</source>
        <translation>Cerca nella Guida in linea</translation>
    </message>
    <message>
        <source>Save Search</source>
        <translation>Salva ricerca</translation>
    </message>
    <message>
        <source>Search (%1)…</source>
        <comment>Search placeholder text, %1 is the keyboard shortcut</comment>
        <translation>Ricerca (%1)…</translation>
    </message>
    <message>
        <source>Case sensitive</source>
        <translation>Differenzia maiuscole/minuscole</translation>
    </message>
    <message>
        <source>Limit search to selected group</source>
        <translation>Limita la ricerca al gruppo selezionato</translation>
    </message>
    <message>
        <source>Press Enter to search</source>
        <translation>Premi &apos;Invio&apos; per cercare</translation>
    </message>
</context>
<context>
    <name>SettingsClientModel</name>
    <message>
        <source>Application</source>
        <translation>Applicazione</translation>
    </message>
    <message>
        <source>PID</source>
        <translation>PID</translation>
    </message>
    <message>
        <source>DBus Address</source>
        <translation>Indirizzo DBus</translation>
    </message>
    <message>
        <source>Manage</source>
        <translation>Gestione</translation>
    </message>
</context>
<context>
    <name>SettingsDatabaseModel</name>
    <message>
        <source>File Name</source>
        <translation>Nome file</translation>
    </message>
    <message>
        <source>Group</source>
        <translation>Gruppo</translation>
    </message>
    <message>
        <source>Manage</source>
        <translation>Gestione</translation>
    </message>
</context>
<context>
    <name>SettingsWidgetFdoSecrets</name>
    <message>
        <source>Options</source>
        <translation>Opzioni</translation>
    </message>
    <message>
        <source>Enable KeepassXC Freedesktop.org Secret Service integration</source>
        <translation>Abilita l&apos;integrazione di KeepassXC con Freedesktop.org Secret Service</translation>
    </message>
    <message>
        <source>General</source>
        <translation>Generali</translation>
    </message>
    <message>
        <source>Show notification when passwords are retrieved by clients</source>
        <translation>Visualizza notifiche quando le password vengono recuperate dai client</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;If enabled, any attempt to read a password must be confirmed. Otherwise, clients can read passwords without confirmation when the database is unlocked.&lt;/p&gt;&lt;p&gt;This option only covers the access to the password of an entry. Clients can always enumerate the items of exposed databases and query their attributes.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Se abilitato, qualsiasi tentativo di leggere una password deve essere confermato. In caso contrario,  quando il database è sbloccato i client possono leggere le password senza conferma.&lt;/p&gt;&lt;p&gt;Questa opzione copre solo l&apos;accesso alla password di una voce. I client possono sempre enumerare gli elementi dei database esposti ed eseguire una ricerca sui relativi attributi.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Confirm when passwords are retrieved by clients</source>
        <translation>Conferma quando le password vengono recuperate dai client</translation>
    </message>
    <message>
        <source>Confirm when clients request entry deletion</source>
        <translation>Conferma quando i client richiedono l&apos;eliminazione delle voci</translation>
    </message>
    <message>
        <source>Prompt to unlock database before searching</source>
        <translation>Richiedi di sbloccare il database prima della ricerca</translation>
    </message>
    <message>
        <source>Exposed database groups:</source>
        <translation>Gruppi database esposti:</translation>
    </message>
    <message>
        <source>Authorization</source>
        <translation>Autorizzazione</translation>
    </message>
    <message>
        <source>These applications are currently connected:</source>
        <translation>Queste applicazioni sono attualmente connesse:</translation>
    </message>
    <message>
        <source>&lt;b&gt;Warning:&lt;/b&gt; </source>
        <translation>&lt;b&gt;Attenzione:&lt;/b&gt; </translation>
    </message>
    <message>
        <source>Save current changes to activate the plugin and enable editing of this section.</source>
        <translation>Salva i cambiamenti per attivare il plugin e modificare questa sezione.</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;This setting does not override disabling recycle bin prompts &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Questa impostazione non ha la precedenza sulla disabilitazione dei messaggi del cestino&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;This improves compatibility with certain applications which search for password without unlocking the database first.&lt;/p&gt;&lt;p&gt;But enabling this may also crash the client if the database can not be unlocked within a certain timeout. (Usually 25s, but may be a different value set in applications.) &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt; Questo migliora la compatibilità con alcune applicazioni che cercano la password senza prima sbloccare il database.&lt;/p&gt;&lt;p&gt;Tuttavia, abilitarlo potrebbe anche mandare in crash il client se il database non può essere sbloccato entro un certo timeout (di solito 25s, ma potrebbe essere un valore diverso impostato nelle applicazioni).&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
</context>
<context>
    <name>SettingsWidgetKeeShare</name>
    <message>
        <source>Active</source>
        <translation>Attivo</translation>
    </message>
    <message>
        <source>Allow KeeShare imports</source>
        <translation>Consenti importazioni KeeShare</translation>
    </message>
    <message>
        <source>Allow import</source>
        <translation>Consenti importazione</translation>
    </message>
    <message>
        <source>Allow KeeShare exports</source>
        <translation>Consenti esportazioni KeeShare</translation>
    </message>
    <message>
        <source>Allow export</source>
        <translation>Consenti esportazione</translation>
    </message>
    <message>
        <source>Only show warnings and errors</source>
        <translation>Visualizza solo avvisi ed errori</translation>
    </message>
    <message>
        <source>Own certificate</source>
        <translation>Certificato proprio</translation>
    </message>
    <message>
        <source>Signer:</source>
        <translation>Firmatario:</translation>
    </message>
    <message>
        <source>Generate new certificate</source>
        <translation>Genera nuovo certificato</translation>
    </message>
    <message>
        <source>Generate</source>
        <translation>Genera</translation>
    </message>
    <message>
        <source>Fingerprint:</source>
        <translation>Impronta digitale:</translation>
    </message>
    <message>
        <source>Signer name field</source>
        <translation>Campo nome firmatario</translation>
    </message>
    <message>
        <source>Fingerprint</source>
        <translation>Impronta digitale</translation>
    </message>
</context>
<context>
    <name>ShareExport</name>
    <message>
        <source>Could not write export container.</source>
        <translation>Impossibile scrivere il contenitore esportazione.</translation>
    </message>
</context>
<context>
    <name>ShareImport</name>
    <message>
        <source>Successful import</source>
        <translation>Importazione riuscita</translation>
    </message>
</context>
<context>
    <name>ShareObserver</name>
    <message>
        <source>Import from %1 failed (%2)</source>
        <translation>Importazione da %1 non riuscita (%2)</translation>
    </message>
    <message>
        <source>Import from %1 successful (%2)</source>
        <translation>Importazione da %1 riuscita (%2)</translation>
    </message>
    <message>
        <source>Imported from %1</source>
        <translation>Importato da %1</translation>
    </message>
    <message>
        <source>Multiple import source path to %1 in %2</source>
        <translation>Percorso multiplo di sorgente di importazione a %1 in %2</translation>
    </message>
    <message>
        <source>Conflicting export target path %1 in %2</source>
        <translation>Percorso destinazione esportazione in conflitto %1 in %2</translation>
    </message>
    <message>
        <source>Export to %1 failed (%2)</source>
        <translation>Esportazione in %1 non riuscita (%2)</translation>
    </message>
    <message>
        <source>Export to %1 successful (%2)</source>
        <translation>Esportazione in %1 riuscita (%2)</translation>
    </message>
    <message>
        <source>Export to %1</source>
        <translation>Esporta in %1</translation>
    </message>
</context>
<context>
    <name>TagModel</name>
    <message>
        <source>Clear Search</source>
        <translation>Cancella ricerca</translation>
    </message>
    <message>
        <source>All Entries</source>
        <translation>Tutte le voci</translation>
    </message>
    <message>
        <source>Expired</source>
        <translation>Scaduto</translation>
    </message>
    <message>
        <source>Weak Passwords</source>
        <translation>Password deboli</translation>
    </message>
    <message>
        <source>TOTP Entries</source>
        <translation>Voci TOTP</translation>
    </message>
</context>
<context>
    <name>TagView</name>
    <message>
        <source>Remove Search</source>
        <translation>Rimuovi ricerca</translation>
    </message>
    <message>
        <source>Remove Tag</source>
        <translation>Rimuovi etichetta</translation>
    </message>
    <message>
        <source>Confirm Remove Tag</source>
        <translation>Conferma rimozione etichetta</translation>
    </message>
    <message>
        <source>Remove tag &quot;%1&quot; from all entries in this database?</source>
        <translation>Vuoi rimuovere l&apos;etichetta &quot;%1&quot; da tutte le voci in questo database?</translation>
    </message>
</context>
<context>
    <name>TextAttachmentsEditWidget</name>
    <message>
        <source>Preview</source>
        <translation>Anteprima</translation>
    </message>
</context>
<context>
    <name>TextAttachmentsPreviewWidget</name>
    <message>
        <source>Form</source>
        <translation>Modulo</translation>
    </message>
    <message>
        <source>Type:</source>
        <translation>Tipo:</translation>
    </message>
</context>
<context>
    <name>TotpDialog</name>
    <message>
        <source>Timed Password</source>
        <translation>Password a tempo</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Copia</translation>
    </message>
    <message numerus="yes">
        <source>Expires in &lt;b&gt;%n&lt;/b&gt; second(s)</source>
        <translation><numerusform>Scadenza tra &lt;b&gt;%n&lt;/b&gt; secondi</numerusform><numerusform>Scadenza tra &lt;b&gt;%n&lt;/b&gt; secondo(i)</numerusform><numerusform>Scade tra &lt;b&gt;%n&lt;/b&gt; secondo/i</numerusform></translation>
    </message>
</context>
<context>
    <name>TotpExportSettingsDialog</name>
    <message>
        <source>Copy</source>
        <translation>Copia</translation>
    </message>
    <message>
        <source>NOTE: These TOTP settings are custom and may not work with other authenticators.</source>
        <comment>TOTP QR code dialog warning</comment>
        <translation>NOTA: queste impostazioni TOTP sono personalizzate e potrebbero non funzionare con altri autenticatori.</translation>
    </message>
    <message>
        <source>There was an error creating the QR code.</source>
        <translation>Si è verificato un errore durante la creazione del codice QR.</translation>
    </message>
    <message>
        <source>Closing in %1 seconds.</source>
        <translation>Chiusura tra %1 secondi.</translation>
    </message>
</context>
<context>
    <name>TotpSetupDialog</name>
    <message>
        <source>Setup TOTP</source>
        <translation>Imposta TOTP</translation>
    </message>
    <message>
        <source>Secret Key:</source>
        <translation>Chiave segreta:</translation>
    </message>
    <message>
        <source>Secret key must be in Base32 format</source>
        <translation>La chiave segreta deve essere in formato Base32</translation>
    </message>
    <message>
        <source>Secret key field</source>
        <translation>Campo chiave segreta</translation>
    </message>
    <message>
        <source>Default settings (RFC 6238)</source>
        <translation>Impostazioni predefinite (RFC 6238)</translation>
    </message>
    <message>
        <source>Steam® settings</source>
        <translation>Impostazioni Steam®</translation>
    </message>
    <message>
        <source>Custom settings:</source>
        <translation>Impostazioni personalizzate:</translation>
    </message>
    <message>
        <source>Custom Settings</source>
        <translation>Impostazioni personalizzate</translation>
    </message>
    <message>
        <source>Algorithm:</source>
        <translation>Algoritmo:</translation>
    </message>
    <message>
        <source>Time step:</source>
        <translation>Passo temporale:</translation>
    </message>
    <message>
        <source>Time step field</source>
        <translation>Campo del passo temporale</translation>
    </message>
    <message>
        <source> sec</source>
        <comment>Seconds</comment>
        <translation> sec</translation>
    </message>
    <message>
        <source>Code size:</source>
        <translation>Dimensioni codice:</translation>
    </message>
    <message>
        <source> digits</source>
        <translation> cifre</translation>
    </message>
    <message>
        <source>Invalid TOTP Secret</source>
        <translation>Segreto TOTP non valido</translation>
    </message>
    <message>
        <source>You have entered an invalid secret key. The key must be in Base32 format.
Example: JBSWY3DPEHPK3PXP</source>
        <translation>Hai inserito una chiave segreta non valida.  La chiave deve essere in formato Base32. 
Esempio: JBSWY3DPEHPK3PXP</translation>
    </message>
    <message>
        <source>Confirm Remove TOTP Settings</source>
        <translation>Conferma rimozione impostazioni TOTP</translation>
    </message>
    <message>
        <source>Are you sure you want to delete TOTP settings for this entry?</source>
        <translation>Vuoi eliminare le impostazioni TOTP per questa voce?</translation>
    </message>
    <message>
        <source>Error: secret key is invalid</source>
        <translation>Errore: la chiave segreta non è valida</translation>
    </message>
</context>
<context>
    <name>URLEdit</name>
    <message>
        <source>Invalid URL</source>
        <translation>URL non valida</translation>
    </message>
</context>
<context>
    <name>UpdateCheckDialog</name>
    <message>
        <source>Checking for updates</source>
        <translation>Verifica disponibilità aggiornamenti</translation>
    </message>
    <message>
        <source>Checking for updates…</source>
        <translation>Verifica disponibilità aggiornamenti…</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Chiudi</translation>
    </message>
    <message>
        <source>Software Update</source>
        <translation>Aggiornamento software</translation>
    </message>
    <message>
        <source>An error occurred when trying to retrieve update information, please try again later.</source>
        <translation>Si è verificato un errore durante la verifica delle informazioni sugli  aggiornamenti, riprova più tardi.</translation>
    </message>
    <message>
        <source>&lt;strong&gt;A new version is available.&lt;/strong&gt;&lt;br/&gt;KeePassXC %1 can be &lt;a href=&quot;https://keepassxc.org/download/&quot;&gt;downloaded here&lt;/a&gt;.</source>
        <translation>&lt;strong&gt;È disponibile una nuova versione.&lt;/strong&gt;&lt;br/&gt;KeePassXC %1 può essere &lt;a href=&quot;https://keepassxc.org/download/&quot;&gt;scaricato qui&lt;/a&gt;.</translation>
    </message>
    <message>
        <source>You have the latest version of KeePassXC</source>
        <translation>Questa versione di KeePassXC è aggiornata</translation>
    </message>
</context>
<context>
    <name>WelcomeWidget</name>
    <message>
        <source>Start storing your passwords securely in a KeePassXC database</source>
        <translation>Archivia le password in modo sicuro in un database KeePassXC</translation>
    </message>
    <message>
        <source>Recent databases</source>
        <translation>Database recenti</translation>
    </message>
    <message>
        <source>Open a recent database</source>
        <translation>Apri un database recente</translation>
    </message>
    <message>
        <source>Welcome to KeePassXC %1</source>
        <translation>Benvenuto in KeePassXC %1</translation>
    </message>
    <message>
        <source>Create Database</source>
        <translation>Crea database</translation>
    </message>
    <message>
        <source>Open Database</source>
        <translation>Apri database</translation>
    </message>
    <message>
        <source>Import File</source>
        <translation>Importa file</translation>
    </message>
</context>
<context>
    <name>WinUtils</name>
    <message>
        <source>Invalid key code</source>
        <translation>Codice chiave non valido</translation>
    </message>
    <message>
        <source>Global shortcut already registered to %1</source>
        <translation>Scorciatoia globale già registrata a %1</translation>
    </message>
    <message>
        <source>Could not register global shortcut</source>
        <translation>Impossibile registrare la scorciatoia globale</translation>
    </message>
</context>
<context>
    <name>YubiKey</name>
    <message>
        <source>Could not find hardware key with serial number %1. Please connect it to continue.</source>
        <translation>Impossibile trovare la chiave hardware con numero di serie %1. 
Per continuare collega la chiave hardware.</translation>
    </message>
</context>
<context>
    <name>YubiKeyEditWidget</name>
    <message>
        <source>Hardware key slot selection</source>
        <translation>Selezione slot chiave fisica</translation>
    </message>
    <message>
        <source>Could not find any hardware keys!</source>
        <translation>Nessuna chiave fisica trovata!</translation>
    </message>
    <message>
        <source>Selected hardware key slot does not support challenge-response!</source>
        <translation>Lo slot chiave fisica selezionato non supporta challenge-response!</translation>
    </message>
    <message>
        <source>Challenge-Response</source>
        <translation>Challenge-Response</translation>
    </message>
    <message>
        <source>Add Challenge-Response</source>
        <translation>Aggiungi Challenge-Response</translation>
    </message>
    <message>
        <source>Change Challenge-Response</source>
        <translation>Modifica Challenge-Response</translation>
    </message>
    <message>
        <source>Remove Challenge-Response</source>
        <translation>Rimuovi Challenge-Response</translation>
    </message>
    <message>
        <source>Challenge-Response set, click to change or remove</source>
        <translation>Challeng-Response impostato, clic per modificarlo/rimuoverlo</translation>
    </message>
    <message>
        <source>Detecting hardware keys…</source>
        <translation>Rilevamento chiavi fisiche...</translation>
    </message>
    <message>
        <source>No hardware keys detected</source>
        <translation>Nessuna chiave fisica rilevata</translation>
    </message>
    <message>
        <source>Refresh hardware keys</source>
        <translation>Aggiorna chiavi hardware</translation>
    </message>
    <message>
        <source>&lt;p&gt;If you own a &lt;a href=&quot;https://www.yubico.com/&quot;&gt;YubiKey&lt;/a&gt; or &lt;a href=&quot;https://onlykey.io&quot;&gt;OnlyKey&lt;/a&gt;, you can use it for additional security.&lt;/p&gt;&lt;p&gt;The key requires one of its slots to be programmed with &lt;a href=&quot;https://keepassxc.org/docs/#faq-yubikey-howto&quot;&gt;Challenge-Response&lt;/a&gt;.&lt;/p&gt;</source>
        <translation>&lt;p&gt;Se possiedi una &lt;a href=&quot;https://www.yubico.com/&quot;&gt;YubiKey&lt;/a&gt; o &lt;a href=&quot;https://onlykey.io&quot;&gt;OnlyKey&lt;/a&gt;, puoi usarla per una maggiore sicurezza.&lt;/p&gt;&lt;p&gt;La chiave richiede che uno dei suoi slot sia programmato con &lt;a href=&quot;https://keepassxc.org/docs/#faq-yubikey-howto&quot;&gt;Challenge-Response&lt;/a&gt;.&lt;/p&gt;</translation>
    </message>
    <message>
        <source>Hardware keys found, but no slots are configured</source>
        <translation>Chiave hardware trovata, ma non è configurato nessuno slot</translation>
    </message>
</context>
<context>
    <name>YubiKeyInterfacePCSC</name>
    <message>
        <source>Hardware key is locked or timed out. Unlock or re-present it to continue.</source>
        <translation>La chiave fisica è bloccata o scaduta. Per continuare sbloccala o ri-collegala.</translation>
    </message>
    <message>
        <source>Hardware key was not found or is not configured.</source>
        <translation>La chiave fisica non è stata trovata o non è configurata.</translation>
    </message>
    <message>
        <source>(NFC) %1 [%2] - Slot %3, %4</source>
        <comment>YubiKey display fields</comment>
        <translation>(NFC) %1 [%2] - Slot %3, %4</translation>
    </message>
    <message>
        <source>Press</source>
        <comment>USB Challenge-Response Key interaction request</comment>
        <translation>Premi</translation>
    </message>
    <message>
        <source>Passive</source>
        <comment>USB Challenge-Response Key no interaction required</comment>
        <translation>Passiva</translation>
    </message>
    <message>
        <source>The YubiKey PC/SC interface has not been initialized.</source>
        <translation>L&apos;interfaccia YubiKey PC/SC non è stata inizializzata.</translation>
    </message>
    <message>
        <source>Failed to complete a challenge-response, the PC/SC error code was: %1</source>
        <translation>Impossibile completare challenge-response,
Codice errore PC/SC: %1</translation>
    </message>
</context>
<context>
    <name>YubiKeyInterfaceUSB</name>
    <message>
        <source>Press</source>
        <comment>USB Challenge-Response Key interaction request</comment>
        <translation>Premi</translation>
    </message>
    <message>
        <source>Passive</source>
        <comment>USB Challenge-Response Key no interaction required</comment>
        <translation>Passiva</translation>
    </message>
    <message>
        <source>The YubiKey USB interface has not been initialized.</source>
        <translation>L&apos;interfaccia USB YubiKey non è stata inizializzata.</translation>
    </message>
    <message>
        <source>Could not find hardware key with serial number %1. Please plug it in to continue.</source>
        <translation>Non è stato possibile trovare una chiave fisica nello slot numero %1. Per continuare collega una chiave fisica.</translation>
    </message>
    <message>
        <source>Hardware key timed out waiting for user interaction.</source>
        <translation>Sessione chiave fisica scaduta in attesa di un interazione da parte dell&apos;utente.</translation>
    </message>
    <message>
        <source>A USB error occurred when accessing the hardware key: %1</source>
        <translation>Errore USB durante l&apos;accesso alla chiave fisica: %1</translation>
    </message>
    <message>
        <source>Failed to complete a challenge-response, the specific error was: %1</source>
        <translation>Impossibile completare challenge-response, l&apos;errore specifico è: %1</translation>
    </message>
    <message>
        <source>%1 [%2] - Slot %3</source>
        <comment>YubiKey NEO display fields</comment>
        <translation>%1 [%2] - Slot %3</translation>
    </message>
    <message>
        <source>%1 [%2] - Slot %3, %4</source>
        <comment>YubiKey display fields</comment>
        <translation>%1 [%2] - Slot %3, %4</translation>
    </message>
    <message>
        <source>Unknown</source>
        <comment>Unknown hardware key name</comment>
        <translation>Sconosciuto</translation>
    </message>
</context>
</TS>
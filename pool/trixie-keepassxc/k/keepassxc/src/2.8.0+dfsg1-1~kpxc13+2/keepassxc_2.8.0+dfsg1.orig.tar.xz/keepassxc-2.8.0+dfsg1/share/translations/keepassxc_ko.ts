<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="ko">
<context>
    <name>AboutDialog</name>
    <message>
        <source>About KeePassXC</source>
        <translation>KeePassXC 정보</translation>
    </message>
    <message>
        <source>About</source>
        <translation>정보</translation>
    </message>
    <message>
        <source>Report bugs at: &lt;a href=&quot;https://github.com/keepassxreboot/keepassxc/issues&quot; style=&quot;text-decoration: underline;&quot;&gt;https://github.com&lt;/a&gt;</source>
        <translation>&lt;a href=&quot;https://github.com/keepassxreboot/keepassxc/issues&quot; style=&quot;text-decoration: underline;&quot;&gt;https://github.com&lt;/a&gt; 사이트에 버그를 보고해 주십시오</translation>
    </message>
    <message>
        <source>KeePassXC is distributed under the terms of the GNU General Public License (GPL) version 2 or (at your option) version 3.</source>
        <translation>KeePassXC는 GNU 일반 공중 라이선스(GPL) 버전 2 및 (선택적으로) 버전 3으로 배포됩니다.</translation>
    </message>
    <message>
        <source>Project Maintainers:</source>
        <translation>프로젝트 관리자:</translation>
    </message>
    <message>
        <source>Special thanks from the KeePassXC team go to debfx for creating the original KeePassX.</source>
        <translation>KeePassXC 팀은 원 프로젝트인 KeePassX의 개발자 debfx에게 특별한 감사를 전합니다.</translation>
    </message>
    <message>
        <source>Contributors</source>
        <translation>기여자</translation>
    </message>
    <message>
        <source>&lt;a href=&quot;https://github.com/keepassxreboot/keepassxc/graphs/contributors&quot;&gt;See Contributions on GitHub&lt;/a&gt;</source>
        <translation>&lt;a href=&quot;https://github.com/keepassxreboot/keepassxc/graphs/contributors&quot;&gt;GitHub에서 기여자 보기&lt;/a&gt;</translation>
    </message>
    <message>
        <source>Debug Info</source>
        <translation>디버그 정보</translation>
    </message>
    <message>
        <source>Include the following information whenever you report a bug:</source>
        <translation>버그를 보고할 때 다음 정보를 포함하십시오:</translation>
    </message>
    <message>
        <source>Copy to clipboard</source>
        <translation>클립보드에 복사</translation>
    </message>
</context>
<context>
    <name>AccessControlDialog</name>
    <message>
        <source>KeePassXC -  Access Request</source>
        <translation>KeePassXC - 접근 확인</translation>
    </message>
    <message>
        <source>Non-existing/inaccessible executable path. Please double-check the client is legit.</source>
        <translation>실행 파일 경로가 존재하지 않거나 접근할 수 없습니다. 클라이언트가 올바른지 확인하십시오.</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;%1 &lt;/span&gt;is requesting access to the following entries:&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;%1 &lt;/span&gt;에서 다음 항목에 접근할 수 있도록 요청했습니다:&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>이름</translation>
    </message>
    <message>
        <source>PID</source>
        <translation>PID</translation>
    </message>
    <message>
        <source>Executable</source>
        <translation>실행 파일</translation>
    </message>
    <message>
        <source>Command Line</source>
        <translation>명령행</translation>
    </message>
    <message>
        <source>Details</source>
        <translation>자세한 정보</translation>
    </message>
    <message>
        <source>Your decision will be remembered for the duration while both the requesting client AND KeePassXC are running.</source>
        <translation>선택 사항은 요청하는 클라이언트와 KeePassXC 둘 다가 실행 중인 동안만 기억합니다.</translation>
    </message>
    <message>
        <source>Remember</source>
        <translation>기억</translation>
    </message>
    <message>
        <source>Allow Selected</source>
        <translation>선택 허용</translation>
    </message>
    <message>
        <source>Deny All &amp;&amp; Future</source>
        <translation>앞으로 계속 모두 거부</translation>
    </message>
    <message>
        <source>Allow All &amp;&amp; &amp;Future</source>
        <translation>앞으로 계속 모두 허용(&amp;F)</translation>
    </message>
</context>
<context>
    <name>AccessControlDialog::DenyButton</name>
    <message>
        <source>Deny for this program</source>
        <translation>이 프로그램 거부</translation>
    </message>
</context>
<context>
    <name>AgentSettingsWidget</name>
    <message>
        <source>Enable SSH Agent integration</source>
        <translation>SSH 에이전트 통합 활성화</translation>
    </message>
    <message>
        <source>Use Pageant</source>
        <translation>Pageant 사용</translation>
    </message>
    <message>
        <source>Use OpenSSH</source>
        <translation>OpenSSH 사용</translation>
    </message>
    <message>
        <source>Use both agents</source>
        <translation>에이전트 둘 다 사용</translation>
    </message>
    <message>
        <source>SSH_AUTH_SOCK override</source>
        <translation>SSH_AUTH_SOCK 재정의</translation>
    </message>
    <message>
        <source>SSH_AUTH_SOCK value</source>
        <translation>SSH_AUTH_SOCK 값</translation>
    </message>
    <message>
        <source>(empty)</source>
        <translation>(비어 있음)</translation>
    </message>
    <message>
        <source>SSH_SK_PROVIDER value</source>
        <translation>SSH_SK_PROVIDER 값</translation>
    </message>
    <message>
        <source>SSH_SK_PROVIDER override</source>
        <translation>SSH_SK_PROVIDER 재정의</translation>
    </message>
    <message>
        <source>No SSH Agent socket available. Either make sure SSH_AUTH_SOCK environment variable exists or set an override.</source>
        <translation>SSH 에이전트 소켓을 사용할 수 없습니다. SSH_AUTH_SOCK 환경 변수가 설정되어 있는지 확인하시고, 없다면 재정의할 수 있습니다.</translation>
    </message>
    <message>
        <source>SSH Agent connection is working!</source>
        <translation>SSH 에이전트에 연결할 수 있습니다!</translation>
    </message>
</context>
<context>
    <name>AppKit</name>
    <message>
        <source>Window</source>
        <translation>창</translation>
    </message>
    <message>
        <source>Minimize</source>
        <translation>최소화</translation>
    </message>
    <message>
        <source>Zoom</source>
        <translation>확대/축소</translation>
    </message>
    <message>
        <source>Bring All to Front</source>
        <translation>모두 앞으로 가져오기</translation>
    </message>
</context>
<context>
    <name>ApplicationSettingsWidget</name>
    <message>
        <source>Application Settings</source>
        <translation>프로그램 설정</translation>
    </message>
    <message>
        <source>General</source>
        <translation>일반</translation>
    </message>
    <message>
        <source>Security</source>
        <translation>보안</translation>
    </message>
    <message>
        <source>This setting cannot be enabled when minimize on unlock is enabled.</source>
        <translation>이 설정은 최소화나 잠금 해제가 활성화되어 있으면 활성화할 수 없습니다.</translation>
    </message>
    <message>
        <source>Access error for config file %1</source>
        <translation>설정 파일 %1에 접근할 수 없음</translation>
    </message>
    <message>
        <source>Icon only</source>
        <translation>아이콘만</translation>
    </message>
    <message>
        <source>Text only</source>
        <translation>텍스트만</translation>
    </message>
    <message>
        <source>Text beside icon</source>
        <translation>아이콘 옆에 텍스트</translation>
    </message>
    <message>
        <source>Text under icon</source>
        <translation>아이콘 밑에 텍스트</translation>
    </message>
    <message>
        <source>Follow style</source>
        <translation>스타일 따르기</translation>
    </message>
    <message>
        <source>Monochrome</source>
        <translation>흑백</translation>
    </message>
    <message>
        <source>Monochrome (light)</source>
        <translation>단색(밝음)</translation>
    </message>
    <message>
        <source>Monochrome (dark)</source>
        <translation>단색(어두움)</translation>
    </message>
    <message>
        <source>Colorful</source>
        <translation>컬러풀</translation>
    </message>
    <message>
        <source>You must restart the application to set the new language. Would you like to restart now?</source>
        <translation>새 언어를 적용하려면 프로그램을 다시 시작해야 합니다. 지금 다시 시작하시겠습니까?</translation>
    </message>
    <message>
        <source>Select backup storage directory</source>
        <translation>백업 저장 디렉터리 선택</translation>
    </message>
    <message>
        <source>Confirm Reset</source>
        <translation>재설정 확인</translation>
    </message>
    <message>
        <source>Are you sure you want to reset all settings to default?</source>
        <translation>모든 설정을 기본값으로 재설정하시겠습니까?</translation>
    </message>
    <message>
        <source>Import KeePassXC Settings</source>
        <translation>KeePassXC 설정 가져오기</translation>
    </message>
    <message>
        <source>Failed to import settings from %1, not a valid settings file.</source>
        <translation>유효한 설정 파일이 아닌 %1에서 설정을 가져오지 못했습니다.</translation>
    </message>
    <message>
        <source>Export KeePassXC Settings</source>
        <translation>KeePassXC 설정 내보내기</translation>
    </message>
    <message>
        <source>Small</source>
        <translation>작은</translation>
    </message>
    <message>
        <source>Normal</source>
        <translation>일반</translation>
    </message>
    <message>
        <source>Medium</source>
        <translation>중간</translation>
    </message>
    <message>
        <source>Large</source>
        <translation>큰</translation>
    </message>
    <message>
        <source>Custom</source>
        <translation>사용자 지정</translation>
    </message>
    <message>
        <source>None</source>
        <translation>없음</translation>
    </message>
    <message>
        <source>Restart KeePassXC to apply the Auto-Type desktop portals preference.</source>
        <translation>자동-입력 데스크톱 포털 기본 설정을 적용하려면 KeePassXC를 다시 시작하세요.</translation>
    </message>
</context>
<context>
    <name>ApplicationSettingsWidgetGeneral</name>
    <message>
        <source>Basic Settings</source>
        <translation>기본 설정</translation>
    </message>
    <message>
        <source>Startup</source>
        <translation>시작</translation>
    </message>
    <message>
        <source>Start only a single instance of KeePassXC</source>
        <translation>KeePassXC 단일 인스턴스만 사용</translation>
    </message>
    <message>
        <source>Automatically launch KeePassXC at system startup</source>
        <translation>시스템 시작 시 KeePassXC 자동 시작</translation>
    </message>
    <message>
        <source>Minimize window at application startup</source>
        <translation>프로그램 시작 시 창 최소화</translation>
    </message>
    <message>
        <source>Minimize window after unlocking database</source>
        <translation>데이터베이스 잠금 해제 후 창 최소화</translation>
    </message>
    <message>
        <source>Remember previously used databases</source>
        <translation>과거 데이터베이스 기억</translation>
    </message>
    <message>
        <source> recent files</source>
        <translation>개 최근 파일</translation>
    </message>
    <message>
        <source>Load previously open databases on startup</source>
        <translation>시작할 때 이전에 사용한 데이터베이스 열기</translation>
    </message>
    <message>
        <source>Remember database key files and security dongles</source>
        <translation>데이터베이스 키 파일과 보안 동글 기억</translation>
    </message>
    <message>
        <source>Check for updates at application startup once per week</source>
        <translation>프로그램을 시작할 때 1주일에 1번 업데이트 확인</translation>
    </message>
    <message>
        <source>Include beta releases when checking for updates</source>
        <translation>업데이트를 확인할 때 베타 릴리스 포함</translation>
    </message>
    <message>
        <source>File Management</source>
        <translation>파일 관리</translation>
    </message>
    <message>
        <source>Automatically save after every change</source>
        <translation>항목을 변경할 때 자동 저장</translation>
    </message>
    <message>
        <source>Automatically save when locking database</source>
        <translation>데이터베이스를 잠글 때 자동으로 저장</translation>
    </message>
    <message>
        <source>Automatically save non-data changes when locking database</source>
        <translation>데이터베이스를 잠글 때 데이터 이외의 변경 사항 자동 저장</translation>
    </message>
    <message>
        <source>Automatically reload the database when modified externally</source>
        <translation>외부에서 데이터베이스를 수정했을 때 자동으로 새로 고침</translation>
    </message>
    <message>
        <source>Backup database file before saving</source>
        <translation>저장하기 전에 데이터베이스 파일 백업</translation>
    </message>
    <message>
        <source>{DB_FILENAME}.old.kdbx</source>
        <translation>{DB_FILENAME}.old.kdbx</translation>
    </message>
    <message>
        <source>Use alternative saving method (may solve problems with Dropbox, Google Drive, GVFS, etc.)</source>
        <translation>대체 저장 방식 사용(Dropbox, Google 드라이브, GVFS 등 문제 해결)</translation>
    </message>
    <message>
        <source>Temporary file moved into place</source>
        <translation>임시 파일에 저장한 후 현재 위치로 이동</translation>
    </message>
    <message>
        <source>Directly write to database file (dangerous)</source>
        <translation>데이터베이스 파일에 직접 기록(위험)</translation>
    </message>
    <message>
        <source>Entry Management</source>
        <translation>항목 관리</translation>
    </message>
    <message>
        <source>Use group icon on entry creation</source>
        <translation>항목을 만들 때 그룹 아이콘 사용</translation>
    </message>
    <message>
        <source>Minimize when opening a URL</source>
        <translation>URL을 열 때 창 최소화</translation>
    </message>
    <message>
        <source>Hide window when copying to clipboard</source>
        <translation>클립보드에 복사할 때 창 숨기기</translation>
    </message>
    <message>
        <source>Minimize</source>
        <translation>최소화</translation>
    </message>
    <message>
        <source>Drop to background</source>
        <translation>백그라운드로 전환</translation>
    </message>
    <message>
        <source>Favicon download timeout:</source>
        <translation>파비콘 다운로드 시간 제한:</translation>
    </message>
    <message>
        <source>Website icon download timeout in seconds</source>
        <translation>웹 사이트 아이콘 다운로드 시간 제한(초 단위)</translation>
    </message>
    <message>
        <source> sec</source>
        <comment>Seconds</comment>
        <translation>초</translation>
    </message>
    <message>
        <source>User Interface</source>
        <translation>사용자 인터페이스</translation>
    </message>
    <message>
        <source>Toolbar button style</source>
        <translation>도구 모음 단추 스타일</translation>
    </message>
    <message>
        <source>Movable toolbar</source>
        <translation>이동 가능한 도구 모음</translation>
    </message>
    <message>
        <source>Language selection</source>
        <translation>언어 선택</translation>
    </message>
    <message>
        <source>Language:</source>
        <translation>언어:</translation>
    </message>
    <message>
        <source>(restart program to activate)</source>
        <translation>(다시 시작 후 적용됨)</translation>
    </message>
    <message>
        <source>Toolbar button style:</source>
        <translation>도구 모음 단추 스타일:</translation>
    </message>
    <message>
        <source>Show passwords in color</source>
        <translation>비밀번호 표시 시 글자 종류별로 색상 적용</translation>
    </message>
    <message>
        <source>Use monospaced font for notes</source>
        <translation>메모에 고정폭 글꼴 사용</translation>
    </message>
    <message>
        <source>Minimize instead of app exit</source>
        <translation>프로그램을 끝내지 않고 최소화</translation>
    </message>
    <message>
        <source>Show a system tray icon</source>
        <translation>시스템 트레이 아이콘 표시</translation>
    </message>
    <message>
        <source>Tray icon type</source>
        <translation>트레이 아이콘 종류</translation>
    </message>
    <message>
        <source>Tray icon type:</source>
        <translation>트레이 아이콘 형식:</translation>
    </message>
    <message>
        <source>Hide window to system tray when minimized</source>
        <translation>시스템 트레이로 최소화</translation>
    </message>
    <message>
        <source>Reset settings to default…</source>
        <translation>기본값으로 설정 복원...</translation>
    </message>
    <message>
        <source>Auto-Type</source>
        <translation>자동 입력</translation>
    </message>
    <message>
        <source>Use entry title to match windows for global Auto-Type</source>
        <translation>전역 자동 입력 시 창 제목을 항목 제목에서 검색</translation>
    </message>
    <message>
        <source>Use entry URL to match windows for global Auto-Type</source>
        <translation>전역 자동 입력 시 창 제목을 항목 URL에서 검색</translation>
    </message>
    <message>
        <source>Always ask before performing Auto-Type</source>
        <translation>자동 입력 시 항상 묻기</translation>
    </message>
    <message>
        <source>Hide expired entries from Auto-Type</source>
        <translation>자동 입력에서 만료된 항목 숨기기</translation>
    </message>
    <message>
        <source>Re-lock previously locked database after performing Auto-Type</source>
        <translation>자동 입력 이후 이전에 잠긴 데이터베이스 다시 잠그기</translation>
    </message>
    <message>
        <source>Auto-Type start delay:</source>
        <translation>자동 입력 시작 지연 시간:</translation>
    </message>
    <message>
        <source>Global Auto-Type shortcut:</source>
        <translation>전역 자동 입력 단축키:</translation>
    </message>
    <message>
        <source>Auto-type start delay milliseconds</source>
        <translation>자동 입력 시작 지연 시간 (밀리초)</translation>
    </message>
    <message>
        <source> ms</source>
        <comment>Milliseconds</comment>
        <translation>ms</translation>
    </message>
    <message>
        <source>Auto-Type typing delay:</source>
        <translation>자동 입력 지연 시간:</translation>
    </message>
    <message>
        <source>Global auto-type shortcut</source>
        <translation>전역 자동 입력 단축키</translation>
    </message>
    <message>
        <source>Auto-type character typing delay milliseconds</source>
        <translation>글자당 자동 입력 지연 시간(밀리초 단위)</translation>
    </message>
    <message>
        <source>Remember last typed entry for:</source>
        <translation>마지막으로 입력한 항목 기억 시간:</translation>
    </message>
    <message>
        <source>On database unlock, show entries that will expire within</source>
        <translation>데이터베이스 잠금 해제 시 만료될 항목 표시</translation>
    </message>
    <message>
        <source>On database unlock, show entries that will expire within </source>
        <translation>데이터베이스 잠금 해제 시 만료될 항목 표시</translation>
    </message>
    <message>
        <source> days</source>
        <comment>number of days warning for password expiration</comment>
        <translation>일 내에 만료됨</translation>
    </message>
    <message>
        <source>Destination format:</source>
        <translation>대상 형식:</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;{DB_FILENAME}&lt;/span&gt; is replaced with the filename of the saved database without extension&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;{TIME:&amp;lt;format&amp;gt;}&lt;/span&gt; is replaced with the specified time format (default: dd_MM_yyyy_hh-mm-ss)&lt;/p&gt;&lt;p&gt;See the User Guide for more details&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;{DB_FILENAME}&lt;/span&gt;이(가) 확장자 없이 저장된 데이터베이스의 파일 이름으로 대체되었습니다&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;{TIME:&amp;lt;format&amp;gt;}&lt;/span&gt; 이(가) 지정된 시간 형식으로 대체되었습니다 (기본값: dd_MM_yyyy_hh-mm-ss)&lt;/p&gt;&lt;p&gt;자세한 내용은 사용자 가이드를 참조하세요&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Choose folder...</source>
        <translation>폴더 선택...</translation>
    </message>
    <message>
        <source>Show confirmation before moving entries to recycle bin</source>
        <translation>항목을 휴지통으로 이동하기 전에 확인 표시</translation>
    </message>
    <message>
        <source>Copy data on double clicking field in entry view</source>
        <translation>항목 보기에서 더블 클릭 필드에 데이터 복사</translation>
    </message>
    <message>
        <source>Show toolbar</source>
        <translation>도구 모음 표시</translation>
    </message>
    <message>
        <source>Show the menu bar by pressing the Alt key</source>
        <translation>Alt 키를 눌러 메뉴 표시줄 표시</translation>
    </message>
    <message>
        <source>Show menubar</source>
        <translation>메뉴 표시줄 표시</translation>
    </message>
    <message>
        <source>Import settings…</source>
        <translation>설정 가져오기...</translation>
    </message>
    <message>
        <source>Export settings…</source>
        <translation>설정 내보내기...</translation>
    </message>
    <message>
        <source>Font size:</source>
        <translation>글꼴 크기:</translation>
    </message>
    <message>
        <source>Font size selection</source>
        <translation>글꼴 크기 선택</translation>
    </message>
    <message>
        <source>Skip confirmation for main window Auto-Type actions</source>
        <translation>기본 창 자동 유형 작업에 대한 확인 건너뛰기</translation>
    </message>
    <message>
        <source>Double-click action for URL:</source>
        <translation>URL에 대한 작업 두 번 클릭:</translation>
    </message>
    <message>
        <source>Double-click action for URL field</source>
        <translation>URL 필드에 대한 더블 클릭 작업</translation>
    </message>
    <message>
        <source>Edit entry</source>
        <translation>항목 편집</translation>
    </message>
    <message>
        <source>Open entry URL in browser</source>
        <translation>브라우저에서 항목 URL 열기</translation>
    </message>
    <message>
        <source>Copy entry URL to clipboard</source>
        <translation>항목 URL을 클립보드에 복사</translation>
    </message>
    <message>
        <source>Auto-generate password for new entries</source>
        <translation>새 항목에 대한 비밀번호 자동 생성</translation>
    </message>
    <message>
        <source>Keep remote desktop connection open after performing Auto-Type</source>
        <translation>자동-입력을 수행한 후 원격 데스크톱 연결을 계속 열어 둡니다</translation>
    </message>
    <message>
        <source>Remote desktop mode:</source>
        <translation>원격 데스크톱 모드:</translation>
    </message>
    <message>
        <source>Never remember session</source>
        <translation>세션을 절대 기억하지 않음</translation>
    </message>
    <message>
        <source>Remember session until exit</source>
        <translation>종료 시까지 세션을 기억</translation>
    </message>
    <message>
        <source>Remember session until revoked by desktop</source>
        <translation>데스크톱에서 해제할 때까지 세션을 기억</translation>
    </message>
    <message>
        <source>None</source>
        <translation>없음</translation>
    </message>
    <message>
        <source>Configure...</source>
        <translation>구성...</translation>
    </message>
    <message>
        <source>Use remote desktop for clipboard access</source>
        <translation>클립보드 액세스를 위해 원격 데스크톱 사용</translation>
    </message>
    <message>
        <source>Experimental: Prefer desktop portals (Wayland implementation)</source>
        <translation>실험적: 데스크톱 포털 선호 (Wayland 구현)</translation>
    </message>
    <message>
        <source>Show autocomplete suggestions for username and additional attributes</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>ApplicationSettingsWidgetSecurity</name>
    <message>
        <source>Timeouts</source>
        <translation>시간 제한</translation>
    </message>
    <message>
        <source>Database lock timeout seconds</source>
        <translation>데이터베이스 잠금 시간 제한(초 단위)</translation>
    </message>
    <message>
        <source> sec</source>
        <comment>Seconds</comment>
        <translation>초</translation>
    </message>
    <message>
        <source>Clear clipboard after</source>
        <translation>다음 시간 이후 클립보드 비우기</translation>
    </message>
    <message>
        <source>Clear search query after</source>
        <translation>다음 시간 이후 검색어 비우기</translation>
    </message>
    <message>
        <source> min</source>
        <comment>Minutes</comment>
        <translation>분</translation>
    </message>
    <message>
        <source>Clipboard clear seconds</source>
        <translation>클립보드를 지울 시간</translation>
    </message>
    <message>
        <source>Lock databases after inactivity of</source>
        <translation>다음 시간 동안 활동이 없을 때 데이터베이스 잠금</translation>
    </message>
    <message>
        <source>Convenience</source>
        <translation>편의성</translation>
    </message>
    <message>
        <source>Enable database quick unlock (Touch ID / Windows Hello)</source>
        <translation>데이터베이스 빠른 잠금 해제 사용 (Touch ID/Windows Hello)</translation>
    </message>
    <message>
        <source>Lock databases when session is locked or lid is closed</source>
        <translation>세션이 잠겼을 때나 덮개를 닫았을 때 데이터베이스 잠금</translation>
    </message>
    <message>
        <source>Lock databases after minimizing the window</source>
        <translation>창을 최소화할 때 데이터베이스 잠금</translation>
    </message>
    <message>
        <source>Hide passwords when editing them</source>
        <translation>비밀번호를 편집할 때 숨기기</translation>
    </message>
    <message>
        <source>Use placeholder for empty password fields</source>
        <translation>빈 비밀번호 필드에 자리 비움자 사용</translation>
    </message>
    <message>
        <source>Hide passwords in the entry preview panel</source>
        <translation>항목 미리 보기 패널에서 비밀번호 숨기기</translation>
    </message>
    <message>
        <source>Privacy</source>
        <translation>개인 정보</translation>
    </message>
    <message>
        <source>Use DuckDuckGo service to download website icons</source>
        <translation>웹 사이트 아이콘을 다운로드할 때 DuckDuckGo 서비스 사용</translation>
    </message>
    <message>
        <source>Hide TOTP in the entry preview panel</source>
        <translation>항목 미리 보기 패널에서 TOTP 숨기기</translation>
    </message>
    <message>
        <source>Lock databases when switching user</source>
        <translation>사용자를 전환할 때 데이터베이스 잠금</translation>
    </message>
    <message>
        <source>Lock Options</source>
        <translation>잠금 옵션</translation>
    </message>
    <message>
        <source>Hide notes in the entry preview panel</source>
        <translation>항목 미리보기 패널에서 메모 숨기기</translation>
    </message>
</context>
<context>
    <name>AttachmentWidget</name>
    <message>
        <source>Attachment Viewer</source>
        <translation>첨부 파일 뷰어</translation>
    </message>
    <message>
        <source>Unknown attachment type</source>
        <translation>알 수 없는 첨부 파일 유형</translation>
    </message>
</context>
<context>
    <name>AutoType</name>
    <message>
        <source>The requested Auto-Type sequence cannot be used due to an error:</source>
        <translation>오류가 발생하여 지정한 자동 입력 시퀀스를 사용할 수 없습니다.</translation>
    </message>
    <message>
        <source>Auto-Type Error</source>
        <translation>자동 입력 오류</translation>
    </message>
    <message>
        <source>Permission Required</source>
        <translation>권한이 필요함</translation>
    </message>
    <message>
        <source>KeePassXC requires the Accessibility permission in order to perform entry level Auto-Type. If you already granted permission, you may have to restart KeePassXC.</source>
        <translation>항목별 자동 입력을 사용하려면 KeePassXC에 접근성 권한을 허용해야 합니다. 권한을 이미 허용했다면 KeePassXC를 다시 시작해 보십시오.</translation>
    </message>
    <message>
        <source>KeePassXC requires the Accessibility and Screen Recorder permission in order to perform global Auto-Type. Screen Recording is necessary to use the window title to find entries. If you already granted permission, you may have to restart KeePassXC.</source>
        <translation>항목별 자동 입력을 사용하려면 KeePassXC에 접근성 및 화면 녹화 권한을 허용해야 합니다. 화면 녹화 권한은 창 제목과 항목을 찾기 위해서 필요합니다. 권한을 이미 허용했다면 KeePassXC를 다시 시작해 보십시오.</translation>
    </message>
    <message>
        <source>Invalid entry provided</source>
        <translation>잘못된 항목 지정됨</translation>
    </message>
    <message>
        <source>Bracket imbalance detected, found extra { or }</source>
        <translation>괄호 쌍이 맞지 않음, 추가 { 또는 } 문자가 있음</translation>
    </message>
    <message>
        <source>Too many repetitions detected, max is %1: %2</source>
        <translation>너무 많은 반복이 감지됨, 최대 %1회: %2</translation>
    </message>
    <message>
        <source>Very slow key press detected, max is %1: %2</source>
        <translation>매우 느린 키 입력이 감지됨, 최대 %1: %2</translation>
    </message>
    <message>
        <source>Very long delay detected, max is %1: %2</source>
        <translation>매우 긴 지연 시간이 감지됨, 최대 %1: %2</translation>
    </message>
    <message>
        <source>Entry does not have attribute for PICKCHARS: %1</source>
        <translation>항목에 PICKCHARS 속성이 없음: %1</translation>
    </message>
    <message>
        <source>Invalid placeholder: %1</source>
        <translation>잘못된 자리 비움자: %1</translation>
    </message>
    <message>
        <source>Entry has invalid TOTP settings</source>
        <translation>항목에 잘못된 TOTP 설정이 있습니다</translation>
    </message>
</context>
<context>
    <name>AutoTypeAssociationsModel</name>
    <message>
        <source>Window</source>
        <translation>창</translation>
    </message>
    <message>
        <source>Sequence</source>
        <translation>순서</translation>
    </message>
    <message>
        <source>(empty)</source>
        <translation>(비어 있음)</translation>
    </message>
    <message>
        <source>Default sequence</source>
        <translation>기본 순서</translation>
    </message>
</context>
<context>
    <name>AutoTypeMatchModel</name>
    <message>
        <source>Group</source>
        <translation>그룹</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>제목</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>사용자 이름</translation>
    </message>
    <message>
        <source>Sequence</source>
        <translation>순서</translation>
    </message>
</context>
<context>
    <name>AutoTypePlatformWayland</name>
    <message>
        <source>No symbol found for key: &apos;%1&apos;</source>
        <translation>키에 대한 기호를 찾을 수 없습니다: &apos;%1&apos;</translation>
    </message>
    <message>
        <source>No symbol found for character: &apos;%1&apos;</source>
        <translation>문자에 대한 기호를 찾을 수 없습니다: &apos;%1&apos;</translation>
    </message>
</context>
<context>
    <name>AutoTypePlatformX11</name>
    <message>
        <source>Sequence aborted: Caps Lock is on</source>
        <translation>입력 순서 중단됨: Caps Lock이 켜져 있음</translation>
    </message>
    <message>
        <source>Sequence aborted: Modifier keys held by user</source>
        <translation>입력 순서 중단됨: 사용자가 수정자 키를 누름</translation>
    </message>
    <message>
        <source>Unable to get valid keycode for key: </source>
        <translation>키에 대한 올바른 키 코드를 가져올 수 없음:</translation>
    </message>
    <message>
        <source>Trying to send invalid keyboard symbol.</source>
        <translation>잘못된 키보드 기호를 보내려고 시도하고 있습니다.</translation>
    </message>
</context>
<context>
    <name>AutoTypeSelectDialog</name>
    <message>
        <source>Auto-Type - KeePassXC</source>
        <translation>자동 입력 - KeePassXC</translation>
    </message>
    <message>
        <source>Double click a row to perform Auto-Type or find an entry using the search:</source>
        <translation>자동 입력을 실행할 항목이 있는 열을 두 번 클릭하거나 검색으로 항목 찾기:</translation>
    </message>
    <message>
        <source>Search all open databases</source>
        <translation>모든 열린 데이터베이스 검색</translation>
    </message>
    <message>
        <source>Search…</source>
        <translation>검색...</translation>
    </message>
    <message>
        <source>Type Sequence</source>
        <translation>입력 시퀀스</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>취소</translation>
    </message>
    <message>
        <source>Type {USERNAME}</source>
        <translation>{USERNAME} 입력</translation>
    </message>
    <message>
        <source>Type {PASSWORD}</source>
        <translation>{PASSWORD} 입력</translation>
    </message>
    <message>
        <source>Type {TOTP}</source>
        <translation>{TOTP} 입력</translation>
    </message>
    <message>
        <source>Copy Username</source>
        <translation>사용자 이름 복사</translation>
    </message>
    <message>
        <source>Copy Password</source>
        <translation>비밀번호 복사</translation>
    </message>
    <message>
        <source>Copy TOTP</source>
        <translation>TOTP 복사</translation>
    </message>
    <message>
        <source>Use Virtual Keyboard</source>
        <translation>가상 키보드 사용</translation>
    </message>
    <message>
        <source>Type {URL}</source>
        <translation>{URL} 입력</translation>
    </message>
    <message>
        <source>Copy URL</source>
        <translation>URL 복사</translation>
    </message>
    <message>
        <source>&lt;p&gt;The following shortcuts are available:&lt;br/&gt;
Ctrl+F - Focus search&lt;br/&gt;
Ctrl+1 - Type username&lt;br/&gt;
Ctrl+2 - Type password&lt;br/&gt;
Ctrl+3 - Type TOTP&lt;br/&gt;
Ctrl+4 - Type URL&lt;br/&gt;
Ctrl+5 - Use Virtual Keyboard (Windows Only)&lt;br/&gt;
Ctrl+Shift+1 - Copy username&lt;br/&gt;
Ctrl+Shift+2 - Copy password&lt;br/&gt;
Ctrl+Shift+3 - Copy TOTP&lt;br/&gt;
Ctrl+Shift+4 - Copy URL&lt;br/&gt;
&lt;/p&gt;</source>
        <translation>&lt;p&gt;다음 단축키를 사용할 수 있습니다:&lt;br/&gt;
Ctrl+F - 집중 검색&lt;br/&gt;
Ctrl+1 - 사용자 이름 입력&lt;br/&gt;
Ctrl+2 - 비밀번호 입력&lt;br/&gt;
Ctrl+3 - TOPT 유형&lt;br/&gt;
Ctrl+4 - URL 입력&lt;br/&gt;
Ctrl+5 - 가상 키보드 사용 (Windows용)&lt;br/&gt;
Ctrl+Shift+1 - 사용자 이름 복사&lt;br/&gt;
Ctrl+Shift+2 - 비밀번호 복사&lt;br/&gt;
Ctrl+Shift+3 - TOTP 복사&lt;br/&gt;
Ctrl+Shift+4 - URL 복사&lt;br/&gt;
&lt;/p&gt;</translation>
    </message>
    <message>
        <source>You can use advanced search queries to find any entry in your open databases.</source>
        <translation>고급 검색 쿼리를 사용하여 열린 데이터베이스에서 항목을 찾을 수 있습니다.</translation>
    </message>
</context>
<context>
    <name>BinaryStream</name>
    <message>
        <source>Failed to read string data: %1</source>
        <translation>문자열 데이터를 읽지 못했습니다: %1</translation>
    </message>
    <message>
        <source>String length exceeds 10 MiB limit (requested %1)</source>
        <translation>문자열 길이가 10 MiB 제한을 초과합니다 (요청된 %1)</translation>
    </message>
</context>
<context>
    <name>BrowserAccessControlDialog</name>
    <message>
        <source>KeePassXC - Browser Access Request</source>
        <translation>KeePassXC - 브라우저 접근 확인</translation>
    </message>
    <message>
        <source>%1 is requesting access to the following entries:</source>
        <translation>%1에서 다음 항목에 접근하려고 합니다:</translation>
    </message>
    <message>
        <source>Remember access to checked entries</source>
        <translation>선택한 항목 접근 여부 기억</translation>
    </message>
    <message>
        <source>Remember</source>
        <translation>기억</translation>
    </message>
    <message>
        <source>Allow access to entries</source>
        <translation>항목 접근 허용</translation>
    </message>
    <message>
        <source>Allow Selected</source>
        <translation>선택 허용</translation>
    </message>
    <message>
        <source>Deny All</source>
        <translation>모두 거부</translation>
    </message>
    <message>
        <source>Disable for this site</source>
        <translation>이 사이트에서는 거부</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation>실행 취소</translation>
    </message>
</context>
<context>
    <name>BrowserEntrySaveDialog</name>
    <message>
        <source>Ok</source>
        <translation>확인</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>취소</translation>
    </message>
    <message>
        <source>You have multiple databases open.
Please select the correct database for saving credentials.</source>
        <translation>여러 데이터베이스가 열려 있습니다.
자격 증명을 저장할 올바른 데이터베이스를 선택해 주세요.</translation>
    </message>
    <message>
        <source>KeePassXC - Select Database</source>
        <translation>KeePassXC - 데이터베이스 선택</translation>
    </message>
</context>
<context>
    <name>BrowserPasskeysConfirmationDialog</name>
    <message>
        <source>Cancel</source>
        <translation>취소</translation>
    </message>
    <message>
        <source>Update</source>
        <translation>업데이트</translation>
    </message>
    <message>
        <source>Authenticate</source>
        <translation>인증</translation>
    </message>
    <message>
        <source>Register new</source>
        <translation>새로 등록</translation>
    </message>
    <message>
        <source>Register</source>
        <translation>등록</translation>
    </message>
    <message numerus="yes">
        <source>Timeout in &lt;b&gt;%n&lt;/b&gt; seconds...</source>
        <translation><numerusform>&lt;b&gt;%n&lt;/b&gt;초 후 시간 초과됨...</numerusform></translation>
    </message>
    <message>
        <source>Relying Party: %1</source>
        <translation>의존 당사자: %1</translation>
    </message>
    <message>
        <source>Username: %1</source>
        <translation>사용자 이름: %1</translation>
    </message>
    <message>
        <source>KeePassXC - Passkey credentials</source>
        <translation>KeePassXC - 패스키 자격 증명</translation>
    </message>
    <message>
        <source>Add to existing entry</source>
        <translation>기존 항목에 추가</translation>
    </message>
    <message>
        <source>Existing passkey found.
Do you want to register a new passkey for:</source>
        <translation>기존 패스키를 찾았습니다.
다음에 대한 새 패스키를 등록하시겠습니까?:</translation>
    </message>
    <message>
        <source>Select the existing passkey and press Update to replace it.</source>
        <translation>기존 패스키를 선택한 후 업데이트를 누르면 대체합니다.</translation>
    </message>
    <message>
        <source>Authenticate passkey credentials for:</source>
        <translation>다음에 대하여 패스키 자격 증명 인증:</translation>
    </message>
    <message>
        <source>Do you want to register a passkey for:</source>
        <translation>다음에 대한 패스키를 등록하시겠습니까?:</translation>
    </message>
</context>
<context>
    <name>BrowserService</name>
    <message>
        <source>A request for creating a new group &quot;%1&quot; has been received.
Do you want to create this group?
</source>
        <translation>새 그룹 &quot;%1&quot;을(를) 생성하는 요청을 받았습니다.
이 그룹을 생성하시겠습니까?
</translation>
    </message>
    <message>
        <source>You have received an association request for the following database:
%1

Give the connection a unique name or ID, for example:
chrome-laptop.</source>
        <translation>다음 데이터베이스 연결 요청을 받았습니다:
%1

데이터베이스 연결을 식별할 수 있는 이름이나 ID를 입력하십시오. 예:
chrome-laptop.</translation>
    </message>
    <message>
        <source>Save and allow access</source>
        <translation>저장하고 접근 허용</translation>
    </message>
    <message>
        <source>A shared encryption key with the name &quot;%1&quot; already exists.
Do you want to overwrite it?</source>
        <translation>이름이 &quot;%1&quot;인 공유 암호화 키가 이미 있습니다.
덮어쓰시겠습니까?</translation>
    </message>
    <message>
        <source>Do you want to update the information in %1 - %2?</source>
        <translation>%1 - %2의 정보를 업데이트하시겠습니까?</translation>
    </message>
    <message>
        <source>A request for deleting entry &quot;%1&quot; has been received.
Do you want to delete the entry?
</source>
        <translation>항목 &quot;%1&quot;을(를) 삭제하는 요청을 받았습니다.
이 항목을 삭제하시겠습니까?
</translation>
    </message>
    <message>
        <source>%1 (Passkey)</source>
        <translation>%1(패스키)</translation>
    </message>
    <message>
        <source>KeePassXC - Create a new group</source>
        <translation>KeePassXC - 새 그룹 만들기</translation>
    </message>
    <message>
        <source>Disable</source>
        <translation>비활성화</translation>
    </message>
    <message>
        <source>KeePassXC - Overwrite existing key?</source>
        <translation>KeePassXC - 기존 키 덮어쓰기?</translation>
    </message>
    <message>
        <source>KeePassXC - Update Entry</source>
        <translation>KeePassXC - 항목 업데이트</translation>
    </message>
    <message>
        <source>KeePassXC - Delete entry</source>
        <translation>KeePassXC - 항목 삭제</translation>
    </message>
    <message>
        <source>KeePassXC - New key association request</source>
        <translation>KeePassXC - 새 키 연결 요청</translation>
    </message>
    <message>
        <source>Passkey</source>
        <translation>패스키</translation>
    </message>
    <message>
        <source>KeePassXC - Passkey credentials</source>
        <translation>KeePassXC - 패스키 자격 증명</translation>
    </message>
    <message>
        <source>Register a new passkey to this entry:</source>
        <translation>이 항목에 새 패스키 등록:</translation>
    </message>
    <message>
        <source>KeePassXC - Update passkey</source>
        <translation>KeePassXC - 패스키 업데이트</translation>
    </message>
    <message>
        <source>Entry already has a passkey.
Do you want to overwrite the passkey in %1 - %2?</source>
        <translation>항목에 이미 패스키가 있습니다.
%1 - %2에 패스키를 덮어쓰시겠습니까?</translation>
    </message>
    <message>
        <source>Register</source>
        <translation>등록</translation>
    </message>
</context>
<context>
    <name>BrowserSettingsWidget</name>
    <message>
        <source>Dialog</source>
        <translation>대화 상자</translation>
    </message>
    <message>
        <source>This is required for accessing your databases with KeePassXC-Browser</source>
        <translation>KeePassXC-브라우저에서 데이터베이스에 접근하려면 필요합니다</translation>
    </message>
    <message>
        <source>Enable browser integration</source>
        <translation>브라우저 통합 활성화</translation>
    </message>
    <message>
        <source>General</source>
        <translation>일반</translation>
    </message>
    <message>
        <source>Enable integration for these browsers:</source>
        <translation>다음 브라우저에 통합:</translation>
    </message>
    <message>
        <source>Vivaldi</source>
        <translation>Vivaldi</translation>
    </message>
    <message>
        <source>&amp;Edge</source>
        <translation>Edge(&amp;E)</translation>
    </message>
    <message>
        <source>Firefox</source>
        <translation>Firefox</translation>
    </message>
    <message>
        <source>Tor Browser</source>
        <translation>Tor 브라우저</translation>
    </message>
    <message>
        <source>Brave</source>
        <translation>Brave</translation>
    </message>
    <message>
        <source>Google Chrome</source>
        <translation>Google Chrome</translation>
    </message>
    <message>
        <source>Chromium</source>
        <translation>Chromium</translation>
    </message>
    <message>
        <source>Show a notification when credentials are requested</source>
        <extracomment>Credentials mean login data requested via browser extension</extracomment>
        <translation>자격 증명이 요청될 때 알림 표시</translation>
    </message>
    <message>
        <source>Request to unlock the database if it is locked</source>
        <translation>데이터베이스가 잠겼을 때 잠금 해제 요청</translation>
    </message>
    <message>
        <source>Only entries with the same scheme (http://, https://, …) are returned.</source>
        <translation>같은 체계(http://, https://)를 사용하는 항목만 반환합니다.</translation>
    </message>
    <message>
        <source>Match URL scheme (e.g., https://example.com)</source>
        <translation>URL 체계 일치 (예: https://example.com)</translation>
    </message>
    <message>
        <source>Only returns the best matches for a specific URL instead of all entries for the whole domain.</source>
        <translation>도메인이 일치하는 모든 항목 대신 지정한 URL과 일치하는 항목만 반환합니다.</translation>
    </message>
    <message>
        <source>Return only best-matching credentials</source>
        <translation>가장 잘 일치하는 자격 증명 항목만 반환</translation>
    </message>
    <message>
        <source>Returns expired credentials. String [expired] is added to the title.</source>
        <translation>만료된 자격 증명도 반환합니다. 제목에 [만료됨] 문자열이 추가됩니다.</translation>
    </message>
    <message>
        <source>Allow returning expired credentials</source>
        <translation>만료된 자격 증명 반환 허용</translation>
    </message>
    <message>
        <source>All databases connected to the extension will return matching credentials.</source>
        <translation>확장 기능에 연결된 모든 데이터베이스에서 일치하는 자격 증명을 반환합니다.</translation>
    </message>
    <message>
        <source>Search in all opened databases for matching credentials</source>
        <extracomment>Credentials mean login data requested via browser extension</extracomment>
        <translation>모든 열린 데이터베이스에서 저장된 자격 증명 검색</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>고급</translation>
    </message>
    <message>
        <source>Never ask before accessing credentials</source>
        <extracomment>Credentials mean login data requested via browser extension</extracomment>
        <translation>저장된 자격 증명에 접근하기 전에 묻지 않기</translation>
    </message>
    <message>
        <source>Never ask before updating credentials</source>
        <extracomment>Credentials mean login data requested via browser extension</extracomment>
        <translation>저장된 자격 증명을 업데이트하기 전에 묻지 않기</translation>
    </message>
    <message>
        <source>Do not ask permission for HTTP Basic Auth</source>
        <extracomment>An extra HTTP Basic Auth setting</extracomment>
        <translation>HTTP Basic 인증 권한 묻지 않기</translation>
    </message>
    <message>
        <source>Automatically creating or updating string fields is not supported.</source>
        <translation>문자열 필드를 자동으로 만들거나 업데이트하는 것은 지원되지 않습니다.</translation>
    </message>
    <message>
        <source>Return advanced string fields which start with &quot;KPH: &quot;</source>
        <translation>&quot;KPH: &quot;로 시작하는 고급 문자열 필드 반환</translation>
    </message>
    <message>
        <source>Don&apos;t display the popup suggesting migration of legacy KeePassHTTP settings.</source>
        <translation>레거시 KeePassHTTP 설정을 이전하는 대화 상자를 표시하지 않습니다.</translation>
    </message>
    <message>
        <source>Do not prompt for KeePassHTTP settings migration.</source>
        <translation>KeePassHTTP 설정 이전 묻지 않기</translation>
    </message>
    <message>
        <source>Updates KeePassXC or keepassxc-proxy binary path automatically to native messaging scripts on startup.</source>
        <translation>네이티브 메시징 스크립트에서 사용하는 KeePassXC 및 keepassxc-proxy 실행 파일 경로를 시작할 때 자동으로 업데이트합니다.</translation>
    </message>
    <message>
        <source>Update native messaging manifest files at startup</source>
        <translation>시작할 때 네이티브 메시징 선언 파일 업데이트</translation>
    </message>
    <message>
        <source>Use a custom proxy location if you installed a proxy manually.</source>
        <translation>프록시를 수동으로 설치한 경우 사용자 지정 프록시 위치를 사용합니다.</translation>
    </message>
    <message>
        <source>Use a custom proxy location:</source>
        <comment>Meant is the proxy for KeePassXC-Browser</comment>
        <translation>사용자 지정 프록시 위치 사용:</translation>
    </message>
    <message>
        <source>Custom proxy location field</source>
        <translation>사용자 지정 프록시 위치 필드</translation>
    </message>
    <message>
        <source>Browser for custom proxy file</source>
        <translation>사용자 지정 프록시 파일 찾아보기</translation>
    </message>
    <message>
        <source>Browse…</source>
        <extracomment>Button for opening file dialog</extracomment>
        <translation>찾아보기...</translation>
    </message>
    <message>
        <source>Use a custom browser configuration location:</source>
        <translation>사용자 지정 브라우저 설정 위치 사용:</translation>
    </message>
    <message>
        <source>Browser type:</source>
        <translation>브라우저 종류:</translation>
    </message>
    <message>
        <source>Toolbar button style</source>
        <translation>도구 모음 단추 스타일</translation>
    </message>
    <message>
        <source>Config Location:</source>
        <translation>설정 위치:</translation>
    </message>
    <message>
        <source>Custom browser location field</source>
        <translation>사용자 지정 브라우저 위치 필드</translation>
    </message>
    <message>
        <source>Browse for custom browser path</source>
        <translation>사용자 지정 브라우저 경로 찾아보기</translation>
    </message>
    <message>
        <source>Custom extension ID:</source>
        <translation>사용자 지정 확장 기능 ID:</translation>
    </message>
    <message>
        <source>Custom extension ID</source>
        <translation>사용자 지정 확장 기능 ID</translation>
    </message>
    <message>
        <source>Executable Files</source>
        <translation>실행 파일</translation>
    </message>
    <message>
        <source>All Files</source>
        <translation>모든 파일</translation>
    </message>
    <message>
        <source>Select custom proxy location</source>
        <translation>사용자 지정 프록시 위치 지정</translation>
    </message>
    <message>
        <source>Select native messaging host folder location</source>
        <translation>네이티브 메시징 호스트 폴더 위치 선택</translation>
    </message>
    <message>
        <source>Allow keepassxc-proxy to list all entries with their title, URL and UUID in connected databases.</source>
        <translation>keepassxc-proxy가 연결된 데이터베이스 내 모든 항목의 제목, URL, UUID를 표시하도록 허용합니다.</translation>
    </message>
    <message>
        <source>Allow limited access to all entries in connected databases (ignores site access restrictions)</source>
        <translation>연결된 데이터베이스 내 모든 항목에 제한된 접근을 허용합니다(사이트 접근 제한 무시)</translation>
    </message>
    <message>
        <source>&lt;b&gt;Warning:&lt;/b&gt; Only adjust these settings if necessary.</source>
        <translation>&lt;b&gt;경고:&lt;/b&gt; 필요한 경우에만 설정을 변경하십시오.</translation>
    </message>
    <message>
        <source>The custom proxy location does not exist.</source>
        <translation>사용자 정의 프록시 위치가 존재하지 않습니다.</translation>
    </message>
    <message>
        <source>&lt;b&gt;Error:&lt;/b&gt; The custom proxy location does not exist. Correct this in the advanced settings tab.</source>
        <translation>&lt;b&gt;오류:&lt;/b&gt; 사용자 정의 프록시 위치가 존재하지 않습니다. 고급 설정 탭에서 수정하십시오.</translation>
    </message>
    <message>
        <source>&lt;b&gt;Error:&lt;/b&gt; The installed proxy executable is missing from the expected location: %1&lt;br/&gt;Please set a custom proxy location in the advanced settings or reinstall the application.</source>
        <translation>&lt;b&gt;오류:&lt;/b&gt; 설치된 실행 파일이 예상된 위치 %1에 없습니다.&lt;br/&gt;고급 설정에서 사용자 정의 프록시 위치를 설정하거나 프로그램을 다시 설치하십시오.</translation>
    </message>
    <message>
        <source>Allows using insecure http://localhost with passkeys for testing purposes.</source>
        <translation>시험 목적으로 보안상 안전하지 않은 http://localhost에 패스키 사용을 허용합니다.</translation>
    </message>
    <message>
        <source>Allow using localhost with passkeys</source>
        <translation>localhost에 패스키 사용 허용</translation>
    </message>
    <message>
        <source>KeePassXC-Browser is needed for the browser integration to work. &lt;br /&gt;Download it for %1 and %2 and %3.</source>
        <translation>브라우저 통합을 사용하려면 KeePassXC-브라우저가 필요합니다.&lt;br /&gt;%1, %2, %3용으로 다운로드할 수 있습니다.</translation>
    </message>
    <message>
        <source>Browsers installed using Snap or Flatpak are not supported with exception to Firefox installed using Snap.</source>
        <translation>Snap 또는 Flatpak을 사용하여 설치된 브라우저는 Snap을 사용하여 설치된 Firefox를 제외하고는 지원되지 않습니다.</translation>
    </message>
</context>
<context>
    <name>CloneDialog</name>
    <message>
        <source>Clone Entry Options</source>
        <translation>항목 복제 옵션</translation>
    </message>
    <message>
        <source>Append &apos; - Clone&apos; to title</source>
        <translation>제목에 &apos; - 사본&apos; 추가</translation>
    </message>
    <message>
        <source>Replace username and password with references</source>
        <translation>사용자 이름과 비밀번호를 참조로 대체</translation>
    </message>
    <message>
        <source>Copy history</source>
        <translation>과거 기록 복사</translation>
    </message>
</context>
<context>
    <name>CsvImportWidget</name>
    <message>
        <source>size, rows, columns</source>
        <translation>크기, 행, 열</translation>
    </message>
    <message>
        <source>Column Association</source>
        <translation>열 연결</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>비밀번호</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>사용자 이름</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>제목</translation>
    </message>
    <message>
        <source>Group</source>
        <translation>그룹</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>Notes</source>
        <translation>메모</translation>
    </message>
    <message>
        <source>TOTP</source>
        <translation>TOTP</translation>
    </message>
    <message>
        <source>Created</source>
        <translation>생성</translation>
    </message>
    <message>
        <source>Last Modified</source>
        <translation>마지막 수정</translation>
    </message>
    <message>
        <source>Icon</source>
        <translation>아이콘</translation>
    </message>
    <message>
        <source>Encoding</source>
        <translation>인코딩</translation>
    </message>
    <message>
        <source>Codec</source>
        <translation>인코딩</translation>
    </message>
    <message>
        <source>Text is qualified by</source>
        <translation>문자열 구분자</translation>
    </message>
    <message>
        <source>Text qualification</source>
        <translation>문자열 구분</translation>
    </message>
    <message>
        <source>Fields are separated by</source>
        <translation>필드 구분자</translation>
    </message>
    <message>
        <source>Field separation</source>
        <translation>필드 구분</translation>
    </message>
    <message>
        <source>Comments start with</source>
        <translation>주석 시작 글자</translation>
    </message>
    <message>
        <source>Header lines skipped</source>
        <translation>머리글 줄 건너뜀</translation>
    </message>
    <message>
        <source>Number of header lines to discard</source>
        <translation>무시할 머리글 줄 수</translation>
    </message>
    <message>
        <source>First line has field names</source>
        <translation>첫 줄에 필드 이름이 있음</translation>
    </message>
    <message>
        <source>Consider &apos;\&apos; an escape character</source>
        <translation>&apos;\&apos; 글자를 탈출 문자로 간주</translation>
    </message>
    <message>
        <source>Preview</source>
        <translation>미리 보기</translation>
    </message>
    <message>
        <source>CSV import preview</source>
        <translation>CSV 가져오기 미리 보기</translation>
    </message>
    <message>
        <source>Not Present</source>
        <translation>없음</translation>
    </message>
    <message>
        <source>Column %1</source>
        <translation>열 %1</translation>
    </message>
    <message numerus="yes">
        <source>[%n more message(s) skipped]</source>
        <translation><numerusform>[%n개의 메시지가 건너뛰어졌습니다]</numerusform></translation>
    </message>
    <message>
        <source>Failed to parse CSV file: %1</source>
        <translation>CSV 파일을 해석할 수 없음: %1</translation>
    </message>
    <message>
        <source>Imported from CSV file: %1</source>
        <translation>CSV 파일에서 가져옴: %1</translation>
    </message>
    <message>
        <source>No Title Selected</source>
        <translation>선택한 제목 없음</translation>
    </message>
    <message>
        <source>No title column was selected, entries will be hard to tell apart.
Are you sure you want to import?</source>
        <translation>제목 열을 선택하지 않았습니다. 개별 항목을 구분하기 어려울 수 있습니다.
계속 가져오시겠습니까?</translation>
    </message>
    <message>
        <source>Tags</source>
        <translation>태그</translation>
    </message>
</context>
<context>
    <name>CsvParserModel</name>
    <message numerus="yes">
        <source>%n row(s)</source>
        <comment>CSV row count</comment>
        <translation><numerusform>%n행</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>%n column(s)</source>
        <comment>CSV column count</comment>
        <translation><numerusform>%n열</numerusform></translation>
    </message>
</context>
<context>
    <name>Database</name>
    <message>
        <source>Passwords</source>
        <comment>Root group name</comment>
        <translation>비밀번호</translation>
    </message>
    <message>
        <source>File %1 does not exist.</source>
        <translation>파일 %1이(가) 존재하지 않습니다.</translation>
    </message>
    <message>
        <source>Unable to open file %1.</source>
        <translation>파일 %1을(를) 열 수 없습니다.</translation>
    </message>
    <message>
        <source>Error while reading the database: %1</source>
        <translation>데이터베이스 읽기 오류: %1</translation>
    </message>
    <message>
        <source>Could not save, database does not point to a valid file.</source>
        <translation>데이터베이스가 올바른 파일을 가리키지 않아서 저장할 수 없습니다.</translation>
    </message>
    <message>
        <source>Database save is already in progress.</source>
        <translation>데이터베이스 저장이 진행 중입니다.</translation>
    </message>
    <message>
        <source>Could not save, database has not been initialized!</source>
        <translation>데이터베이스 파일이 초기화되지 않아서 저장할 수 없습니다!</translation>
    </message>
    <message>
        <source>Database file has unmerged changes.</source>
        <translation>데이터베이스 파일에 병합되지 않은 변경 사항이 있습니다.</translation>
    </message>
    <message>
        <source>%1
Backup database located at %2</source>
        <translation>%1
백업 데이터베이스 위치: %2</translation>
    </message>
    <message>
        <source>Key not transformed. This is a bug, please report it to the developers.</source>
        <translation>키가 변형되지 않았습니다. 버그이므로 개발자에게 보고해 주십시오.</translation>
    </message>
    <message>
        <source>Recycle Bin</source>
        <translation>휴지통</translation>
    </message>
    <message>
        <source>Database file read error.</source>
        <translation>데이터베이스 파일 읽기 오류입니다.</translation>
    </message>
    <message>
        <source>No file path was provided.</source>
        <translation>파일 경로가 제공되지 않았습니다.</translation>
    </message>
</context>
<context>
    <name>DatabaseOpenDialog</name>
    <message>
        <source>Unlock Database - KeePassXC</source>
        <translation>데이터베이스 잠금 해제 - KeePassXC</translation>
    </message>
</context>
<context>
    <name>DatabaseOpenWidget</name>
    <message>
        <source>Unlock KeePassXC Database</source>
        <translation>KeePassXC 데이터베이스 잠금 해제</translation>
    </message>
    <message>
        <source>Enter Password:</source>
        <translation>비밀번호 입력:</translation>
    </message>
    <message>
        <source>Password field</source>
        <translation>비밀번호 필드</translation>
    </message>
    <message>
        <source>Hardware key slot selection</source>
        <translation>하드웨어 키 슬롯 선택</translation>
    </message>
    <message>
        <source>Key file to unlock the database</source>
        <translation>데이터베이스 잠금 해제 키 파일</translation>
    </message>
    <message>
        <source>Browse for key file</source>
        <translation>키 파일 찾아보기</translation>
    </message>
    <message>
        <source>Browse…</source>
        <translation>찾아보기...</translation>
    </message>
    <message>
        <source>Unlock Database</source>
        <translation>데이터베이스 잠금 해제</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>취소</translation>
    </message>
    <message>
        <source>Unlock</source>
        <translation>잠금 해제</translation>
    </message>
    <message>
        <source>Please present or touch your YubiKey to continue…</source>
        <translation>계속 진행하려면 YubiKey를 연결하거나 버튼을 누르십시오...</translation>
    </message>
    <message>
        <source>Database Version Mismatch</source>
        <translation>데이터베이스 버전 불일치</translation>
    </message>
    <message>
        <source>The database you are trying to open was most likely
created by a newer version of KeePassXC.

You can try to open it anyway, but it may be incomplete
and saving any changes may incur data loss.

We recommend you update your KeePassXC installation.</source>
        <translation>열려고 하는 데이터베이스가 새로운 KeePassXC
버전에서 생성되었을 수도 있습니다.

그래도 이 데이터베이스를 열 수 있지만, 데이터가
불완전할 수 있으며 다시 저장했을 때 손실될 수 있습니다.

KeePassXC 설치본을 업데이트하기를 추천합니다.</translation>
    </message>
    <message>
        <source>Open database anyway</source>
        <translation>그래도 데이터베이스 열기</translation>
    </message>
    <message>
        <source>Database unlock canceled.</source>
        <translation>데이터베이스 잠금 해제가 취소되었습니다.</translation>
    </message>
    <message>
        <source>Unlock failed and no password given</source>
        <translation>잠금 해제 실패, 지정한 비밀번호 없음</translation>
    </message>
    <message>
        <source>Unlocking the database failed and you did not enter a password.
Do you want to retry with an &quot;empty&quot; password instead?

To prevent this error from appearing, you must go to &quot;Database Settings / Security&quot; and reset your password.</source>
        <translation>데이터베이스 잠금 해제가 실패했고 비밀번호를 입력하지 않았습니다.
&quot;빈&quot; 비밀번호로 다시 시도하시겠습니까?

이 오류가 표시되지 않도록 하려면 &quot;데이터베이스 설정/보안&quot;에서 비밀번호를 초기화해야 합니다.</translation>
    </message>
    <message>
        <source>Retry with empty password</source>
        <translation>빈 비밀번호로 다시 시도</translation>
    </message>
    <message>
        <source>Failed to open key file: %1</source>
        <translation>키 파일을 열 수 없음: %1</translation>
    </message>
    <message>
        <source>Old key file format</source>
        <translation>이전 키 파일 형식</translation>
    </message>
    <message>
        <source>You are using an old key file format which KeePassXC may&lt;br&gt;stop supporting in the future.&lt;br&gt;&lt;br&gt;Please consider generating a new key file by going to:&lt;br&gt;&lt;strong&gt;Database &amp;gt; Database Security &amp;gt; Change Key File.&lt;/strong&gt;&lt;br&gt;</source>
        <translation>KeePassXC에서 차후에 지원을 중단할 수도 있는&lt;br&gt;이전 키 파일 형식을 사용하고 있습니다.&lt;br&gt;&lt;br&gt;다음 메뉴 항목을 사용하여 새 키 파일을 생성하기를 추천합니다:&lt;br&gt;&lt;strong&gt;데이터베이스 &amp;gt; 데이터베이스 보안 &amp;gt; 키 파일 변경&lt;/strong&gt;&lt;br&gt;</translation>
    </message>
    <message>
        <source>Don&apos;t show this warning again</source>
        <translation>더 이상 이 경고 표시하지 않기</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>모든 파일</translation>
    </message>
    <message>
        <source>Key files</source>
        <translation>키 파일</translation>
    </message>
    <message>
        <source>Select key file</source>
        <translation>키 파일 선택</translation>
    </message>
    <message>
        <source>Cannot use database file as key file</source>
        <translation>데이터베이스 파일은 키 파일로 사용할 수 없습니다.</translation>
    </message>
    <message>
        <source>authenticate to access the database</source>
        <translation>데이터베이스에 접근하려면 인증하십시오</translation>
    </message>
    <message>
        <source>Failed to authenticate with Quick Unlock: %1</source>
        <translation>빠른 잠금 해제로 인증할 수 없음: %1</translation>
    </message>
    <message>
        <source>Select Key File:</source>
        <translation>키 파일 선택:</translation>
    </message>
    <message>
        <source>&lt;p&gt;In addition to a password, you can use a secret file to enhance the security of your database. This file can be generated in your database&apos;s security settings.&lt;/p&gt;&lt;p&gt;This is &lt;strong&gt;not&lt;/strong&gt; your *.kdbx database file!&lt;/p&gt;</source>
        <translation>&lt;p&gt;데이터베이스 파일의 보안을 개선할 수 있도록 비밀번호 외에도 비밀 파일을 사용할 수 있습니다. 해당 파일은 데이터베이스 보안 설정에서 생성할 수 있습니다.&lt;/p&gt;&lt;p&gt;이 파일은 *.kdbx 데이터베이스 파일이 &lt;strong&gt;아닙니다&lt;/strong&gt;!&lt;/p&gt;</translation>
    </message>
    <message>
        <source>Use hardware key [Serial: %1]</source>
        <translation>하드웨어 키 사용 [일련 번호: %1]</translation>
    </message>
    <message>
        <source>Use hardware key</source>
        <translation>하드웨어 키 사용</translation>
    </message>
    <message>
        <source>Your database file is NOT a key file!
If you don&apos;t have a key file or don&apos;t know what that is, you don&apos;t have to select one.</source>
        <translation>데이터베이스 파일은 키 파일이 아닙니다!
키 파일이 없거나 키 파일이 무엇인지 모르겠다면 선택하지 마십시오.</translation>
    </message>
    <message>
        <source>KeePassXC database file selected</source>
        <translation>KeePassXC 데이터베이스 파일 선택됨</translation>
    </message>
    <message>
        <source>The file you selected looks like a database file.
A database file is NOT a key file!

Are you sure you want to continue with this file?.</source>
        <translation>선택한 파일은 데이터베이스 파일 같습니다.
데이터베이스 파일은 키 파일이 아닙니다!

이 파일로 계속 진행하시겠습니까?</translation>
    </message>
    <message>
        <source>No hardware keys found.</source>
        <translation>하드웨어 키를 찾을 수 없습니다.</translation>
    </message>
    <message>
        <source>Refresh Hardware Keys</source>
        <translation>하드웨어 키 새로 고침</translation>
    </message>
    <message>
        <source>Click to add a key file.</source>
        <translation>키 파일을 추가하려면 클릭하십시오.</translation>
    </message>
    <message>
        <source>Hardware keys found, but no slots are configured.</source>
        <translation>하드웨어 키를 찾았지만 슬롯이 구성되지 않았습니다.</translation>
    </message>
    <message>
        <source>Press ESC again to close this database</source>
        <translation>이 데이터베이스를 닫으려면 ESC를 다시 누릅니다</translation>
    </message>
    <message>
        <source>I have a key file</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>DatabaseSettingWidgetMetaData</name>
    <message>
        <source>Passwords</source>
        <translation>비밀번호</translation>
    </message>
</context>
<context>
    <name>DatabaseSettingsDialog</name>
    <message>
        <source>General</source>
        <translation>일반</translation>
    </message>
    <message>
        <source>Security</source>
        <translation>보안</translation>
    </message>
    <message>
        <source>Database Credentials</source>
        <translation>데이터베이스 자격 증명</translation>
    </message>
    <message>
        <source>Encryption Settings</source>
        <translation>암호화 설정</translation>
    </message>
    <message>
        <source>Browser Integration</source>
        <translation>브라우저 통합</translation>
    </message>
    <message>
        <source>Maintenance</source>
        <translation>관리</translation>
    </message>
    <message>
        <source>KeeShare</source>
        <translation>KeeShare</translation>
    </message>
    <message>
        <source>Secret Service Integration</source>
        <translation>비밀 서비스 통합</translation>
    </message>
    <message>
        <source>Remote Sync</source>
        <translation>원격 동기화</translation>
    </message>
    <message>
        <source>Database Settings: %1</source>
        <translation>데이터베이스 설정: %1</translation>
    </message>
</context>
<context>
    <name>DatabaseSettingsWidgetBrowser</name>
    <message>
        <source>KeePassXC-Browser settings</source>
        <translation>KeePassXC-브라우저 설정</translation>
    </message>
    <message>
        <source>Disconnect all browsers</source>
        <translation>모든 브라우저 연결 끊기</translation>
    </message>
    <message>
        <source>Forget all site-specific settings on entries</source>
        <translation>항목의 모든 사이트별 설정 삭제</translation>
    </message>
    <message>
        <source>Refresh database root group ID</source>
        <translation>데이터베이스 루트 그룹 ID 새로 고침</translation>
    </message>
    <message>
        <source>Stored keys</source>
        <translation>저장된 키</translation>
    </message>
    <message>
        <source>Stored browser keys</source>
        <translation>저장된 브라우저 키</translation>
    </message>
    <message>
        <source>Remove selected key</source>
        <translation>선택한 키 삭제</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>삭제</translation>
    </message>
    <message>
        <source>Delete the selected key?</source>
        <translation>선택한 키를 삭제하시겠습니까?</translation>
    </message>
    <message>
        <source>Do you really want to delete the selected key?
This may prevent connection to the browser plugin.</source>
        <translation>선택한 키를 삭제하시겠습니까?
브라우저 플러그인에 연결하지 못할 수도 있습니다.</translation>
    </message>
    <message>
        <source>Key</source>
        <translation>키</translation>
    </message>
    <message>
        <source>Value</source>
        <translation>값</translation>
    </message>
    <message>
        <source>Created</source>
        <translation>생성</translation>
    </message>
    <message>
        <source>Enable Browser Integration to access these settings.</source>
        <translation>이 설정을 변경하려면 브라우저 통합을 활성화하십시오.</translation>
    </message>
    <message>
        <source>Do you really want to disconnect all browsers?
This may prevent connection to the browser plugin.</source>
        <translation>모든 브라우저 연결을 끊으시겠습니까?
브라우저 플러그인에 연결하지 못할 수도 있습니다.</translation>
    </message>
    <message>
        <source>No shared encryption keys found in KeePassXC settings.</source>
        <translation>KeePassXC 설정에서 공유된 암호화 키를 찾을 수 없습니다.</translation>
    </message>
    <message numerus="yes">
        <source>Successfully removed %n encryption key(s) from KeePassXC settings.</source>
        <translation><numerusform>KeePassXC 설정에서 암호화 키 %n개를 삭제했습니다.</numerusform></translation>
    </message>
    <message>
        <source>Do you really want forget all site-specific settings on every entry?
Permissions to access entries will be revoked.</source>
        <translation>모든 항목의 사이트별 설정을 삭제하시겠습니까?
항목에 접근할 권한이 취소됩니다.</translation>
    </message>
    <message>
        <source>Removing stored permissions…</source>
        <translation>저장된 권한 삭제 중...</translation>
    </message>
    <message>
        <source>Abort</source>
        <translation>중지</translation>
    </message>
    <message numerus="yes">
        <source>Successfully removed permissions from %n entry(s).</source>
        <translation><numerusform>항목 %n개에서 권한을 삭제했습니다.</numerusform></translation>
    </message>
    <message>
        <source>The active database does not contain an entry with permissions.</source>
        <translation>활성 데이터베이스에 권한이 부여된 항목이 없습니다.</translation>
    </message>
    <message>
        <source>Refresh database ID</source>
        <translation>데이터베이스 ID 새로 고침</translation>
    </message>
    <message>
        <source>Do you really want refresh the database ID?
This is only necessary if your database is a copy of another and the browser extension cannot connect.</source>
        <translation>데이터베이스 ID를 새로 고치시겠습니까?
데이터베이스가 다른 데이터베이스의 복제본이고 브라우저 확장 기능에서 연결할 수 없을 때에만 사용하십시오.</translation>
    </message>
    <message>
        <source>Convert legacy KeePassHTTP attributes to KeePassXC-Browser compatible custom data</source>
        <translation>레거시 KeePassHTTP 설정을 KeePassXC-브라우저 호환 사용자 정의 데이터로 변환</translation>
    </message>
    <message>
        <source>No keys found</source>
        <translation>키를 찾을 수 없음</translation>
    </message>
    <message>
        <source>Removed keys from database</source>
        <translation>데이터베이스에서 키 삭제함</translation>
    </message>
    <message>
        <source>Removed permissions</source>
        <translation>권한 삭제함</translation>
    </message>
    <message>
        <source>No entry with permissions found!</source>
        <translation>권한이 있는 항목을 찾을 수 없습니다!</translation>
    </message>
</context>
<context>
    <name>DatabaseSettingsWidgetDatabaseKey</name>
    <message>
        <source>Add additional protection…</source>
        <translation>추가 보호 추가…</translation>
    </message>
    <message>
        <source>No password set</source>
        <translation>비밀번호가 설정되지 않았음</translation>
    </message>
    <message>
        <source>WARNING! You have not set a password. Using a database without a password is strongly discouraged!

Are you sure you want to continue without a password?</source>
        <translation>경고! 비밀번호를 설정하지 않았습니다. 데이터베이스 비밀번호를 설정하지 않는 것은 추천하지 않습니다!

비밀번호를 지정하지 않고 계속 진행하시겠습니까?</translation>
    </message>
    <message>
        <source>Continue without password</source>
        <translation>비밀번호 없이 계속</translation>
    </message>
    <message>
        <source>No encryption key added</source>
        <translation>암호화 키가 추가되지 않았음</translation>
    </message>
    <message>
        <source>You must add at least one encryption key to secure your database!</source>
        <translation>데이터베이스를 보호할 암호화 키를 최소 하나 추가해야 합니다!</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation>알 수 없는 오류</translation>
    </message>
    <message>
        <source>Failed to change database credentials</source>
        <translation>데이터베이스 자격 증명을 변경할 수 없음</translation>
    </message>
    <message>
        <source>Weak password</source>
        <translation>약한 비밀번호</translation>
    </message>
    <message>
        <source>This is a weak password! For better protection of your secrets, you should choose a stronger password.</source>
        <translation>비밀번호가 너무 약합니다! 기밀 정보를 보호하려면 더 강한 비밀번호를 입력해야 합니다.</translation>
    </message>
    <message>
        <source>The provided password does not meet the minimum quality requirement.</source>
        <translation>지정한 비밀번호가 최소 보안 조건을 만족하지 않습니다.</translation>
    </message>
</context>
<context>
    <name>DatabaseSettingsWidgetEncryption</name>
    <message>
        <source>Decryption Time:</source>
        <translation>복호화 시간:</translation>
    </message>
    <message>
        <source>Decryption time in seconds</source>
        <translation>초 단위의 복호화 시간</translation>
    </message>
    <message>
        <source>Higher values offer more protection, but opening the database will take longer.</source>
        <translation>시간을 더 늘리면 보호 정도를 높일 수 있지만 데이터베이스를 여는 데 더 오랜 시간이 걸릴 것입니다.</translation>
    </message>
    <message>
        <source>Database format:</source>
        <translation>데이터베이스 형식:</translation>
    </message>
    <message>
        <source>Database format</source>
        <translation>데이터베이스 형식</translation>
    </message>
    <message>
        <source>Format cannot be changed: Your database uses KDBX 4 features</source>
        <translation>형식을 변경할 수 없음: 데이터베이스에서 KDBX 4의 기능 사용 중</translation>
    </message>
    <message>
        <source>Unless you need to open your database with other programs, always use the latest format.</source>
        <translation>다른 프로그램으로 데이터베이스를 열 필요가 없다면 항상 최신 형식을 사용하십시오.</translation>
    </message>
    <message>
        <source>Encryption Algorithm:</source>
        <translation>암호화 알고리즘:</translation>
    </message>
    <message>
        <source>Encryption algorithm</source>
        <translation>암호화 알고리즘</translation>
    </message>
    <message>
        <source>AES:  256 Bit   (default)</source>
        <translation>AES: 256비트(기본값)</translation>
    </message>
    <message>
        <source>Twofish:  256 Bit</source>
        <translation>Twofish: 256비트</translation>
    </message>
    <message>
        <source>Key Derivation Function:</source>
        <translation>키 유도 함수:</translation>
    </message>
    <message>
        <source>Key derivation function</source>
        <translation>키 유도 함수</translation>
    </message>
    <message>
        <source>Transform rounds:</source>
        <translation>변환 횟수:</translation>
    </message>
    <message>
        <source>Transform rounds</source>
        <translation>변환 횟수</translation>
    </message>
    <message>
        <source>Memory Usage:</source>
        <translation>메모리 사용량:</translation>
    </message>
    <message>
        <source>Memory usage</source>
        <translation>메모리 사용</translation>
    </message>
    <message>
        <source>Parallelism:</source>
        <translation>스레드 수:</translation>
    </message>
    <message>
        <source>Parallelism</source>
        <translation>병렬화</translation>
    </message>
    <message>
        <source>KDBX 4 (recommended)</source>
        <translation>KDBX 4(추천)</translation>
    </message>
    <message>
        <source>KDBX 3</source>
        <translation>KDBX 3</translation>
    </message>
    <message>
        <source>Number of rounds too high</source>
        <comment>Key transformation rounds</comment>
        <translation>라운드 수가 너무 높음</translation>
    </message>
    <message>
        <source>You are using a very high number of key transform rounds with Argon2.

If you keep this number, your database may take hours, days, or even longer to open.</source>
        <translation>Argon2 키 변형 라운드 수가 너무 높습니다.

해당 수치를 사용하면 데이터베이스를 열 때 수 시간이나 수 일 이상 소요될 수 있습니다.</translation>
    </message>
    <message>
        <source>Understood, keep number</source>
        <translation>이해함, 숫자 유지</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>취소</translation>
    </message>
    <message>
        <source>Number of rounds too low</source>
        <comment>Key transformation rounds</comment>
        <translation>라운드 수가 너무 낮음</translation>
    </message>
    <message>
        <source>You are using a very low number of key transform rounds with AES-KDF.

If you keep this number, your database will not be protected from brute force attacks.</source>
        <translation>AES-KDF 키 변형 라운드 수가 너무 낮습니다.

해당 수치를 계속 사용하면 데이터베이스가 무작위 대입 공격에 취약할 수 있습니다.</translation>
    </message>
    <message>
        <source>KDF unchanged</source>
        <translation>키 유도 함수 변경되지 않음</translation>
    </message>
    <message>
        <source>Failed to transform key with new KDF parameters; KDF unchanged.</source>
        <translation>새로운 키 유도 함수 인자로 키를 변경할 수 없어서 키 유도 함수를 변경하지 않았습니다.</translation>
    </message>
    <message numerus="yes">
        <source> MiB</source>
        <comment>Abbreviation for Mebibytes (KDF settings)</comment>
        <translation><numerusform>MiB</numerusform></translation>
    </message>
    <message numerus="yes">
        <source> thread(s)</source>
        <comment>Threads for parallel execution (KDF settings)</comment>
        <translation><numerusform>개 스레드</numerusform></translation>
    </message>
    <message>
        <source>Encryption Settings:</source>
        <translation>암호화 설정:</translation>
    </message>
    <message>
        <source>Basic</source>
        <translation>기본</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>고급</translation>
    </message>
</context>
<context>
    <name>DatabaseSettingsWidgetFdoSecrets</name>
    <message>
        <source>Exposed Entries</source>
        <translation>내보낼 항목</translation>
    </message>
    <message>
        <source>Don&apos;t expose this database</source>
        <translation>이 데이터베이스 내보내지 않기</translation>
    </message>
    <message>
        <source>Expose entries under this group:</source>
        <translation>다음 그룹에 속한 항목 내보내기:</translation>
    </message>
    <message>
        <source>Enable Secret Service to access these settings.</source>
        <translation>이 설정에 접근하려면 비밀 서비스를 활성화하십시오.</translation>
    </message>
</context>
<context>
    <name>DatabaseSettingsWidgetGeneral</name>
    <message>
        <source>Database Metadata</source>
        <translation>데이터베이스 메타데이터</translation>
    </message>
    <message>
        <source>Database name:</source>
        <translation>데이터베이스 이름:</translation>
    </message>
    <message>
        <source>Database name field</source>
        <translation>데이터베이스 이름 필드</translation>
    </message>
    <message>
        <source>Database description:</source>
        <translation>데이터베이스 설명:</translation>
    </message>
    <message>
        <source>Database description field</source>
        <translation>데이터베이스 설명 필드</translation>
    </message>
    <message>
        <source>Default username:</source>
        <translation>기본 사용자 이름:</translation>
    </message>
    <message>
        <source>Default username field</source>
        <translation>기본 사용자 이름 필드</translation>
    </message>
    <message>
        <source>History Settings</source>
        <translation>과거 기록 설정</translation>
    </message>
    <message>
        <source>Maximum number of history items per entry</source>
        <translation>항목당 최대 과거 기록 개수</translation>
    </message>
    <message>
        <source>Maximum size of history per entry</source>
        <translation>항목당 최대 과거 기록 크기</translation>
    </message>
    <message>
        <source> MiB</source>
        <translation> MiB</translation>
    </message>
    <message>
        <source>Use recycle bin</source>
        <translation>휴지통 사용</translation>
    </message>
    <message>
        <source>Additional Database Settings</source>
        <translation>추가 데이터베이스 설정</translation>
    </message>
    <message>
        <source>Enable compression (recommended)</source>
        <translation>압축 사용(추천)</translation>
    </message>
    <message>
        <source>Delete Recycle Bin</source>
        <translation>휴지통 지우기</translation>
    </message>
    <message>
        <source>Do you want to delete the current recycle bin and all its contents?
This action is not reversible.</source>
        <translation>현재 휴지통과 포함된 모든 내용을 삭제하시겠습니까?
이 작업은 취소할 수 없습니다.</translation>
    </message>
    <message>
        <source> (old)</source>
        <translation>(이전)</translation>
    </message>
    <message>
        <source>When saving this setting or editing an entry
the oldest history items of an entry will be
removed such that only the specified amount
of entries remain at most.</source>
        <translation>이 설정을 저장하거나 항목을 편집할 때
항목의 과거 기록 중 가장 오래된 항목부터
삭제되어 최대 지정한 개수만큼의 과거
기록만을 저장합니다.</translation>
    </message>
    <message>
        <source>Limit the amount of history items per entry to:</source>
        <translation>항목별 과거 기록 개수 제한:</translation>
    </message>
    <message>
        <source>When saving this setting or editing an entry
the oldest history items of an entry will be
removed such that the remaining history items
add up to the specified amount at most.</source>
        <translation>이 설정을 저장하거나 항목을 편집할 때
항목의 과거 기록 중 가장 오래된 항목부터
삭제되어 최대 지정한 크기만큼의 과거
기록만을 저장합니다.</translation>
    </message>
    <message>
        <source>Limit the total size of history items per entry to:</source>
        <translation>항목별 과거 기록 총 크기 제한:</translation>
    </message>
    <message>
        <source>Move entries to a recycle bin group
instead of deleting them from the database.
Entries deleted from the recycle bin are
removed from the database.</source>
        <translation>데이터베이스에서 항목을 삭제하지 않고
휴지통 그룹으로 이동합니다.
휴지통에서 삭제된 항목은
데이터베이스에서 삭제됩니다.</translation>
    </message>
    <message>
        <source>Autosave delay since last change</source>
        <translation>마지막 변경 후 자동 저장까지 대기 시간</translation>
    </message>
    <message>
        <source>Autosave delay</source>
        <translation>자동 저장 대기 시간</translation>
    </message>
    <message>
        <source>Autosave delay since last change in minutes</source>
        <translation>분 단위의 마지막 변경 후 자동 저장 대기 시간</translation>
    </message>
    <message>
        <source> min</source>
        <translation>분</translation>
    </message>
    <message>
        <source>Autosave delay since last change checkbox</source>
        <translation>마지막 체크 상자 변경 후 자동 저장 대기 시간</translation>
    </message>
    <message>
        <source>Public Database Metadata</source>
        <translation>공개 데이터베이스 메타데이터</translation>
    </message>
    <message>
        <source>Warning: the following settings are not encrypted.</source>
        <translation>경고: 다음 설정은 암호화되지 않았습니다.</translation>
    </message>
    <message>
        <source>Display name:</source>
        <translation>표시 이름:</translation>
    </message>
    <message>
        <source>Database public display name</source>
        <translation>데이터베이스 공개 표시 이름</translation>
    </message>
    <message>
        <source>Display color:</source>
        <translation>표시 색상:</translation>
    </message>
    <message>
        <source>Database public display color chooser</source>
        <translation>데이터베이스 공개 디스플레이 색상 선택기</translation>
    </message>
    <message>
        <source>Clear</source>
        <translation>비우기</translation>
    </message>
    <message>
        <source>Display icon:</source>
        <translation>표시 아이콘:</translation>
    </message>
    <message>
        <source>Select Database Icon</source>
        <translation>데이터베이스 아이콘 선택</translation>
    </message>
    <message>
        <source>Publicly visible display name used on the unlock dialog</source>
        <translation>잠금 해제 대화 상자에서 사용되는 공개적으로 보이는 표시 이름</translation>
    </message>
    <message>
        <source>Publicly visible color used on the unlock dialog</source>
        <translation>잠금 해제 대화 상자에 사용된 공개적으로 보이는 색상</translation>
    </message>
</context>
<context>
    <name>DatabaseSettingsWidgetKeeShare</name>
    <message>
        <source>Sharing</source>
        <translation>공유</translation>
    </message>
    <message>
        <source>Breadcrumb</source>
        <translation>단계</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>형식</translation>
    </message>
    <message>
        <source>Path</source>
        <translation>경로</translation>
    </message>
    <message>
        <source>Last Signer</source>
        <translation>마지막 서명자</translation>
    </message>
    <message>
        <source>Certificates</source>
        <translation>인증서</translation>
    </message>
    <message>
        <source> &gt; </source>
        <comment>Breadcrumb separator</comment>
        <translation> &gt; </translation>
    </message>
</context>
<context>
    <name>DatabaseSettingsWidgetMaintenance</name>
    <message>
        <source>Manage Custom Icons</source>
        <translation>사용자 정의 아이콘 관리</translation>
    </message>
    <message>
        <source>Delete selected icon(s)</source>
        <translation>선택한 아이콘 삭제</translation>
    </message>
    <message>
        <source>Delete all custom icons not in use by any entry or group</source>
        <translation>사용하는 항목이나 그룹이 없는 모든 사용자 정의 아이콘 삭제</translation>
    </message>
    <message>
        <source>Purge unused icons</source>
        <translation>사용하지 않는 아이콘 비우기</translation>
    </message>
    <message>
        <source>Confirm Deletion</source>
        <translation>삭제 확인</translation>
    </message>
    <message>
        <source>At least one of the selected icons is currently in use by at least one entry or group. The icons of all affected entries and groups will be replaced by the default icon. Are you sure you want to delete icons that are currently in use?</source>
        <translation>이 아이콘을 사용하고 있는 항목이나 그룹이 최소한 한 개 있습니다. 아이콘을 삭제 하면 기본 아이콘으로 대체됩니다. 그래도 사용 중인 아이콘을 삭제하시겠습니까?</translation>
    </message>
    <message>
        <source>Custom Icons Are In Use</source>
        <translation>사용자 정의 아이콘 사용 중</translation>
    </message>
    <message>
        <source>All custom icons are in use by at least one entry or group.</source>
        <translation>모든 사용자 정의 아이콘이 항목이나 그룹에서 사용 중입니다.</translation>
    </message>
    <message>
        <source>Purged Unused Icons</source>
        <translation>사용하지 않는 아이콘 비우기</translation>
    </message>
    <message numerus="yes">
        <source>Purged %n icon(s) from the database.</source>
        <translation><numerusform>데이터베이스에서 아이콘 %n개를 비웠습니다.</numerusform></translation>
    </message>
</context>
<context>
    <name>DatabaseSettingsWidgetMetaDataSimple</name>
    <message>
        <source>Database Name:</source>
        <translation>데이터베이스 이름:</translation>
    </message>
    <message>
        <source>Database name field</source>
        <translation>데이터베이스 이름 필드</translation>
    </message>
    <message>
        <source>Description:</source>
        <translation>설명:</translation>
    </message>
    <message>
        <source>Database description field</source>
        <translation>데이터베이스 설명 필드</translation>
    </message>
</context>
<context>
    <name>DatabaseSettingsWidgetRemote</name>
    <message>
        <source>Sync Commands</source>
        <translation>동기화 명령</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>삭제</translation>
    </message>
    <message>
        <source>Command Settings</source>
        <translation>명령 설정</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>이름</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>저장</translation>
    </message>
    <message>
        <source>Download</source>
        <translation>다운로드</translation>
    </message>
    <message>
        <source>Command:</source>
        <translation>명령:</translation>
    </message>
    <message>
        <source>Download command field</source>
        <translation>다운로드 명령 필드</translation>
    </message>
    <message>
        <source>e.g.: &quot;sftp user@hostname&quot; or &quot;scp user@hostname:DatabaseOnRemote.kdbx {TEMP_DATABASE}&quot;</source>
        <translation>예제: &quot;sftp user@hostname&quot; 또는 &quot;scp user@hostname:DatabaseOnRemote.kdbx {TEMP_DATABASE}&quot;</translation>
    </message>
    <message>
        <source>Input:</source>
        <translation>입력:</translation>
    </message>
    <message>
        <source>Download input field</source>
        <translation>다운로드 입력 필드</translation>
    </message>
    <message>
        <source>Upload</source>
        <translation>업로드</translation>
    </message>
    <message>
        <source>Upload command field</source>
        <translation>업로드 명령 필드</translation>
    </message>
    <message>
        <source>e.g.: &quot;sftp user@hostname&quot; or &quot;scp {TEMP_DATABASE} user@hostname:DatabaseOnRemote.kdbx&quot;</source>
        <translation>예제: &quot;sftp user@hostname&quot; 또는 &quot;scp {TEMP_DATABASE} user@hostname:DatabaseOnRemote.kdbx&quot;</translation>
    </message>
    <message>
        <source>Upload input field</source>
        <translation>업로드 입력 필드</translation>
    </message>
    <message>
        <source>Name cannot be empty.</source>
        <translation>이름을 비워 둘 수 없습니다.</translation>
    </message>
    <message>
        <source>Test</source>
        <translation>시험</translation>
    </message>
    <message>
        <source>Download command cannot be empty.</source>
        <translation>다운로드 명령을 비워 둘 수 없습니다.</translation>
    </message>
    <message>
        <source>Download failed with error: %1</source>
        <translation>다운로드 실패, 오류: %1</translation>
    </message>
    <message>
        <source>Download finished, but file %1 could not be found.</source>
        <translation>다운로드가 완료되었지만 %1 파일을 찾을 수 없습니다.</translation>
    </message>
    <message>
        <source>Download successful.</source>
        <translation>다운로드에 성공했습니다.</translation>
    </message>
    <message>
        <source>Save Remote Settings</source>
        <translation>원격 설정 저장</translation>
    </message>
    <message>
        <source>You have unsaved changes. Do you want to save them?</source>
        <translation>저장하지 않은 변경 사항이 있습니다. 저장하시겠습니까?</translation>
    </message>
    <message>
        <source>e.g.:
get DatabaseOnRemote.kdbx {TEMP_DATABASE}
exit
---
{TEMP_DATABASE} is used as placeholder to store the database in a temporary location
The command has to exit. In case of `sftp` as last command `exit` has to be sent
            </source>
        <translation>예제.:
get DatabaseOnRemote.kdbx {TEMP_DATABASE}
exit
---
{TEMP_DATABASE}는 임시 위치에 저장된 데이터베이스를 가리키는 자리 비움자입니다
명령은 종료되어야 합니다. `sftp`의 경우 마지막 `exit` 명령을 전송해야 합니다
            </translation>
    </message>
    <message>
        <source>e.g.:
put {TEMP_DATABASE} DatabaseOnRemote.kdbx
exit
---
{TEMP_DATABASE} is used as placeholder to store the database in a temporary location
The command has to exit. In case of `sftp` as last command `exit` has to be sent
            </source>
        <translation>예제.:
put {TEMP_DATABASE} DatabaseOnRemote.kdbx
exit
---
{TEMP_DATABASE}는 임시 위치에 저장된 데이터베이스를 가리키는 자리 비움자입니다
명령은 종료되어야 합니다. `sftp`의 경우 마지막 `exit` 명령을 전송해야 합니다
            </translation>
    </message>
    <message>
        <source>Timeout:</source>
        <translation>시간 초과:</translation>
    </message>
    <message>
        <source> seconds</source>
        <translation>초</translation>
    </message>
</context>
<context>
    <name>DatabaseTabWidget</name>
    <message>
        <source>Database creation error</source>
        <translation>Database creation error</translation>
    </message>
    <message>
        <source>The created database has no key or KDF, refusing to save it.
This is definitely a bug, please report it to the developers.</source>
        <translation>이 생성된 데이터베이스에 키나 KDF가 없어서 저장하지 않을 것입니다.
버그이므로 개발자에게 보고해 주십시오.</translation>
    </message>
    <message>
        <source>KeePass 2 Database</source>
        <translation>KeePass 2 데이터베이스</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>모든 파일</translation>
    </message>
    <message>
        <source>Open database</source>
        <translation>데이터베이스 열기</translation>
    </message>
    <message>
        <source>Failed to open %1. It either does not exist or is not accessible.</source>
        <translation>%1을(를) 열 수 없습니다. 더 이상 존재하지 않거나 접근할 수 없습니다.</translation>
    </message>
    <message>
        <source>CSV file</source>
        <translation>CSV 파일</translation>
    </message>
    <message>
        <source>Merge database</source>
        <translation>데이터베이스 합치기</translation>
    </message>
    <message>
        <source>Export database to CSV file</source>
        <translation>데이터베이스를 CSV 파일로 내보내기</translation>
    </message>
    <message>
        <source>Writing the CSV file failed.</source>
        <translation>CSV 파일에 기록할 수 없습니다.</translation>
    </message>
    <message>
        <source>Writing the HTML file failed.</source>
        <translation>HTML 파일에 쓸 수 없습니다.</translation>
    </message>
    <message>
        <source>Export database to XML file</source>
        <translation>데이터베이스를 XML 파일로 내보내기</translation>
    </message>
    <message>
        <source>XML file</source>
        <translation>XML 파일</translation>
    </message>
    <message>
        <source>Writing the XML file failed</source>
        <translation>XML 파일 기록 실패</translation>
    </message>
    <message>
        <source>Export Confirmation</source>
        <translation>내보내기 확인</translation>
    </message>
    <message>
        <source>You are about to export your database to an unencrypted file. This will leave your passwords and sensitive information vulnerable! Are you sure you want to continue?</source>
        <translation>데이터베이스를 암호화되지 않은 파일로 내보냅니다. 비밀번호와 기타 민감 정보를 노출시킬 수 있습니다! 계속 진행하시겠습니까?</translation>
    </message>
    <message>
        <source>%1 [Locked]</source>
        <comment>Database tab name modifier</comment>
        <translation>%1 [잠김]</translation>
    </message>
    <message>
        <source>%1 [Temporary]</source>
        <comment>Database tab name modifier</comment>
        <translation>%1 [임시]</translation>
    </message>
</context>
<context>
    <name>DatabaseWidget</name>
    <message>
        <source>Searches and Tags</source>
        <translation>검색과 태그</translation>
    </message>
    <message>
        <source>Searching…</source>
        <translation>검색 중...</translation>
    </message>
    <message>
        <source>Shared group…</source>
        <translation>공유된 그룹...</translation>
    </message>
    <message>
        <source>Confirm Auto-Type</source>
        <translation>자동 입력 확인</translation>
    </message>
    <message>
        <source>Perform Auto-Type into the previously active window?</source>
        <translation>이전에 활성화된 창에 자동 입력을 수행하시겠습니까?</translation>
    </message>
    <message>
        <source>Execute command?</source>
        <translation>명령을 실행하시겠습니까?</translation>
    </message>
    <message>
        <source>Do you really want to execute the following command?&lt;br&gt;&lt;br&gt;%1&lt;br&gt;</source>
        <translation>다음 명령을 실행하시겠습니까?&lt;br&gt;&lt;br&gt;%1&lt;br&gt;</translation>
    </message>
    <message>
        <source>Remember my choice</source>
        <translation>이 선택 기억하기</translation>
    </message>
    <message>
        <source>Do you really want to move the group &quot;%1&quot; to the recycle bin?</source>
        <translation>그룹 &quot;%1&quot;을(를) 휴지통으로 이동하시겠습니까?</translation>
    </message>
    <message>
        <source>Expired entries</source>
        <translation>만료된 항목</translation>
    </message>
    <message numerus="yes">
        <source>Entries expiring within %1 day(s)</source>
        <translation><numerusform>%1일 내에 만료되는 항목</numerusform></translation>
    </message>
    <message>
        <source>No current database.</source>
        <translation>현재 데이터베이스가 없습니다.</translation>
    </message>
    <message>
        <source>No source database, nothing to do.</source>
        <translation>원본 데이터베이스가 없습니다.</translation>
    </message>
    <message>
        <source>Search Results (%1)</source>
        <translation>검색 결과(%1)</translation>
    </message>
    <message>
        <source>No Results</source>
        <translation>결과 없음</translation>
    </message>
    <message>
        <source>Enter a unique name or overwrite an existing search from the list:</source>
        <translation>고유한 이름을 입력하거나 목록에 있는 기존 검색을 덮어쓸 수 있습니다:</translation>
    </message>
    <message>
        <source>Save Search</source>
        <translation>검색 저장</translation>
    </message>
    <message>
        <source>Lock Database?</source>
        <translation>데이터베이스를 잠그시겠습니까?</translation>
    </message>
    <message>
        <source>You are editing an entry. Discard changes and lock anyway?</source>
        <translation>항목을 편집하고 있습니다. 변경 사항을 무시하고 잠그시겠습니까?</translation>
    </message>
    <message>
        <source>&quot;%1&quot; was modified.
Save changes?</source>
        <translation>&quot;%1&quot;이(가) 변경되었습니다. 저장하시겠습니까?</translation>
    </message>
    <message>
        <source>Database was modified.
Save changes?</source>
        <translation>데이터베이스가 변경되었습니다.
저장하시겠습니까?</translation>
    </message>
    <message>
        <source>Save changes?</source>
        <translation>변경 사항 저장 확인?</translation>
    </message>
    <message>
        <source>File has changed</source>
        <translation>파일 변경됨</translation>
    </message>
    <message>
        <source>Disable safe saves?</source>
        <translation>안전 저장을 비활성화 하시겠습니까?</translation>
    </message>
    <message>
        <source>KeePassXC has failed to save the database multiple times. This is likely caused by file sync services holding a lock on the save file.
Disable safe saves and try again?</source>
        <translation>KeePassXC에서 데이터베이스를 여러 번 저장하려고 시도했으나 실패했습니다. 파일 동기화 서비스에서 데이터베이스 파일을 잠근 것 같습니다.
안전 저장을 비활성화 한 다음 다시 시도하시겠습니까?</translation>
    </message>
    <message>
        <source>Writing the database failed: %1</source>
        <translation>데이터베이스에기록할 수 없음: %1</translation>
    </message>
    <message>
        <source>Passwords</source>
        <translation>비밀번호</translation>
    </message>
    <message>
        <source>Save database as</source>
        <translation>다른 이름으로 데이터베이스 저장</translation>
    </message>
    <message>
        <source>KeePass 2 Database</source>
        <translation>KeePass 2 데이터베이스</translation>
    </message>
    <message>
        <source>Empty recycle bin?</source>
        <translation>휴지통을 비우시겠습니까?</translation>
    </message>
    <message>
        <source>Are you sure you want to permanently delete everything from your recycle bin?</source>
        <translation>휴지통에 있는 항목을 영원히 삭제하시겠습니까?</translation>
    </message>
    <message>
        <source>Could not find database file: %1</source>
        <translation>데이터베이스 파일을 찾을 수 없음: %1</translation>
    </message>
    <message>
        <source>New Database</source>
        <translation>새 데이터베이스</translation>
    </message>
    <message>
        <source>%1 [New Database]</source>
        <comment>Database tab name modifier</comment>
        <translation>%1 [새 데이터베이스]</translation>
    </message>
    <message>
        <source>Remote Sync did not contain any download or upload commands.</source>
        <translation>원격 동기화에 다운로드나 업로드 명령이 없습니다.</translation>
    </message>
    <message>
        <source>Remote sync &apos;%1&apos; completed successfully!</source>
        <translation>&apos;%1&apos; 원격 동기화에 성공했습니다!</translation>
    </message>
    <message>
        <source>Downloading...</source>
        <translation>다운로드 중...</translation>
    </message>
    <message>
        <source>Uploading...</source>
        <translation>업로드 중...</translation>
    </message>
    <message>
        <source>Remote sync &apos;%1&apos; failed: %2</source>
        <translation>&apos;%1&apos; 원격 동기화 실패: %2</translation>
    </message>
    <message>
        <source>Syncing...</source>
        <translation>동기화 중...</translation>
    </message>
    <message>
        <source>Error while saving database %1: %2</source>
        <translation>%1 데이터베이스를 저장하는 중 오류 발생: %2</translation>
    </message>
    <message>
        <source>Remove passkey from entry</source>
        <translation>항목에서 패스키 삭제</translation>
    </message>
    <message>
        <source>Do you want to remove the passkey from this entry?</source>
        <translation>이 항목에서 패스키를 삭제하시겠습니까?</translation>
    </message>
    <message>
        <source>The database file &quot;%1&quot; was modified externally</source>
        <translation>데이터베이스 파일 &quot;%1&quot;이 외부에서 수정되었습니다</translation>
    </message>
    <message>
        <source>Do you want to load the changes?</source>
        <translation>변경 사항을 로드하시겠습니까?</translation>
    </message>
    <message>
        <source>Reloading database…</source>
        <translation>데이터베이스를 다시 로드하는 중...</translation>
    </message>
    <message>
        <source>Reload canceled</source>
        <translation>다 시로드 취소</translation>
    </message>
    <message>
        <source>Reload successful</source>
        <translation>다시 로드 성공</translation>
    </message>
    <message>
        <source>Reload pending user action…</source>
        <translation>대기 중인 사용자 작업 다시 로드...</translation>
    </message>
    <message>
        <source>The database file &quot;%1&quot; was modified externally.&lt;br&gt;How would you like to proceed?&lt;br&gt;&lt;br&gt;Merge all changes&lt;br&gt;Ignore the changes on disk until save&lt;br&gt;Discard unsaved changes</source>
        <translation>데이터베이스 파일 &quot;%1&quot;이 외부에서 수정되었습니다.&lt;br&gt;어떻게 진행하시겠습니까?&lt;br&gt;&lt;br&gt;모든 변경 사항 병합&lt;br&gt;저장할 때까지 디스크의 변경 사항 무시&lt;br&gt;저장되지 않은 변경 사항 폐기</translation>
    </message>
    <message>
        <source>The database file &quot;%1&quot; was modified externally.&lt;br&gt;How would you like to proceed?&lt;br&gt;&lt;br&gt;Merge all changes then save&lt;br&gt;Overwrite the changes on disk&lt;br&gt;Discard unsaved changes</source>
        <translation>데이터베이스 파일 &quot;%1&quot;이 외부에서 수정되었습니다&lt;br&gt;어떻게 진행하시겠습니까?&lt;br&gt;&lt;br&gt;모든 변경 사항을 병합한 다음 저장&lt;br&gt;디스크에 변경 사항 덮어쓰기&lt;br&gt;저장되지 않은 변경 사항 폐기</translation>
    </message>
    <message>
        <source>Reload database</source>
        <translation>데이터베이스 다시 로드</translation>
    </message>
    <message>
        <source>Database file overwritten.</source>
        <translation>데이터베이스 파일을 덮어 썼습니다.</translation>
    </message>
    <message>
        <source>Database file on disk cannot be unlocked with current credentials.&lt;br&gt;Enter new credentials and/or present hardware key to continue.</source>
        <translation>디스크의 데이터베이스 파일을 현재 자격 증명으로 잠금 해제할 수 없습니다.&lt;br&gt;계속하려면 새 자격 증명을 입력하거나 하드웨어 키를 제시하세요.</translation>
    </message>
    <message>
        <source>Failed to save backup database: %1</source>
        <translation>백업 데이터베이스를 저장하지 못했습니다: %1</translation>
    </message>
    <message>
        <source>Confirm Delete Group</source>
        <translation>그룹 삭제 확인</translation>
    </message>
    <message>
        <source>Do you really want to permanently delete the group &quot;%1&quot;?</source>
        <translation>그룹 &quot;%1&quot;을 영구적으로 삭제하시겠습니까?</translation>
    </message>
    <message>
        <source>Confirm Recycle Group</source>
        <translation>재활용 그룹 확인</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>저장</translation>
    </message>
    <message>
        <source>Save Database Backup</source>
        <translation>데이터베이스 백업 저장</translation>
    </message>
    <message>
        <source>Successfully merged the selected database.</source>
        <translation>선택한 데이터베이스를 성공적으로 병합했습니다.</translation>
    </message>
    <message>
        <source>No changes were made by the merge operation.</source>
        <translation>병합 작업에 의해 변경되지 않았습니다.</translation>
    </message>
    <message>
        <source>Merge canceled, no changes were made.</source>
        <translation>병합이 취소되었지만 변경 사항이 없습니다.</translation>
    </message>
</context>
<context>
    <name>EditEntryAttachmentsDialog</name>
    <message>
        <source>Edit: %1</source>
        <translation>편집: %1</translation>
    </message>
</context>
<context>
    <name>EditEntryWidget</name>
    <message>
        <source>Entry</source>
        <translation>항목</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>고급</translation>
    </message>
    <message>
        <source>Icon</source>
        <translation>아이콘</translation>
    </message>
    <message>
        <source>Auto-Type</source>
        <translation>자동 입력</translation>
    </message>
    <message>
        <source>Browser Integration</source>
        <translation>브라우저 통합</translation>
    </message>
    <message>
        <source>&lt;empty URL&gt;</source>
        <translation>&lt;빈 URL&gt;</translation>
    </message>
    <message>
        <source>Confirm Removal</source>
        <translation>삭제 확인</translation>
    </message>
    <message>
        <source>Are you sure you want to remove this URL?</source>
        <translation>이 URL을 삭제하시겠습니까?</translation>
    </message>
    <message>
        <source>Properties</source>
        <translation>속성</translation>
    </message>
    <message>
        <source>History</source>
        <translation>과거 기록</translation>
    </message>
    <message>
        <source>SSH Agent</source>
        <translation>SSH 에이전트</translation>
    </message>
    <message>
        <source>n/a</source>
        <translation>없음</translation>
    </message>
    <message>
        <source>Select private key</source>
        <translation>비밀 키 선택</translation>
    </message>
    <message>
        <source>Entry history</source>
        <translation>항목 과거 기록</translation>
    </message>
    <message>
        <source>Add entry</source>
        <translation>항목 추가</translation>
    </message>
    <message>
        <source>Edit entry</source>
        <translation>항목 편집</translation>
    </message>
    <message>
        <source>Some Browser Integration settings are overridden by group settings.</source>
        <translation>일부 브라우저 통합 설정은 그룹 설정에 의해서 재정의됩니다.</translation>
    </message>
    <message>
        <source>Invalid Entry</source>
        <translation>잘못된 항목</translation>
    </message>
    <message>
        <source>An external merge operation has invalidated this entry.
Unfortunately, any changes made have been lost.</source>
        <translation>외부 합치기 작업으로 인해서 이 항목은 더 이상 유효하지 않습니다.
모든 변경 사항은 손실되었습니다.</translation>
    </message>
    <message>
        <source>Auto-Type Validation Error</source>
        <translation>자동 입력 검증 오류</translation>
    </message>
    <message>
        <source>An error occurred while validating the custom Auto-Type sequence:
%1
Would you like to correct it?</source>
        <translation>사용자 정의 자동 입력 시퀀스를 검증하는 중 오류가 발생했습니다:
%1
오류를 수정하시겠습니까?</translation>
    </message>
    <message>
        <source>An error occurred while validating the Auto-Type sequence for &quot;%1&quot;:
%2
Would you like to correct it?</source>
        <translation>&quot;%1&quot;의 자동 입력 시퀀스를 검증하는 중 오류가 발생했습니다:
%2
오류를 수정하시겠습니까?</translation>
    </message>
    <message>
        <source>Entry updated successfully.</source>
        <translation>항목을 업데이트했습니다.</translation>
    </message>
    <message>
        <source>Unsaved Changes</source>
        <translation>저장하지 않은 변경 사항</translation>
    </message>
    <message>
        <source>Would you like to save changes to this entry?</source>
        <translation>이 항목의 변경 사항을 저장하시겠습니까?</translation>
    </message>
    <message>
        <source>New attribute</source>
        <translation>새 속성</translation>
    </message>
    <message>
        <source>New attribute %1</source>
        <translation>새 속성 %1</translation>
    </message>
    <message>
        <source>Are you sure you want to remove this attribute?</source>
        <translation>이 속성을 삭제하시겠습니까?</translation>
    </message>
    <message>
        <source>Reveal</source>
        <translation>보이기</translation>
    </message>
    <message>
        <source>[PROTECTED] Press Reveal to view or edit</source>
        <translation>[보호됨] 보거나 편집하려면 &quot;보이기&quot;를 누르십시오</translation>
    </message>
    <message>
        <source>Hide</source>
        <translation>숨기기</translation>
    </message>
    <message numerus="yes">
        <source>%n hour(s)</source>
        <translation><numerusform>%n시간</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>%n week(s)</source>
        <translation><numerusform>%n주</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>%n month(s)</source>
        <translation><numerusform>%n개월</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>%n year(s)</source>
        <translation><numerusform>%n년</numerusform></translation>
    </message>
    <message>
        <source>Failed to decrypt SSH key, ensure password is correct.</source>
        <translation>SSH 키를 복호화할 수 없습니다. 비밀번호가 올바른지 확인하십시오.</translation>
    </message>
</context>
<context>
    <name>EditEntryWidgetAdvanced</name>
    <message>
        <source>Additional attributes</source>
        <translation>추가 속성</translation>
    </message>
    <message>
        <source>Attribute selection</source>
        <translation>속성 선택</translation>
    </message>
    <message>
        <source>Attribute value</source>
        <translation>속성 값</translation>
    </message>
    <message>
        <source>Add a new attribute</source>
        <translation>새 속성 추가</translation>
    </message>
    <message>
        <source>Add</source>
        <translation>추가</translation>
    </message>
    <message>
        <source>Remove selected attribute</source>
        <translation>선택한 속성 삭제</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>삭제</translation>
    </message>
    <message>
        <source>Edit attribute name</source>
        <translation>속성 이름 편집</translation>
    </message>
    <message>
        <source>Edit Name</source>
        <translation>이름 편집</translation>
    </message>
    <message>
        <source>Toggle attribute protection</source>
        <translation>속성 보호 전환</translation>
    </message>
    <message>
        <source>Protect</source>
        <translation>보호</translation>
    </message>
    <message>
        <source>Show a protected attribute</source>
        <translation>보호된 속성 표시</translation>
    </message>
    <message>
        <source>Reveal</source>
        <translation>보이기</translation>
    </message>
    <message>
        <source>Attachments</source>
        <translation>첨부</translation>
    </message>
    <message>
        <source>If checked, the entry will not appear in reports like Health Check and HIBP even if it doesn&apos;t match the quality requirements.</source>
        <translation>이 옵션을 사용하면 항목이 기준을 만족하지 못해도 데이터베이스 건강 보고서나 HIBP와 같은 항목에 표시하지 않습니다.</translation>
    </message>
    <message>
        <source>Exclude from database reports</source>
        <translation>데이터베이스 보고서에서 제외</translation>
    </message>
    <message>
        <source>Foreground Color:</source>
        <translation>글자색:</translation>
    </message>
    <message>
        <source>Foreground color selection</source>
        <translation>글자색 선택</translation>
    </message>
    <message>
        <source>Background Color:</source>
        <translation>배경색:</translation>
    </message>
    <message>
        <source>Background color selection</source>
        <translation>배경색 선택</translation>
    </message>
</context>
<context>
    <name>EditEntryWidgetAutoType</name>
    <message>
        <source>Enable Auto-Type for this entry</source>
        <translation>이 항목 자동 입력 사용</translation>
    </message>
    <message>
        <source>Inherit default Auto-Type sequence from the group</source>
        <translation>그룹의 기본 자동 입력 순서 사용</translation>
    </message>
    <message>
        <source>Use custom Auto-Type sequence:</source>
        <translation>사용자 정의 자동 입력 순서 사용:</translation>
    </message>
    <message>
        <source>Custom Auto-Type sequence</source>
        <translation>사용자 정의 자동 입력 순서</translation>
    </message>
    <message>
        <source>Open Auto-Type help webpage</source>
        <translation>자동 입력 도움말 웹 페이지 열기</translation>
    </message>
    <message>
        <source>Window Associations</source>
        <translation>창 연결</translation>
    </message>
    <message>
        <source>Existing window associations</source>
        <translation>기존 창 연결</translation>
    </message>
    <message>
        <source>Add new window association</source>
        <translation>새 창 연결 추가</translation>
    </message>
    <message>
        <source>+</source>
        <comment>Add item</comment>
        <translation>+</translation>
    </message>
    <message>
        <source>Remove selected window association</source>
        <translation>선택한 창 연결 삭제</translation>
    </message>
    <message>
        <source>-</source>
        <comment>Remove item</comment>
        <translation>-</translation>
    </message>
    <message>
        <source>Window title:</source>
        <translation>창 제목:</translation>
    </message>
    <message>
        <source>You can use an asterisk (*) to match everything</source>
        <translation>모든 것과 일치하려면 별표(*)를 사용하십시오</translation>
    </message>
    <message>
        <source>Set the window association title</source>
        <translation>창 연결 제목 설정</translation>
    </message>
    <message>
        <source>You can use an asterisk to match everything</source>
        <translation>모든 것과 일치하려면 별표(*)를 사용하십시오</translation>
    </message>
    <message>
        <source>Use a specific sequence for this association:</source>
        <translation>이 조합에 지정된 순서 사용:</translation>
    </message>
    <message>
        <source>Custom Auto-Type sequence for this window</source>
        <translation>이 창의 사용자 정의 자동 입력 순서</translation>
    </message>
</context>
<context>
    <name>EditEntryWidgetBrowser</name>
    <message>
        <source>General</source>
        <translation>일반</translation>
    </message>
    <message>
        <source>Hide this entry from the browser extension</source>
        <translation>이 항목을 브라우저 확장 기능에서 숨기기</translation>
    </message>
    <message>
        <source>Skip Auto-Submit for this entry</source>
        <translation>이 항목 자동 제출 건너뛰기</translation>
    </message>
    <message>
        <source>Use this entry only with HTTP Basic Auth</source>
        <translation>HTTP Basic 인증에만 이 항목 사용</translation>
    </message>
    <message>
        <source>Do not use this entry with HTTP Basic Auth</source>
        <translation>HTTP Basic 인증에 이 항목 사용하지 않기</translation>
    </message>
    <message>
        <source>Add</source>
        <translation>추가</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>삭제</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>편집</translation>
    </message>
    <message>
        <source>These settings affect the entry&apos;s behaviour with the browser extension.</source>
        <translation>이 설정은 브라우저 확장 기능에서 항목을 사용하는 방법에 영향을 줍니다.</translation>
    </message>
    <message>
        <source>Additional URLs</source>
        <translation>추가 URL</translation>
    </message>
    <message>
        <source>Only send this entry to the browser for HTTP Auth dialogs. If enabled, normal login forms will not show this entry for selection.</source>
        <translation>브라우저의 HTTP 인증 대화 상자에 이 항목만 보냅니다. 이 옵션을 사용하면 일반 로그인 폼에는 이 항목을 선택할 수 있도록 표시하지 않습니다.</translation>
    </message>
    <message>
        <source>Do not send this entry to the browser for HTTP Auth dialogs. If enabled, HTTP Auth dialogs will not show this entry for selection.</source>
        <translation>이 항목을 브라우저의 HTTP 인증 대화 상자에 보내지 않습니다. 이 옵션을 사용하면 HTTP 인증 대화 상자에는 이 항목을 선택할 수 있도록 표시하지 않습니다.</translation>
    </message>
</context>
<context>
    <name>EditEntryWidgetHistory</name>
    <message>
        <source>Entry history selection</source>
        <translation>항목 과거 기록 선택</translation>
    </message>
    <message>
        <source>Show entry at selected history state</source>
        <translation>선택한 과거 기록 시점에서의 항목 표시</translation>
    </message>
    <message>
        <source>Show</source>
        <translation>표시</translation>
    </message>
    <message>
        <source>Restore entry to selected history state</source>
        <translation>선택한 과거 기록 시점으로 항목 되돌리기</translation>
    </message>
    <message>
        <source>Restore</source>
        <translation>복원</translation>
    </message>
    <message>
        <source>Delete selected history state</source>
        <translation>선택한 과거 기록 시점 삭제</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>삭제</translation>
    </message>
    <message>
        <source>Delete all history</source>
        <translation>모든 과거 기록 삭제</translation>
    </message>
    <message>
        <source>Delete all</source>
        <translation>모두 삭제</translation>
    </message>
</context>
<context>
    <name>EditEntryWidgetMain</name>
    <message>
        <source>Edit Entry</source>
        <translation>항목 편집</translation>
    </message>
    <message>
        <source>Notes field</source>
        <translation>메모 필드</translation>
    </message>
    <message>
        <source>Username field</source>
        <translation>사용자 이름 필드</translation>
    </message>
    <message>
        <source>Expiration field</source>
        <translation>만료 필드</translation>
    </message>
    <message>
        <source>Expiration Presets</source>
        <translation>만료 사전 설정</translation>
    </message>
    <message>
        <source>Expiration presets</source>
        <translation>만료 사전 설정</translation>
    </message>
    <message>
        <source>Presets</source>
        <translation>사전 설정</translation>
    </message>
    <message>
        <source>Url field</source>
        <translation>URL 필드</translation>
    </message>
    <message>
        <source>Download favicon for URL</source>
        <translation>URL의 파비콘 다운로드</translation>
    </message>
    <message>
        <source>Title field</source>
        <translation>제목 필드</translation>
    </message>
    <message>
        <source>Password field</source>
        <translation>비밀번호 필드</translation>
    </message>
    <message>
        <source>Toggle expiration</source>
        <translation>만료 여부 전환</translation>
    </message>
    <message>
        <source>Tags list</source>
        <translation>태그 목록</translation>
    </message>
    <message>
        <source>&amp;Username:</source>
        <translation>사용자 이름(&amp;U):</translation>
    </message>
    <message>
        <source>&amp;Title:</source>
        <translation>제목(&amp;T):</translation>
    </message>
    <message>
        <source>&amp;Password:</source>
        <translation>비밀번호(&amp;P):</translation>
    </message>
    <message>
        <source>UR&amp;L:</source>
        <translation>URL(&amp;L):</translation>
    </message>
    <message>
        <source>&amp;Notes:</source>
        <translation>메모(&amp;N):</translation>
    </message>
    <message>
        <source>Toggle notes visibility</source>
        <translation>메모 표시 여부 전환</translation>
    </message>
    <message>
        <source>T&amp;ags:</source>
        <translation>태그(&amp;A):</translation>
    </message>
    <message>
        <source>&amp;Expires:</source>
        <translation>만료 날짜(&amp;E):</translation>
    </message>
</context>
<context>
    <name>EditEntryWidgetSSHAgent</name>
    <message>
        <source>Form</source>
        <translation>폼</translation>
    </message>
    <message>
        <source>Remove key from agent when database is closed/locked</source>
        <translation>데이터베이스를 잠그거나 닫을 때 에이전트에서 키 삭제</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>주석</translation>
    </message>
    <message>
        <source>Add key to agent when database is opened/unlocked</source>
        <translation>데이터베이스를 열거나 잠금 해제할 때 에이전트에 키 추가</translation>
    </message>
    <message>
        <source>Decrypt</source>
        <translation>복호화</translation>
    </message>
    <message>
        <source>Fingerprint</source>
        <translation>지문</translation>
    </message>
    <message>
        <source>Copy to clipboard</source>
        <translation>클립보드에 복사</translation>
    </message>
    <message>
        <source>Public key</source>
        <translation>공개 키</translation>
    </message>
    <message>
        <source>Private key</source>
        <translation>비밀 키</translation>
    </message>
    <message>
        <source>Attachment</source>
        <translation>첨부</translation>
    </message>
    <message>
        <source>External key file</source>
        <translation>외부 키 파일</translation>
    </message>
    <message>
        <source>Add to agent</source>
        <translation>에이전트에 추가</translation>
    </message>
    <message>
        <source>Remove from agent</source>
        <translation>에이전트에서 삭제</translation>
    </message>
    <message>
        <source>External file</source>
        <translation>외부 파일</translation>
    </message>
    <message>
        <source>Browser for key file</source>
        <translation>키 파일 찾아보기</translation>
    </message>
    <message>
        <source>Browse…</source>
        <extracomment>Button for opening file dialog</extracomment>
        <translation>찾아보기...</translation>
    </message>
    <message>
        <source>Generate</source>
        <translation>생성</translation>
    </message>
    <message>
        <source>Select attachment file</source>
        <translation>첨부 파일 선택</translation>
    </message>
    <message>
        <source>Require user confirmation when this key is used</source>
        <translation>이 키를 사용할 때 사용자에게 묻기</translation>
    </message>
    <message>
        <source>n/a</source>
        <translation>없음</translation>
    </message>
    <message>
        <source>Remove key from agent after</source>
        <translation>다음 시간 이후에 에이전트에서 키 삭제</translation>
    </message>
    <message>
        <source>Remove key from agent after specified seconds</source>
        <translation>다음 시간 이후에 에이전트에서 키 삭제</translation>
    </message>
    <message>
        <source> seconds</source>
        <translation>초</translation>
    </message>
    <message>
        <source>Clear agent</source>
        <translation>에이전트 지우기</translation>
    </message>
</context>
<context>
    <name>EditGroupWidget</name>
    <message>
        <source>Group</source>
        <translation>그룹</translation>
    </message>
    <message>
        <source>Icon</source>
        <translation>아이콘</translation>
    </message>
    <message>
        <source>Properties</source>
        <translation>속성</translation>
    </message>
    <message>
        <source>Add group</source>
        <translation>그룹 추가</translation>
    </message>
    <message>
        <source>Edit group</source>
        <translation>그룹 편집</translation>
    </message>
    <message>
        <source>Group has unsaved changes</source>
        <translation>그룹에 저장하지 않은 변경 사항이 있음</translation>
    </message>
    <message>
        <source>Browser Integration</source>
        <translation>브라우저 통합</translation>
    </message>
    <message>
        <source>Enable</source>
        <translation>활성화</translation>
    </message>
    <message>
        <source>Disable</source>
        <translation>비활성화</translation>
    </message>
    <message>
        <source>Inherit from parent group (%1)</source>
        <translation>부모 그룹에서 상속(%1)</translation>
    </message>
</context>
<context>
    <name>EditGroupWidgetBrowser</name>
    <message>
        <source>These settings affect to the group&apos;s behaviour with the browser extension.</source>
        <translation>이 설정은 브라우저 확장 기능에서 해당 그룹을 처리하는 방법을 변경합니다.</translation>
    </message>
    <message>
        <source>Hide entries from browser extension:</source>
        <translation>브라우저 확장 기능에서 항목 숨기기:</translation>
    </message>
    <message>
        <source>Hide entries from browser extension toggle for this and sub groups</source>
        <translation>이 그룹과 하위 그룹의 항목을 브라우저 확장 토글에서 숨기기</translation>
    </message>
    <message>
        <source>Skip Auto-Submit for entries:</source>
        <translation>항목 자동 제출 건너뛰기:</translation>
    </message>
    <message>
        <source>Skip Auto-Submit toggle for this and sub groups</source>
        <translation>이 그룹과 하위 그룹의 항목을 자동 제출 건너뛰기에서 전환</translation>
    </message>
    <message>
        <source>Use entries only with HTTP Basic Auth:</source>
        <translation>HTTP Basic 인증에만 항목 사용:</translation>
    </message>
    <message>
        <source>Only HTTP Auth toggle for this and sub groups</source>
        <translation>이 그룹과 하위 그룹의 항목을 HTTP 인증에만 사용 전환</translation>
    </message>
    <message>
        <source>Do not use entries with HTTP Basic Auth:</source>
        <translation>HTTP Basic 인증에 항목 사용하지 않음:</translation>
    </message>
    <message>
        <source>Do not use HTTP Auth toggle for this and sub groups</source>
        <translation>이 그룹과 하위 그룹의 항목을 HTTP 인증에 사용하지 않기 전환</translation>
    </message>
    <message>
        <source>Omit WWW subdomain from matching:</source>
        <translation>일치할 때 WWW 하위 도메인 제외:</translation>
    </message>
    <message>
        <source>Omit WWW subdomain from matching toggle for this and sub groups</source>
        <translation>이 그룹과 하위 그룹 항목을 일치할 때 WWW 하위 도메인 제외</translation>
    </message>
    <message>
        <source>Restrict matching to given browser key:</source>
        <translation>지정한 브라우저 키로 일치 제한:</translation>
    </message>
    <message>
        <source>Restrict matching to given browser key toggle for this and sub groups</source>
        <translation>이 그룹과 하위 그룹의 항목을 지정한 브라우저 키로 일치 제한</translation>
    </message>
</context>
<context>
    <name>EditGroupWidgetKeeShare</name>
    <message>
        <source>Sharing mode field</source>
        <translation>공유 모드 필드</translation>
    </message>
    <message>
        <source>Password field</source>
        <translation>비밀번호 필드</translation>
    </message>
    <message>
        <source>Type:</source>
        <translation>형식:</translation>
    </message>
    <message>
        <source>Password:</source>
        <translation>비밀번호:</translation>
    </message>
    <message>
        <source>Path:</source>
        <translation>경로:</translation>
    </message>
    <message>
        <source>Path to share file field</source>
        <translation>공유할 파일 경로 필드</translation>
    </message>
    <message>
        <source>Browse for share file</source>
        <translation>공유 파일 찾아보기</translation>
    </message>
    <message>
        <source>Browse…</source>
        <translation>찾아보기...</translation>
    </message>
    <message>
        <source>Clear fields</source>
        <translation>필드 비우기</translation>
    </message>
    <message>
        <source>Clear</source>
        <translation>비우기</translation>
    </message>
    <message>
        <source>Inactive</source>
        <translation>비활성</translation>
    </message>
    <message>
        <source>Import</source>
        <translation>가져오기</translation>
    </message>
    <message>
        <source>Export</source>
        <translation>내보내기</translation>
    </message>
    <message>
        <source>Synchronize</source>
        <translation>동기화</translation>
    </message>
    <message>
        <source>Your KeePassXC version does not support sharing this container type.
Supported extensions are: %1.</source>
        <translation>KeePassXC 현재 버전에서 현재 컨테이너 형식을 공유할 수 없습니다.
지원하는 확장 형식: %1.</translation>
    </message>
    <message>
        <source>%1 is already being exported by this database.</source>
        <translation>이 데이터베이스에서 %1을(를) 이미 내보내고 있습니다.</translation>
    </message>
    <message>
        <source>%1 is already being imported by this database.</source>
        <translation>이 데이터베이스에서 %1을(를) 이미 가져오고 있습니다.</translation>
    </message>
    <message>
        <source>%1 is being imported and exported by different groups in this database.</source>
        <translation>이 데이터베이스의 다른 그룹에서 %1을(를) 가져오거나 내보내고 있습니다.</translation>
    </message>
    <message>
        <source>KeeShare is currently disabled. You can enable import/export in the application settings.</source>
        <comment>KeeShare is a proper noun</comment>
        <translation>KeeShare가 비활성화되어 있습니다. 프로그램 설정에서 가져오기/내보내기를 활성화할 수 있습니다.</translation>
    </message>
    <message>
        <source>Database export is currently disabled by application settings.</source>
        <translation>프로그램 설정에서 데이터베이스 내보내기가 비활성화되어 있습니다.</translation>
    </message>
    <message>
        <source>Database import is currently disabled by application settings.</source>
        <translation>프로그램 설정에서 데이터베이스 가져오기가 비활성화되어 있습니다.</translation>
    </message>
    <message>
        <source>KeeShare container</source>
        <translation>KeeShare 컨테이너</translation>
    </message>
    <message>
        <source>KeeShare signed container</source>
        <translation>KeeShare 서명된 컨테이너</translation>
    </message>
    <message>
        <source>Select import source</source>
        <translation>가져올 원본 선택</translation>
    </message>
    <message>
        <source>Select export target</source>
        <translation>내보낼 대상 선택</translation>
    </message>
    <message>
        <source>Select import/export file</source>
        <translation>가져올/내보낼 파일 선택</translation>
    </message>
    <message>
        <source>Maintain group structure with shared database</source>
        <translation>공유 데이터베이스를 사용하여 그룹 구조 유지</translation>
    </message>
    <message>
        <source>Keep Group Structure</source>
        <translation>그룹 구조 유지</translation>
    </message>
</context>
<context>
    <name>EditGroupWidgetMain</name>
    <message>
        <source>Edit Group</source>
        <translation>그룹 편집</translation>
    </message>
    <message>
        <source>Toggle expiration</source>
        <translation>만료 여부 전환</translation>
    </message>
    <message>
        <source>Expires:</source>
        <translation>만료:</translation>
    </message>
    <message>
        <source>Name field</source>
        <translation>이름 필드</translation>
    </message>
    <message>
        <source>Expiration field</source>
        <translation>만료 필드</translation>
    </message>
    <message>
        <source>Use default Auto-Type sequence of parent group</source>
        <translation>부모 그룹의 기본 자동 입력 순서 사용</translation>
    </message>
    <message>
        <source>Auto-Type:</source>
        <translation>자동 입력:</translation>
    </message>
    <message>
        <source>Search:</source>
        <translation>찾기:</translation>
    </message>
    <message>
        <source>Auto-Type toggle for this and sub groups</source>
        <translation>이 그룹과 하위 그룹의 자동 입력 전환</translation>
    </message>
    <message>
        <source>Notes:</source>
        <translation>메모:</translation>
    </message>
    <message>
        <source>Default auto-type sequence field</source>
        <translation>기본 자동 입력 순서 필드</translation>
    </message>
    <message>
        <source>Notes field</source>
        <translation>메모 필드</translation>
    </message>
    <message>
        <source>Name:</source>
        <translation>이름:</translation>
    </message>
    <message>
        <source>Set default Auto-Type sequence</source>
        <translation>기본 자동 입력 순서 설정</translation>
    </message>
    <message>
        <source>Search toggle for this and sub groups</source>
        <translation>이 그룹과 하위 그룹의 검색 전환</translation>
    </message>
</context>
<context>
    <name>EditWidgetIcons</name>
    <message>
        <source>Use default icon</source>
        <translation>기본 아이콘 사용</translation>
    </message>
    <message>
        <source>Use custom icon</source>
        <translation>사용자 정의 아이콘 사용</translation>
    </message>
    <message>
        <source>Choose icon…</source>
        <translation>아이콘 선택...</translation>
    </message>
    <message>
        <source>Set the URL to use to search for a favicon</source>
        <translation>파비콘을 검색할 아이콘 URL 설정</translation>
    </message>
    <message>
        <source>Favicon URL</source>
        <translation>파비콘 URL</translation>
    </message>
    <message>
        <source>Download favicon for URL</source>
        <translation>URL의 파비콘 다운로드</translation>
    </message>
    <message>
        <source>Download favicon</source>
        <translation>파비콘 다운로드</translation>
    </message>
    <message>
        <source>Apply selected icon to subgroups and entries</source>
        <translation>선택한 아이콘을 하위 그룹과 항목에 적용</translation>
    </message>
    <message>
        <source>Apply icon to…</source>
        <translation>다음에 아이콘 적용…</translation>
    </message>
    <message>
        <source>Apply to this group only</source>
        <translation>이 그룹에만 적용</translation>
    </message>
    <message>
        <source>Also apply to child groups</source>
        <translation>하위 그룹에도 적용</translation>
    </message>
    <message>
        <source>Also apply to child entries</source>
        <translation>하위 항목에도 적용</translation>
    </message>
    <message>
        <source>Also apply to all children</source>
        <translation>모든 하위 항목에도 적용</translation>
    </message>
    <message>
        <source>Unable to fetch favicon.</source>
        <translation>파비콘을 다운로드할 수 없습니다.</translation>
    </message>
    <message>
        <source>Existing icon selected.</source>
        <translation>기존 아이콘을 선택했습니다.</translation>
    </message>
    <message>
        <source>Images</source>
        <translation>그림</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>모든 파일</translation>
    </message>
    <message>
        <source>Select Image(s)</source>
        <translation>이미지 선택</translation>
    </message>
    <message numerus="yes">
        <source>Successfully loaded %1 of %n icon(s)</source>
        <translation><numerusform>아이콘 %n개 중 %1개 불러옴</numerusform></translation>
    </message>
    <message>
        <source>No icons were loaded</source>
        <translation>아이콘을 불러오지 않았음</translation>
    </message>
    <message numerus="yes">
        <source>%n icon(s) already exist in the database</source>
        <translation><numerusform>데이터베이스에 아이콘 %n개가 이미 존재함</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>The following icon(s) failed:</source>
        <translation><numerusform>다음 아이콘에서 오류가 발생했습니다:</numerusform></translation>
    </message>
    <message>
        <source>You can enable the DuckDuckGo website icon service under Application Settings -&gt; Security</source>
        <translation>프로그램 설정 -&gt; 보안에서 DuckDuckGo 웹사이트 아이콘 서비스를 활성화할 수 있습니다</translation>
    </message>
</context>
<context>
    <name>EditWidgetProperties</name>
    <message>
        <source>Created:</source>
        <translation>만든 날짜:</translation>
    </message>
    <message>
        <source>Datetime created</source>
        <translation>만든 날짜</translation>
    </message>
    <message>
        <source>Modified:</source>
        <translation>수정한 날짜:</translation>
    </message>
    <message>
        <source>Datetime modified</source>
        <translation>수정한 날짜</translation>
    </message>
    <message>
        <source>Uuid:</source>
        <translation>UUID:</translation>
    </message>
    <message>
        <source>Unique ID</source>
        <translation>고유 ID</translation>
    </message>
    <message>
        <source>Plugin Data</source>
        <translation>플러그인 데이터</translation>
    </message>
    <message>
        <source>Plugin data</source>
        <translation>플러그인 데이터</translation>
    </message>
    <message>
        <source>Remove selected plugin data</source>
        <translation>선택한 플러그인 데이터 삭제</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>삭제</translation>
    </message>
    <message>
        <source>Delete plugin data?</source>
        <translation>플러그인 데이터를 삭제하시겠습니까?</translation>
    </message>
    <message>
        <source>Do you really want to delete the selected plugin data?
This may cause the affected plugins to malfunction.</source>
        <translation>선택한 플러그인 데이터를 삭제하시겠습니까?
영향받는 플러그인이 제대로 동작하지 않을 수도 있습니다.</translation>
    </message>
    <message>
        <source>Key</source>
        <translation>키</translation>
    </message>
    <message>
        <source>Value</source>
        <translation>값</translation>
    </message>
</context>
<context>
    <name>Entry</name>
    <message>
        <source>%1 - Clone</source>
        <translation>%1 - 사본</translation>
    </message>
    <message>
        <source>Passkey</source>
        <translation>패스키</translation>
    </message>
    <message>
        <source>Invalid conversion type: %1</source>
        <translation>잘못된 변환 형식: %1</translation>
    </message>
    <message>
        <source>Invalid conversion syntax: %1</source>
        <translation>잘못된 변환 문법: %1</translation>
    </message>
    <message>
        <source>Invalid regular expression syntax %1
%2</source>
        <translation>잘못된 정규 표현식 문법 %1
%2</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>제목</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>사용자 이름</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>비밀번호</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>Notes</source>
        <translation>참고</translation>
    </message>
    <message>
        <source>Custom Attributes</source>
        <translation>사용자 지정 속성</translation>
    </message>
    <message>
        <source>Icon</source>
        <translation>아이콘</translation>
    </message>
    <message>
        <source>Color</source>
        <translation>색상</translation>
    </message>
    <message>
        <source>Expiration</source>
        <translation>만료</translation>
    </message>
    <message>
        <source>TOTP</source>
        <translation>TOTP</translation>
    </message>
    <message>
        <source>Custom Data</source>
        <translation>사용자 지정 데이터</translation>
    </message>
    <message>
        <source>Attachments</source>
        <translation>첨부 파일</translation>
    </message>
    <message>
        <source>Auto-Type</source>
        <translation>자동 유형</translation>
    </message>
    <message>
        <source>Tags</source>
        <translation>태그</translation>
    </message>
</context>
<context>
    <name>EntryAttachments</name>
    <message>
        <source>Cannot open file &quot;%1&quot;</source>
        <translation>파일 &quot;%1&quot;을(를) 열 수 없음</translation>
    </message>
</context>
<context>
    <name>EntryAttachmentsModel</name>
    <message>
        <source>Name</source>
        <translation>이름</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>크기</translation>
    </message>
</context>
<context>
    <name>EntryAttachmentsWidget</name>
    <message>
        <source>Form</source>
        <translation>폼</translation>
    </message>
    <message>
        <source>Attachments</source>
        <translation>첨부</translation>
    </message>
    <message>
        <source>Add new attachment</source>
        <translation>새 첨부 파일 추가</translation>
    </message>
    <message>
        <source>Remove selected attachment</source>
        <translation>선택한 첨부 파일 삭제</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>삭제</translation>
    </message>
    <message>
        <source>Open selected attachment</source>
        <translation>선택한 첨부 파일 열기</translation>
    </message>
    <message>
        <source>Open</source>
        <translation>열기</translation>
    </message>
    <message>
        <source>Save selected attachment to disk</source>
        <translation>선택한 첨부 파일 저장</translation>
    </message>
    <message>
        <source>Select files</source>
        <translation>파일 선택</translation>
    </message>
    <message>
        <source>Confirm remove</source>
        <translation>삭제 확인</translation>
    </message>
    <message numerus="yes">
        <source>Are you sure you want to remove %n attachment(s)?</source>
        <translation><numerusform>첨부 항목 %n개를 삭제하시겠습니까?</numerusform></translation>
    </message>
    <message>
        <source>Save attachments</source>
        <translation>첨부 항목 저장</translation>
    </message>
    <message>
        <source>Unable to create directory:
%1</source>
        <translation>디렉터리를 만들 수 없음:
%1</translation>
    </message>
    <message>
        <source>Are you sure you want to overwrite the existing file &quot;%1&quot; with the attachment?</source>
        <translation>기존 파일 &quot;%1&quot;의 내용을 첨부 항목으로 덮어쓰시겠습니까?</translation>
    </message>
    <message>
        <source>Confirm overwrite</source>
        <translation>덮어쓰기 확인</translation>
    </message>
    <message>
        <source>Unable to save attachments:
%1</source>
        <translation>첨부 항목을 저장할 수 없음:
%1</translation>
    </message>
    <message>
        <source>Unable to open attachment:
%1</source>
        <translation>첨부 항목을 열 수 없음:
%1</translation>
    </message>
    <message>
        <source>Unable to open attachments:
%1</source>
        <translation>첨부 항목을 열 수 없음:
%1</translation>
    </message>
    <message numerus="yes">
        <source>Unable to open file(s):
%1</source>
        <translation><numerusform>파일을 열 수 없음:
%1</numerusform></translation>
    </message>
    <message>
        <source>Confirm Overwrite Attachment</source>
        <translation>첨부 덮어쓰기 확인</translation>
    </message>
    <message>
        <source>Confirm Attachment</source>
        <translation>첨부 확인</translation>
    </message>
    <message>
        <source>%1 is a big file (%2 MB).
Your database may get very large and reduce performance.

Are you sure to add this file?</source>
        <translation>파일 %1이(가) 큽니다(%2 MB).
데이터베이스 크기가 커질 수도 있으며 성능이 저하될 수도 있습니다.

이 파일을 추가하시겠습니까?</translation>
    </message>
    <message>
        <source>Attachment modified</source>
        <translation>첨부 수정됨</translation>
    </message>
    <message>
        <source>The attachment '%1' was modified.
Do you want to save the changes to your database?</source>
        <translation>첨부 &apos;%1&apos;이(가) 수정되었습니다.
변경 사항을 데이터베이스에 저장하시겠습니까?</translation>
    </message>
    <message>
        <source>Saving attachment failed</source>
        <translation>첨부 저장 실패</translation>
    </message>
    <message>
        <source>Saving updated attachment failed.
Error: %1</source>
        <translation>업데이트된 첨부 항목을 저장할 수 없습니다.
오류: %1</translation>
    </message>
    <message>
        <source>Attachment &quot;%1&quot; already exists. 
Would you like to overwrite the existing attachment?</source>
        <translation>첨부 &quot;%1&quot;이(가) 이미 있습니다.
기존 첨부 항목을 덮어쓰시겠습니까?</translation>
    </message>
    <message>
        <source>Preview</source>
        <translation>미리 보기</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>편집</translation>
    </message>
    <message>
        <source>New Text Document</source>
        <translation>새 텍스트 문서</translation>
    </message>
    <message>
        <source>Add file…</source>
        <translation>파일 추가...</translation>
    </message>
    <message>
        <source>Load from Disk…</source>
        <translation>디스크에서 로드...</translation>
    </message>
    <message>
        <source>Save…</source>
        <translation>저장...</translation>
    </message>
    <message>
        <source>New Attachment</source>
        <translation>새 첨부 파일</translation>
    </message>
</context>
<context>
    <name>EntryAttributesModel</name>
    <message>
        <source>Name</source>
        <translation>이름</translation>
    </message>
</context>
<context>
    <name>EntryHistoryModel</name>
    <message>
        <source>Current (%1)</source>
        <translation>현재(%1)</translation>
    </message>
    <message>
        <source>Last modified</source>
        <translation>마지막 수정</translation>
    </message>
    <message>
        <source>Age</source>
        <translation>시기</translation>
    </message>
    <message>
        <source>Difference</source>
        <translation>차이</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>크기</translation>
    </message>
</context>
<context>
    <name>EntryModel</name>
    <message>
        <source>Ref: </source>
        <comment>Reference abbreviation</comment>
        <translation>참조: </translation>
    </message>
    <message>
        <source>Never</source>
        <translation>하지 않음</translation>
    </message>
    <message>
        <source>Group</source>
        <translation>그룹</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>제목</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>사용자 이름</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>비밀번호</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>Notes</source>
        <translation>메모</translation>
    </message>
    <message>
        <source>Expires</source>
        <translation>만료 기간</translation>
    </message>
    <message>
        <source>Created</source>
        <translation>생성</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>수정됨</translation>
    </message>
    <message>
        <source>Attachments</source>
        <translation>첨부</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>크기</translation>
    </message>
    <message>
        <source>Group name</source>
        <translation>그룹 이름</translation>
    </message>
    <message>
        <source>Entry title</source>
        <translation>항목 이름</translation>
    </message>
    <message>
        <source>Password Strength</source>
        <translation>비밀번호 강도</translation>
    </message>
    <message>
        <source>Entry notes</source>
        <translation>항목 메모</translation>
    </message>
    <message>
        <source>Entry expires at</source>
        <translation>항목 만료 시간</translation>
    </message>
    <message>
        <source>Creation date</source>
        <translation>만든 날짜</translation>
    </message>
    <message>
        <source>Last modification date</source>
        <translation>마지막 수정한 날짜</translation>
    </message>
    <message>
        <source>Attached files</source>
        <translation>첨부된 파일</translation>
    </message>
    <message>
        <source>Entry size</source>
        <translation>항목 크기</translation>
    </message>
    <message>
        <source>Has attachments</source>
        <translation>첨부 항목 있음</translation>
    </message>
    <message>
        <source>Has TOTP</source>
        <translation>TOTP 있음</translation>
    </message>
    <message>
        <source>Background Color</source>
        <translation>배경색</translation>
    </message>
    <message>
        <source>Group Path</source>
        <translation>그룹 경로</translation>
    </message>
</context>
<context>
    <name>EntryPreviewWidget</name>
    <message>
        <source>Display current TOTP value</source>
        <translation>현재 TOTP 값 표시</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>닫기</translation>
    </message>
    <message>
        <source>General</source>
        <translation>일반</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>비밀번호</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>Expiration</source>
        <translation>만료</translation>
    </message>
    <message>
        <source>Tags</source>
        <translation>태그</translation>
    </message>
    <message>
        <source>Tags list</source>
        <translation>태그 목록</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>사용자 이름</translation>
    </message>
    <message>
        <source>Notes</source>
        <translation>메모</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>고급</translation>
    </message>
    <message>
        <source>Attachments</source>
        <translation>첨부</translation>
    </message>
    <message>
        <source>Attributes</source>
        <translation>속성</translation>
    </message>
    <message>
        <source>Autotype</source>
        <translation>자동 입력</translation>
    </message>
    <message>
        <source>Default Sequence</source>
        <translation>기본 시퀀스</translation>
    </message>
    <message>
        <source>Window</source>
        <translation>창</translation>
    </message>
    <message>
        <source>Sequence</source>
        <translation>순서</translation>
    </message>
    <message>
        <source>Searching</source>
        <translation>찾기</translation>
    </message>
    <message>
        <source>Share</source>
        <translation>공유</translation>
    </message>
    <message>
        <source>Search</source>
        <translation>찾기</translation>
    </message>
    <message>
        <source>Clear</source>
        <translation>비우기</translation>
    </message>
    <message>
        <source>Never</source>
        <translation>하지 않음</translation>
    </message>
    <message>
        <source>Double click to copy value</source>
        <translation>두 번 클릭하여 값 복사</translation>
    </message>
    <message>
        <source>Enabled</source>
        <translation>사용함</translation>
    </message>
    <message>
        <source>Disabled</source>
        <translation>사용 안함</translation>
    </message>
    <message>
        <source>Double click to copy to clipboard</source>
        <translation>두 번 클릭하여 클립보드에 복사</translation>
    </message>
</context>
<context>
    <name>EntryURLModel</name>
    <message>
        <source>Invalid URL</source>
        <translation>잘못된 URL</translation>
    </message>
    <message>
        <source>Duplicate URL</source>
        <translation>URL 복제</translation>
    </message>
</context>
<context>
    <name>EntryView</name>
    <message>
        <source>Fit to window</source>
        <translation>창에 맞춤</translation>
    </message>
    <message>
        <source>Fit to contents</source>
        <translation>내용에 맞춤</translation>
    </message>
    <message>
        <source>Reset to defaults</source>
        <translation>기본값으로 복원</translation>
    </message>
    <message numerus="yes">
        <source>+ %1 entry(s)...</source>
        <translation><numerusform>+ 항목 %1개...</numerusform></translation>
    </message>
</context>
<context>
    <name>ExportDialog</name>
    <message>
        <source>Export options</source>
        <translation>내보내기 옵션</translation>
    </message>
    <message>
        <source>Sort entries by...</source>
        <translation>항목 정렬 순서...</translation>
    </message>
    <message>
        <source>You are about to export your database to an unencrypted file.
This will leave your passwords and sensitive information vulnerable!
</source>
        <translation>데이터베이스를 암호화되지 않은 파일로 내보냅니다.
비밀번호와 기타 민감 정보를 노출시킬 수 있습니다!
</translation>
    </message>
    <message>
        <source>database order</source>
        <translation>데이터베이스 순서</translation>
    </message>
    <message>
        <source>name (ascending)</source>
        <translation>이름(가나다순)</translation>
    </message>
    <message>
        <source>name (descending)</source>
        <translation>이름(가나다 역순)</translation>
    </message>
    <message>
        <source>Export database to HTML file</source>
        <translation>데이터베이스를 HTML 파일로 내보내기</translation>
    </message>
    <message>
        <source>HTML file</source>
        <translation>HTML 파일</translation>
    </message>
    <message>
        <source>invalid sort order</source>
        <translation>잘못된 정렬 순서</translation>
    </message>
</context>
<context>
    <name>FdoSecrets::DBusMgr</name>
    <message>
        <source>Failed to deliver message</source>
        <translation>메시지를 전송할 수 없음</translation>
    </message>
    <message>
        <source>Failed to send reply on DBus</source>
        <translation>DBus에 응답을 보낼 수 없음</translation>
    </message>
    <message>
        <source>Unknown</source>
        <comment>Unknown PID</comment>
        <translation>알 수 없음</translation>
    </message>
    <message>
        <source>Unknown</source>
        <comment>Unknown executable path</comment>
        <translation>알 수 없음</translation>
    </message>
    <message>
        <source>&lt;i&gt;PID: %1, Executable: %2&lt;/i&gt;</source>
        <comment>&lt;i&gt;PID: 1234, Executable: /path/to/exe&lt;/i&gt;</comment>
        <translation>&lt;i&gt;PID: %1, 실행 파일: %2&lt;/i&gt;</translation>
    </message>
    <message>
        <source>Another secret service is running (%1).&lt;br/&gt;Please stop/remove it before re-enabling the Secret Service Integration.</source>
        <translation>다른 비밀 서비스(%1)가 실행 중입니다.&lt;br/&gt;비밀 서비스 통합을 다시 활성화하기 전에 정지/삭제하십시오.</translation>
    </message>
    <message>
        <source>Failed to register DBus service at %1.&lt;br/&gt;</source>
        <translation>%1에 DBus 서비스를 등록할 수 없습니다.&lt;br/&gt;</translation>
    </message>
    <message>
        <source>Failed to register service on DBus at path &apos;%1&apos;</source>
        <translation>서비스를 DBus 경로 &apos;%1&apos;에 등록할 수 없음</translation>
    </message>
    <message>
        <source>Failed to register database on DBus under the name &apos;%1&apos;</source>
        <translation>데이터베이스를 DBus에 이름 &apos;%1&apos;(으)로 등록할 수 없음</translation>
    </message>
    <message>
        <source>Failed to register session on DBus at path &apos;%1&apos;</source>
        <translation>세션을 DBus 경로 &apos;%1&apos;에 등록할 수 없음</translation>
    </message>
    <message>
        <source>Failed to register item on DBus at path &apos;%1&apos;</source>
        <translation>항목을 DBus 경로 &apos;%1&apos;에 등록할 수 없음</translation>
    </message>
    <message>
        <source>Failed to register prompt object on DBus at path &apos;%1&apos;</source>
        <translation>프롬프트 객체를 DBus 경로 &apos;%1&apos;에 등록할 수 없음</translation>
    </message>
</context>
<context>
    <name>FdoSecrets::Item</name>
    <message>
        <source>Entry &quot;%1&quot; from database &quot;%2&quot; was used by %3</source>
        <translation>%3이(가) 데이터베이스 &quot;%2&quot;의 항목 &quot;%1&quot;을(를) 사용함</translation>
    </message>
</context>
<context>
    <name>FdoSecrets::Service</name>
    <message numerus="yes">
        <source>%n Entry(s) was used by %1</source>
        <comment>%1 is the name of an application</comment>
        <translation><numerusform>%1에서 항목 %n개 사용함</numerusform></translation>
    </message>
</context>
<context>
    <name>FdoSecrets::SettingsClientModel</name>
    <message>
        <source>Unknown</source>
        <translation>알 수 없음</translation>
    </message>
    <message>
        <source>Non-existing/inaccessible executable path. Please double-check the client is legit.</source>
        <translation>실행 파일 경로가 존재하지 않거나 접근할 수 없습니다. 클라이언트가 올바른지 확인하십시오.</translation>
    </message>
</context>
<context>
    <name>FdoSecrets::SettingsDatabaseModel</name>
    <message>
        <source>Unlock to show</source>
        <translation>잠금 해제해서 보기</translation>
    </message>
    <message>
        <source>None</source>
        <translation>없음</translation>
    </message>
</context>
<context>
    <name>FdoSecrets::UnlockPrompt</name>
    <message>
        <source>%1 (PID: %2)</source>
        <translation>%1(PID: %2)</translation>
    </message>
</context>
<context>
    <name>FdoSecretsPlugin</name>
    <message>
        <source>&lt;b&gt;Fdo Secret Service:&lt;/b&gt; %1</source>
        <translation>&lt;b&gt;Fdo 비밀 서비스:&lt;/b&gt; %1</translation>
    </message>
</context>
<context>
    <name>GlobalShortcutsPortal</name>
    <message>
        <source>KeePassXC - Global Shortcuts</source>
        <translation>KeePassXC - 전역 단축키</translation>
    </message>
    <message>
        <source>The XDG Desktop Portal for global shortcuts is not available on this system.</source>
        <translation>이 시스템에서는 전역 단축키를 위한 XDG 데스크탑 포털을 사용할 수 없습니다.</translation>
    </message>
    <message>
        <source>Global Auto-Type shortcut is already configured. To change it, open your system settings and navigate to the keyboard or application shortcuts section.</source>
        <translation>전역  지동 입력 단축키가 이미 구성되어 있습니다. 변경하려면 시스템 설정을 열고 키보드 또는 응용 프로그램 단축키 섹션으로 이동하세요.</translation>
    </message>
    <message>
        <source>Trigger global Auto-Type</source>
        <translation>전역 자동 입력 활성화</translation>
    </message>
</context>
<context>
    <name>Group</name>
    <message>
        <source>[empty]</source>
        <comment>group has no children</comment>
        <translation>[비어 있음]</translation>
    </message>
    <message>
        <source>%1 - Clone</source>
        <translation>%1 - 사본</translation>
    </message>
</context>
<context>
    <name>HibpDownloader</name>
    <message>
        <source>Online password validation failed</source>
        <translation>온라인 비밀번호 검증 실패</translation>
    </message>
</context>
<context>
    <name>IconDownloaderDialog</name>
    <message>
        <source>Download Favicons</source>
        <translation>파비콘 다운로드</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>취소</translation>
    </message>
    <message>
        <source>Having trouble downloading icons?
You can enable the DuckDuckGo website icon service in the security section of the application settings.</source>
        <translation>다운로드에 문제가 있나요?
프로그램 설정의 보안 부분에서 DuckDuckGo 웹 사이트 아이콘 서비스를 활성화할 수 있습니다.</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>닫기</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>상태</translation>
    </message>
    <message>
        <source>Please wait, processing entry list…</source>
        <translation>기다려 주십시오. 항목 목록 처리 중…</translation>
    </message>
    <message>
        <source>Downloading…</source>
        <translation>다운로드 중…</translation>
    </message>
    <message>
        <source>Ok</source>
        <translation>확인</translation>
    </message>
    <message>
        <source>Already Exists</source>
        <translation>이미 존재함</translation>
    </message>
    <message>
        <source>Download Failed</source>
        <translation>다운로드 실패</translation>
    </message>
    <message>
        <source>Downloading favicons (%1/%2)…</source>
        <translation>파비콘 다운로드 중(%1/%2)…</translation>
    </message>
</context>
<context>
    <name>ImageAttachmentsWidget</name>
    <message>
        <source>Zoom:</source>
        <translation>확대/축소:</translation>
    </message>
    <message>
        <source>Fit</source>
        <translation>맟추기</translation>
    </message>
</context>
<context>
    <name>ImportWizard</name>
    <message>
        <source>Import Wizard</source>
        <translation>가져오기 마법사</translation>
    </message>
</context>
<context>
    <name>ImportWizardPageReview</name>
    <message>
        <source>WizardPage</source>
        <translation>마법사페이지</translation>
    </message>
    <message>
        <source>Entry count: %1</source>
        <translation>항목 개수: %1</translation>
    </message>
    <message>
        <source>Group</source>
        <translation>그룹</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>제목</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>사용자 이름</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>비밀번호</translation>
    </message>
    <message>
        <source>Url</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>Could not load key file.</source>
        <translation>키 파일을 로드할 수 없습니다.</translation>
    </message>
    <message>
        <source>Could not open remote database. Password or key file may be incorrect.</source>
        <translation>원격 데이터베이스를 열 수 없습니다. 비밀번호나 키 파일이 잘못되었을 수 있습니다.</translation>
    </message>
</context>
<context>
    <name>ImportWizardPageSelect</name>
    <message>
        <source>Form</source>
        <translation>폼</translation>
    </message>
    <message>
        <source>Import File Selection</source>
        <translation>가져올 파일 선택</translation>
    </message>
    <message>
        <source>Password:</source>
        <translation>비밀번호:</translation>
    </message>
    <message>
        <source>Key File:</source>
        <translation>키 파일:</translation>
    </message>
    <message>
        <source>Browse…</source>
        <translation>찾아보기...</translation>
    </message>
    <message>
        <source>Import Into:</source>
        <translation>다음으로 가져오기:</translation>
    </message>
    <message>
        <source>New Database</source>
        <translation>새 데이터베이스</translation>
    </message>
    <message>
        <source>No unlocked databases available</source>
        <translation>잠금 해제된 데이터베이스가 없음</translation>
    </message>
    <message>
        <source>Existing Database:</source>
        <translation>기존 데이터베이스:</translation>
    </message>
    <message>
        <source>Import File:</source>
        <translation>가져올 파일:</translation>
    </message>
    <message>
        <source>Comma Separated Values (.csv)</source>
        <translation>쉼표로 구분된 값 (.csv)</translation>
    </message>
    <message>
        <source>1Password Export (.1pux)</source>
        <translation>1Password 내보내기 (.1pux)</translation>
    </message>
    <message>
        <source>1Password Vault (.opvault)</source>
        <translation>1Password Vault (.opvault)</translation>
    </message>
    <message>
        <source>Bitwarden (.json)</source>
        <translation>Bitwarden (.json)</translation>
    </message>
    <message>
        <source>KeePass 1 Database (.kdb)</source>
        <translation>KeePass 1 데이터베이스 (.kdb)</translation>
    </message>
    <message>
        <source>Open OPVault</source>
        <translation>OPVault 열기</translation>
    </message>
    <message>
        <source>Select import file</source>
        <translation>가져올 파일 선택</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>모든 파일</translation>
    </message>
    <message>
        <source>Key files</source>
        <translation>키 파일</translation>
    </message>
    <message>
        <source>Select key file</source>
        <translation>키 파일 선택</translation>
    </message>
    <message>
        <source>Comma Separated Values</source>
        <translation>쉼표로 구분된 값</translation>
    </message>
    <message>
        <source>1Password Export</source>
        <translation>1Password 내보내기</translation>
    </message>
    <message>
        <source>Bitwarden JSON Export</source>
        <translation>Bitwarden JSON 내보내기</translation>
    </message>
    <message>
        <source>1Password Vault</source>
        <translation>1Password Vault</translation>
    </message>
    <message>
        <source>KeePass1 Database</source>
        <translation>KeePass1 데이터베이스</translation>
    </message>
    <message>
        <source>Proton Pass (.json)</source>
        <translation>Proton Pass (.json)</translation>
    </message>
    <message>
        <source>Proton Pass JSON Export</source>
        <translation>Proton Pass JSON 내보내기</translation>
    </message>
    <message>
        <source>Temporary Database</source>
        <translation>임시 데이터베이스</translation>
    </message>
    <message>
        <source>Command:</source>
        <translation>명령:</translation>
    </message>
    <message>
        <source>e.g.: &quot;sftp user@hostname&quot; or &quot;scp user@hostname:DatabaseOnRemote.kdbx {TEMP_DATABASE}&quot;</source>
        <translation>예제: &quot;sftp user@hostname&quot; 또는 &quot;scp user@hostname:DatabaseOnRemote.kdbx {TEMP_DATABASE}&quot;</translation>
    </message>
    <message>
        <source>Input:</source>
        <translation>입력:</translation>
    </message>
    <message>
        <source>e.g.:
get DatabaseOnRemote.kdbx {TEMP_DATABASE}
exit
---
{TEMP_DATABASE} is used as placeholder to store the database in a temporary location
The command has to exit. In case of `sftp` as last commend `exit` has to be sent
         </source>
        <translation>예:
DatabaseOnRemote.kdbx {TEMP_DATAbase} 가져오기
종료
---
{TEMP_DATABase}는 임시 위치에 데이터베이스를 저장하는 자리 표시자로 사용됩니다
명령이 종료되어야 합니다. 마지막으로 &apos;sftp&apos;인 경우 &apos;exit&apos;를 보내야 합니다</translation>
    </message>
    <message>
        <source>Remote Database (.kdbx)</source>
        <translation>원격 데이터베이스 (.kdbx)</translation>
    </message>
</context>
<context>
    <name>KMessageWidget</name>
    <message>
        <source>&amp;Close</source>
        <translation>닫기(&amp;C)</translation>
    </message>
    <message>
        <source>Close message</source>
        <translation>메시지 닫기</translation>
    </message>
</context>
<context>
    <name>Kdbx3Reader</name>
    <message>
        <source>Missing database headers</source>
        <translation>데이터베이스 헤더 없음</translation>
    </message>
    <message>
        <source>Unable to calculate database key</source>
        <translation>데이터베이스 키를 계산할 수 없음</translation>
    </message>
    <message>
        <source>Unable to issue challenge-response: %1</source>
        <translation>Challenge-Response를 생성할 수 없음: %1</translation>
    </message>
    <message>
        <source>Invalid credentials were provided, please try again.
If this reoccurs, then your database file may be corrupt.</source>
        <translation>자격 증명이 잘못되었습니다. 다시 시도하십시오.
같은 오류가 계속 발생한다면 데이터베이스 파일이 손상되었을 수도 있습니다.</translation>
    </message>
    <message>
        <source>Header doesn&apos;t match hash</source>
        <translation>헤더의 해시가 일치하지 않음</translation>
    </message>
    <message>
        <source>Invalid header id size</source>
        <translation>잘못된 헤더 ID 크기</translation>
    </message>
    <message>
        <source>Invalid header field length: field %1</source>
        <translation>잘못된 헤더 필드 길이: 필드 %1</translation>
    </message>
    <message>
        <source>Invalid header data length: field %1, %2 expected, %3 found</source>
        <translation>잘못된 헤더 데이터 길이 %1, %2 예상됨, 실제 %3</translation>
    </message>
</context>
<context>
    <name>Kdbx3Writer</name>
    <message>
        <source>Invalid symmetric cipher IV size.</source>
        <comment>IV = Initialization Vector for symmetric cipher</comment>
        <translation>잘못된 대칭 키 암호화 IV 크기입니다.</translation>
    </message>
    <message>
        <source>Unable to issue challenge-response: %1</source>
        <translation>Challenge-Response를 생성할 수 없음: %1</translation>
    </message>
    <message>
        <source>Unable to calculate database key</source>
        <translation>데이터베이스 키를 계산할 수 없음</translation>
    </message>
</context>
<context>
    <name>Kdbx4Reader</name>
    <message>
        <source>missing database headers</source>
        <translation>데이터베이스 헤더 없음</translation>
    </message>
    <message>
        <source>Unable to calculate database key: %1</source>
        <translation>데이터베이스 키를 계산할 수 없음: %1</translation>
    </message>
    <message>
        <source>Invalid header checksum size</source>
        <translation>잘못된 헤더 체크섬 크기</translation>
    </message>
    <message>
        <source>Header SHA256 mismatch</source>
        <translation>헤더 SHA256이 일치하지 않음</translation>
    </message>
    <message>
        <source>Invalid credentials were provided, please try again.
If this reoccurs, then your database file may be corrupt.</source>
        <translation>자격 증명이 잘못되었습니다. 다시 시도하십시오.
같은 오류가 계속 발생한다면 데이터베이스 파일이 손상되었을 수도 있습니다.</translation>
    </message>
    <message>
        <source>(HMAC mismatch)</source>
        <translation>(HMAC 일치하지 않음)</translation>
    </message>
    <message>
        <source>Unknown cipher</source>
        <translation>알 수 없는 암호화</translation>
    </message>
    <message>
        <source>Invalid header id size</source>
        <translation>잘못된 헤더 ID 크기</translation>
    </message>
    <message>
        <source>Invalid header field length: field %1</source>
        <translation>잘못된 헤더 필드 길이: 필드 %1</translation>
    </message>
    <message>
        <source>Invalid header data length: field %1, %2 expected, %3 found</source>
        <translation>잘못된 헤더 데이터 길이 %1, %2 예상됨, 실제 %3</translation>
    </message>
    <message>
        <source>Failed to open buffer for KDF parameters in header</source>
        <translation>헤더에 있는 키 유도 함수 인자에 필요한 버퍼를 열 수 없음</translation>
    </message>
    <message>
        <source>Unsupported key derivation function (KDF) or invalid parameters</source>
        <translation>지원하지 않는 키 유도 함수(KDF) 및 잘못된 인자</translation>
    </message>
    <message>
        <source>Legacy header fields found in KDBX4 file.</source>
        <translation>KDBX4 파일에 레거시 헤더 필드가 있습니다.</translation>
    </message>
    <message>
        <source>Invalid inner header id size</source>
        <translation>잘못된 내부 헤더 ID 크기</translation>
    </message>
    <message>
        <source>Invalid inner header field length: field %1</source>
        <translation>잘못된 내부 헤더 필드 길이: 필드 %1</translation>
    </message>
    <message>
        <source>Invalid inner header data length: field %1, %2 expected, %3 found</source>
        <translation>잘못된 내부 헤더 데이터 길이 %1, %2 예상됨, 실제 %3</translation>
    </message>
    <message>
        <source>Invalid inner header binary size</source>
        <translation>잘못된 내부 헤더 바이너리 크기</translation>
    </message>
    <message>
        <source>Unsupported KeePass variant map version.</source>
        <extracomment>Translation: variant map = data structure for storing meta data</extracomment>
        <translation>지원하지 않는 KeePass 메타데이터 저장소 버전입니다.</translation>
    </message>
    <message>
        <source>Invalid variant map entry name length</source>
        <extracomment>Translation: variant map = data structure for storing meta data</extracomment>
        <translation>잘못된 메타데이터 저장소 항목 이름 길이</translation>
    </message>
    <message>
        <source>Invalid variant map entry name data</source>
        <extracomment>Translation: variant map = data structure for storing meta data</extracomment>
        <translation>잘못된 메타데이터 저장소 이름 데이터</translation>
    </message>
    <message>
        <source>Invalid variant map entry value length</source>
        <extracomment>Translation: variant map = data structure for storing meta data</extracomment>
        <translation>잘못된 메타데이터 저장소 값 길이</translation>
    </message>
    <message>
        <source>Invalid variant map entry value data</source>
        <extracomment>Translation comment: variant map = data structure for storing meta data</extracomment>
        <translation>잘못된 메타데이터 저장소 값 데이터</translation>
    </message>
    <message>
        <source>Invalid variant map Bool entry value length</source>
        <extracomment>Translation: variant map = data structure for storing meta data</extracomment>
        <translation>잘못된 메타데이터 저장소 Bool 항목 값 길이</translation>
    </message>
    <message>
        <source>Invalid variant map Int32 entry value length</source>
        <extracomment>Translation: variant map = data structure for storing meta data</extracomment>
        <translation>잘못된 메타데이터 저장소 Int32 항목 값 길이</translation>
    </message>
    <message>
        <source>Invalid variant map UInt32 entry value length</source>
        <extracomment>Translation: variant map = data structure for storing meta data</extracomment>
        <translation>잘못된 메타데이터 저장소 UInt32 항목 값 길이</translation>
    </message>
    <message>
        <source>Invalid variant map Int64 entry value length</source>
        <extracomment>Translation: variant map = data structure for storing meta data</extracomment>
        <translation>잘못된 메타데이터 저장소 Int64 항목 값 길이</translation>
    </message>
    <message>
        <source>Invalid variant map UInt64 entry value length</source>
        <extracomment>Translation: variant map = data structure for storing meta data</extracomment>
        <translation>잘못된 메타데이터 저장소 UInt64 항목 값 길이</translation>
    </message>
    <message>
        <source>Invalid variant map entry type</source>
        <extracomment>Translation: variant map = data structure for storing meta data</extracomment>
        <translation>잘못된 메타데이터 저장소 항목 형식</translation>
    </message>
    <message>
        <source>Invalid variant map field type size</source>
        <extracomment>Translation: variant map = data structure for storing meta data</extracomment>
        <translation>잘못된 메타데이터 저장소 필드 형식 크기</translation>
    </message>
</context>
<context>
    <name>Kdbx4Writer</name>
    <message>
        <source>Invalid symmetric cipher algorithm.</source>
        <translation>잘못된 대칭 키 암호화 알고리즘입니다.</translation>
    </message>
    <message>
        <source>Invalid symmetric cipher IV size.</source>
        <comment>IV = Initialization Vector for symmetric cipher</comment>
        <translation>잘못된 대칭 키 암호화 IV 크기입니다.</translation>
    </message>
    <message>
        <source>Unable to calculate database key: %1</source>
        <translation>데이터베이스 키를 계산할 수 없음: %1</translation>
    </message>
    <message>
        <source>Failed to serialize KDF parameters variant map</source>
        <extracomment>Translation comment: variant map = data structure for storing meta data</extracomment>
        <translation>키 유도 함수 인자 메타데이터 저장소를 직렬화할 수 없음</translation>
    </message>
</context>
<context>
    <name>KdbxReader</name>
    <message>
        <source>Invalid cipher uuid length: %1 (length=%2)</source>
        <translation>잘못된 암호화 UUID 길이: %1(length=%2)</translation>
    </message>
    <message>
        <source>Unable to parse UUID: %1</source>
        <translation>UUID를 처리할 수 없음: %1</translation>
    </message>
    <message>
        <source>Unsupported cipher</source>
        <translation>지원하지 않는 암호화</translation>
    </message>
    <message>
        <source>Invalid compression flags length</source>
        <translation>잘못된 압축 플래그 길이</translation>
    </message>
    <message>
        <source>Unsupported compression algorithm</source>
        <translation>지원하지 않는 압축 알고리즘</translation>
    </message>
    <message>
        <source>Invalid master seed size</source>
        <translation>잘못된 마스터 시드 크기</translation>
    </message>
    <message>
        <source>Invalid transform seed size</source>
        <translation>잘못된 변형 시드 크기</translation>
    </message>
    <message>
        <source>Invalid transform rounds size</source>
        <translation>잘못된 변형 라운드 크기</translation>
    </message>
    <message>
        <source>Invalid start bytes size</source>
        <translation>잘못된 시작 바이트 크기</translation>
    </message>
    <message>
        <source>Invalid random stream id size</source>
        <translation>잘못된 무작위 스트림 ID 크기</translation>
    </message>
    <message>
        <source>Invalid inner random stream cipher</source>
        <translation>잘못된 내부 무작위 스트림 암호화</translation>
    </message>
    <message>
        <source>Failed to read database file.</source>
        <translation>데이터베이스 파일을 읽을 수 없습니다.</translation>
    </message>
    <message>
        <source>The selected file is an old KeePass 1 database (.kdb).

You can import it by clicking on Database &gt; 'Import KeePass 1 database…'.
This is a one-way migration. You won&apos;t be able to open the imported database with the old KeePassX 0.4 version.</source>
        <translation>선택한 파일은 KeePass 1 데이터베이스(.kdb)입니다.

데이터베이스 &gt; &apos;KeePass 1 데이터베이스 가져오기…&apos; 메뉴 항목을 클릭해서 변환해야 합니다.
변환은 한 방향으로만 이루어지며, 가져온 데이터베이스는 KeePassX 0.4 버전으로 더 이상 열 수 없습니다.</translation>
    </message>
    <message>
        <source>Not a KeePass database.</source>
        <translation>KeePass 데이터베이스가 아닙니다.</translation>
    </message>
    <message>
        <source>Unsupported KeePass 2 database version.</source>
        <translation>지원하지 않는 KeePass 2 데이터베이스 버전입니다.</translation>
    </message>
</context>
<context>
    <name>KdbxXmlReader</name>
    <message>
        <source>XML parsing failure: %1</source>
        <translation>XML 처리 실패: %1</translation>
    </message>
    <message>
        <source>No root group</source>
        <translation>루트 그룹 없음</translation>
    </message>
    <message>
        <source>XML error:
%1
Line %2, column %3</source>
        <translation>XML 오류:
%1
%2줄, %3칸</translation>
    </message>
    <message>
        <source>Missing icon uuid or data</source>
        <translation>아이콘 UUID나 데이터 없음</translation>
    </message>
    <message>
        <source>Missing custom data key or value</source>
        <translation>사용자 정의 데이터 키나 값이 없음</translation>
    </message>
    <message>
        <source>Multiple group elements</source>
        <translation>여러 개의 그룹 원소</translation>
    </message>
    <message>
        <source>Null group uuid</source>
        <translation>빈 그룹 UUID</translation>
    </message>
    <message>
        <source>Invalid group icon number</source>
        <translation>잘못된 그룹 아이콘 번호</translation>
    </message>
    <message>
        <source>Invalid EnableAutoType value</source>
        <translation>잘못된 EnableAutoType 값</translation>
    </message>
    <message>
        <source>Invalid EnableSearching value</source>
        <translation>잘못된 EnableSearching 값</translation>
    </message>
    <message>
        <source>No group uuid found</source>
        <translation>그룹 UUID를 찾을 수 없음</translation>
    </message>
    <message>
        <source>Null DeleteObject uuid</source>
        <translation>비어 있는 DeleteObject UUID</translation>
    </message>
    <message>
        <source>Missing DeletedObject uuid or time</source>
        <translation>DeletedObject UUID나 시간이 없음</translation>
    </message>
    <message>
        <source>Null entry uuid</source>
        <translation>빈 항목 UUID</translation>
    </message>
    <message>
        <source>Invalid entry icon number</source>
        <translation>잘못된 항목 아이콘 번호</translation>
    </message>
    <message>
        <source>History element in history entry</source>
        <translation>과거 기록 항목의 과거 기록 원소</translation>
    </message>
    <message>
        <source>No entry uuid found</source>
        <translation>항목 UUID를 찾을 수 없음</translation>
    </message>
    <message>
        <source>History element with different uuid</source>
        <translation>다른 UUID를 사용하는 과거 기록 원소</translation>
    </message>
    <message>
        <source>Duplicate custom attribute found</source>
        <translation>중복된 사용자 정의 속성이 있음</translation>
    </message>
    <message>
        <source>Entry string key or value missing</source>
        <translation>항목 문자열 키나 값이 없음</translation>
    </message>
    <message>
        <source>Entry binary key or value missing</source>
        <translation>항목 바이너리 키나 값이 없음</translation>
    </message>
    <message>
        <source>Auto-type association window or sequence missing</source>
        <translation>자동 입력 연결 창이나 순서가 없음</translation>
    </message>
    <message>
        <source>Invalid bool value</source>
        <translation>잘못된 이진값</translation>
    </message>
    <message>
        <source>Invalid date time value</source>
        <translation>잘못된 날짜/시간 값</translation>
    </message>
    <message>
        <source>Invalid color value</source>
        <translation>잘못된 색상 값</translation>
    </message>
    <message>
        <source>Invalid color rgb part</source>
        <translation>잘못된 색상 RGB 부분</translation>
    </message>
    <message>
        <source>Invalid number value</source>
        <translation>잘못된 숫자 값</translation>
    </message>
    <message>
        <source>Invalid uuid value</source>
        <translation>잘못된 UUID 값</translation>
    </message>
    <message>
        <source>Unable to decompress binary</source>
        <extracomment>Translator meant is a binary data inside an entry</extracomment>
        <translation>바이너리 압축을 해제할 수 없음</translation>
    </message>
</context>
<context>
    <name>KeeAgentSettings</name>
    <message>
        <source>Invalid KeeAgent settings file structure.</source>
        <translation>KeeAgent 설정 파일 구조가 잘못되었습니다.</translation>
    </message>
    <message>
        <source>Private key is an attachment but no attachments provided.</source>
        <translation>비밀 키를 첨부된 항목에서 사용하기로 했으나 첨부된 항목을 지정하지 않았습니다.</translation>
    </message>
    <message>
        <source>Private key is empty</source>
        <translation>비밀 키가 비어 있음</translation>
    </message>
    <message>
        <source>File too large to be a private key</source>
        <translation>비밀 키로 사용하기에 파일이 너무 큼</translation>
    </message>
    <message>
        <source>Failed to open private key</source>
        <translation>비밀 키를 열 수 없음</translation>
    </message>
</context>
<context>
    <name>KeePass1Reader</name>
    <message>
        <source>Unable to read keyfile.</source>
        <translation>키 파일을 읽을 수 없습니다.</translation>
    </message>
    <message>
        <source>Not a KeePass database.</source>
        <translation>KeePass 데이터베이스가 아닙니다.</translation>
    </message>
    <message>
        <source>Unsupported encryption algorithm.</source>
        <translation>지원하지 않는 암호화 알고리즘입니다.</translation>
    </message>
    <message>
        <source>Unsupported KeePass database version.</source>
        <translation>지원하지 않는 KeePass 데이터베이스 버전입니다.</translation>
    </message>
    <message>
        <source>Unable to read encryption IV</source>
        <comment>IV = Initialization Vector for symmetric cipher</comment>
        <translation>암호화 IV를 읽을 수 없음</translation>
    </message>
    <message>
        <source>Invalid number of groups</source>
        <translation>잘못된 그룹 개수</translation>
    </message>
    <message>
        <source>Invalid number of entries</source>
        <translation>잘못된 항목 개수</translation>
    </message>
    <message>
        <source>Invalid content hash size</source>
        <translation>잘못된 내용 해시 크기</translation>
    </message>
    <message>
        <source>Invalid transform seed size</source>
        <translation>잘못된 변형 시드 크기</translation>
    </message>
    <message>
        <source>Invalid number of transform rounds</source>
        <translation>잘못된 변형 라운드 크기</translation>
    </message>
    <message>
        <source>Unable to construct group tree</source>
        <translation>그룹 트리를 만들 수 없음</translation>
    </message>
    <message>
        <source>Root</source>
        <translation>루트</translation>
    </message>
    <message>
        <source>Unable to calculate database key</source>
        <translation>데이터베이스 키를 계산할 수 없음</translation>
    </message>
    <message>
        <source>unable to seek to content position</source>
        <translation>내용 위치로 이동할 수 없음</translation>
    </message>
    <message>
        <source>Invalid credentials were provided, please try again.
If this reoccurs, then your database file may be corrupt.</source>
        <translation>자격 증명이 잘못되었습니다. 다시 시도하십시오.
같은 오류가 계속 발생한다면 데이터베이스 파일이 손상되었을 수도 있습니다.</translation>
    </message>
    <message>
        <source>Key transformation failed</source>
        <translation>키 변형 실패</translation>
    </message>
    <message>
        <source>Invalid group field type number</source>
        <translation>잘못된 그룹 필드 형식 번호</translation>
    </message>
    <message>
        <source>Invalid group field size</source>
        <translation>잘못된 그룹 필드 크기</translation>
    </message>
    <message>
        <source>Read group field data doesn&apos;t match size</source>
        <translation>읽은 그룹 필드 데이터와 크기가 일치하지 않음</translation>
    </message>
    <message>
        <source>Incorrect group id field size</source>
        <translation>잘못된 그룹 ID 필드 크기</translation>
    </message>
    <message>
        <source>Incorrect group creation time field size</source>
        <translation>잘못된 그룹 생성 시간 필드 크기</translation>
    </message>
    <message>
        <source>Incorrect group modification time field size</source>
        <translation>잘못된 그룹 수정 시간 필드 크기</translation>
    </message>
    <message>
        <source>Incorrect group access time field size</source>
        <translation>잘못된 그룹 접근 시간 필드 크기</translation>
    </message>
    <message>
        <source>Incorrect group expiry time field size</source>
        <translation>잘못된 그룹 만료 시간 필드 크기</translation>
    </message>
    <message>
        <source>Incorrect group icon field size</source>
        <translation>잘못된 그룹 아이콘 필드 크기</translation>
    </message>
    <message>
        <source>Incorrect group level field size</source>
        <translation>잘못된 그룹 단계 필드 크기</translation>
    </message>
    <message>
        <source>Invalid group field type</source>
        <translation>잘못된 그룹 필드 형싞</translation>
    </message>
    <message>
        <source>Missing group id or level</source>
        <translation>그룹 ID나 단계가 없음</translation>
    </message>
    <message>
        <source>Missing entry field type number</source>
        <translation>그룹 항목 형식 번호가 없음</translation>
    </message>
    <message>
        <source>Invalid entry field size</source>
        <translation>잘못된 항목 필드 크기</translation>
    </message>
    <message>
        <source>Read entry field data doesn&apos;t match size</source>
        <translation>읽은 항목 필드 데이터와 크기가 일치하지 않음</translation>
    </message>
    <message>
        <source>Invalid entry UUID field size</source>
        <translation>잘못된 항목 UUID 필드 크기</translation>
    </message>
    <message>
        <source>Invalid entry group id field size</source>
        <translation>잘못된 항목 그룹 ID 필드 크기</translation>
    </message>
    <message>
        <source>Invalid entry icon field size</source>
        <translation>잘못된 항목 아이콘 필드 크기</translation>
    </message>
    <message>
        <source>Invalid entry creation time field size</source>
        <translation>잘못된 항목 생성 시간 필드 크기</translation>
    </message>
    <message>
        <source>Invalid entry modification time field size</source>
        <translation>잘못된 항목 수정 시간 필드 크기</translation>
    </message>
    <message>
        <source>Invalid entry expiry time field size</source>
        <translation>잘못된 항목 만료 시간 필드 크기</translation>
    </message>
    <message>
        <source>Invalid entry field type</source>
        <translation>잘못된 항목 필드 크기</translation>
    </message>
</context>
<context>
    <name>KeeShare</name>
    <message>
        <source>Invalid sharing reference</source>
        <translation>잘못된 공유 참조</translation>
    </message>
    <message>
        <source>Inactive share %1</source>
        <translation>비활성 공유 %1</translation>
    </message>
    <message>
        <source>Imported from %1</source>
        <translation>%1에서 가져옴</translation>
    </message>
    <message>
        <source>Exported to %1</source>
        <translation>%1(으)로 내보냄</translation>
    </message>
    <message>
        <source>Synchronized with %1</source>
        <translation>%1와(과) 동기화됨</translation>
    </message>
    <message>
        <source>Import is disabled in settings</source>
        <translation>설정에서 가져오기가 비활성화됨</translation>
    </message>
    <message>
        <source>Export is disabled in settings</source>
        <translation>설정에서 내보내기가 비활성화됨</translation>
    </message>
    <message>
        <source>Inactive share</source>
        <translation>비활성 공유</translation>
    </message>
    <message>
        <source>Imported from</source>
        <translation>가져온 위치:</translation>
    </message>
    <message>
        <source>Exported to</source>
        <translation>내보낸 위치:</translation>
    </message>
    <message>
        <source>Synchronized with</source>
        <translation>동기화 대상:</translation>
    </message>
</context>
<context>
    <name>KeyComponentWidget</name>
    <message>
        <source>Key Component</source>
        <translation>키 구성 요소</translation>
    </message>
    <message>
        <source>Key Component Description</source>
        <translation>키 구성 요소 설명</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>취소</translation>
    </message>
    <message>
        <source>Key Component set, click to change or remove</source>
        <translation>키 구성 요소 집합, 눌러서 변경하거나 삭제</translation>
    </message>
</context>
<context>
    <name>KeyFileEditWidget</name>
    <message>
        <source>Generate a new key file</source>
        <translation>새 키 파일 생성</translation>
    </message>
    <message>
        <source>Generate</source>
        <translation>생성</translation>
    </message>
    <message>
        <source>Generate a new key file or choose an existing one to protect your database.</source>
        <translation>데이터베이스를 안전하게 보호할 수 있는 새 키 파일을 생성하거나 기존 파일을 선택할 수 있습니다.</translation>
    </message>
    <message>
        <source>Note: Do NOT use a file that may change as that will prevent you from unlocking your database.</source>
        <translation>메모: 변경될 수 있는 파일을 사용하면 나중에 데이터베이스의 잠금을 해제하지 못할 수도 있습니다.</translation>
    </message>
    <message>
        <source>Browse for key file</source>
        <translation>키 파일 찾아보기</translation>
    </message>
    <message>
        <source>Browse…</source>
        <translation>찾아보기...</translation>
    </message>
    <message>
        <source>Old key file format</source>
        <translation>이전 키 파일 형식</translation>
    </message>
    <message>
        <source>You selected a key file in an old format which KeePassXC&lt;br&gt;may stop supporting in the future.&lt;br&gt;&lt;br&gt;Please consider generating a new key file instead.</source>
        <translation>KeePassXC에서 차후에 지원을 중단할 수도 있는&lt;br&gt;이전 키 파일 형식을 사용하고 있습니다.&lt;br&gt;&lt;br&gt;새 키 파일을 생성하기를 추천합니다:</translation>
    </message>
    <message>
        <source>Error loading the key file '%1'
Message: %2</source>
        <translation>키 파일 &apos;%1&apos;을(를) 불러올 수 없음
메시지: %2</translation>
    </message>
    <message>
        <source>Key File</source>
        <translation>키 파일</translation>
    </message>
    <message>
        <source>Add Key File</source>
        <translation>키 파일 추가</translation>
    </message>
    <message>
        <source>Change Key File</source>
        <translation>키 파일 변경</translation>
    </message>
    <message>
        <source>Remove Key File</source>
        <translation>키 파일 삭제</translation>
    </message>
    <message>
        <source>Key File set, click to change or remove</source>
        <translation>키 파일 설정됨, 클릭해서 변경하거나 삭제</translation>
    </message>
    <message>
        <source>&lt;p&gt;You can add a key file containing random bytes for additional security.&lt;/p&gt;&lt;p&gt;You must keep it secret and never lose it or you will be locked out.&lt;/p&gt;</source>
        <translation>&lt;p&gt;무작위 바이트가 들어 있는 키 파일을 추가하여 보안을 향상시킬 수 있습니다.&lt;/p&gt;&lt;p&gt;키 파일을 안전한 곳에 보관해야 하며 키 파일을 잃어버리면 데이터베이스에 접근할 수 없습니다.&lt;/p&gt;</translation>
    </message>
    <message>
        <source>Key files</source>
        <translation>키 파일</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>모든 파일</translation>
    </message>
    <message>
        <source>Create Key File…</source>
        <translation>키 파일 만들기…</translation>
    </message>
    <message>
        <source>Error creating key file</source>
        <translation>키 파일 생성 오류</translation>
    </message>
    <message>
        <source>Unable to create key file: %1</source>
        <translation>키 파일을 만들 수 없음: %1</translation>
    </message>
    <message>
        <source>Select a key file</source>
        <translation>키 파일 선택</translation>
    </message>
    <message>
        <source>Invalid Key File</source>
        <translation>잘못된 키 파일</translation>
    </message>
    <message>
        <source>You cannot use the current database as its own keyfile. Please choose a different file or generate a new key file.</source>
        <translation>데이터베이스 파일을 자기 자신의 키 파일로 사용할 수 없습니다. 다른 파일을 선택하거나 새 키 파일을 생성하십시오.</translation>
    </message>
    <message>
        <source>Suspicious Key File</source>
        <translation>의심되는 키 파일</translation>
    </message>
    <message>
        <source>The chosen key file looks like a password database file. A key file must be a static file that never changes or you will lose access to your database forever.
Are you sure you want to continue with this file?</source>
        <translation>선택한 키 파일이 비밀번호 데이터베이스 파일 같습니다. 키 파일은 변경되지 않을 파일이어야 하며 파일이 변경되면 데이터베이스에 더 이상 접근할 수 없습니다.
이 파일을 그래도 사용하시겠습니까?</translation>
    </message>
</context>
<context>
    <name>MacUtils</name>
    <message>
        <source>Invalid key code</source>
        <translation>잘못된 키 코드</translation>
    </message>
    <message>
        <source>Global shortcut already registered to %1</source>
        <translation>전역 단축키가 이미 %1에 등록됨</translation>
    </message>
    <message>
        <source>Could not register global shortcut</source>
        <translation>전역 단축키를 등록할 수 없음</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>&amp;Database</source>
        <translation>데이터베이스(&amp;D)</translation>
    </message>
    <message>
        <source>&amp;Recent Databases</source>
        <translation>최근 데이터베이스(&amp;R)</translation>
    </message>
    <message>
        <source>&amp;Export</source>
        <translation>내보내기(&amp;E)</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>도움말(&amp;H)</translation>
    </message>
    <message>
        <source>&amp;Entries</source>
        <translation>항목(&amp;E)</translation>
    </message>
    <message>
        <source>Copy Att&amp;ribute</source>
        <translation>속성 복사(&amp;R)</translation>
    </message>
    <message>
        <source>TOTP</source>
        <translation>TOTP</translation>
    </message>
    <message>
        <source>Tags</source>
        <translation>태그</translation>
    </message>
    <message>
        <source>&amp;Groups</source>
        <translation>그룹(&amp;G)</translation>
    </message>
    <message>
        <source>&amp;Tools</source>
        <translation>도구(&amp;T)</translation>
    </message>
    <message>
        <source>View</source>
        <translation>보기</translation>
    </message>
    <message>
        <source>Theme</source>
        <translation>테마</translation>
    </message>
    <message>
        <source>&amp;Quit</source>
        <translation>끝내기(&amp;Q)</translation>
    </message>
    <message>
        <source>&amp;About</source>
        <translation>정보(&amp;A)</translation>
    </message>
    <message>
        <source>&amp;Check for Updates</source>
        <translation>업데이트 확인(&amp;C)</translation>
    </message>
    <message>
        <source>&amp;Open Database…</source>
        <translation>데이터베이스 열기(&amp;O)...</translation>
    </message>
    <message>
        <source>&amp;Save Database</source>
        <translation>데이터베이스 저장(&amp;S)</translation>
    </message>
    <message>
        <source>&amp;Close Database</source>
        <translation>데이터베이스 닫기(&amp;C)</translation>
    </message>
    <message>
        <source>&amp;New Database…</source>
        <translation>새 데이터베이스(&amp;N)...</translation>
    </message>
    <message>
        <source>&amp;Merge From Database…</source>
        <translation>데이터베이스에서 합치기(&amp;M)...</translation>
    </message>
    <message>
        <source>&amp;New Entry…</source>
        <translation>새 항목(&amp;N)...</translation>
    </message>
    <message>
        <source>&amp;Edit Entry…</source>
        <translation>항목 편집(&amp;E)...</translation>
    </message>
    <message>
        <source>&amp;New Group…</source>
        <translation>새 그룹(&amp;N)...</translation>
    </message>
    <message>
        <source>&amp;Edit Group…</source>
        <translation>그룹 편집(&amp;E)...</translation>
    </message>
    <message>
        <source>&amp;Delete Group…</source>
        <translation>그룹 삭제(&amp;D)...</translation>
    </message>
    <message>
        <source>Download All &amp;Favicons…</source>
        <translation>모든 파비콘 다운로드(&amp;F)...</translation>
    </message>
    <message>
        <source>Sort &amp;A-Z</source>
        <translation>가나다순 정렬(&amp;A)</translation>
    </message>
    <message>
        <source>Sort &amp;Z-A</source>
        <translation>가나다 역순 정렬(&amp;Z)</translation>
    </message>
    <message>
        <source>Sa&amp;ve Database As…</source>
        <translation>다른 이름으로 데이터베이스 저장(&amp;V)...</translation>
    </message>
    <message>
        <source>Database &amp;Security…</source>
        <translation>데이터베이스 보안(&amp;S)...</translation>
    </message>
    <message>
        <source>Database &amp;Reports…</source>
        <translation>데이터베이스 보고서(&amp;R)…</translation>
    </message>
    <message>
        <source>&amp;Database Settings…</source>
        <translation>데이터베이스 설정(&amp;D)...</translation>
    </message>
    <message>
        <source>&amp;Clone Entry…</source>
        <translation>항목 복제(&amp;C)...</translation>
    </message>
    <message>
        <source>Move u&amp;p</source>
        <translation>위로 이동(&amp;P)</translation>
    </message>
    <message>
        <source>Move do&amp;wn</source>
        <translation>아래로 이동(&amp;W)</translation>
    </message>
    <message>
        <source>Copy &amp;Username</source>
        <translation>사용자 이름 복사(&amp;U)</translation>
    </message>
    <message>
        <source>Copy &amp;Password</source>
        <translation>비밀번호 복사(&amp;P)</translation>
    </message>
    <message>
        <source>&amp;Settings</source>
        <translation>설정(&amp;S)</translation>
    </message>
    <message>
        <source>&amp;Password Generator</source>
        <translation>비밀번호 생성기(&amp;P)</translation>
    </message>
    <message>
        <source>Perform &amp;Auto-Type</source>
        <translation>자동 입력 실행(&amp;A)</translation>
    </message>
    <message>
        <source>Download &amp;Favicon</source>
        <translation>파비콘 다운로드(&amp;F)</translation>
    </message>
    <message>
        <source>Open &amp;URL</source>
        <translation>URL 열기(&amp;U)</translation>
    </message>
    <message>
        <source>&amp;Lock Database</source>
        <translation>데이터베이스 잠금(&amp;L)</translation>
    </message>
    <message>
        <source>Lock &amp;All Databases</source>
        <translation>모든 데이터베이스 잠금(&amp;A)</translation>
    </message>
    <message>
        <source>&amp;Title</source>
        <translation>제목(&amp;T)</translation>
    </message>
    <message>
        <source>Copy &amp;URL</source>
        <translation>URL 복사(&amp;U)</translation>
    </message>
    <message>
        <source>&amp;Notes</source>
        <translation>메모(&amp;N)</translation>
    </message>
    <message>
        <source>&amp;CSV File…</source>
        <translation>CSV 파일(&amp;C)...</translation>
    </message>
    <message>
        <source>&amp;HTML File…</source>
        <translation>HTML 파일(&amp;H)...</translation>
    </message>
    <message>
        <source>KeePass 1 Database…</source>
        <translation>KeePass 1 데이터베이스...</translation>
    </message>
    <message>
        <source>1Password Vault…</source>
        <translation>1Password Vault...</translation>
    </message>
    <message>
        <source>CSV File…</source>
        <translation>CSV 파일...</translation>
    </message>
    <message>
        <source>Show TOTP</source>
        <translation>TOTP 표시</translation>
    </message>
    <message>
        <source>Show QR Code</source>
        <translation>QR 코드 표시</translation>
    </message>
    <message>
        <source>Set up TOTP…</source>
        <translation>TOTP 설정...</translation>
    </message>
    <message>
        <source>Copy &amp;TOTP</source>
        <translation>TOTP 복사(&amp;T)</translation>
    </message>
    <message>
        <source>Copy Password and TOTP</source>
        <translation>비밀번호와 TOTP 복사</translation>
    </message>
    <message>
        <source>E&amp;mpty recycle bin</source>
        <translation>휴지통 비우기(&amp;M)</translation>
    </message>
    <message>
        <source>&amp;Donate</source>
        <translation>기부(&amp;D)</translation>
    </message>
    <message>
        <source>Report a &amp;Bug</source>
        <translation>버그 보고(&amp;B)</translation>
    </message>
    <message>
        <source>&amp;Getting Started</source>
        <translation>시작하기(&amp;G)</translation>
    </message>
    <message>
        <source>Open Getting Started Guide</source>
        <translation>시작하기 도움말 열기</translation>
    </message>
    <message>
        <source>&amp;Online Help</source>
        <translation>온라인 도움말(&amp;O)</translation>
    </message>
    <message>
        <source>&amp;User Guide</source>
        <translation>사용자 가이드(&amp;U)</translation>
    </message>
    <message>
        <source>Open User Guide</source>
        <translation>사용자 가이드 열기</translation>
    </message>
    <message>
        <source>&amp;Keyboard Shortcuts</source>
        <translation>키보드 단축키(&amp;K)</translation>
    </message>
    <message>
        <source>Save Database Backup…</source>
        <translation>데이터베이스 백업 저장…</translation>
    </message>
    <message>
        <source>Add key to SSH Agent</source>
        <translation>SSH 에이전트에 키 추가</translation>
    </message>
    <message>
        <source>Remove key from SSH Agent</source>
        <translation>SSH 에이전트에서 키 삭제</translation>
    </message>
    <message>
        <source>Compact Mode</source>
        <translation>축소 모드</translation>
    </message>
    <message>
        <source>Automatic</source>
        <translation>자동</translation>
    </message>
    <message>
        <source>Light</source>
        <translation>밝음</translation>
    </message>
    <message>
        <source>Dark</source>
        <translation>어두움</translation>
    </message>
    <message>
        <source>Classic (Platform-native)</source>
        <translation>고전(플랫폼 네이티브)</translation>
    </message>
    <message>
        <source>Show Menubar</source>
        <translation>메뉴 표시줄 표시</translation>
    </message>
    <message>
        <source>Show Toolbar</source>
        <translation>도구 모음 표시</translation>
    </message>
    <message>
        <source>Show Preview Panel</source>
        <translation>미리 보기 패널 표시</translation>
    </message>
    <message>
        <source>Always on Top</source>
        <translation>항상 위</translation>
    </message>
    <message>
        <source>Hide Usernames</source>
        <translation>사용자 이름 숨기기</translation>
    </message>
    <message>
        <source>Hide Passwords</source>
        <translation>비밀번호 숨기기</translation>
    </message>
    <message>
        <source>Clone Group...</source>
        <translation>그룹 복제...</translation>
    </message>
    <message>
        <source>&amp;XML File…</source>
        <translation>XML 파일(&amp;X)...</translation>
    </message>
    <message>
        <source>Clear history</source>
        <translation>과거 기록 삭제</translation>
    </message>
    <message>
        <source>Access error for config file %1</source>
        <translation>설정 파일 %1에 접근할 수 없음</translation>
    </message>
    <message>
        <source>Don&apos;t show again for this version</source>
        <translation>이 버전에서 다시 표시하지 않기</translation>
    </message>
    <message>
        <source>No Tags</source>
        <translation>태그 없음</translation>
    </message>
    <message numerus="yes">
        <source>Restore Entry(s)</source>
        <translation><numerusform>항목 복원</numerusform></translation>
    </message>
    <message>
        <source>Settings</source>
        <translation>설정</translation>
    </message>
    <message>
        <source>Check for updates on startup?</source>
        <translation>시작할 때 업데이트를 확인하시겠습니까?</translation>
    </message>
    <message>
        <source>Would you like KeePassXC to check for updates on startup?</source>
        <translation>KeePassXC를 시작할 때 업데이트를 확인하시겠습니까?</translation>
    </message>
    <message>
        <source>You can always check for updates manually from the application menu.</source>
        <translation>언제든지 프로그램 메뉴에서 수동으로 업데이트를 확인할 수 있습니다.</translation>
    </message>
    <message>
        <source>Toggle window</source>
        <translation>창 전환</translation>
    </message>
    <message>
        <source>Quit KeePassXC</source>
        <translation>KeePassXC 끝내기</translation>
    </message>
    <message numerus="yes">
        <source>%1 Entry(s)</source>
        <translation><numerusform>항목 %1개</numerusform></translation>
    </message>
    <message>
        <source>Please present or touch your YubiKey to continue…</source>
        <translation>계속 진행하려면 YubiKey를 연결하거나 버튼을 누르십시오...</translation>
    </message>
    <message>
        <source>Restart Application?</source>
        <translation>프로그램을 다시 시작하시겠습니까?</translation>
    </message>
    <message>
        <source>You must restart the application to apply this setting. Would you like to restart now?</source>
        <translation>이 설정을 적용하려면 프로그램을 다시 시작해야 합니다. 지금 다시 시작하시겠습니까?</translation>
    </message>
    <message>
        <source>Allow Screen Capture</source>
        <translation>화면 캡처 허용</translation>
    </message>
    <message>
        <source>1Password 1PUX...</source>
        <translation>1Password 1PUX...</translation>
    </message>
    <message>
        <source>Import a 1Password 1PUX file</source>
        <translation>1Password 1PUX 파일 가져오기</translation>
    </message>
    <message>
        <source>Import…</source>
        <translation>가져오기…</translation>
    </message>
    <message>
        <source>Passkeys…</source>
        <translation>패스키…</translation>
    </message>
    <message>
        <source>Import Passkey</source>
        <translation>패스키 가져오기</translation>
    </message>
    <message>
        <source>Remote S&amp;ync…</source>
        <translation>원격 동기화(&amp;Y)…</translation>
    </message>
    <message>
        <source>Quit Application</source>
        <translation>프로그램 끝내기</translation>
    </message>
    <message>
        <source>Open About Dialog</source>
        <translation>정보 대화 상자 열기</translation>
    </message>
    <message>
        <source>Open Database</source>
        <translation>데이터베이스 열기</translation>
    </message>
    <message>
        <source>Create Database</source>
        <translation>데이터베이스 만들기</translation>
    </message>
    <message>
        <source>Merge From Database</source>
        <translation>데이터베이스에서 합치기</translation>
    </message>
    <message>
        <source>Edit Entry</source>
        <translation>항목 편집</translation>
    </message>
    <message>
        <source>Delete Entry</source>
        <translation>항목 삭제</translation>
    </message>
    <message>
        <source>Create Group</source>
        <translation>그룹 만들기</translation>
    </message>
    <message>
        <source>Edit Group</source>
        <translation>그룹 편집</translation>
    </message>
    <message>
        <source>Delete Group</source>
        <translation>그룹 삭제</translation>
    </message>
    <message>
        <source>Download All Favicons</source>
        <translation>모든 파비콘 다운로드</translation>
    </message>
    <message>
        <source>Sort Groups A-Z</source>
        <translation>그룹 가나다순 정렬</translation>
    </message>
    <message>
        <source>Sort Groups Z-A</source>
        <translation>그룹 가나다 역순 정렬</translation>
    </message>
    <message>
        <source>Save Database As</source>
        <translation>다른 이름으로 데이터베이스 저장</translation>
    </message>
    <message>
        <source>Show Database Security</source>
        <translation>데이터베이스 보안 표시</translation>
    </message>
    <message>
        <source>Show Database Reports</source>
        <translation>데이터베이스 보고서 표시</translation>
    </message>
    <message>
        <source>Show Database Settings</source>
        <translation>데이터베이스 설정 표시</translation>
    </message>
    <message>
        <source>Show Passkeys</source>
        <translation>Passkey 표시</translation>
    </message>
    <message>
        <source>Clone Entry</source>
        <translation>항목 복제</translation>
    </message>
    <message>
        <source>Move Entry Up</source>
        <translation>항목 위로 이동</translation>
    </message>
    <message>
        <source>Move Entry Down</source>
        <translation>항목 아래로 이동</translation>
    </message>
    <message>
        <source>Copy Username</source>
        <translation>사용자 이름 복사</translation>
    </message>
    <message>
        <source>Copy Password</source>
        <translation>암호 복사</translation>
    </message>
    <message>
        <source>Show Application Settings</source>
        <translation>프로그램 설정 표시</translation>
    </message>
    <message>
        <source>Show Password Generator</source>
        <translation>암호 생성기 표시</translation>
    </message>
    <message>
        <source>Remove Passkey From Entry</source>
        <translation>항목에서 패스키 삭제</translation>
    </message>
    <message>
        <source>Perform Auto-Type: {USERNAME}</source>
        <translation>자동 입력 실행: {USERNAME}</translation>
    </message>
    <message>
        <source>Perform Auto-Type: {USERNAME}{ENTER}</source>
        <translation>자동 입력 실행: {USERNAME}{ENTER}</translation>
    </message>
    <message>
        <source>Perform Auto-Type: {PASSWORD}</source>
        <translation>자동 입력 실행: {PASSWORD}</translation>
    </message>
    <message>
        <source>Perform Auto-Type: {PASSWORD}{ENTER}</source>
        <translation>자동 입력 실행: {PASSWORD}{ENTER}</translation>
    </message>
    <message>
        <source>Perform Auto-Type: {TOTP}</source>
        <translation>자동 입력 실행: {TOTP}</translation>
    </message>
    <message>
        <source>Copy Title</source>
        <translation>제목 복사</translation>
    </message>
    <message>
        <source>Copy URL</source>
        <translation>URL 복사</translation>
    </message>
    <message>
        <source>Copy Notes</source>
        <translation>메모 복사</translation>
    </message>
    <message>
        <source>Export to CSV</source>
        <translation>CSV로 내보내기</translation>
    </message>
    <message>
        <source>Export to HTML</source>
        <translation>HTML로 내보내기</translation>
    </message>
    <message>
        <source>Import KeePass1 Database</source>
        <translation>KeePass1 데이터베이스 가져오기</translation>
    </message>
    <message>
        <source>Import 1Password Vault</source>
        <translation>1Password Valut에서 가져오기</translation>
    </message>
    <message>
        <source>Import CSV File</source>
        <translation>CSV 파일 가져오기</translation>
    </message>
    <message>
        <source>Show TOTP QR Code</source>
        <translation>TOTP QR 코드 표시</translation>
    </message>
    <message>
        <source>Set up TOTP</source>
        <translation>TOTP 설정</translation>
    </message>
    <message>
        <source>Empty Recycle Bin</source>
        <translation>휴지통 비우기</translation>
    </message>
    <message>
        <source>Open Donation Website</source>
        <translation>기부 웹사이트 열기</translation>
    </message>
    <message>
        <source>Open Bug Report</source>
        <translation>버그 보고 열기</translation>
    </message>
    <message>
        <source>Open Online Documentation</source>
        <translation>온라인 문서 열기</translation>
    </message>
    <message>
        <source>Open Keyboard Shortcuts Guide</source>
        <translation>키보드 단축키 도움말 열기</translation>
    </message>
    <message>
        <source>Save Database Backup</source>
        <translation>데이터베이스 백업 저장</translation>
    </message>
    <message>
        <source>SSH Agent: Add Key</source>
        <translation>SSH 에이전트: 키 추가</translation>
    </message>
    <message>
        <source>SSH Agent: Remove Key</source>
        <translation>SSH 에이전트: 키 삭제</translation>
    </message>
    <message>
        <source>Toggle Compact Mode</source>
        <translation>축소 모드 전환</translation>
    </message>
    <message>
        <source>Set Theme: Automatic</source>
        <translation>테마 설정: 자동</translation>
    </message>
    <message>
        <source>Set Theme: Light</source>
        <translation>테마 설정: 밝음</translation>
    </message>
    <message>
        <source>Set Theme: Dark</source>
        <translation>테마 설정: 어두움</translation>
    </message>
    <message>
        <source>Set Theme: Classic</source>
        <translation>테마 설정: 고전</translation>
    </message>
    <message>
        <source>Toggle Show Menubar</source>
        <translation>메뉴 표시줄 표시 전환</translation>
    </message>
    <message>
        <source>Toggle Show Toolbar</source>
        <translation>도구 모음 표시 전환</translation>
    </message>
    <message>
        <source>Toggle Show Preview Panel</source>
        <translation>미리 보기 패널 표시 전환</translation>
    </message>
    <message>
        <source>Toggle Always on Top</source>
        <translation>항상 위 전환</translation>
    </message>
    <message>
        <source>Toggle Hide Usernames</source>
        <translation>사용자 이름 숨기기 전환</translation>
    </message>
    <message>
        <source>Toggle Hide Passwords</source>
        <translation>암호 숨기기 전환</translation>
    </message>
    <message>
        <source>Export to XML</source>
        <translation>XML로 내보내기</translation>
    </message>
    <message>
        <source>Toggle Allow Screen Capture</source>
        <translation>화면 캡처 허용 전환</translation>
    </message>
    <message>
        <source>Show Group Panel</source>
        <translation>그룹 패널 표시</translation>
    </message>
    <message>
        <source>Toggle Show Group Panel</source>
        <translation>그룹 패널 표시 전환</translation>
    </message>
    <message>
        <source>Setup Remote Sync…</source>
        <translation>원격 동기화 설정…</translation>
    </message>
    <message>
        <source>WARNING: You are using a development snapshot build of KeePassXC.
Maintain a backup of your databases in the event of unknown bugs.
This version is not meant for production use.</source>
        <translation>경고: 현재 KeePassXC의 개발 스냅샷 빌드를 사용하고 있습니다.
알 수 없는 버그가 발생할 경우를 대비해 데이터베이스 백업을 유지하세요.
이 버전은 운영 환경에서 사용하도록 설계된 것이 아닙니다.</translation>
    </message>
    <message>
        <source>Clear SSH Agent</source>
        <translation>SSH 에이전트 지우기</translation>
    </message>
    <message>
        <source>Clear all identities in ssh-agent</source>
        <translation>SSH 에이전트에서 모든 ID 지우기</translation>
    </message>
    <message>
        <source>New Entry</source>
        <translation>새 항목</translation>
    </message>
    <message>
        <source>Password Generator</source>
        <translation>비밀번호 생성기</translation>
    </message>
    <message>
        <source>Edit Entry…</source>
        <translation>항목 편집...</translation>
    </message>
    <message>
        <source>E&amp;xpire Entry</source>
        <translation>만료 항목(&amp;X)</translation>
    </message>
    <message>
        <source>Expire Entry</source>
        <translation>만료 항목</translation>
    </message>
    <message>
        <source>&amp;Delete Entry</source>
        <translation>항목 삭제(&amp;D)</translation>
    </message>
    <message numerus="yes">
        <source>Move selected entry(s) to the recycle bin</source>
        <translation><numerusform>선택한 항목을 휴지통으로 이동</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>Permanently delete the selected entry(s)</source>
        <translation><numerusform>선택한 항목을 영구적으로 삭제</numerusform></translation>
    </message>
</context>
<context>
    <name>ManageDatabase</name>
    <message>
        <source>Database settings</source>
        <translation>데이터베이스 설정</translation>
    </message>
    <message>
        <source>Edit database settings</source>
        <translation>데이터베이스 설정 편집</translation>
    </message>
    <message>
        <source>Unlock database</source>
        <translation>데이터베이스 잠금 해제</translation>
    </message>
    <message>
        <source>Unlock database to show more information</source>
        <translation>더 많은 정보를 보려면 데이터베이스 잠금을 해제하십시오</translation>
    </message>
    <message>
        <source>Lock database</source>
        <translation>데이터베이스 잠금</translation>
    </message>
</context>
<context>
    <name>ManageSession</name>
    <message>
        <source>Disconnect</source>
        <translation>연결 해제</translation>
    </message>
    <message>
        <source>Disconnect this application</source>
        <translation>이 프로그램 연결 해제</translation>
    </message>
    <message>
        <source>Reset</source>
        <translation>초기화</translation>
    </message>
    <message>
        <source>Reset any remembered decisions for this application</source>
        <translation>이 프로그램에서 기억하는 모든 결정 사항 초기화</translation>
    </message>
</context>
<context>
    <name>MergeDialog</name>
    <message>
        <source>Database Merge Confirmation</source>
        <translation>데이터베이스 병합 확인</translation>
    </message>
    <message>
        <source>Merge</source>
        <translation>병합</translation>
    </message>
    <message>
        <source>Group</source>
        <translation>그룹</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>제목</translation>
    </message>
    <message>
        <source>UUID</source>
        <translation>UUID</translation>
    </message>
    <message>
        <source>Details</source>
        <translation>세부 사항</translation>
    </message>
    <message>
        <source>Change</source>
        <translation>변경</translation>
    </message>
</context>
<context>
    <name>Merger</name>
    <message>
        <source>Changed deleted objects</source>
        <translation>변경된 삭제된 개체</translation>
    </message>
    <message>
        <source>Removed custom data %1 [%2]</source>
        <translation>사용자 정의 데이터 %1[%2] 삭제됨</translation>
    </message>
    <message>
        <source>Adding custom data %1 [%2]</source>
        <translation>사용자 정의 데이터 %1[%2] 추가 중</translation>
    </message>
    <message>
        <source>Added</source>
        <translation>추가됨</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>수정됨</translation>
    </message>
    <message>
        <source>Moved</source>
        <translation>이동됨</translation>
    </message>
    <message>
        <source>Deleted</source>
        <translation>삭제됨</translation>
    </message>
    <message>
        <source>Previous location: %1</source>
        <translation>이전 위치: %1</translation>
    </message>
    <message>
        <source>Number of entries in group: %1</source>
        <translation>그룹 내 항목 수: %1</translation>
    </message>
    <message>
        <source>Group name</source>
        <translation>그룹 이름</translation>
    </message>
    <message>
        <source>Notes</source>
        <translation>참고</translation>
    </message>
    <message>
        <source>Icon (UUID)</source>
        <translation>아이콘 (UUID)</translation>
    </message>
    <message>
        <source>Icon (Number)</source>
        <translation>아이콘 (번호)</translation>
    </message>
    <message>
        <source>Expiry time</source>
        <translation>만료 시간</translation>
    </message>
    <message>
        <source>Modification time</source>
        <translation>수정 시간</translation>
    </message>
    <message>
        <source>%1 (Add local modifications to new entry)</source>
        <translation>%1 (새 항목에 로컬 수정 추가)</translation>
    </message>
    <message>
        <source>%1 (Add new modifications to existing entry)</source>
        <translation>%1 (기존 항목에 새 수정 사항 추가)</translation>
    </message>
    <message>
        <source>Explicit deletion</source>
        <translation>명시적 삭제</translation>
    </message>
    <message>
        <source>Implicit deletion (e.g. removal of parent group)</source>
        <translation>암묵적 삭제 (예: 부모 그룹 제거)</translation>
    </message>
    <message>
        <source>Adding new icon %1</source>
        <translation>새 아이콘 추가 %1</translation>
    </message>
</context>
<context>
    <name>NewDatabaseWizard</name>
    <message>
        <source>Create a new KeePassXC database…</source>
        <translation>새 KeePassXC 데이터베이스 만들기…</translation>
    </message>
    <message>
        <source>Root</source>
        <comment>Root group</comment>
        <translation>루트</translation>
    </message>
</context>
<context>
    <name>NewDatabaseWizardPage</name>
    <message>
        <source>WizardPage</source>
        <translation>마법사페이지</translation>
    </message>
    <message>
        <source>Encryption Settings</source>
        <translation>암호화 설정</translation>
    </message>
    <message>
        <source>Here you can adjust the database encryption settings. Don&apos;t worry, you can change them later in the database settings.</source>
        <translation>데이터베이스 암호화 설정을 변경할 수 있습니다. 나중에 데이터베이스 설정에서도 변경할 수 있습니다.</translation>
    </message>
</context>
<context>
    <name>NewDatabaseWizardPageDatabaseKey</name>
    <message>
        <source>Database Credentials</source>
        <translation>데이터베이스 자격 증명</translation>
    </message>
    <message>
        <source>A set of credentials known only to you that protects your database.</source>
        <translation>나만 알고 있는 데이터베이스를 보호할 자격 증명입니다.</translation>
    </message>
</context>
<context>
    <name>NewDatabaseWizardPageEncryption</name>
    <message>
        <source>Encryption Settings</source>
        <translation>암호화 설정</translation>
    </message>
    <message>
        <source>Here you can adjust the database encryption settings. Don&apos;t worry, you can change them later in the database settings.</source>
        <translation>데이터베이스 암호화 설정을 변경할 수 있습니다. 나중에 데이터베이스 설정에서도 변경할 수 있습니다.</translation>
    </message>
</context>
<context>
    <name>NewDatabaseWizardPageMetaData</name>
    <message>
        <source>General Database Information</source>
        <translation>일반 데이터베이스 정보</translation>
    </message>
    <message>
        <source>Please fill in the display name and an optional description for your new database:</source>
        <translation>새 데이터베이스 표시 이름과 추가 설명(선택)을 입력하십시오:</translation>
    </message>
</context>
<context>
    <name>NixUtils</name>
    <message>
        <source>Password Manager</source>
        <translation>비밀번호 관리자</translation>
    </message>
    <message>
        <source>Global shortcut already registered to %1</source>
        <translation>전역 단축키가 이미 %1에 등록됨</translation>
    </message>
    <message>
        <source>Could not register global shortcut</source>
        <translation>전역 단축키를 등록할 수 없음</translation>
    </message>
</context>
<context>
    <name>OpData01</name>
    <message>
        <source>Invalid OpData01, does not contain header</source>
        <translation>잘못된 OpData01, 헤더 정보 없음</translation>
    </message>
    <message>
        <source>Unable to read all IV bytes, wanted 16 but got %1</source>
        <translation>모든 IV 바이트를 읽을 수 없음, 16바이트가 필요하지만 %1바이트만 받음</translation>
    </message>
    <message>
        <source>Unable to init cipher for opdata01: %1</source>
        <translation>opdata01의 암호화를 초기화할 수 없음: %1</translation>
    </message>
    <message>
        <source>Unable to read all HMAC signature bytes</source>
        <translation>모든 HMAC 서명 바이트를 읽을 수 없음</translation>
    </message>
    <message>
        <source>Malformed OpData01 due to a failed HMAC</source>
        <translation>잘못된 OpData01, HMAC이 잘못됨</translation>
    </message>
    <message>
        <source>Unable to process clearText in place</source>
        <translation>위치에서 곧바로 clearText를 처리할 수 없음</translation>
    </message>
    <message>
        <source>Expected %1 bytes of clear-text, found %2</source>
        <translation>평문 문자열 %1바이트가 필요하지만 %2바이트를 받음</translation>
    </message>
</context>
<context>
    <name>OpVaultReader</name>
    <message>
        <source>Directory .opvault must exist</source>
        <translation>.opvault 디렉터리가 존재해야 함</translation>
    </message>
    <message>
        <source>Directory .opvault must be readable</source>
        <translation>.opvault 디렉터리를 읽을 수 있어야 함</translation>
    </message>
    <message>
        <source>Directory .opvault/default must exist</source>
        <translation>.opvault/default 디렉터리가 존재해야 함</translation>
    </message>
    <message>
        <source>Directory .opvault/default must be readable</source>
        <translation>.opvault/default 디렉터리를 읽을 수 있어야 함</translation>
    </message>
    <message>
        <source>Unable to decode masterKey: %1</source>
        <translation>masterKey를 디코드할 수 없음: %1</translation>
    </message>
    <message>
        <source>Unable to derive master key: %1</source>
        <translation>마스터 키를 계산할 수 없음: %1</translation>
    </message>
</context>
<context>
    <name>OpenSSHKey</name>
    <message>
        <source>Invalid key file, expecting an OpenSSH key</source>
        <translation>잘못된 키 파일, OpenSSH 키가 필요함</translation>
    </message>
    <message>
        <source>PEM boundary mismatch</source>
        <translation>PEM 경계가 일치하지 않음</translation>
    </message>
    <message>
        <source>Base64 decoding failed</source>
        <translation>Base64 디코드 실패</translation>
    </message>
    <message>
        <source>Key file way too small.</source>
        <translation>키 파일이 너무 작습니다.</translation>
    </message>
    <message>
        <source>Key file magic header id invalid</source>
        <translation>키 파일 매직 헤더 ID가 잘못됨</translation>
    </message>
    <message>
        <source>Found zero keys</source>
        <translation>키를 찾을 수 없음</translation>
    </message>
    <message>
        <source>Corrupted key file, reading private key failed</source>
        <translation>키 파일이 잘못됨, 비밀 키를 읽을 수 없음</translation>
    </message>
    <message>
        <source>Unsupported key type: %1</source>
        <translation>지원하지 않는 키 형식: %1</translation>
    </message>
    <message>
        <source>No private key payload to decrypt</source>
        <translation>암호화 해제할 비밀 키 페이로드가 없음</translation>
    </message>
    <message>
        <source>Unknown cipher: %1</source>
        <translation>알 수 없는 암호화: %1</translation>
    </message>
    <message>
        <source>AES-256/GCM is currently not supported</source>
        <translation>AES-256/GCM은 현재 지원하지 않음</translation>
    </message>
    <message>
        <source>Passphrase is required to decrypt this key</source>
        <translation>이 키를 복호화하려면 비밀번호가 필요함</translation>
    </message>
    <message>
        <source>Key derivation failed: %1</source>
        <translation>키 유도 실패: %1</translation>
    </message>
    <message>
        <source>Cipher IV is too short for MD5 kdf</source>
        <translation>MD5 키 유도 함수에 IV가 너무 짧음</translation>
    </message>
    <message>
        <source>Unknown KDF: %1</source>
        <translation>알 수 없는 KDF: %1</translation>
    </message>
    <message>
        <source>Failed to initialize cipher: %1</source>
        <translation>암호화 초기화 실패: %1</translation>
    </message>
    <message>
        <source>Decryption failed: %1</source>
        <translation>복호화 실패: %1</translation>
    </message>
    <message>
        <source>Decryption failed, wrong passphrase?</source>
        <translation>복호화 실패, 비밀번호가 올바릅니까?</translation>
    </message>
    <message>
        <source>Unexpected EOF while reading key</source>
        <translation>키를 읽는 중 예상하지 못한 곳에서 파일이 끝남</translation>
    </message>
    <message>
        <source>Unsupported key part</source>
        <translation>지원하지 않는 키 부분</translation>
    </message>
    <message>
        <source>Unexpected EOF while reading public key</source>
        <translation>공개 키를 읽는 중 예상하지 못한 곳에서 파일이 끝남</translation>
    </message>
    <message>
        <source>Unknown key type: %1</source>
        <translation>알 수 없는 키 형식: %1</translation>
    </message>
    <message>
        <source>Unexpected EOF while reading private key</source>
        <translation>비밀 키를 읽는 중 예상하지 못한 곳에서 파일이 끝남</translation>
    </message>
    <message>
        <source>Can&apos;t write public key as it is empty</source>
        <translation>공개 키가 비어 있어서 기록할 수 없음</translation>
    </message>
    <message>
        <source>Unexpected EOF when writing public key</source>
        <translation>공개 키를 기록하는 중 예상하지 못한 곳에서 파일이 끝남</translation>
    </message>
    <message>
        <source>Can&apos;t write private key as it is empty</source>
        <translation>비밀 키가 비어 있어서 기록할 수 없음</translation>
    </message>
    <message>
        <source>Unexpected EOF when writing private key</source>
        <translation>비밀 키를 기록하는 중 예상하지 못한 곳에서 파일이 끝남</translation>
    </message>
    <message>
        <source>(encrypted)</source>
        <translation>(암호화됨)</translation>
    </message>
    <message>
        <source>Failed to read key file: %1</source>
        <translation>키 파일을 읽지 못했습니다: %1</translation>
    </message>
    <message>
        <source>Failed to read public key: %1</source>
        <translation>공개 키를 읽지 못했습니다: %1</translation>
    </message>
</context>
<context>
    <name>OpenSSHKeyGenDialog</name>
    <message>
        <source>SSH Key Generator</source>
        <translation>SSH 키 생성기</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>형식</translation>
    </message>
    <message>
        <source>Bits</source>
        <translation>비트</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>주석</translation>
    </message>
</context>
<context>
    <name>PasskeyExportDialog</name>
    <message>
        <source>KeePassXC - Passkey Export</source>
        <translation>KeePassXC - 패스키 내보내기</translation>
    </message>
    <message>
        <source>Filenames will be generated with title and .passkey file extension.</source>
        <translation>파일 이름은 제목과 .passkey 파일 확장자로 생성됩니다.</translation>
    </message>
    <message>
        <source>Export entries</source>
        <translation>항목 내보내기</translation>
    </message>
    <message>
        <source>Export Selected</source>
        <translation>선택 내보내기</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>취소</translation>
    </message>
    <message>
        <source>Export to folder</source>
        <translation>폴더로 내보내기</translation>
    </message>
    <message>
        <source>Export the following passkey entries.</source>
        <translation>지정한 패스키 항목을 내보냅니다.</translation>
    </message>
</context>
<context>
    <name>PasskeyExporter</name>
    <message>
        <source>File &quot;%1.passkey&quot; already exists.
Do you want to overwrite it?
</source>
        <translation>&quot;%1.passkey&quot; 파일이 이미 존재합니다.
덮어쓰시겠습니까?
</translation>
    </message>
    <message>
        <source>Cannot open file</source>
        <translation>파일을 열 수 없음</translation>
    </message>
    <message>
        <source>Cannot open file &quot;%1&quot; for writing.</source>
        <translation>&quot;%1&quot; 파일에 쓰기 위해 열 수 없음</translation>
    </message>
    <message>
        <source>Cannot write to file</source>
        <translation>파일에 쓸 수 없음</translation>
    </message>
    <message>
        <source>Overwrite Existing File?</source>
        <translation>기존 파일을 덮어쓰시겠습니까?</translation>
    </message>
</context>
<context>
    <name>PasskeyImportDialog</name>
    <message>
        <source>KeePassXC - Passkey Import</source>
        <translation>KeePassXC - 패스키 가져오기</translation>
    </message>
    <message>
        <source>Username: %1</source>
        <translation>사용자 이름: %1</translation>
    </message>
    <message>
        <source>Group</source>
        <translation>그룹</translation>
    </message>
    <message>
        <source>Database</source>
        <translation>데이터베이스</translation>
    </message>
    <message>
        <source>Import Passkey</source>
        <translation>패스키 가져오기</translation>
    </message>
    <message>
        <source>Import</source>
        <translation>가져오기</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>취소</translation>
    </message>
    <message>
        <source>Entry</source>
        <translation>항목</translation>
    </message>
    <message>
        <source>Create new entry</source>
        <translation>새 항목 만들기</translation>
    </message>
    <message>
        <source>Relying Party: %1</source>
        <translation>의존 당사자: %1</translation>
    </message>
    <message>
        <source>Import the following passkey:</source>
        <translation>다음 패스키 가져오기:</translation>
    </message>
    <message>
        <source>Import the following passkey to this entry:</source>
        <translation>이 항목으로 다음 패스키 가져오기:</translation>
    </message>
    <message>
        <source>Default passkeys group (Imported Passkeys)</source>
        <translation>기본 패스키 그룹(가져온 패스키)</translation>
    </message>
</context>
<context>
    <name>PasskeyImporter</name>
    <message>
        <source>Passkey file</source>
        <translation>패스키 파일</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>모든 파일</translation>
    </message>
    <message>
        <source>Cannot open file</source>
        <translation>파일을 열 수 없음</translation>
    </message>
    <message>
        <source>Cannot open file &quot;%1&quot; for reading.</source>
        <translation>&quot;%1&quot; 파일에서 읽기 위해 열 수 없습니다.</translation>
    </message>
    <message>
        <source>Cannot import passkey file &quot;%1&quot;. Data is missing.</source>
        <translation>패스키 파일 &quot;%1&quot;을 가져올 수 없습니다. 데이터가 누락되었습니다.</translation>
    </message>
    <message>
        <source>Cannot import passkey file &quot;%1&quot;.
The following data is missing:
%2</source>
        <translation>패스키 파일 &quot;%1&quot;을 가져올 수 없습니다.
다음 데이터가 누락되었습니다:
%2</translation>
    </message>
    <message>
        <source>Cannot import passkey file &quot;%1&quot;. Private key is missing or malformed.</source>
        <translation>패스키 파일 &quot;%1&quot;을 가져올 수 없습니다. 개인 키가 누락되었거나 잘못된 형식입니다.</translation>
    </message>
    <message>
        <source>Open Passkey File</source>
        <translation>패스키 파일 열기</translation>
    </message>
    <message>
        <source>Passkey Import Failed</source>
        <translation>패스키 가져오기 실패</translation>
    </message>
</context>
<context>
    <name>PasswordEditWidget</name>
    <message>
        <source>Enter password:</source>
        <translation>비밀번호 입력:</translation>
    </message>
    <message>
        <source>Password field</source>
        <translation>비밀번호 필드</translation>
    </message>
    <message>
        <source>Confirm password:</source>
        <translation>비밀번호 확인:</translation>
    </message>
    <message>
        <source>Repeat password field</source>
        <translation>비밀번호 확인 필드</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>비밀번호</translation>
    </message>
    <message>
        <source>Add Password</source>
        <translation>비밀번호 추가</translation>
    </message>
    <message>
        <source>Change Password</source>
        <translation>비밀번호 변경</translation>
    </message>
    <message>
        <source>Remove Password</source>
        <translation>비밀번호 삭제</translation>
    </message>
    <message>
        <source>Password set, click to change or remove</source>
        <translation>비밀번호 설정됨, 클릭해서 변경하거나 삭제</translation>
    </message>
    <message>
        <source>&lt;p&gt;A password is the primary method for securing your database.&lt;/p&gt;&lt;p&gt;Good passwords are long and unique. KeePassXC can generate one for you.&lt;/p&gt;</source>
        <translation>&lt;p&gt;비밀번호는 데이터베이스를 보호하는 주요 수단입니다.&lt;/p&gt;&lt;p&gt;좋은 비밀번호는 길고 예측할 수 없어야 합니다. KeePassXC에서 비밀번호를 생성할 수 있습니다.&lt;/p&gt;</translation>
    </message>
    <message>
        <source>Passwords do not match.</source>
        <translation>비밀번호가 일치하지 않습니다.</translation>
    </message>
</context>
<context>
    <name>PasswordGeneratorWidget</name>
    <message>
        <source>Generate Password</source>
        <translation>비밀번호 생성</translation>
    </message>
    <message>
        <source>strength</source>
        <comment>Password strength</comment>
        <translation>강도</translation>
    </message>
    <message>
        <source>entropy</source>
        <translation>엔트로피</translation>
    </message>
    <message>
        <source>Generated password</source>
        <translation>생성된 비밀번호</translation>
    </message>
    <message>
        <source>%p%</source>
        <translation>%p%</translation>
    </message>
    <message>
        <source>Regenerate password</source>
        <translation>비밀번호 다시 생성</translation>
    </message>
    <message>
        <source>Copy password</source>
        <translation>비밀번호 복사</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>비밀번호</translation>
    </message>
    <message>
        <source>&amp;Length:</source>
        <translation>길이(&amp;L):</translation>
    </message>
    <message>
        <source>Password length</source>
        <translation>비밀번호 길이</translation>
    </message>
    <message>
        <source>Switch to advanced mode</source>
        <translation>고급 모드로 전환</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>고급</translation>
    </message>
    <message>
        <source>Character Types</source>
        <translation>문자 종류</translation>
    </message>
    <message>
        <source>Special characters</source>
        <translation>특수문자</translation>
    </message>
    <message>
        <source>Quotes</source>
        <translation>따옴표</translation>
    </message>
    <message>
        <source>Punctuation</source>
        <translation>구두점</translation>
    </message>
    <message>
        <source>Dashes and Slashes</source>
        <translation>대시와 슬래시</translation>
    </message>
    <message>
        <source>Upper-case letters</source>
        <translation>대문자</translation>
    </message>
    <message>
        <source>Numbers</source>
        <translation>숫자</translation>
    </message>
    <message>
        <source>Lower-case letters</source>
        <translation>소문자</translation>
    </message>
    <message>
        <source>Math Symbols</source>
        <translation>수학 기호</translation>
    </message>
    <message>
        <source>Extended ASCII</source>
        <translation>확장 ASCII</translation>
    </message>
    <message>
        <source>Braces</source>
        <translation>괄호</translation>
    </message>
    <message>
        <source>Do not include:</source>
        <translation>포함하지 않음:</translation>
    </message>
    <message>
        <source>Additional characters to use for the generated password</source>
        <translation>생성한 비밀번호에 포함할 추가 문자</translation>
    </message>
    <message>
        <source>Additional characters</source>
        <translation>추가 문자</translation>
    </message>
    <message>
        <source>Add non-hex letters to &quot;do not include&quot; list</source>
        <translation>&quot;포함하지 않음&quot; 목록에 16진수가 아닌 문자 추가</translation>
    </message>
    <message>
        <source>Hex Passwords</source>
        <translation>16진 비밀번호</translation>
    </message>
    <message>
        <source>Hex</source>
        <translation>16진</translation>
    </message>
    <message>
        <source>Character set to exclude from generated password</source>
        <translation>생성된 비밀번호에서 제외할 문자 집합</translation>
    </message>
    <message>
        <source>Excluded characters</source>
        <translation>제외할 문자</translation>
    </message>
    <message>
        <source>Also choose from:</source>
        <translation>다음에서도 선택:</translation>
    </message>
    <message>
        <source>Exclude look-alike characters</source>
        <translation>비슷하게 생긴 문자 제외</translation>
    </message>
    <message>
        <source>Pick characters from every group</source>
        <translation>모든 그룹에서 글자 선택</translation>
    </message>
    <message>
        <source>Passphrase</source>
        <translation>암호</translation>
    </message>
    <message>
        <source>Word Separator:</source>
        <translation>단어 구분자:</translation>
    </message>
    <message>
        <source>Wordlist:</source>
        <translation>단어 목록:</translation>
    </message>
    <message>
        <source>Word Count:</source>
        <translation>단어 개수:</translation>
    </message>
    <message>
        <source>Word Case:</source>
        <translation>대소문자:</translation>
    </message>
    <message>
        <source>Delete selected wordlist</source>
        <translation>지정한 단어 목록 삭제</translation>
    </message>
    <message>
        <source>Add custom wordlist</source>
        <translation>사용자 정의 단어 목록 추가</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>닫기</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
    <message>
        <source>Apply Password</source>
        <translation>비밀번호 적용</translation>
    </message>
    <message>
        <source>Regenerate password (%1)</source>
        <translation>비밀번호 다시 생성(%1)</translation>
    </message>
    <message>
        <source>lower case</source>
        <translation>소문자</translation>
    </message>
    <message>
        <source>UPPER CASE</source>
        <translation>대문자</translation>
    </message>
    <message>
        <source>Title Case</source>
        <translation>제목 대소문자 구분</translation>
    </message>
    <message>
        <source>(SYSTEM)</source>
        <translation>(시스템)</translation>
    </message>
    <message>
        <source>Entropy: %1 bit</source>
        <translation>엔트로피: %1비트</translation>
    </message>
    <message>
        <source>Password Quality: %1</source>
        <translation>비밀번호 강도: %1</translation>
    </message>
    <message>
        <source>Poor</source>
        <comment>Password quality</comment>
        <translation>매우 약함</translation>
    </message>
    <message>
        <source>Weak</source>
        <comment>Password quality</comment>
        <translation>약함</translation>
    </message>
    <message>
        <source>Good</source>
        <comment>Password quality</comment>
        <translation>좋음</translation>
    </message>
    <message>
        <source>Excellent</source>
        <comment>Password quality</comment>
        <translation>매우 좋음</translation>
    </message>
    <message>
        <source>Failed to delete wordlist</source>
        <translation>단어 목록을 삭제할 수 없음</translation>
    </message>
    <message>
        <source>Wordlists</source>
        <translation>단어 목록</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>모든 파일</translation>
    </message>
    <message>
        <source>Select Custom Wordlist</source>
        <translation>사용자 지정 단어 목록 선택</translation>
    </message>
    <message>
        <source>Overwrite Wordlist?</source>
        <translation>단어 목록을 덮어쓰시겠습니까?</translation>
    </message>
    <message>
        <source>Wordlist &quot;%1&quot; already exists as a custom wordlist.
Do you want to overwrite it?</source>
        <translation>단어 목록 &quot;%1&quot;은 이미 사용자 지정 단어 목록에 있습니다.
덮어쓰시겠습니까?</translation>
    </message>
    <message>
        <source>Failed to add wordlist</source>
        <translation>단어 목록을 추가할 수 없음</translation>
    </message>
    <message>
        <source>Logograms</source>
        <translation>로고그램</translation>
    </message>
    <message>
        <source>Special Characters</source>
        <translation>특수 문자</translation>
    </message>
    <message>
        <source>passwordLength</source>
        <translation>비밀번호 길이</translation>
    </message>
    <message>
        <source>Characters: %1</source>
        <translation>글자 수: %1</translation>
    </message>
    <message>
        <source>MIXED case</source>
        <translation> 혼합 대소문자</translation>
    </message>
    <message>
        <source>Excluded characters: &quot;0&quot;, &quot;1&quot;, &quot;l&quot;, &quot;I&quot;, &quot;O&quot;, &quot;|&quot;, &quot;﹒&quot;, &quot;B&quot;, &quot;8&quot;, &quot;G&quot;, &quot;6&quot;</source>
        <translation>제외된 문자: &quot;0&quot;, &quot;1&quot;, &quot;l&quot;, &quot;I&quot;, &quot;O&quot;, &quot;|&quot;, &quot;﹒&quot;, &quot;B&quot;, &quot;8&quot;, &quot;G&quot;, &quot;6&quot;</translation>
    </message>
    <message>
        <source>Warning: the chosen wordlist is smaller than the minimum recommended size!</source>
        <translation>경고: 선택한 단어 목록이 최소 권장 크기보다 작습니다!</translation>
    </message>
    <message>
        <source>Confirm Remove Wordlist</source>
        <translation>단어 목록 제거 확인</translation>
    </message>
    <message>
        <source>Do you really want to remove the wordlist &quot;%1&quot;?</source>
        <translation>단어 목록 &quot;%1&quot;을 정말로 제거하시겠습니까?</translation>
    </message>
</context>
<context>
    <name>PasswordWidget</name>
    <message>
        <source>Passwords do not match</source>
        <translation>비밀번호가 일치하지 않음</translation>
    </message>
    <message>
        <source>Passwords match so far</source>
        <translation>비밀번호가 일치함</translation>
    </message>
    <message>
        <source>Toggle Password (%1)</source>
        <translation>비밀번호 표시/숨기기(%1)</translation>
    </message>
    <message>
        <source>Generate Password (%1)</source>
        <translation>비밀번호 생성(%1)</translation>
    </message>
    <message>
        <source>Warning: Caps Lock enabled!</source>
        <translation>경고: Caps Lock이 켜져 있습니다</translation>
    </message>
    <message>
        <source>Quality: %1</source>
        <translation>품질: %1</translation>
    </message>
    <message>
        <source>Poor</source>
        <comment>Password quality</comment>
        <translation>매우 약함</translation>
    </message>
    <message>
        <source>Weak</source>
        <comment>Password quality</comment>
        <translation>약함</translation>
    </message>
    <message>
        <source>Good</source>
        <comment>Password quality</comment>
        <translation>좋음</translation>
    </message>
    <message>
        <source>Excellent</source>
        <comment>Password quality</comment>
        <translation>매우 좋음</translation>
    </message>
    <message>
        <source>Toggle password visibility using Control + H. Open the password generator using Control + G.</source>
        <translation>Ctrl+H 키를 사용하여 암호 표시 여부를 전환하십시오. Ctrl+G 키를 사용하여 암호 생성기를 여십시오.</translation>
    </message>
</context>
<context>
    <name>PickcharsDialog</name>
    <message>
        <source>KeePassXC - Pick Characters</source>
        <translation>KeePassXC - 글자 선택</translation>
    </message>
    <message>
        <source>Select characters to type, navigate with arrow keys, Ctrl + S submits.</source>
        <translation>입력할 글자를 선택하십시오. 화살표 키로 탐색할 수 있으며 Ctrl+S 키를 누르면 확정합니다.</translation>
    </message>
    <message>
        <source>Press &amp;Tab between characters</source>
        <translation>문자 사이에 탭 누르기(&amp;T)</translation>
    </message>
</context>
<context>
    <name>PreviewEntryAttachmentsDialog</name>
    <message>
        <source>Form</source>
        <translation>폼</translation>
    </message>
    <message>
        <source>Preview: %1</source>
        <translation>미리보기: %1</translation>
    </message>
    <message>
        <source>Save…</source>
        <translation>저장...</translation>
    </message>
</context>
<context>
    <name>QMessageBox</name>
    <message>
        <source>Overwrite</source>
        <translation>덮어쓰기</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>삭제</translation>
    </message>
    <message>
        <source>Move</source>
        <translation>이동</translation>
    </message>
    <message>
        <source>Empty</source>
        <translation>비우기</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>제거</translation>
    </message>
    <message>
        <source>Skip</source>
        <translation>건너뛰기</translation>
    </message>
    <message>
        <source>Disable</source>
        <translation>비활성화</translation>
    </message>
    <message>
        <source>Merge</source>
        <translation>병합</translation>
    </message>
    <message>
        <source>Continue</source>
        <translation>계속</translation>
    </message>
    <message>
        <source>Continue with weak password</source>
        <translation>약한 비밀번호로 계속</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Database not opened</source>
        <translation>데이터베이스가 열리지 않음</translation>
    </message>
    <message>
        <source>Database hash not available</source>
        <translation>데이터베이스 해시를 사용할 수 없음</translation>
    </message>
    <message>
        <source>Client public key not received</source>
        <translation>클라이언트 공개 키를 받지 않았음</translation>
    </message>
    <message>
        <source>Cannot decrypt message</source>
        <translation>메시지를 복호화할 수 없음</translation>
    </message>
    <message>
        <source>Action cancelled or denied</source>
        <translation>접근이 취소되었거나 거부됨</translation>
    </message>
    <message>
        <source>Message encryption failed.</source>
        <translation>메시지를 암호화할 수 없습니다.</translation>
    </message>
    <message>
        <source>KeePassXC association failed, try again</source>
        <translation>KeePassXC 연결에 실패했습니다. 다시 시도하세요</translation>
    </message>
    <message>
        <source>Encryption key is not recognized</source>
        <translation>암호화 키를 인식할 수 없음</translation>
    </message>
    <message>
        <source>Incorrect action</source>
        <translation>잘못된 동작</translation>
    </message>
    <message>
        <source>Empty message received</source>
        <translation>빈 메시지 받음</translation>
    </message>
    <message>
        <source>No URL provided</source>
        <translation>URL이 지정되지 않음</translation>
    </message>
    <message>
        <source>No logins found</source>
        <translation>로그인을 찾을 수 없음</translation>
    </message>
    <message>
        <source>No groups found</source>
        <translation>그룹을 찾을 수 없음</translation>
    </message>
    <message>
        <source>Cannot create new group</source>
        <translation>새 그룹을 만들 수 없음</translation>
    </message>
    <message>
        <source>No valid UUID provided</source>
        <translation>올바른 UUID를 지정하지 않았음</translation>
    </message>
    <message>
        <source>Username or password cannot contain references</source>
        <translation>사용자 이름 또는 비밀번호에는 참조를 포함할 수 없습니다</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation>알 수 없는 오류</translation>
    </message>
    <message>
        <source>Browser Integration</source>
        <translation>브라우저 통합</translation>
    </message>
    <message>
        <source>Browser Plugin Failure</source>
        <translation>브라우저 플러그인 오류</translation>
    </message>
    <message>
        <source>Could not save the native messaging script file for %1.</source>
        <translation>%1의 네이티브 메시징 스크립트 파일을 저장할 수 없습니다.</translation>
    </message>
    <message>
        <source>Username for the entry.</source>
        <translation>항목의 사용자 이름입니다.</translation>
    </message>
    <message>
        <source>username</source>
        <translation>사용자 이름</translation>
    </message>
    <message>
        <source>URL for the entry.</source>
        <translation>항목의 URL입니다.</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>Notes for the entry.</source>
        <translation>항목의 메모입니다.</translation>
    </message>
    <message>
        <source>Notes</source>
        <translation>메모</translation>
    </message>
    <message>
        <source>Prompt for the entry&apos;s password.</source>
        <translation>항목 비밀번호의 프롬프트입니다.</translation>
    </message>
    <message>
        <source>Generate a password for the entry.</source>
        <translation>항목 비밀번호를 생성합니다.</translation>
    </message>
    <message>
        <source>Add a new entry to a database.</source>
        <translation>데이터베이스에 새 항목을 추가합니다.</translation>
    </message>
    <message>
        <source>Path of the entry to add.</source>
        <translation>추가할 항목의 경로입니다.</translation>
    </message>
    <message>
        <source>Cannot generate a password and prompt at the same time.</source>
        <translation>비밀번호와 프롬프트를 동시에 생성할 수 없습니다.</translation>
    </message>
    <message>
        <source>Could not create entry with path %1.</source>
        <translation>경로 %1에 항목을 만들 수 없습니다.</translation>
    </message>
    <message>
        <source>Enter password for new entry: </source>
        <translation>새 항목의 비밀번호 입력: </translation>
    </message>
    <message>
        <source>Writing the database failed %1.</source>
        <translation>데이터베이스에 기록할 수 없습니다 %1.</translation>
    </message>
    <message>
        <source>Successfully added entry %1.</source>
        <translation>항목 %1을(를) 추가했습니다.</translation>
    </message>
    <message>
        <source>Adds a new group to a database.</source>
        <translation>데이터베이스에 새 그룹을 추가합니다.</translation>
    </message>
    <message>
        <source>Path of the group to add.</source>
        <translation>추가할 그룹의 경로입니다.</translation>
    </message>
    <message>
        <source>Group %1 already exists!</source>
        <translation>그룹 %1이(가) 이미 존재합니다!</translation>
    </message>
    <message>
        <source>Group %1 not found.</source>
        <translation>그룹 %1을(를) 찾을 수 없습니다.</translation>
    </message>
    <message>
        <source>Successfully added group %1.</source>
        <translation>그룹 %1을(를) 추가했습니다.</translation>
    </message>
    <message>
        <source>Check if any passwords have been publicly leaked. FILENAME must be the path of a file listing SHA-1 hashes of leaked passwords in HIBP format, as available from https://haveibeenpwned.com/Passwords.</source>
        <translation>비밀번호가 유출된 적이 있는지 검사합니다. 파일 이름에는 HIBP 형식으로 된 유출된 비밀번호의 SHA-1 해시가 저장된 파일을 지정해야 합니다. https://haveibeenpwned.com/Passwords 사이트에서 다운로드할 수 있습니다.</translation>
    </message>
    <message>
        <source>FILENAME</source>
        <translation>파일 이름</translation>
    </message>
    <message>
        <source>Path to okon-cli to search a formatted HIBP file</source>
        <translation>HIBP 파일을 검색할 okon-cli의 경로</translation>
    </message>
    <message>
        <source>okon-cli</source>
        <translation>okon-cli</translation>
    </message>
    <message>
        <source>Analyze passwords for weaknesses and problems.</source>
        <translation>취약한 비밀번호와 문제를 분석합니다.</translation>
    </message>
    <message>
        <source>Cannot find HIBP file: %1</source>
        <translation>HIBP 파일을 찾을 수 없음: %1</translation>
    </message>
    <message>
        <source>Evaluating database entries using okon…</source>
        <translation>okon으로 데이터베이스 항목 검사 중…</translation>
    </message>
    <message>
        <source>Failed to open HIBP file %1: %2</source>
        <translation>HIBP 파일 %1을(를) 열 수 없음: %2</translation>
    </message>
    <message>
        <source>Evaluating database entries against HIBP file, this will take a while…</source>
        <translation>데이터베이스 항목과 HIBP 파일을 분석하고 있습니다. 잠시 기다려 주십시오…</translation>
    </message>
    <message numerus="yes">
        <source>Password for &apos;%1&apos; has been leaked %2 time(s)!</source>
        <translation><numerusform>&apos;%1&apos;의 비밀번호가 %2번 유출되었습니다!</numerusform></translation>
    </message>
    <message>
        <source>Password for &apos;%1&apos; has been leaked!</source>
        <translation>&apos;%1&apos;의 비밀번호가 유출되었습니다!</translation>
    </message>
    <message>
        <source>Export an attachment of an entry.</source>
        <translation>항목의 첨부를 내보냅니다.</translation>
    </message>
    <message>
        <source>Path of the entry with the target attachment.</source>
        <translation>대상 첨부 항목이 있는 항목의 경로입니다.</translation>
    </message>
    <message>
        <source>Name of the attachment to be exported.</source>
        <translation>내보낼 첨부 항목의 이름입니다.</translation>
    </message>
    <message>
        <source>Path to which the attachment should be exported.</source>
        <translation>첨부 파일을 내보낼 경로입니다.</translation>
    </message>
    <message>
        <source>Could not find entry with path %1.</source>
        <translation>경로 %1에서 항목을 찾을 수 없습니다.</translation>
    </message>
    <message>
        <source>Could not find attachment with name %1.</source>
        <translation>이름이 %1인 첨부 항목을 찾을 수 없습니다.</translation>
    </message>
    <message>
        <source>No export target given. Please use &apos;--stdout&apos; or specify an &apos;export-file&apos;.</source>
        <translation>내보낼 대상을 지정하지 않았습니다. &apos;--stdout&apos; 또는 &apos;export-file&apos;을 지정하십시오.</translation>
    </message>
    <message>
        <source>Could not open output file %1.</source>
        <translation>출력 파일 %1을(를) 열 수 없습니다.</translation>
    </message>
    <message>
        <source>Successfully exported attachment %1 of entry %2 to %3.</source>
        <translation>항목 %2의 첨부 %1을(를) %3(으)로 내보냈습니다.</translation>
    </message>
    <message>
        <source>Overwrite existing attachments.</source>
        <translation>기존 첨부를 덮어씁니다.</translation>
    </message>
    <message>
        <source>Imports an attachment to an entry.</source>
        <translation>항목으로 첨부를 가져옵니다.</translation>
    </message>
    <message>
        <source>Path of the entry.</source>
        <translation>항목의 경로입니다.</translation>
    </message>
    <message>
        <source>Name of the attachment to be added.</source>
        <translation>추가할 첨부의 이름입니다.</translation>
    </message>
    <message>
        <source>Path of the attachment to be imported.</source>
        <translation>가져올 첨부의 경로입니다.</translation>
    </message>
    <message>
        <source>Attachment %1 already exists for entry %2.</source>
        <translation>항목 %2에 첨부 %1이(가) 이미 존재합니다.</translation>
    </message>
    <message>
        <source>Could not open attachment file %1.</source>
        <translation>첨부 파일 %1을(를) 열 수 없습니다.</translation>
    </message>
    <message>
        <source>Successfully imported attachment %1 as %2 to entry %3.</source>
        <translation>첨부 %1을(를) 항목 %3의 %2(으)로 가져왔습니다.</translation>
    </message>
    <message>
        <source>Remove an attachment of an entry.</source>
        <translation>항목의 첨부를 삭제합니다.</translation>
    </message>
    <message>
        <source>Name of the attachment to be removed.</source>
        <translation>삭제할 첨부의 이름입니다.</translation>
    </message>
    <message>
        <source>Successfully removed attachment %1 from entry %2.</source>
        <translation>항목 %2에서 첨부 %1을(를) 삭제했습니다.</translation>
    </message>
    <message>
        <source>Copy the given attribute to the clipboard. Defaults to &quot;password&quot; if not specified.</source>
        <comment>Don't translate &quot;password&quot;, it refers to the attribute.</comment>
        <translation>지정한 속성을 클립보드에 복사합니다. 지정하지 않았을 때의 기본값은 &quot;password&quot;입니다.</translation>
    </message>
    <message>
        <source>Copy the current TOTP to the clipboard (equivalent to &quot;-a totp&quot;).</source>
        <translation>현재 TOTP 값을 클립보드에 복사합니다(&quot;-a totp&quot;와 동일함).</translation>
    </message>
    <message>
        <source>Must match only one entry, otherwise a list of possible matches is shown.</source>
        <translation>한 개 항목만 일치해야 합니다. 그렇지 않으면 전체 일치 목록을 표시합니다.</translation>
    </message>
    <message>
        <source>Copy an entry&apos;s attribute to the clipboard.</source>
        <translation>항목의 속성을 클립보드에 복사합니다.</translation>
    </message>
    <message>
        <source>Path of the entry to clip.</source>
        <comment>clip = copy to clipboard</comment>
        <translation>클립보드에 복사할 항목의 경로입니다.</translation>
    </message>
    <message>
        <source>Timeout before clearing the clipboard (default is %1 seconds, set to 0 for unlimited).</source>
        <translation>클립보드를 비울 시간 제한입니다(기본값 %1초, 0은 무제한).</translation>
    </message>
    <message>
        <source>Invalid timeout value %1.</source>
        <translation>시간 제한 값 %1이(가) 잘못되었습니다.</translation>
    </message>
    <message>
        <source>Multiple entries matching:</source>
        <translation>여러 항목이 일치함:</translation>
    </message>
    <message>
        <source>Using matching entry: %1</source>
        <translation>일치하는 항목 사용: %1</translation>
    </message>
    <message>
        <source>Entry %1 not found.</source>
        <translation>항목 %1을(를) 찾을 수 없습니다.</translation>
    </message>
    <message>
        <source>ERROR: Please specify one of --attribute or --totp, not both.</source>
        <translation>오류: --attribute나 --totp 둘 중 하나만 지정하십시오.</translation>
    </message>
    <message>
        <source>Entry with path %1 has no TOTP set up.</source>
        <translation>경로 %1에 있는 항목에 TOTP가 설정되지 않았습니다.</translation>
    </message>
    <message>
        <source>ERROR: attribute %1 is ambiguous, it matches %2.</source>
        <translation>오류: 속성 %1이(가) 모호합니다. 일치하는 항목: %2.</translation>
    </message>
    <message>
        <source>Attribute &quot;%1&quot; not found.</source>
        <translation>속성 &quot;%1&quot;을(를) 찾을 수 없습니다.</translation>
    </message>
    <message>
        <source>Entry&apos;s &quot;%1&quot; attribute copied to the clipboard!</source>
        <translation>항목의 &quot;%1&quot; 속성을 클립보드에 복사했습니다!</translation>
    </message>
    <message numerus="yes">
        <source>Clearing the clipboard in %1 second(s)...</source>
        <translation><numerusform>%1초 후 클립보드를 지웁니다...</numerusform></translation>
    </message>
    <message>
        <source>Clipboard cleared!</source>
        <translation>클립보드를 지웠습니다!</translation>
    </message>
    <message>
        <source>Close the currently opened database.</source>
        <translation>현재 열린 데이터베이스를 닫습니다.</translation>
    </message>
    <message>
        <source>Display this help.</source>
        <translation>이 도움말을 표시합니다.</translation>
    </message>
    <message>
        <source>Silence password prompt and other secondary outputs.</source>
        <translation>비밀번호 입력 프롬프트 및 추가 출력을 숨깁니다.</translation>
    </message>
    <message>
        <source>Key file of the database.</source>
        <translation>데이터베이스의 키 파일입니다.</translation>
    </message>
    <message>
        <source>path</source>
        <translation>경로</translation>
    </message>
    <message>
        <source>Deactivate password key for the database.</source>
        <translation>데이터베이스의 비밀번호 키를 비활성화합니다.</translation>
    </message>
    <message>
        <source>Yubikey slot and optional serial used to access the database (e.g., 1:7370001).</source>
        <translation>데이터베이스에 접근할 때 사용할 YubiKey 슬롯과 선택적인 일련 번호입니다(예: 1:7370001).</translation>
    </message>
    <message>
        <source>slot[:serial]</source>
        <translation>slot[:serial]</translation>
    </message>
    <message>
        <source>Missing positional argument(s).</source>
        <translation>위치 인자가 빠졌습니다.</translation>
    </message>
    <message>
        <source>Too many arguments provided.</source>
        <translation>인자가 너무 많습니다.</translation>
    </message>
    <message>
        <source>Path of the database.</source>
        <translation>데이터베이스의 경로입니다.</translation>
    </message>
    <message>
        <source>Target decryption time in MS for the database.</source>
        <translation>밀리초 단위 데이터베이스 복호화 목표 시간입니다.</translation>
    </message>
    <message>
        <source>time</source>
        <translation>time</translation>
    </message>
    <message>
        <source>Set the key file for the database.</source>
        <translation>데이터베이스 키 파일을 설정합니다.</translation>
    </message>
    <message>
        <source>Set a password for the database.</source>
        <translation>데이터베이스 비밀번호를 설정합니다.</translation>
    </message>
    <message>
        <source>Create a new database.</source>
        <translation>새 데이터베이스를 만듭니다.</translation>
    </message>
    <message>
        <source>Invalid decryption time %1.</source>
        <translation>잘못된 복호화 시간: %1.</translation>
    </message>
    <message>
        <source>Target decryption time must be between %1 and %2.</source>
        <translation>대상 복호화 시간은 %1 - %2 사이에 있어야 합니다.</translation>
    </message>
    <message>
        <source>Failed to set database password.</source>
        <translation>데이터베이스 비밀번호를 설정할 수 없습니다.</translation>
    </message>
    <message>
        <source>Loading the key file failed</source>
        <translation>키 파일을 불러올 수 없음</translation>
    </message>
    <message>
        <source>No key is set. Aborting database creation.</source>
        <translation>설정된 키가 없습니다. 데이터베이스 생성을 중단합니다.</translation>
    </message>
    <message>
        <source>Benchmarking key derivation function for %1ms delay.</source>
        <translation>%1 ms 지연 시간 동안 키 유도 함수(KDF)를 벤치마크하고 있습니다.</translation>
    </message>
    <message>
        <source>Setting %1 rounds for key derivation function.</source>
        <translation>키 유도 함수(KDF)의 라운드 수를 %1(으)로 설정합니다.</translation>
    </message>
    <message>
        <source>error while setting database key derivation settings.</source>
        <translation>데이터베이스 키 유도 설정 중 오류가 발생했습니다.</translation>
    </message>
    <message>
        <source>File %1 already exists.</source>
        <translation>파일 %1이(가) 이미 존재합니다.</translation>
    </message>
    <message>
        <source>Failed to save the database: %1.</source>
        <translation>데이터베이스를 저장할 수 없음: %1.</translation>
    </message>
    <message>
        <source>Successfully created new database.</source>
        <translation>새 데이터베이스를 만들었습니다.</translation>
    </message>
    <message>
        <source>Unset the password for the database.</source>
        <translation>데이터베이스 비밀번호를 설정 해제했습니다.</translation>
    </message>
    <message>
        <source>Unset the key file for the database.</source>
        <translation>데이터베이스 키 파일을 설정 해제했습니다.</translation>
    </message>
    <message>
        <source>Edit a database.</source>
        <translation>데이터베이스를 편집합니다.</translation>
    </message>
    <message>
        <source>Cannot use %1 and %2 at the same time.</source>
        <translation>%1와(과) %2을(를) 동시에 사용할 수 없습니다.</translation>
    </message>
    <message>
        <source>Could not change the database key.</source>
        <translation>데이터베이스 키를 변경할 수 없습니다.</translation>
    </message>
    <message>
        <source>Database was not modified.</source>
        <translation>데이터베이스가 수정되지 않았습니다.</translation>
    </message>
    <message>
        <source>Writing the database failed: %1</source>
        <translation>데이터베이스에기록할 수 없음: %1</translation>
    </message>
    <message>
        <source>Successfully edited the database.</source>
        <translation>데이터베이스를 편집했습니다.</translation>
    </message>
    <message>
        <source>Cannot remove password: The database does not have a password.</source>
        <translation>비밀번호를 삭제할 수 없음: 데이터베이스에 비밀번호가 설정되어 있지 않습니다.</translation>
    </message>
    <message>
        <source>Cannot remove file key: The database does not have a file key.</source>
        <translation>키를 삭제할 수 없음: 데이터베이스에 파일 키가 설정되어 있지 않습니다.</translation>
    </message>
    <message>
        <source>Loading the new key file failed: %1</source>
        <translation>새 키 파일 불러오기 실패: %1</translation>
    </message>
    <message>
        <source>Found unexpected Key type %1</source>
        <translation>예상하지 못한 키 형식 %1</translation>
    </message>
    <message>
        <source>Cannot remove all the keys from a database.</source>
        <translation>데이터베이스에서 모든 키를 삭제할 수 없습니다.</translation>
    </message>
    <message>
        <source>Show a database&apos;s information.</source>
        <translation>데이터베이스 정보를 표시합니다.</translation>
    </message>
    <message>
        <source>UUID: </source>
        <translation>UUID: </translation>
    </message>
    <message>
        <source>Name: </source>
        <translation>이름: </translation>
    </message>
    <message>
        <source>Description: </source>
        <translation>설명: </translation>
    </message>
    <message>
        <source>Cipher: </source>
        <translation>암호화: </translation>
    </message>
    <message>
        <source>KDF: </source>
        <translation>KDF: </translation>
    </message>
    <message>
        <source>Recycle bin is enabled.</source>
        <translation>휴지통이 활성화되었습니다.</translation>
    </message>
    <message>
        <source>Recycle bin is not enabled.</source>
        <translation>휴지통이 비활성화되었습니다.</translation>
    </message>
    <message>
        <source>Location</source>
        <translation>위치</translation>
    </message>
    <message>
        <source>Database created</source>
        <translation>데이터베이스 생성됨</translation>
    </message>
    <message>
        <source>Last saved</source>
        <translation>마지막 저장</translation>
    </message>
    <message>
        <source>Unsaved changes</source>
        <translation>저장하지 않은 변경 사항</translation>
    </message>
    <message>
        <source>yes</source>
        <translation>예</translation>
    </message>
    <message>
        <source>no</source>
        <translation>아니요</translation>
    </message>
    <message>
        <source>Number of groups</source>
        <translation>그룹 개수</translation>
    </message>
    <message>
        <source>Number of entries</source>
        <translation>항목 개수</translation>
    </message>
    <message>
        <source>Number of expired entries</source>
        <translation>내보낸 항목 개수</translation>
    </message>
    <message>
        <source>Unique passwords</source>
        <translation>중복되지 않는 비밀번호</translation>
    </message>
    <message>
        <source>Non-unique passwords</source>
        <translation>중복된 비밀번호</translation>
    </message>
    <message>
        <source>Maximum password reuse</source>
        <translation>최대 비밀번호 재사용</translation>
    </message>
    <message>
        <source>Number of short passwords</source>
        <translation>짧은 비밀번호 개수</translation>
    </message>
    <message>
        <source>Number of weak passwords</source>
        <translation>약한 비밀번호 개수</translation>
    </message>
    <message>
        <source>Entries excluded from reports</source>
        <translation>보고서에서 제외된 항목</translation>
    </message>
    <message>
        <source>Average password length</source>
        <translation>평균 비밀번호 길이</translation>
    </message>
    <message>
        <source>Number of passkeys</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Entries with TOTP setup</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Word count for the diceware passphrase.</source>
        <translation>주사위 비밀번호 단어 개수입니다.</translation>
    </message>
    <message>
        <source>count</source>
        <comment>CLI parameter</comment>
        <translation>count</translation>
    </message>
    <message>
        <source>Wordlist for the diceware generator.
[Default: EFF English]</source>
        <translation>주사위 비밀번호 생성 시 사용할 단어 목록입니다.
[기본값: EFF 영어]</translation>
    </message>
    <message>
        <source>Generate a new random diceware passphrase.</source>
        <translation>새로운 주사위 비밀번호를 생성합니다.</translation>
    </message>
    <message>
        <source>Invalid word count %1</source>
        <translation>잘못된 단어 개수 %1</translation>
    </message>
    <message>
        <source>Title for the entry.</source>
        <translation>항목의 제목입니다.</translation>
    </message>
    <message>
        <source>title</source>
        <translation>제목</translation>
    </message>
    <message>
        <source>Edit an entry.</source>
        <translation>항목을 편집합니다.</translation>
    </message>
    <message>
        <source>Path of the entry to edit.</source>
        <translation>편집할 항목의 경로입니다.</translation>
    </message>
    <message>
        <source>Not changing any field for entry %1.</source>
        <translation>항목 %1의 필드를 변경하지 않습니다.</translation>
    </message>
    <message>
        <source>Enter new password for entry: </source>
        <translation>항목의 새로운 비밀번호 입력: </translation>
    </message>
    <message>
        <source>Successfully edited entry %1.</source>
        <translation>항목 %1을(를) 편집했습니다.</translation>
    </message>
    <message>
        <source>Perform advanced analysis on the password.</source>
        <translation>비밀번호에 고급 분석을 시행합니다.</translation>
    </message>
    <message>
        <source>Password for which to estimate the entropy.</source>
        <translation>엔트로피를 예상할 비밀번호입니다.</translation>
    </message>
    <message>
        <source>Estimate the entropy of a password.</source>
        <translation>비밀번호의 예상 엔트로피를 계산합니다.</translation>
    </message>
    <message>
        <source>Length %1</source>
        <translation>길이 %1</translation>
    </message>
    <message>
        <source>Entropy %1</source>
        <translation>엔트로피 %1</translation>
    </message>
    <message>
        <source>Log10 %1</source>
        <translation>Log10 %1</translation>
    </message>
    <message>
        <source>Multi-word extra bits %1</source>
        <translation>여러 단어 추가 비트 %1</translation>
    </message>
    <message>
        <source>Type: Bruteforce</source>
        <translation>형식: 무작위 대입</translation>
    </message>
    <message>
        <source>Type: Dictionary</source>
        <translation>형식: 사전</translation>
    </message>
    <message>
        <source>Type: Dict+Leet</source>
        <translation>형식: 사전+Leet</translation>
    </message>
    <message>
        <source>Type: User Words</source>
        <translation>형식: 사용자 단어</translation>
    </message>
    <message>
        <source>Type: User+Leet</source>
        <translation>형식: 사용자+Leet</translation>
    </message>
    <message>
        <source>Type: Repeated</source>
        <translation>형식: 반복됨</translation>
    </message>
    <message>
        <source>Type: Sequence</source>
        <translation>형식: 시퀀스</translation>
    </message>
    <message>
        <source>Type: Spatial</source>
        <translation>형식: 인접</translation>
    </message>
    <message>
        <source>Type: Date</source>
        <translation>형식: 날짜</translation>
    </message>
    <message>
        <source>Type: Bruteforce(Rep)</source>
        <translation>형식: 무작위 대입(반복)</translation>
    </message>
    <message>
        <source>Type: Dictionary(Rep)</source>
        <translation>형식: 사전(반복)</translation>
    </message>
    <message>
        <source>Type: Dict+Leet(Rep)</source>
        <translation>형식: 사전+Leet(반복)</translation>
    </message>
    <message>
        <source>Type: User Words(Rep)</source>
        <translation>형식: 사용자 단어(반복)</translation>
    </message>
    <message>
        <source>Type: User+Leet(Rep)</source>
        <translation>형식: 사용자+Leet(반복)</translation>
    </message>
    <message>
        <source>Type: Repeated(Rep)</source>
        <translation>형식: 반복됨(반복)</translation>
    </message>
    <message>
        <source>Type: Sequence(Rep)</source>
        <translation>형식: 시퀀스(반복)</translation>
    </message>
    <message>
        <source>Type: Spatial(Rep)</source>
        <translation>형식: 인접(반복)</translation>
    </message>
    <message>
        <source>Type: Date(Rep)</source>
        <translation>형식: 날짜(반복)</translation>
    </message>
    <message>
        <source>Type: Unknown (%1)</source>
        <translation>형식: 알 수 없음(%1)</translation>
    </message>
    <message>
        <source>Entropy %1 (%2)</source>
        <translation>엔트로피 %1(%2)</translation>
    </message>
    <message>
        <source>*** Password length (%1) != sum of length of parts (%2) ***</source>
        <translation>*** 비밀번호 길이 (%1) != 개별 부분 길이의 합 (%2) ***</translation>
    </message>
    <message>
        <source>Exit interactive mode.</source>
        <translation>대화형 모드를 종료합니다.</translation>
    </message>
    <message>
        <source>Exports the content of a database to standard output in the specified format.</source>
        <translation>데이터베이스 내용을 지정한 형식으로 표준 출력으로 내보냅니다.</translation>
    </message>
    <message>
        <source>Unable to export database to XML: %1</source>
        <translation>XML로 데이터베이스를 내보낼 수 없음: %1</translation>
    </message>
    <message>
        <source>Unsupported format %1</source>
        <translation>지원하지 않는 형식: %1</translation>
    </message>
    <message>
        <source>Length of the generated password</source>
        <translation>생성된 비밀번호의 길이</translation>
    </message>
    <message>
        <source>length</source>
        <translation>길이</translation>
    </message>
    <message>
        <source>Use lowercase characters</source>
        <translation>소문자 사용</translation>
    </message>
    <message>
        <source>Use uppercase characters</source>
        <translation>대문자 사용</translation>
    </message>
    <message>
        <source>Use numbers</source>
        <translation>숫자 사용</translation>
    </message>
    <message>
        <source>Use special characters</source>
        <translation>특수 문자 사용</translation>
    </message>
    <message>
        <source>Use extended ASCII</source>
        <translation>확장 ASCII 사용</translation>
    </message>
    <message>
        <source>Exclude character set</source>
        <translation>제외할 문자 집합</translation>
    </message>
    <message>
        <source>chars</source>
        <translation>글자</translation>
    </message>
    <message>
        <source>Use custom character set</source>
        <translation>사용자 정의 문자 집합 사용</translation>
    </message>
    <message>
        <source>Exclude similar looking characters</source>
        <translation>비슷하게 생긴 문자 제외</translation>
    </message>
    <message>
        <source>Include characters from every selected group</source>
        <translation>모든 그룹에서 글자 선택</translation>
    </message>
    <message>
        <source>Generate a new random password.</source>
        <translation>새 무작위 비밀번호를 생성합니다.</translation>
    </message>
    <message>
        <source>Invalid password length %1</source>
        <translation>잘못된 비밀번호 길이: %1</translation>
    </message>
    <message>
        <source>Invalid password generator after applying all options</source>
        <translation>모든 옵션을 적용했을 때 비밀번호 생성기가 잘못됨</translation>
    </message>
    <message>
        <source>Display command help.</source>
        <translation>명령 도움말을 표시합니다.</translation>
    </message>
    <message>
        <source>Available commands:</source>
        <translation>사용 가능한 명령:</translation>
    </message>
    <message>
        <source>Import the contents of an XML database.</source>
        <translation>XML 데이터베이스의 내용을 가져옵니다.</translation>
    </message>
    <message>
        <source>Path of the XML database export.</source>
        <translation>XML로 데이터베이스를 내보낼 경로입니다.</translation>
    </message>
    <message>
        <source>Path of the new database.</source>
        <translation>새 데이터베이스의 경로입니다.</translation>
    </message>
    <message>
        <source>Unable to import XML database: %1</source>
        <translation>XML 데이터베이스를 가져올 수 없음: %1</translation>
    </message>
    <message>
        <source>Successfully imported database.</source>
        <translation>데이터베이스를 가져왔습니다.</translation>
    </message>
    <message>
        <source>Unknown command %1</source>
        <translation>알 수 없는 명령 %1</translation>
    </message>
    <message>
        <source>

Available commands:
</source>
        <translation>

사용 가능한 명령:
</translation>
    </message>
    <message>
        <source>Name of the command to execute.</source>
        <translation>실행할 명령 이름입니다.</translation>
    </message>
    <message>
        <source>Displays debugging information.</source>
        <translation>디버그 정보를 표시합니다.</translation>
    </message>
    <message>
        <source>Invalid command %1.</source>
        <translation>잘못된 명령 %1.</translation>
    </message>
    <message>
        <source>Recursively list the elements of the group.</source>
        <translation>그룹의 구성 요소를 재귀적으로 표시합니다.</translation>
    </message>
    <message>
        <source>Flattens the output to single lines.</source>
        <translation>출력을 한 줄로 합칩니다.</translation>
    </message>
    <message>
        <source>List database entries.</source>
        <translation>데이터베이스 항목을 표시합니다.</translation>
    </message>
    <message>
        <source>Path of the group to list. Default is /</source>
        <translation>표시할 그룹의 경로입니다. 기본값은 /입니다</translation>
    </message>
    <message>
        <source>Cannot find group %1.</source>
        <translation>그룹 %1을(를) 찾을 수 없습니다.</translation>
    </message>
    <message>
        <source>Use the same credentials for both database files.</source>
        <translation>두 데이터베이스 파일에 같은 자격 증명을 사용합니다.</translation>
    </message>
    <message>
        <source>Key file of the database to merge from.</source>
        <translation>합칠 데이터베이스 파일의 키 파일입니다.</translation>
    </message>
    <message>
        <source>Deactivate password key for the database to merge from.</source>
        <translation>합칠 데이터베이스의 비밀번호 키를 비활성화합니다.</translation>
    </message>
    <message>
        <source>Only print the changes detected by the merge operation.</source>
        <translation>합치기 작업으로 변경할 사항만 출력합니다.</translation>
    </message>
    <message>
        <source>Yubikey slot for the second database.</source>
        <translation>두 번째 데이터베이스의 YubiKey 슬롯입니다.</translation>
    </message>
    <message>
        <source>slot</source>
        <translation>슬롯</translation>
    </message>
    <message>
        <source>Merge two databases.</source>
        <translation>두 데이터베이스를 합칩니다.</translation>
    </message>
    <message>
        <source>Path of the database to merge from.</source>
        <translation>합칠 원본 데이터베이스 경로입니다.</translation>
    </message>
    <message>
        <source>Error reading merge file:
%1</source>
        <translation>합칠 파일을 읽는 중 오류 발생:
%1</translation>
    </message>
    <message>
        <source>Unable to save database to file : %1</source>
        <translation>데이터베이스를 파일로 저장할 수 없음: %1</translation>
    </message>
    <message>
        <source>Successfully merged %1 into %2.</source>
        <translation>%1을(를) %2(으)로 합쳤습니다.</translation>
    </message>
    <message>
        <source>Database was not modified by merge operation.</source>
        <translation>수정 작업으로 데이터베이스가 변경되지 않았습니다.</translation>
    </message>
    <message>
        <source>Moves an entry to a new group.</source>
        <translation>항목을 새 그룹으로 이동합니다.</translation>
    </message>
    <message>
        <source>Path of the entry to move.</source>
        <translation>이동할 항목의 경로입니다.</translation>
    </message>
    <message>
        <source>Path of the destination group.</source>
        <translation>대상 그룹의 경로입니다.</translation>
    </message>
    <message>
        <source>Could not find group with path %1.</source>
        <translation>경로 %1에서 그룹을 찾을 수 없습니다.</translation>
    </message>
    <message>
        <source>Entry is already in group %1.</source>
        <translation>경로 %1에 항목이 이미 있습니다.</translation>
    </message>
    <message>
        <source>Successfully moved entry %1 to group %2.</source>
        <translation>항목 %1을(를) 그룹 %2(으)로 이동했습니다.</translation>
    </message>
    <message>
        <source>Open a database.</source>
        <translation>데이터베이스를 엽니다.</translation>
    </message>
    <message>
        <source>Path of the entry to remove.</source>
        <translation>삭제할 항목의 경로입니다.</translation>
    </message>
    <message>
        <source>Unable to save database to file: %1</source>
        <translation>데이터베이스를 파일로 저장할 수 없음: %1</translation>
    </message>
    <message>
        <source>Successfully recycled entry %1.</source>
        <translation>항목 %1을(를) 휴지통으로 이동했습니다.</translation>
    </message>
    <message>
        <source>Successfully deleted entry %1.</source>
        <translation>항목 %1을(를) 삭제했습니다.</translation>
    </message>
    <message>
        <source>Path of the group to remove.</source>
        <translation>삭제할 그룹의 경로입니다.</translation>
    </message>
    <message>
        <source>Cannot remove root group from database.</source>
        <translation>데이터베이스 루트 그룹을 삭제할 수 없습니다.</translation>
    </message>
    <message>
        <source>Successfully recycled group %1.</source>
        <translation>그룹 %1을(를) 휴지통으로 이동했습니다.</translation>
    </message>
    <message>
        <source>Successfully deleted group %1.</source>
        <translation>그룹 %1을(를) 삭제했습니다.</translation>
    </message>
    <message>
        <source>Find entries quickly.</source>
        <translation>빠르게 항목을 찾습니다.</translation>
    </message>
    <message>
        <source>Search term.</source>
        <translation>항목을 검색합니다.</translation>
    </message>
    <message>
        <source>Show the entry&apos;s current TOTP.</source>
        <translation>항목의 현재 TOTP를 표시합니다.</translation>
    </message>
    <message>
        <source>Show the protected attributes in clear text.</source>
        <translation>보호된 속성을 평문으로 표시합니다.</translation>
    </message>
    <message>
        <source>Show all the attributes of the entry.</source>
        <translation>항목의 모든 속성을 표시합니다.</translation>
    </message>
    <message>
        <source>Show the attachments of the entry.</source>
        <translation>항목의 첨부를 표시합니다.</translation>
    </message>
    <message>
        <source>Names of the attributes to show. This option can be specified more than once, with each attribute shown one-per-line in the given order. If no attributes are specified, a summary of the default attributes is given.</source>
        <translation>표시할 속성 이름입니다. 이 옵션은 한 번 이상 사용할 수 있으며, 주어진 순서대로 각각 속성을 한 줄에 하나씩 표시합니다. 속성을 지정하지 않으면 기본 속성의 요약을 표시합니다.</translation>
    </message>
    <message>
        <source>attribute</source>
        <translation>속성</translation>
    </message>
    <message>
        <source>Show an entry&apos;s information.</source>
        <translation>항목 정보를 표시합니다.</translation>
    </message>
    <message>
        <source>Name of the entry to show.</source>
        <translation>표시할 항목 이름입니다.</translation>
    </message>
    <message>
        <source>ERROR: unknown attribute %1.</source>
        <translation>오류: 알 수 없는 속성 %1.</translation>
    </message>
    <message>
        <source>No attachments present.</source>
        <translation>첨부가 없습니다.</translation>
    </message>
    <message>
        <source>Attachments:</source>
        <translation>첨부:</translation>
    </message>
    <message>
        <source>Failed to open database file %1: not found</source>
        <translation>데이터베이스 파일 %1을(를) 열 수 없음: 찾을 수 없음</translation>
    </message>
    <message>
        <source>Failed to open database file %1: not a plain file</source>
        <translation>데이터베이스 파일 %1을(를) 열 수 없음: 일반 파일이 아님</translation>
    </message>
    <message>
        <source>Failed to open database file %1: not readable</source>
        <translation>데이터베이스 파일 %1을(를) 열 수 없음: 읽을 수 없음</translation>
    </message>
    <message>
        <source>Enter password to unlock %1: </source>
        <translation>%1의 잠금 해제 비밀번호 입력:</translation>
    </message>
    <message>
        <source>Failed to load key file %1: %2</source>
        <translation>키 파일 %1을(를) 불러올 수 없음: %2</translation>
    </message>
    <message>
        <source>WARNING: You are using an old key file format which KeePassXC may
stop supporting in the future.

Please consider generating a new key file.</source>
        <translation>경고: KeePassXC에서 차후에 지원을 중단할 수도 있는
이전 키 파일 형식을 사용하고 있습니다.

새 키 파일을 생성하기를 추천합니다.</translation>
    </message>
    <message>
        <source>Invalid YubiKey slot %1</source>
        <translation>잘못된 YubiKey 슬롯 %1</translation>
    </message>
    <message>
        <source>Invalid YubiKey serial %1</source>
        <translation>잘못된 YubiKey 일련 번호 %1</translation>
    </message>
    <message>
        <source>Please present or touch your YubiKey to continue.</source>
        <translation>계속 진행하려면 YubiKey를 연결하거나 버튼을 누르십시오...</translation>
    </message>
    <message>
        <source>Enter password to encrypt database (optional): </source>
        <translation>데이터베이스를 암호화할 비밀번호 입력(선택 사항):</translation>
    </message>
    <message>
        <source>Do you want to create a database with an empty password? [y/N]: </source>
        <translation>빈 비밀번호를 사용해서 데이터베이스를 만드시겠습니까? [y/N]: </translation>
    </message>
    <message>
        <source>Repeat password: </source>
        <translation>비밀번호 반복: </translation>
    </message>
    <message>
        <source>Error: Passwords do not match.</source>
        <translation>오류: 비밀번호가 일치하지 않습니다.</translation>
    </message>
    <message>
        <source>No program defined for clipboard manipulation</source>
        <translation>클립보드 변경 프로그램이 지정되지 않았음</translation>
    </message>
    <message>
        <source>All clipping programs failed. Tried %1
</source>
        <translation>모든 클립보드 프로그램이 실패했습니다. 시도: %1
</translation>
    </message>
    <message>
        <source>Creating KeyFile %1 failed: %2</source>
        <translation>키 파일 %1 생성 실패: %2</translation>
    </message>
    <message>
        <source>Loading KeyFile %1 failed: %2</source>
        <translation>키 파일 %1 불러오기 실패: %2</translation>
    </message>
    <message>
        <source>HIBP file, line %1: parse error</source>
        <translation>HIBP 파일 %1줄: 처리 오류</translation>
    </message>
    <message>
        <source>To use okon, you must provide a post-processed file (e.g. file.okon)</source>
        <translation>okon을 사용하려면 후처리된 파일을 지정해야 합니다(예: file.okon)</translation>
    </message>
    <message>
        <source>Could not start okon process: %1</source>
        <translation>okon 프로세스를 시작할 수 없음: %1</translation>
    </message>
    <message>
        <source>Error: okon process did not finish</source>
        <translation>오류: okon 프로세스가 끝나지 않았음</translation>
    </message>
    <message>
        <source>Failed to load okon processed database: %1</source>
        <translation>okon에서 처리한 데이터베이스를 불러올 수 없음: %1</translation>
    </message>
    <message>
        <source>Very weak password</source>
        <translation>매우 약한 비밀번호</translation>
    </message>
    <message>
        <source>Password entropy is %1 bits</source>
        <translation>비밀번호 엔트로피가 %1비트임</translation>
    </message>
    <message>
        <source>Weak password</source>
        <translation>약한 비밀번호</translation>
    </message>
    <message>
        <source>Used in %1/%2</source>
        <translation>%1/%2에서 사용됨</translation>
    </message>
    <message numerus="yes">
        <source>Password is used %1 time(s)</source>
        <translation><numerusform>비밀번호가 %1회 사용됨</numerusform></translation>
    </message>
    <message>
        <source>Password has expired</source>
        <translation>비밀번호가 만료됨</translation>
    </message>
    <message>
        <source>Password expiry was %1</source>
        <translation>비밀번호 만료: %1</translation>
    </message>
    <message>
        <source>Password expires on %1</source>
        <translation>비밀번호가 %1에 만료됨</translation>
    </message>
    <message>
        <source>Password is about to expire</source>
        <translation>비밀번호가 빠른 시일 내 만료됨</translation>
    </message>
    <message numerus="yes">
        <source>Password expires in %1 day(s)</source>
        <translation><numerusform>비밀번호가 %1일 후에 만료됨</numerusform></translation>
    </message>
    <message>
        <source>Password will expire soon</source>
        <translation>비밀번호가 곧 만료됨</translation>
    </message>
    <message>
        <source>Version %1</source>
        <translation>버전 %1</translation>
    </message>
    <message>
        <source>Build Type: %1</source>
        <translation>빌드 형식: %1</translation>
    </message>
    <message>
        <source>Revision: %1</source>
        <translation>리비전: %1</translation>
    </message>
    <message>
        <source>Distribution: %1</source>
        <translation>배포판: %1</translation>
    </message>
    <message>
        <source>Debugging mode is disabled.</source>
        <translation>디버그 모드가 비활성화되었습니다.</translation>
    </message>
    <message>
        <source>Debugging mode is enabled.</source>
        <translation>디버그 모드가 활성화되었습니다.</translation>
    </message>
    <message>
        <source>Operating system: %1
CPU architecture: %2
Kernel: %3 %4</source>
        <translation>운영 체제: %1
CPU 아키텍처: %2
커널: %3 %4</translation>
    </message>
    <message>
        <source>Auto-Type</source>
        <translation>자동 입력</translation>
    </message>
    <message>
        <source>SSH Agent</source>
        <translation>SSH 에이전트</translation>
    </message>
    <message>
        <source>KeeShare</source>
        <translation>KeeShare</translation>
    </message>
    <message>
        <source>Quick Unlock</source>
        <translation>빠른 잠금 해제</translation>
    </message>
    <message>
        <source>Secret Service Integration</source>
        <translation>비밀 서비스 통합</translation>
    </message>
    <message>
        <source>Enabled extensions:</source>
        <translation>활성화된 확장 기능:</translation>
    </message>
    <message numerus="yes">
        <source>over %1 year(s)</source>
        <translation><numerusform>%1년 이상</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>about %1 month(s)</source>
        <translation><numerusform>약 %1개월</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>%1 week(s)</source>
        <translation><numerusform>%1주</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>%1 day(s)</source>
        <translation><numerusform>%1일</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>%1 hour(s)</source>
        <translation><numerusform>%1시간</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>%1 minute(s)</source>
        <translation><numerusform>%1분</numerusform></translation>
    </message>
    <message>
        <source>Botan library must be at least %1, found %2.%3.%4</source>
        <translation>Botan 라이브러리의 최소 필요 버전은 %1이지만 %2.%3.%4 버전이 설치되어 있음</translation>
    </message>
    <message>
        <source>Cryptographic libraries:</source>
        <translation>암호화 라이브러리:</translation>
    </message>
    <message>
        <source>AES (%1 rounds)</source>
        <translation>AES(%1라운드)</translation>
    </message>
    <message>
        <source>Argon2%1 (%2 rounds, %3 KB)</source>
        <translation>Argon2%1(%2라운드, %3 KB)</translation>
    </message>
    <message>
        <source>SymmetricCipher::init: Invalid cipher mode.</source>
        <translation>SymmetricCipher::init: 암호화 모드가 잘못되었습니다.</translation>
    </message>
    <message>
        <source>SymmetricCipher::init: Invalid IV size of %1 for %2.</source>
        <translation>SymmetricCipher::init: %2을(를) 위한 %1의 IV 크기가 잘못되었습니다.</translation>
    </message>
    <message>
        <source>Cipher not initialized prior to use.</source>
        <translation>암호화를 사용하기 전에 초기화하지 않았습니다.</translation>
    </message>
    <message>
        <source>Cannot process 0 length data.</source>
        <translation>길이가 0인 데이터를 처리할 수 없습니다.</translation>
    </message>
    <message>
        <source>unknown executable (DBus address %1)</source>
        <translation>알 수 없는 실행 파일(DBus 주소 %1)</translation>
    </message>
    <message>
        <source>%1 (invalid executable path)</source>
        <translation>%1(잘못된 실행 파일 경로)</translation>
    </message>
    <message>
        <source>NULL device</source>
        <translation>NULL 장치</translation>
    </message>
    <message>
        <source>error reading from device</source>
        <translation>장치에서 읽는 중 오류 발생</translation>
    </message>
    <message>
        <source>file empty</source>
        <translation>파일이 비어 있음</translation>
    </message>
    <message>
        <source>AES 256-bit</source>
        <translation>AES 256비트</translation>
    </message>
    <message>
        <source>Twofish 256-bit</source>
        <translation>Twofish 256비트</translation>
    </message>
    <message>
        <source>ChaCha20 256-bit</source>
        <translation>ChaCha20 256비트</translation>
    </message>
    <message>
        <source>Argon2d (KDBX 4 – recommended)</source>
        <translation>Argon2d(KDBX 4 – 추천)</translation>
    </message>
    <message>
        <source>Argon2id (KDBX 4)</source>
        <translation>Argon2id(KDBX 4)</translation>
    </message>
    <message>
        <source>AES-KDF (KDBX 4)</source>
        <translation>AES-KDF(KDBX 4)</translation>
    </message>
    <message>
        <source>AES-KDF (KDBX 3)</source>
        <translation>AES-KDF(KDBX 3)</translation>
    </message>
    <message>
        <source>Existing single-instance lock file is invalid. Launching new instance.</source>
        <translation>존재하는 단일 인스턴스 잠금 파일이 잘못되었습니다. 새 인스턴스를 실행합니다.</translation>
    </message>
    <message>
        <source>The lock file could not be created. Single-instance mode disabled.</source>
        <translation>잠금 파일을 만들 수 없습니다. 단일 인스턴스 모드가 비활성화되었습니다.</translation>
    </message>
    <message numerus="yes">
        <source>Clearing the clipboard in %1 second(s)…</source>
        <translation><numerusform>%1초 후 클립보드를 지웁니다...</numerusform></translation>
    </message>
    <message>
        <source>Group</source>
        <translation>그룹</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>제목</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>사용자 이름</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>비밀번호</translation>
    </message>
    <message>
        <source>TOTP</source>
        <translation>TOTP</translation>
    </message>
    <message>
        <source>Icon</source>
        <translation>아이콘</translation>
    </message>
    <message>
        <source>Last Modified</source>
        <translation>마지막 수정</translation>
    </message>
    <message>
        <source>Created</source>
        <translation>생성</translation>
    </message>
    <message>
        <source>Benchmark %1 delay</source>
        <translation>%1 벤치마크 지연 시간</translation>
    </message>
    <message numerus="yes">
        <source>%1 ms</source>
        <comment>milliseconds</comment>
        <translation><numerusform>%1 ms</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>%1 s</source>
        <comment>seconds</comment>
        <translation><numerusform>%1초</numerusform></translation>
    </message>
    <message>
        <source>Do you really want to move entry &quot;%1&quot; to the recycle bin?</source>
        <translation>항목 &quot;%1&quot;을(를) 휴지통으로 이동하시겠습니까?</translation>
    </message>
    <message numerus="yes">
        <source>Do you really want to move %n entry(s) to the recycle bin?</source>
        <translation><numerusform>항목 %n개를 휴지통으로 이동하시겠습니까?</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>Entry &quot;%1&quot; has %2 reference(s). Do you want to overwrite references with values, skip this entry, or delete anyway?</source>
        <translation><numerusform>항목 &quot;%1&quot;이(가) %2회 참조되었습니다. 해당 참조를 값으로 덮어쓰거나, 이 항목을 건너뛰거나, 그래도 삭제하시겠습니까?</numerusform></translation>
    </message>
    <message>
        <source>User name</source>
        <translation>사용자 이름</translation>
    </message>
    <message>
        <source>Browser Statistics</source>
        <translation>브라우저 통계</translation>
    </message>
    <message>
        <source>Health Check</source>
        <translation>안전성 검사</translation>
    </message>
    <message>
        <source>HIBP</source>
        <translation>HIBP</translation>
    </message>
    <message>
        <source>Statistics</source>
        <translation>통계</translation>
    </message>
    <message>
        <source>Unsupported key file version: %1</source>
        <translation>지원하지 않는 키 파일 버전: %1</translation>
    </message>
    <message>
        <source>Checksum mismatch! Key file may be corrupt.</source>
        <translation>체크섬이 일치하지 않습니다! 키 파일이 손상되었을 수도 있습니다.</translation>
    </message>
    <message>
        <source>Unexpected key file data! Key file may be corrupt.</source>
        <translation>예상하지 못한 키 파일 데이터입니다! 키 파일이 손상되었을 수도 있습니다.</translation>
    </message>
    <message>
        <source>KeePassXC - cross-platform password manager</source>
        <translation>KeePassXC - 크로스 플랫폼 비밀번호 관리자</translation>
    </message>
    <message>
        <source>filenames of the password databases to open (*.kdbx)</source>
        <translation>열 비밀번호 데이터베이스 파일 이름(*.kdbx)</translation>
    </message>
    <message>
        <source>path to a custom config file</source>
        <translation>사용자 정의 설정 파일 경로</translation>
    </message>
    <message>
        <source>path to a custom local config file</source>
        <translation>사용자 정의 로컬 설정 파일 경로</translation>
    </message>
    <message>
        <source>lock all open databases</source>
        <translation>모든 열린 데이터베이스 잠금</translation>
    </message>
    <message>
        <source>key file of the database</source>
        <translation>데이터베이스 키 파일</translation>
    </message>
    <message>
        <source>read password of the database from stdin</source>
        <translation>표준 입력에서 데이터베이스 비밀번호 읽기</translation>
    </message>
    <message>
        <source>Database failed to lock.</source>
        <translation>데이터베이스를 잠글 수 없습니다.</translation>
    </message>
    <message>
        <source>Another instance of KeePassXC is already running.</source>
        <translation>다른 KeePassXC 인스턴스가 이미 실행 중입니다.</translation>
    </message>
    <message>
        <source>KeePassXC is not running. No open database to lock</source>
        <translation>KeePassXC가 실행 중이 아닙니다. 잠글 데이터베이스가 열리지 않았음</translation>
    </message>
    <message>
        <source>Fatal error while testing the cryptographic functions.</source>
        <translation>암호화 함수를 시험하는 중 오류가 발생하였습니다.</translation>
    </message>
    <message>
        <source>KeePassXC - Error</source>
        <translation>KeePassXC - 오류</translation>
    </message>
    <message>
        <source>Database password: </source>
        <translation>데이터베이스 비밀번호: </translation>
    </message>
    <message>
        <source>Invalid Settings</source>
        <comment>TOTP</comment>
        <translation>잘못된 설정</translation>
    </message>
    <message>
        <source>Invalid Key</source>
        <comment>TOTP</comment>
        <translation>잘못된 키</translation>
    </message>
    <message>
        <source>Failed to create Windows Hello credential.</source>
        <translation>Windows Hello 자격 증명을 생성할 수 없습니다.</translation>
    </message>
    <message>
        <source>Failed to sign challenge using Windows Hello.</source>
        <translation>Windows Hello로 Challenge를 서명할 수 없습니다.</translation>
    </message>
    <message>
        <source>Warning: Failed to block screenshot capture on a top-level window.</source>
        <translation>경고: 최상위 창의 화면 캡처를 차단할 수 없습니다.</translation>
    </message>
    <message>
        <source>Invalid Cipher</source>
        <translation>잘못된 암호화</translation>
    </message>
    <message>
        <source>Invalid KDF</source>
        <translation>잘못된 KDF</translation>
    </message>
    <message>
        <source>Access to all entries is denied</source>
        <translation>모든 항목 접근이 거부됨</translation>
    </message>
    <message>
        <source>allow screenshots and app recording (Windows/macOS)</source>
        <translation>스크린샷과 앱 녹화 허용(Windows/macOS)</translation>
    </message>
    <message>
        <source>Set the key file for the database.
This option is deprecated, use --set-key-file instead.</source>
        <translation>데이터베이스의 키 파일을 선택합니다.
이 옵션은 삭제될 예정입니다. --set-key-file 옵션을 대신 사용하십시오.</translation>
    </message>
    <message>
        <source>Databases have been locked.</source>
        <translation>데이터베이스가 잠겼습니다.</translation>
    </message>
    <message>
        <source>Attestation not supported</source>
        <translation>증명을 지원하지 않음</translation>
    </message>
    <message>
        <source>Credential is excluded</source>
        <translation>자격 증명이 제외됨</translation>
    </message>
    <message>
        <source>Passkeys request canceled</source>
        <translation>패스키 요청 취소됨</translation>
    </message>
    <message>
        <source>Invalid user verification</source>
        <translation>잘못된 사용자 검증</translation>
    </message>
    <message>
        <source>Empty public key</source>
        <translation>공개 키가 비어 있음</translation>
    </message>
    <message>
        <source>Invalid URL provided</source>
        <translation>잘못된 URL 지정됨</translation>
    </message>
    <message>
        <source>Passkeys</source>
        <translation>패스키</translation>
    </message>
    <message>
        <source>AES initialization failed</source>
        <translation>AES 초기화 실패</translation>
    </message>
    <message>
        <source>AES encrypt failed</source>
        <translation>AES 암호화 실패</translation>
    </message>
    <message>
        <source>Failed to store in Linux Keyring</source>
        <translation>리눅스 키링에 저장할 수 없음</translation>
    </message>
    <message>
        <source>Polkit returned an error: %1</source>
        <translation>Polkit에서 오류를 반환함: %1</translation>
    </message>
    <message>
        <source>Could not locate key in keyring</source>
        <translation>키링에서 키를 찾을 수 없음</translation>
    </message>
    <message>
        <source>Could not read key in keyring</source>
        <translation>키링에서 키를 읽을 수 없음</translation>
    </message>
    <message>
        <source>AES decrypt failed</source>
        <translation>AES 복호화 실패</translation>
    </message>
    <message>
        <source>No Polkit authentication agent was available</source>
        <translation>Polkit 인증 에이전트를 사용할 수 없음</translation>
    </message>
    <message>
        <source>Polkit authorization failed</source>
        <translation>Polkit 인증 실패</translation>
    </message>
    <message>
        <source>No Quick Unlock provider is available</source>
        <translation>빠른 잠금 해제 공급자를 사용할 수 없음</translation>
    </message>
    <message>
        <source>Failed to init KeePassXC crypto.</source>
        <translation>KeePassXC 암호화를 초기화할 수 없습니다.</translation>
    </message>
    <message>
        <source>Failed to encrypt key data.</source>
        <translation>키 데이터를 암호화할 수 없습니다.</translation>
    </message>
    <message>
        <source>Failed to get Windows Hello credential.</source>
        <translation>Windows Hello 자격 증명을 가져올 수 없습니다.</translation>
    </message>
    <message>
        <source>Failed to decrypt key data.</source>
        <translation>키 데이터를 복호화할 수 없습니다.</translation>
    </message>
    <message>
        <source>Origin is empty or not allowed</source>
        <translation>원본이 비어 있거나 허용되지 않음</translation>
    </message>
    <message>
        <source>Effective domain is not a valid domain</source>
        <translation>유효 도메인이 올바른 도메인이 아님</translation>
    </message>
    <message>
        <source>Origin and RP ID do not match</source>
        <translation>원본과 RP ID가 일치하지 않음</translation>
    </message>
    <message>
        <source>No supported algorithms were provided</source>
        <translation>지원하는 알고리즘을 제시하지 않았음</translation>
    </message>
    <message>
        <source>Wait for timer to expire</source>
        <translation>타이머 만료 대기 중</translation>
    </message>
    <message>
        <source>Challenge is shorter than required minimum length</source>
        <translation>Challenge가 필요한 최소 길이보다 짧음</translation>
    </message>
    <message>
        <source>user.id does not match the required length</source>
        <translation>user.id가 필요한 길이와 일치하지 않음</translation>
    </message>
    <message>
        <source>Favorite</source>
        <comment>Tag for favorite entries</comment>
        <translation>책갈피</translation>
    </message>
    <message>
        <source>File does not exist.</source>
        <translation>파일이 존재하지 않습니다.</translation>
    </message>
    <message>
        <source>Cannot open file: %1</source>
        <translation>파일을 열 수 없음: %1</translation>
    </message>
    <message>
        <source>Cannot parse file: %1 at position %2</source>
        <translation>파일을 해석할 수 없음: %1, 위치 %2</translation>
    </message>
    <message>
        <source>Failed to decrypt json file: %1</source>
        <translation>JSON 파일을 복호화할 수 없음: %1</translation>
    </message>
    <message>
        <source>Invalid encKeyValidation field</source>
        <translation>잘못된 encKeyValidation 필드</translation>
    </message>
    <message>
        <source>Invalid cipher list within encKeyValidation field</source>
        <translation>encKeyValidation 필드에 잘못된 암호화 목록이 있음</translation>
    </message>
    <message>
        <source>Wrong password</source>
        <translation>비밀번호가 잘못됨</translation>
    </message>
    <message>
        <source>Invalid encrypted data field</source>
        <translation>잘못된 암호화된 데이터 필드</translation>
    </message>
    <message>
        <source>Invalid cipher list within encrypted data field</source>
        <translation>암호화된 데이터 필드에 잘못된 암호화 목록이 있음</translation>
    </message>
    <message>
        <source>Cannot initialize cipher</source>
        <translation>암호화를 초기화할 수 없음</translation>
    </message>
    <message>
        <source>Cannot decrypt data</source>
        <translation>데이터를 복호화할 수 없음</translation>
    </message>
    <message>
        <source>Bitwarden Import</source>
        <translation>Bitwarden 가져오기</translation>
    </message>
    <message>
        <source>Archived</source>
        <comment>Tag for archived entries</comment>
        <translation>보관됨</translation>
    </message>
    <message>
        <source>Invalid 1PUX file format: Not a valid ZIP file.</source>
        <translation>잘못된 1PUX 파일 형식: 올바른 ZIP 파일이 아닙니다.</translation>
    </message>
    <message>
        <source>Invalid 1PUX file format: Missing export.data</source>
        <translation>잘못된 1PUX 파일 형식: export.data 파일이 없음</translation>
    </message>
    <message>
        <source>1Password Import</source>
        <translation>1Password 가져오기</translation>
    </message>
    <message>
        <source>Enter Shortcut</source>
        <translation>단축키 입력</translation>
    </message>
    <message>
        <source>Action</source>
        <translation>동작</translation>
    </message>
    <message>
        <source>Shortcuts</source>
        <translation>단축키</translation>
    </message>
    <message>
        <source>Unknown passkeys error</source>
        <translation>알 수 없는 패스키 오류</translation>
    </message>
    <message>
        <source>Invalid KDF iterations, cannot decrypt json file</source>
        <translation>잘못된 KDF 반복 횟수, JSON 파일을 복호화할 수 없음</translation>
    </message>
    <message>
        <source>Unsupported format, ensure your Bitwarden export is password-protected</source>
        <translation>지원하지 않는 형식, Bitwarden 내보내기 파일이 비밀번호로 보호되었는지 확인하십시오</translation>
    </message>
    <message>
        <source>Only PBKDF and Argon2 are supported, cannot decrypt json file</source>
        <translation>PBKDF와 Argon2만 지원함, JSON 파일을 복호화할 수 없음</translation>
    </message>
    <message>
        <source>Hardware Keys</source>
        <translation>하드웨어 키</translation>
    </message>
    <message>
        <source>Passkey</source>
        <translation>패스키</translation>
    </message>
    <message>
        <source>Reset Shortcuts</source>
        <translation>단축키 초기화</translation>
    </message>
    <message>
        <source>Double click an action to change its shortcut</source>
        <translation>동작을 두 번 클릭해서 단축키 변경</translation>
    </message>
    <message>
        <source>Filter...</source>
        <translation>필터...</translation>
    </message>
    <message>
        <source>Shortcut Conflict</source>
        <translation>단축키 충돌</translation>
    </message>
    <message>
        <source>Shortcut %1 conflicts with &apos;%2&apos;. Overwrite shortcut?</source>
        <translation>%1 단축키가 &apos;%2&apos;와(과) 충돌합니다. 단축키를 덮어쓰시겠습니까?</translation>
    </message>
    <message>
        <source>Format to use when exporting. Available choices are &apos;xml&apos;, &apos;csv&apos; or &apos;html&apos;. Defaults to &apos;xml&apos;.</source>
        <translation>내보낼 때 사용할 형식입니다. 사용 가능한 옵션은 &apos;xml&apos;, &apos;csv&apos; 또는 &apos;html&apos;입니다. 기본값은 &apos;xml&apos;입니다.</translation>
    </message>
    <message>
        <source>malformed string, possible unescaped delimiter</source>
        <translation>잘못된 문자열, 이스케이프되지 않은 구분자 가능성</translation>
    </message>
    <message>
        <source>missing closing delimiter</source>
        <translation>닫힘 구분 기호 누락</translation>
    </message>
    <message>
        <source>%1, row: %2, column: %3</source>
        <translation>%1, 행: %2, 열: %3</translation>
    </message>
    <message>
        <source>Encrypted files are not supported.</source>
        <translation>암호화된 파일은 지원되지 않습니다.</translation>
    </message>
    <message>
        <source>Proton Pass Import</source>
        <translation>Proton Pass 가져오기</translation>
    </message>
    <message>
        <source>Tags</source>
        <translation>태그</translation>
    </message>
    <message>
        <source>start minimized to the system tray</source>
        <translation>시스템 트레이에 최소화로 시작</translation>
    </message>
    <message>
        <source>Warning: the chosen wordlist is smaller than the minimum recommended size!</source>
        <translation>경고: 선택한 단어 목록이 최소 권장 크기보다 작습니다!</translation>
    </message>
    <message>
        <source>Invalid Step</source>
        <comment>TOTP</comment>
        <translation>잘못된 단계</translation>
    </message>
    <message>
        <source>Invalid Digits</source>
        <comment>TOTP</comment>
        <translation>잘못된 숫자</translation>
    </message>
    <message numerus="yes">
        <source>%1 character(s)</source>
        <translation><numerusform>%1 문자</numerusform></translation>
    </message>
    <message>
        <source>Do you really want to permanently delete the entry &quot;%1&quot;?</source>
        <translation>항목 &quot;%1&quot;을 영구적으로 삭제하시겠습니까?</translation>
    </message>
    <message numerus="yes">
        <source>Do you really want to permanently delete %n entry(s)?</source>
        <translation><numerusform>%n 항목을 영구적으로 삭제하시겠습니까?</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>Confirm Delete Entry(s)</source>
        <translation><numerusform>항목 삭제 확인</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>Confirm Recycle Entry(s)</source>
        <translation><numerusform>휴지통 항목 확인</numerusform></translation>
    </message>
    <message>
        <source>Confirm Delete Plugin Data</source>
        <translation>플러그인 데이터 삭제 확인</translation>
    </message>
    <message numerus="yes">
        <source>Delete plugin data from the selected entry(s)?</source>
        <translation><numerusform>선택한 항목에서 플러그인 데이터를 삭제하시겠습니까?</numerusform></translation>
    </message>
    <message>
        <source>Confirm Replace Entry References</source>
        <translation>항목 참조 교체 확인</translation>
    </message>
</context>
<context>
    <name>QtIOCompressor</name>
    <message>
        <source>Internal zlib error when compressing: </source>
        <translation>압축 중 내부 zlib 오류 발생: </translation>
    </message>
    <message>
        <source>Error writing to underlying device: </source>
        <translation>장치에 기록하는 중 오류 발생: </translation>
    </message>
    <message>
        <source>Error opening underlying device: </source>
        <translation>장치를 여는 중 오류 발생: </translation>
    </message>
    <message>
        <source>Error reading data from underlying device: </source>
        <translation>장치에서 읽는 중 오류 발생: </translation>
    </message>
    <message>
        <source>Internal zlib error when decompressing: </source>
        <translation>압축 푸는 중 내부 zlib 오류 발생: </translation>
    </message>
</context>
<context>
    <name>QtIOCompressor::open</name>
    <message>
        <source>The gzip format not supported in this version of zlib.</source>
        <translation>이 버전의 zlib에서 gzip 형식을 지원하지 않습니다.</translation>
    </message>
    <message>
        <source>Internal zlib error: </source>
        <translation>내부 zlib 오류: </translation>
    </message>
</context>
<context>
    <name>RemoteDesktopPortal</name>
    <message>
        <source>Remote desktop session is not active</source>
        <translation>원격 데스크톱 세션이 활성화되어 있지 않습니다</translation>
    </message>
    <message>
        <source>Session closed</source>
        <translation>세션이 종료되었습니다</translation>
    </message>
    <message>
        <source>User cancelled the interaction</source>
        <translation>사용자가 상호작용을 취소했습니다</translation>
    </message>
    <message>
        <source>User interaction was canceled for unknown reason</source>
        <translation>사용자 상호작용이 알 수 없는 이유로 취소되었습니다</translation>
    </message>
    <message>
        <source>Remote desktop session handle does not match expected path</source>
        <translation>원격 데스크톱 세션 핸들이 예상한 경로와 일치하지 않습니다</translation>
    </message>
</context>
<context>
    <name>RemoteHandler</name>
    <message>
        <source>Command `%1` did not finish in time. Process was killed.</source>
        <translation>`%1` 명령이 시간 내에 완료되지 않았습니다. 프로세스가 종료되었습니다.</translation>
    </message>
    <message>
        <source>Failed to upload merged database. Command `%1` did not finish in time. Process was killed.</source>
        <translation>병합된 데이터베이스를 업로드하지 못했습니다. `%1` 명령이 시간 내에 완료되지 않았습니다. 프로세스가 종료되었습니다.</translation>
    </message>
    <message>
        <source>Invalid download parameters provided.</source>
        <translation>잘못된 다운로드 인자가 지정되었습니다.</translation>
    </message>
    <message>
        <source>Command `%1` failed to download database.</source>
        <translation>`%1` 명령으로 데이터베이스를 다운로드하지 못했습니다.</translation>
    </message>
    <message>
        <source>Invalid database pointer or upload parameters provided.</source>
        <translation>잘못된 데이터베이스 포인터나 업로드 인자가 지정되었습니다.</translation>
    </message>
    <message>
        <source>Command `%1` exited with status code: %2</source>
        <translation>`%1` 명령이 종료되면서 다음 상태 코드를 반환함: %2</translation>
    </message>
    <message>
        <source>Failed to upload merged database. Command `%1` exited with status code: %2</source>
        <translation>병합된 데이터베이스를 업로드하지 못했습니다. `%1` 명령이 다음 상태 코드를 반환함: %2</translation>
    </message>
</context>
<context>
    <name>ReportsWidgetBrowserStatistics</name>
    <message>
        <source>Double-click entries to edit.</source>
        <translation>항목을 두 번 클릭하면 편집할 수 있습니다.</translation>
    </message>
    <message>
        <source>List of entry URLs</source>
        <translation>항목 URL 목록</translation>
    </message>
    <message>
        <source>Entry has no URLs set</source>
        <translation>항목에 설정한 URL이 없음</translation>
    </message>
    <message>
        <source>Allowed URLs</source>
        <translation>허용된 URL</translation>
    </message>
    <message>
        <source>Entry has no Browser Integration settings</source>
        <translation>항목에 브라우저 통합 설정이 없음</translation>
    </message>
    <message>
        <source>Denied URLs</source>
        <translation>거부된 URL</translation>
    </message>
    <message>
        <source> (Excluded)</source>
        <translation>(제외됨)</translation>
    </message>
    <message>
        <source>This entry is being excluded from reports</source>
        <translation>이 항목은 보고서에서 제외됨</translation>
    </message>
    <message>
        <source>Please wait, browser statistics is being calculated…</source>
        <translation>브라우저 통계를 계산하는 동안 잠시 기다려 주십시오…</translation>
    </message>
    <message>
        <source>No entries with a URL, or none has browser extension settings saved.</source>
        <translation>URL이 지정된 항목이나 브라우저 확장 설정이 저장된 항목이 없습니다.</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>제목</translation>
    </message>
    <message>
        <source>Path</source>
        <translation>경로</translation>
    </message>
    <message>
        <source>URLs</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>Edit Entry…</source>
        <translation>항목 편집…</translation>
    </message>
    <message numerus="yes">
        <source>Delete Entry(s)…</source>
        <translation><numerusform>항목 삭제...</numerusform></translation>
    </message>
    <message>
        <source>Exclude from reports</source>
        <translation>보고서에서 제외</translation>
    </message>
    <message numerus="yes">
        <source>Expire Entry(s)…</source>
        <translation><numerusform>항목 만료...</numerusform></translation>
    </message>
    <message>
        <source>Only show entries that have a URL</source>
        <translation>URL이 있는 항목만 표시</translation>
    </message>
    <message>
        <source>Only show entries that have been explicitly allowed or denied</source>
        <translation>명시적으로 허용되었거나 거부된 항목만 표시</translation>
    </message>
    <message>
        <source>Show expired entries</source>
        <translation>만료된 항목 표시</translation>
    </message>
    <message>
        <source> (Expired)</source>
        <translation>(만료됨)</translation>
    </message>
    <message numerus="yes">
        <source>Delete plugin data from Entry(s)…</source>
        <translation><numerusform>항목에서 플러그인 데이터 삭제...</numerusform></translation>
    </message>
</context>
<context>
    <name>ReportsWidgetHealthcheck</name>
    <message>
        <source>Show expired entries</source>
        <translation>만료된 항목 표시</translation>
    </message>
    <message>
        <source> (Expired)</source>
        <translation>(만료됨)</translation>
    </message>
    <message>
        <source>Hover over reason to show additional details. Double-click entries to edit.</source>
        <translation>이유 위에 마우스를 올려 두면 자세한 정보를 표시합니다. 항목을 두 번 클릭하면 편집할 수 있습니다.</translation>
    </message>
    <message>
        <source>Bad — password must be changed</source>
        <translation>나쁨 — 비밀번호를 변경해야 함</translation>
    </message>
    <message>
        <source>Poor — password should be changed</source>
        <translation>매우 약함 — 비밀번호 변경을 고려해야 함</translation>
    </message>
    <message>
        <source>Weak — consider changing the password</source>
        <translation>약함 — 비밀번호 변경을 권장함</translation>
    </message>
    <message>
        <source> (Excluded)</source>
        <translation>(제외됨)</translation>
    </message>
    <message>
        <source>This entry is being excluded from reports</source>
        <translation>이 항목은 보고서에서 제외됨</translation>
    </message>
    <message>
        <source>Please wait, health data is being calculated…</source>
        <translation>안전성 검사를 진행하는 동안 잠시 기다려 주십시오…</translation>
    </message>
    <message>
        <source>Congratulations, everything is healthy!</source>
        <translation>축하합니다, 모든 항목이 안전합니다!</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>제목</translation>
    </message>
    <message>
        <source>Path</source>
        <translation>경로</translation>
    </message>
    <message>
        <source>Score</source>
        <translation>점수</translation>
    </message>
    <message>
        <source>Reason</source>
        <translation>이유</translation>
    </message>
    <message>
        <source>Edit Entry…</source>
        <translation>항목 편집…</translation>
    </message>
    <message numerus="yes">
        <source>Delete Entry(s)…</source>
        <translation><numerusform>항목 삭제...</numerusform></translation>
    </message>
    <message>
        <source>Exclude from reports</source>
        <translation>보고서에서 제외</translation>
    </message>
    <message numerus="yes">
        <source>Expire Entry(s)…</source>
        <translation><numerusform>항목 만료...</numerusform></translation>
    </message>
    <message>
        <source>Show entries that have been excluded from reports</source>
        <translation>보고서에서 제외된 항목 표시</translation>
    </message>
</context>
<context>
    <name>ReportsWidgetHibp</name>
    <message>
        <source>CAUTION: This report requires sending information to the Have I Been Pwned online service (https://haveibeenpwned.com). If you proceed, your database passwords will be cryptographically hashed and the first five characters of those hashes will be sent securely to this service. Your database remains secure and cannot be reconstituted from this information. However, the number of passwords you send and your IP address will be exposed to this service.</source>
        <translation>경고: 이 보고서를 생성하려면 Have I Been Pwned 온라인 서비스(https://haveibeenpwned.com)로 정보를 보내야 합니다. 계속 진행하면 데이터베이스에 저장된 모든 비밀번호의 비밀번호학적 해시의 첫 5글자를 이 서비스로 안전하게 전송합니다. 데이터베이스는 안전하게 유지되며, 이 정보를 사용하여 데이터베이스에 저장된 원래 비밀번호를 복원할 수는 없습니다. 그러나 해당 온라인 서비스에서는 비밀번호를 보낸 횟수와 IP 주소를 알 수도 있습니다.</translation>
    </message>
    <message>
        <source>Perform Online Analysis</source>
        <translation>온라인 분석 시행</translation>
    </message>
    <message>
        <source>Also show entries that have been excluded from reports</source>
        <translation>보고서에서 제외된 항목도 표시</translation>
    </message>
    <message>
        <source>This build of KeePassXC does not have network functions. Networking is required to check your passwords against Have I Been Pwned databases.</source>
        <translation>현재 KeePassXC 빌드에서 네트워크 기능을 지원하지 않습니다. Have I Been Pwned 데이터베이스에 비밀번호를 조회하려면 네트워크 기능이 필요합니다.</translation>
    </message>
    <message>
        <source>Congratulations, no exposed passwords!</source>
        <translation>축하합니다, 유출된 비밀번호가 없습니다!</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>제목</translation>
    </message>
    <message>
        <source>Path</source>
        <translation>경로</translation>
    </message>
    <message>
        <source>Password exposed…</source>
        <translation>비밀번호 유출됨...</translation>
    </message>
    <message>
        <source> (Excluded)</source>
        <translation>(제외됨)</translation>
    </message>
    <message>
        <source>This entry is being excluded from reports</source>
        <translation>이 항목은 보고서에서 제외됨</translation>
    </message>
    <message>
        <source>once</source>
        <comment>Password exposure amount</comment>
        <translation>한 번</translation>
    </message>
    <message>
        <source>up to 10 times</source>
        <comment>Password exposure amount</comment>
        <translation>최대 10번</translation>
    </message>
    <message>
        <source>up to 100 times</source>
        <comment>Password exposure amount</comment>
        <translation>최대 100번</translation>
    </message>
    <message>
        <source>up to 1000 times</source>
        <comment>Password exposure amount</comment>
        <translation>최대 1000번</translation>
    </message>
    <message>
        <source>up to 10,000 times</source>
        <comment>Password exposure amount</comment>
        <translation>최대 10,000번</translation>
    </message>
    <message>
        <source>up to 100,000 times</source>
        <comment>Password exposure amount</comment>
        <translation>최대 100,000번</translation>
    </message>
    <message>
        <source>up to a million times</source>
        <comment>Password exposure amount</comment>
        <translation>최대 1,000,000번</translation>
    </message>
    <message>
        <source>millions of times</source>
        <comment>Password exposure amount</comment>
        <translation>1,000,000번 이상</translation>
    </message>
    <message>
        <source>Edit Entry…</source>
        <translation>항목 편집…</translation>
    </message>
    <message numerus="yes">
        <source>Delete Entry(s)…</source>
        <translation><numerusform>항목 삭제...</numerusform></translation>
    </message>
    <message>
        <source>Exclude from reports</source>
        <translation>보고서에서 제외</translation>
    </message>
    <message numerus="yes">
        <source>Expire Entry(s)…</source>
        <translation><numerusform>항목 만료...</numerusform></translation>
    </message>
</context>
<context>
    <name>ReportsWidgetPasskeys</name>
    <message>
        <source>Export</source>
        <translation>내보내기</translation>
    </message>
    <message>
        <source>Import</source>
        <translation>가져오기</translation>
    </message>
    <message>
        <source>List of entry URLs</source>
        <translation>항목 URL 목록</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>제목</translation>
    </message>
    <message>
        <source>Path</source>
        <translation>경로</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>사용자 이름</translation>
    </message>
    <message>
        <source>URLs</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>Edit Entry…</source>
        <translation>항목 편집…</translation>
    </message>
    <message numerus="yes">
        <source>Delete Entry(s)…</source>
        <translation><numerusform>항목 삭제...</numerusform></translation>
    </message>
    <message>
        <source>Relying Party</source>
        <translation>의존하는 상대방</translation>
    </message>
    <message>
        <source>Show expired entries</source>
        <translation>만료된 항목 표시</translation>
    </message>
    <message>
        <source> (Expired)</source>
        <translation>(만료됨)</translation>
    </message>
    <message>
        <source>Export Confirmation</source>
        <translation>내보내기 확인</translation>
    </message>
    <message>
        <source>The passkey file will be vulnerable to theft and unauthorized use, if left unsecured. Are you sure you want to continue?</source>
        <translation>패스키 파일을 안전하게 보존하지 않으면 탈취 및 인증되지 않은 사용에 취약해질 수 있습니다. 계속 진행하시겠습니까?</translation>
    </message>
    <message>
        <source>Please wait, list of entries with passkeys is being updated…</source>
        <translation>잠시 기다려 주십시오. 패스키가 있는 항목을 업데이트하는 중…</translation>
    </message>
    <message>
        <source>No entries with passkeys.</source>
        <translation>패스키가 있는 항목이 없습니다.</translation>
    </message>
</context>
<context>
    <name>ReportsWidgetStatistics</name>
    <message>
        <source>Hover over lines with error icons for further information.</source>
        <translation>오류 아이콘이 표시된 항목 위에 마우스를 올려 놓으면 자세한 정보를 표시합니다.</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>이름</translation>
    </message>
    <message>
        <source>Value</source>
        <translation>값</translation>
    </message>
    <message>
        <source>Please wait, database statistics are being calculated…</source>
        <translation>데이터베이스 통계를 계산하는 동안 잠시 기다려 주십시오…</translation>
    </message>
    <message>
        <source>Database name</source>
        <translation>데이터베이스 이름</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>설명</translation>
    </message>
    <message>
        <source>Location</source>
        <translation>위치</translation>
    </message>
    <message>
        <source>Database created</source>
        <translation>데이터베이스 생성됨</translation>
    </message>
    <message>
        <source>Last saved</source>
        <translation>마지막 저장</translation>
    </message>
    <message>
        <source>Unsaved changes</source>
        <translation>저장하지 않은 변경 사항</translation>
    </message>
    <message>
        <source>yes</source>
        <translation>예</translation>
    </message>
    <message>
        <source>no</source>
        <translation>아니요</translation>
    </message>
    <message>
        <source>The database was modified, but the changes have not yet been saved to disk.</source>
        <translation>데이터베이스가 수정되었지만 변경 사항을 디스크에 저장하지 않았습니다.</translation>
    </message>
    <message>
        <source>Number of groups</source>
        <translation>그룹 개수</translation>
    </message>
    <message>
        <source>Number of entries</source>
        <translation>항목 개수</translation>
    </message>
    <message>
        <source>Number of expired entries</source>
        <translation>내보낸 항목 개수</translation>
    </message>
    <message>
        <source>The database contains entries that have expired.</source>
        <translation>데이터베이스에 만료된 항목이 포함되어 있습니다.</translation>
    </message>
    <message>
        <source>Unique passwords</source>
        <translation>중복되지 않는 비밀번호</translation>
    </message>
    <message>
        <source>Non-unique passwords</source>
        <translation>중복된 비밀번호</translation>
    </message>
    <message>
        <source>More than 10% of passwords are reused. Use unique passwords when possible.</source>
        <translation>전체 비밀번호 중 10% 이상을 재사용하고 있습니다. 가능하다면 유일한 비밀번호를 사용하십시오.</translation>
    </message>
    <message>
        <source>Maximum password reuse</source>
        <translation>최대 비밀번호 재사용</translation>
    </message>
    <message>
        <source>Some passwords are used more than three times. Use unique passwords when possible.</source>
        <translation>일부 비밀번호가 3곳 이상에서 재사용되고 있습니다. 가능하다면 유일한 비밀번호를 사용하십시오.</translation>
    </message>
    <message>
        <source>Number of short passwords</source>
        <translation>짧은 비밀번호 개수</translation>
    </message>
    <message>
        <source>Recommended minimum password length is at least 8 characters.</source>
        <translation>최소 8자 이상의 비밀번호를 사용하십시오.</translation>
    </message>
    <message>
        <source>Number of weak passwords</source>
        <translation>약한 비밀번호 개수</translation>
    </message>
    <message>
        <source>Recommend using long, randomized passwords with a rating of &apos;good&apos; or &apos;excellent&apos;.</source>
        <translation>비밀번호 강도가 &apos;좋음&apos;이나 &apos;매우 좋음&apos; 등급으로 분류된 긴 무작위 비밀번호를 사용하는 것을 추천합니다.</translation>
    </message>
    <message>
        <source>Entries excluded from reports</source>
        <translation>보고서에서 제외된 항목</translation>
    </message>
    <message>
        <source>Excluding entries from reports, e. g. because they are known to have a poor password, isn&apos;t necessarily a problem but you should keep an eye on them.</source>
        <translation>보안 강도가 낮은 비밀번호를 사용하는 등의 항목을 보고서에서 제외할 수 있습니다. 항상 문제인 것은 아니지만 사용에 주의하십시오.</translation>
    </message>
    <message>
        <source>Average password length</source>
        <translation>평균 비밀번호 길이</translation>
    </message>
    <message>
        <source>Average password length is less than ten characters. Longer passwords provide more security.</source>
        <translation>평균 비밀번호 길이가 10자 이하입니다. 긴 비밀번호를 사용할수록 더 안전합니다.</translation>
    </message>
    <message>
        <source>Number of passkeys</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Entries with TOTP setup</source>
        <translation type="unfinished"/>
    </message>
    <message numerus="yes">
        <source>%1 character(s)</source>
        <translation><numerusform>%1 문자</numerusform></translation>
    </message>
</context>
<context>
    <name>SSHAgent</name>
    <message>
        <source>Agent connection failed.</source>
        <translation>에이전트에 연결할 수 없습니다.</translation>
    </message>
    <message>
        <source>Agent protocol error.</source>
        <translation>에이전트 프로토콜 오류입니다.</translation>
    </message>
    <message>
        <source>No agent running, cannot add identity.</source>
        <translation>에이전트가 실행 중이지 않아서 식별자를 추가할 수 없습니다.</translation>
    </message>
    <message>
        <source>Key identity ownership conflict. Refusing to add.</source>
        <translation>키 식별자 소유권이 충돌합니다. 추가하지 않습니다.</translation>
    </message>
    <message>
        <source>Agent refused this identity. Possible reasons include:</source>
        <translation>에이전트에서 이 식별자를 거부했습니다. 가능한 이유:</translation>
    </message>
    <message>
        <source>The key has already been added.</source>
        <translation>키가 이미 추가되었습니다.</translation>
    </message>
    <message>
        <source>Restricted lifetime is not supported by the agent (check options).</source>
        <translation>에이전트에서 시간 제한을 지원하지 않습니다(옵션을 확인하십시오).</translation>
    </message>
    <message>
        <source>A confirmation request is not supported by the agent (check options).</source>
        <translation>에이전트에서 확인 요청을 지원하지 않습니다(옵션을 확인하십시오).</translation>
    </message>
    <message>
        <source>Security keys are not supported by the agent or the security key provider is unavailable.</source>
        <translation>에이전트에서 보안 키를 지원하지 않거나 보안 키 공급자를 사용할 수 없습니다.</translation>
    </message>
    <message>
        <source>No agent running, cannot remove identity.</source>
        <translation>에이전트가 실행 중이지 않아서 식별자를 삭제할 수 없습니다.</translation>
    </message>
    <message>
        <source>No agent running, cannot list identities.</source>
        <translation>에이전트가 실행 중이지 않아서 식별자 목록을 표시할 수 없습니다.</translation>
    </message>
    <message>
        <source>Failed to remove all SSH identities from agent.</source>
        <translation>에이전트에서 모든 SSH ID를 제거하지 못했습니다.</translation>
    </message>
    <message>
        <source>All SSH identities removed from agent.</source>
        <translation>에이전트에서 모든 SSH ID가 제거되었습니다.</translation>
    </message>
</context>
<context>
    <name>SearchHelpWidget</name>
    <message>
        <source>Search Help</source>
        <translation>검색 도움말</translation>
    </message>
    <message>
        <source>Search terms are as follows: [modifiers][field:][&quot;]term[&quot;]</source>
        <translation>다음 검색어를 사용할 수 있습니다: [수정자][필드:][&quot;]검색어[&quot;]</translation>
    </message>
    <message>
        <source>Every search term must match (ie, logical AND)</source>
        <translation>모든 검색어가 일치해야 합니다(논리곱, AND)</translation>
    </message>
    <message>
        <source>Modifiers</source>
        <translation>수정자</translation>
    </message>
    <message>
        <source>exclude term from results</source>
        <translation>결과에서 검색어 제외</translation>
    </message>
    <message>
        <source>match term exactly</source>
        <translation>검색어와 정확히 일치</translation>
    </message>
    <message>
        <source>use regex in term</source>
        <translation>검색어에 정규 표현식 사용</translation>
    </message>
    <message>
        <source>Fields</source>
        <translation>필드</translation>
    </message>
    <message>
        <source>Term Wildcards</source>
        <translation>항목 와일드카드</translation>
    </message>
    <message>
        <source>match anything</source>
        <translation>모든 것과 일치</translation>
    </message>
    <message>
        <source>match one</source>
        <translation>하나와 일치</translation>
    </message>
    <message>
        <source>logical OR</source>
        <translation>논리합(OR)</translation>
    </message>
    <message>
        <source>Examples</source>
        <translation>예제</translation>
    </message>
</context>
<context>
    <name>SearchWidget</name>
    <message>
        <source>Search</source>
        <translation>찾기</translation>
    </message>
    <message>
        <source>Search Help</source>
        <translation>검색 도움말</translation>
    </message>
    <message>
        <source>Save Search</source>
        <translation>검색 저장</translation>
    </message>
    <message>
        <source>Search (%1)…</source>
        <comment>Search placeholder text, %1 is the keyboard shortcut</comment>
        <translation>검색(%1)…</translation>
    </message>
    <message>
        <source>Case sensitive</source>
        <translation>대소문자 구분</translation>
    </message>
    <message>
        <source>Limit search to selected group</source>
        <translation>지정한 그룹에서만 찾기</translation>
    </message>
    <message>
        <source>Press Enter to search</source>
        <translation>검색하려면 Enter 키를 누르세요</translation>
    </message>
</context>
<context>
    <name>SettingsClientModel</name>
    <message>
        <source>Application</source>
        <translation>프로그램</translation>
    </message>
    <message>
        <source>PID</source>
        <translation>PID</translation>
    </message>
    <message>
        <source>DBus Address</source>
        <translation>DBus 주소</translation>
    </message>
    <message>
        <source>Manage</source>
        <translation>관리</translation>
    </message>
</context>
<context>
    <name>SettingsDatabaseModel</name>
    <message>
        <source>File Name</source>
        <translation>파일 이름</translation>
    </message>
    <message>
        <source>Group</source>
        <translation>그룹</translation>
    </message>
    <message>
        <source>Manage</source>
        <translation>관리</translation>
    </message>
</context>
<context>
    <name>SettingsWidgetFdoSecrets</name>
    <message>
        <source>Options</source>
        <translation>옵션</translation>
    </message>
    <message>
        <source>Enable KeepassXC Freedesktop.org Secret Service integration</source>
        <translation>KeePassXC Freedesktop.org 비밀 서비스 통합 사용</translation>
    </message>
    <message>
        <source>General</source>
        <translation>일반</translation>
    </message>
    <message>
        <source>Show notification when passwords are retrieved by clients</source>
        <translation>클라이언트에서 비밀번호를 가져갈 때 알림 표시</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;If enabled, any attempt to read a password must be confirmed. Otherwise, clients can read passwords without confirmation when the database is unlocked.&lt;/p&gt;&lt;p&gt;This option only covers the access to the password of an entry. Clients can always enumerate the items of exposed databases and query their attributes.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;이 옵션을 사용하면 비밀번호 파일을 읽으려는 모든 시도를 물어 봅니다. 이 옵션을 사용하지 않으면 데이터베이스의 잠금이 해제되어 있을 때 클라이언트에서 묻지 않고 비밀번호를 읽을 수 있습니다.&lt;/p&gt;&lt;p&gt;아 옵션은 항목의 비밀번호 접근 권한만 제어합니다. 클라이언트에서는 항상 노출된 데이터베이스의 항목 목록을 가져오고 속성을 질의할 수 있습니다.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Confirm when passwords are retrieved by clients</source>
        <translation>클라이언트에서 비밀번호를 가져갈 때 확인</translation>
    </message>
    <message>
        <source>Confirm when clients request entry deletion</source>
        <translation>클라이언트에서 항목 삭제를 요청할 때 확인</translation>
    </message>
    <message>
        <source>Prompt to unlock database before searching</source>
        <translation>검색 전에 데이터베이스 잠금 해제 묻기</translation>
    </message>
    <message>
        <source>Exposed database groups:</source>
        <translation>내보낼 데이터베이스 그룹:</translation>
    </message>
    <message>
        <source>Authorization</source>
        <translation>인증</translation>
    </message>
    <message>
        <source>These applications are currently connected:</source>
        <translation>다음 프로그램이 연결되어 있습니다:</translation>
    </message>
    <message>
        <source>&lt;b&gt;Warning:&lt;/b&gt; </source>
        <translation>&lt;b&gt;경고:&lt;/b&gt; </translation>
    </message>
    <message>
        <source>Save current changes to activate the plugin and enable editing of this section.</source>
        <translation>플러그인을 활성화하고 이 부분 편집을 활성화하려면 변경 사항을 저장하십시오.</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;This setting does not override disabling recycle bin prompts &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;이 설정은 휴지통 프롬프트 비활성화를 재정의하지 않습니다 &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;This improves compatibility with certain applications which search for password without unlocking the database first.&lt;/p&gt;&lt;p&gt;But enabling this may also crash the client if the database can not be unlocked within a certain timeout. (Usually 25s, but may be a different value set in applications.) &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;이 옵션은 데이터베이스의 잠금을 해제하지 않고 비밀번호를 검색하는 프로그램과의 호환성을 개선합니다.&lt;/p&gt;&lt;p&gt;그러나 이 옵션을 사용하면 데이터베이스가 지정한 시간 내에 잠금 해제될 수 없을 때 클라이언트를 충돌시킬 수도 있습니다.(대개 25초, 프로그램에 따라서 다른 설정을 사용할 수도 있음) &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
</context>
<context>
    <name>SettingsWidgetKeeShare</name>
    <message>
        <source>Active</source>
        <translation>활성</translation>
    </message>
    <message>
        <source>Allow KeeShare imports</source>
        <translation>KeeShare 가져오기 허용</translation>
    </message>
    <message>
        <source>Allow import</source>
        <translation>가져오기 허용</translation>
    </message>
    <message>
        <source>Allow KeeShare exports</source>
        <translation>KeeShare 내보내기 허용</translation>
    </message>
    <message>
        <source>Allow export</source>
        <translation>내보내기 허용</translation>
    </message>
    <message>
        <source>Only show warnings and errors</source>
        <translation>경고와 오류만 표시</translation>
    </message>
    <message>
        <source>Own certificate</source>
        <translation>자가 인증서</translation>
    </message>
    <message>
        <source>Signer:</source>
        <translation>서명자:</translation>
    </message>
    <message>
        <source>Generate new certificate</source>
        <translation>새 인증서 생성</translation>
    </message>
    <message>
        <source>Generate</source>
        <translation>생성</translation>
    </message>
    <message>
        <source>Fingerprint:</source>
        <translation>지문:</translation>
    </message>
    <message>
        <source>Signer name field</source>
        <translation>서명자 이름 필드</translation>
    </message>
    <message>
        <source>Fingerprint</source>
        <translation>지문</translation>
    </message>
</context>
<context>
    <name>ShareExport</name>
    <message>
        <source>Could not write export container.</source>
        <translation>내보내기 컨테이너를 기록할 수 없습니다.</translation>
    </message>
</context>
<context>
    <name>ShareImport</name>
    <message>
        <source>Successful import</source>
        <translation>가져오기 성공</translation>
    </message>
</context>
<context>
    <name>ShareObserver</name>
    <message>
        <source>Import from %1 failed (%2)</source>
        <translation>%1에서 가져오기 실패 (%2)</translation>
    </message>
    <message>
        <source>Import from %1 successful (%2)</source>
        <translation>%1에서 가져오기 성공 (%2)</translation>
    </message>
    <message>
        <source>Imported from %1</source>
        <translation>%1에서 가져옴</translation>
    </message>
    <message>
        <source>Multiple import source path to %1 in %2</source>
        <translation>%2의 %1(으)로 다중 가져오기 원본 경로</translation>
    </message>
    <message>
        <source>Conflicting export target path %1 in %2</source>
        <translation>%2의 내보내기 대상 경로 %1이(가) 충돌함</translation>
    </message>
    <message>
        <source>Export to %1 failed (%2)</source>
        <translation>%1(으)로 내보내기 실패 (%2)</translation>
    </message>
    <message>
        <source>Export to %1 successful (%2)</source>
        <translation>%1(으)로 내보내기 성공 (%2)</translation>
    </message>
    <message>
        <source>Export to %1</source>
        <translation>%1(으)로 내보내기</translation>
    </message>
</context>
<context>
    <name>TagModel</name>
    <message>
        <source>Clear Search</source>
        <translation>검색 비우기</translation>
    </message>
    <message>
        <source>All Entries</source>
        <translation>모든 항목</translation>
    </message>
    <message>
        <source>Expired</source>
        <translation>만료됨</translation>
    </message>
    <message>
        <source>Weak Passwords</source>
        <translation>약한 비밀번호</translation>
    </message>
    <message>
        <source>TOTP Entries</source>
        <translation>TOTP 항목</translation>
    </message>
</context>
<context>
    <name>TagView</name>
    <message>
        <source>Remove Search</source>
        <translation>검색 삭제</translation>
    </message>
    <message>
        <source>Remove Tag</source>
        <translation>태그 삭제</translation>
    </message>
    <message>
        <source>Confirm Remove Tag</source>
        <translation>태그 삭제 확인</translation>
    </message>
    <message>
        <source>Remove tag &quot;%1&quot; from all entries in this database?</source>
        <translation>이 데이터베이스에 있는 모든 항목에서 &quot;%1&quot; 태그를 삭제하시겠습니까?</translation>
    </message>
</context>
<context>
    <name>TextAttachmentsEditWidget</name>
    <message>
        <source>Preview</source>
        <translation>미리 보기</translation>
    </message>
</context>
<context>
    <name>TextAttachmentsPreviewWidget</name>
    <message>
        <source>Form</source>
        <translation>폼</translation>
    </message>
    <message>
        <source>Type:</source>
        <translation>형식:</translation>
    </message>
</context>
<context>
    <name>TotpDialog</name>
    <message>
        <source>Timed Password</source>
        <translation>시간 제한된 비밀번호</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>복사</translation>
    </message>
    <message numerus="yes">
        <source>Expires in &lt;b&gt;%n&lt;/b&gt; second(s)</source>
        <translation><numerusform>&lt;b&gt;%n&lt;/b&gt;초 후 만료됨</numerusform></translation>
    </message>
</context>
<context>
    <name>TotpExportSettingsDialog</name>
    <message>
        <source>Copy</source>
        <translation>복사</translation>
    </message>
    <message>
        <source>NOTE: These TOTP settings are custom and may not work with other authenticators.</source>
        <comment>TOTP QR code dialog warning</comment>
        <translation>메모: 이 TOTP 설정은 사용자 정의 설정이며 다른 인증기에서 동작하지 않을 수도 있습니다.</translation>
    </message>
    <message>
        <source>There was an error creating the QR code.</source>
        <translation>QR 코드를 생성하는 중 오류가 발생했습니다.</translation>
    </message>
    <message>
        <source>Closing in %1 seconds.</source>
        <translation>%1초 후 닫습니다.</translation>
    </message>
</context>
<context>
    <name>TotpSetupDialog</name>
    <message>
        <source>Setup TOTP</source>
        <translation>TOTP 설정</translation>
    </message>
    <message>
        <source>Secret Key:</source>
        <translation>비밀 키:</translation>
    </message>
    <message>
        <source>Secret key must be in Base32 format</source>
        <translation>비밀 키는 Base32 형식이어야 함</translation>
    </message>
    <message>
        <source>Secret key field</source>
        <translation>비밀 키 필드</translation>
    </message>
    <message>
        <source>Default settings (RFC 6238)</source>
        <translation>기본 설정(RFC 6238)</translation>
    </message>
    <message>
        <source>Steam® settings</source>
        <translation>Steam® 설정</translation>
    </message>
    <message>
        <source>Custom settings:</source>
        <translation>사용자 정의 설정:</translation>
    </message>
    <message>
        <source>Custom Settings</source>
        <translation>사용자 정의 설정</translation>
    </message>
    <message>
        <source>Algorithm:</source>
        <translation>알고리즘:</translation>
    </message>
    <message>
        <source>Time step:</source>
        <translation>시간 단계:</translation>
    </message>
    <message>
        <source>Time step field</source>
        <translation>시간 단계 필드</translation>
    </message>
    <message>
        <source> sec</source>
        <comment>Seconds</comment>
        <translation>초</translation>
    </message>
    <message>
        <source>Code size:</source>
        <translation>코드 크기:</translation>
    </message>
    <message>
        <source> digits</source>
        <translation>자리</translation>
    </message>
    <message>
        <source>Invalid TOTP Secret</source>
        <translation>잘못된 TOTP 비밀 값</translation>
    </message>
    <message>
        <source>You have entered an invalid secret key. The key must be in Base32 format.
Example: JBSWY3DPEHPK3PXP</source>
        <translation>잘못된 비밀 키를 입력했습니다. 키는 Base32 형식이어야 합니다.
예: JBSWY3DPEHPK3PXP</translation>
    </message>
    <message>
        <source>Confirm Remove TOTP Settings</source>
        <translation>TOTP 설정 삭제 확인</translation>
    </message>
    <message>
        <source>Are you sure you want to delete TOTP settings for this entry?</source>
        <translation>이 항목의 TOTP 설정을 삭제하시겠습니까?</translation>
    </message>
    <message>
        <source>Error: secret key is invalid</source>
        <translation>오류: 비밀 키가 잘못되었습니다</translation>
    </message>
</context>
<context>
    <name>URLEdit</name>
    <message>
        <source>Invalid URL</source>
        <translation>잘못된 URL</translation>
    </message>
</context>
<context>
    <name>UpdateCheckDialog</name>
    <message>
        <source>Checking for updates</source>
        <translation>업데이트 확인 중</translation>
    </message>
    <message>
        <source>Checking for updates…</source>
        <translation>업데이트 확인 중…</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>닫기</translation>
    </message>
    <message>
        <source>Software Update</source>
        <translation>소프트웨어 업데이트</translation>
    </message>
    <message>
        <source>An error occurred when trying to retrieve update information, please try again later.</source>
        <translation>업데이트 정보를 가져오는 중 오류가 발생했습니다. 나중에 다시 시도하십시오.</translation>
    </message>
    <message>
        <source>&lt;strong&gt;A new version is available.&lt;/strong&gt;&lt;br/&gt;KeePassXC %1 can be &lt;a href=&quot;https://keepassxc.org/download/&quot;&gt;downloaded here&lt;/a&gt;.</source>
        <translation>&lt;strong&gt;새 버전을 사용할 수 없습니다.&lt;/strong&gt;&lt;br/&gt;KeePassXC %1을 &lt;a href=&quot;https://keepassxc.org/download/&quot;&gt;여기에서 다운로드&lt;/a&gt;할 수 있습니다.</translation>
    </message>
    <message>
        <source>You have the latest version of KeePassXC</source>
        <translation>KeePassXC 최신 버전을 사용하고 있습니다</translation>
    </message>
</context>
<context>
    <name>WelcomeWidget</name>
    <message>
        <source>Start storing your passwords securely in a KeePassXC database</source>
        <translation>KeePassXC 데이터베이스에 비밀번호를 안전하게 저장하십시오</translation>
    </message>
    <message>
        <source>Recent databases</source>
        <translation>최근 데이터베이스</translation>
    </message>
    <message>
        <source>Open a recent database</source>
        <translation>최근 데이터베이스 열기</translation>
    </message>
    <message>
        <source>Welcome to KeePassXC %1</source>
        <translation>KeePassXC %1에 오신 것을 환영합니다</translation>
    </message>
    <message>
        <source>Create Database</source>
        <translation>데이터베이스 만들기</translation>
    </message>
    <message>
        <source>Open Database</source>
        <translation>데이터베이스 열기</translation>
    </message>
    <message>
        <source>Import File</source>
        <translation>파일 가져오기</translation>
    </message>
</context>
<context>
    <name>WinUtils</name>
    <message>
        <source>Invalid key code</source>
        <translation>잘못된 키 코드</translation>
    </message>
    <message>
        <source>Global shortcut already registered to %1</source>
        <translation>전역 단축키가 이미 %1에 등록됨</translation>
    </message>
    <message>
        <source>Could not register global shortcut</source>
        <translation>전역 단축키를 등록할 수 없음</translation>
    </message>
</context>
<context>
    <name>YubiKey</name>
    <message>
        <source>Could not find hardware key with serial number %1. Please connect it to continue.</source>
        <translation>일련 번호 %1의 하드웨어 키를 찾을 수 없습니다. 계속하려면 연결해 주세요.</translation>
    </message>
</context>
<context>
    <name>YubiKeyEditWidget</name>
    <message>
        <source>Hardware key slot selection</source>
        <translation>하드웨어 키 슬롯 선택</translation>
    </message>
    <message>
        <source>Could not find any hardware keys!</source>
        <translation>하드웨어 키를 찾을 수 없습니다!</translation>
    </message>
    <message>
        <source>Selected hardware key slot does not support challenge-response!</source>
        <translation>선택한 하드웨어 키 슬롯에서 Challenge-Response를 지원하지 않습니다!</translation>
    </message>
    <message>
        <source>Challenge-Response</source>
        <translation>Challenge-Response</translation>
    </message>
    <message>
        <source>Add Challenge-Response</source>
        <translation>Challenge-Response 추가</translation>
    </message>
    <message>
        <source>Change Challenge-Response</source>
        <translation>Challenge-Response 변경</translation>
    </message>
    <message>
        <source>Remove Challenge-Response</source>
        <translation>Challenge-Response 삭제</translation>
    </message>
    <message>
        <source>Challenge-Response set, click to change or remove</source>
        <translation>Challenge-Response 설정됨, 클릭해서 변경하거나 삭제</translation>
    </message>
    <message>
        <source>Detecting hardware keys…</source>
        <translation>하드웨어 키 인식 중...</translation>
    </message>
    <message>
        <source>No hardware keys detected</source>
        <translation>인식된 하드웨어 키 없음</translation>
    </message>
    <message>
        <source>Refresh hardware keys</source>
        <translation>하드웨어 키 새로 고침</translation>
    </message>
    <message>
        <source>&lt;p&gt;If you own a &lt;a href=&quot;https://www.yubico.com/&quot;&gt;YubiKey&lt;/a&gt; or &lt;a href=&quot;https://onlykey.io&quot;&gt;OnlyKey&lt;/a&gt;, you can use it for additional security.&lt;/p&gt;&lt;p&gt;The key requires one of its slots to be programmed with &lt;a href=&quot;https://keepassxc.org/docs/#faq-yubikey-howto&quot;&gt;Challenge-Response&lt;/a&gt;.&lt;/p&gt;</source>
        <translation>&lt;p&gt; &lt;a href=&quot;https://www.yubico.com/&quot;&gt;YubiKey&lt;/a&gt; 또는 &lt;a href=&quot;https://onlykey.io&quot;&gt;OnlyKey&lt;/a&gt;를 소유하고 있다면 추가 보안을 위해 사용할 수 있습니다.&lt;/p&gt;&lt;p&gt; 키를 사용하려면 슬롯 중 하나에  &lt;a href=&quot;https://keepassxc.org/docs/#faq-yubikey-howto&quot;&gt;Challenge-Response&lt;/a&gt;를 프로그래밍해야 합니다.&lt;/p&gt;</translation>
    </message>
    <message>
        <source>Hardware keys found, but no slots are configured</source>
        <translation>하드웨어 키를 찾았지만 슬롯이 구성되지 않았습니다</translation>
    </message>
</context>
<context>
    <name>YubiKeyInterfacePCSC</name>
    <message>
        <source>Hardware key is locked or timed out. Unlock or re-present it to continue.</source>
        <translation>하드웨어 키가 잠겼거나 시간이 초과되었습니다. 계속 진행하려면 잠금을 해제하거나 다시 연결하십시오.</translation>
    </message>
    <message>
        <source>Hardware key was not found or is not configured.</source>
        <translation>하드웨어 키를 찾을 수 없거나 설정되지 않았습니다.</translation>
    </message>
    <message>
        <source>(NFC) %1 [%2] - Slot %3, %4</source>
        <comment>YubiKey display fields</comment>
        <translation>(NFC) %1 [%2] - 슬롯 %3, %4</translation>
    </message>
    <message>
        <source>Press</source>
        <comment>USB Challenge-Response Key interaction request</comment>
        <translation>누르기</translation>
    </message>
    <message>
        <source>Passive</source>
        <comment>USB Challenge-Response Key no interaction required</comment>
        <translation>수동적</translation>
    </message>
    <message>
        <source>The YubiKey PC/SC interface has not been initialized.</source>
        <translation>YubiKey PC/SC 인터페이스가 초기화되지 않았습니다.</translation>
    </message>
    <message>
        <source>Failed to complete a challenge-response, the PC/SC error code was: %1</source>
        <translation>챌린지 응답을 완료하지 못했습니다. PC/SC 오류 코드는 다음과 같습니다: %1</translation>
    </message>
</context>
<context>
    <name>YubiKeyInterfaceUSB</name>
    <message>
        <source>Press</source>
        <comment>USB Challenge-Response Key interaction request</comment>
        <translation>누르기</translation>
    </message>
    <message>
        <source>Passive</source>
        <comment>USB Challenge-Response Key no interaction required</comment>
        <translation>수동적</translation>
    </message>
    <message>
        <source>The YubiKey USB interface has not been initialized.</source>
        <translation>YubiKey USB 인터페이스가 초기화되지 않았습니다.</translation>
    </message>
    <message>
        <source>Could not find hardware key with serial number %1. Please plug it in to continue.</source>
        <translation>일련 번호가 %1인 하드웨어 키를 찾을 수 없습니다. 계속 진행하려면 연결하십시오.</translation>
    </message>
    <message>
        <source>Hardware key timed out waiting for user interaction.</source>
        <translation>사용자 입력을 기다리는 중 하드웨어 키 시간이 초과되었습니다.</translation>
    </message>
    <message>
        <source>A USB error occurred when accessing the hardware key: %1</source>
        <translation>하드웨어 키에 접근하는 중 USB 오류가 발생했습니다: %1</translation>
    </message>
    <message>
        <source>Failed to complete a challenge-response, the specific error was: %1</source>
        <translation>Challenge-Response를 완료할 수 없습니다. 오류: %1</translation>
    </message>
    <message>
        <source>%1 [%2] - Slot %3</source>
        <comment>YubiKey NEO display fields</comment>
        <translation>%1 [%2] - 슬롯 %3</translation>
    </message>
    <message>
        <source>%1 [%2] - Slot %3, %4</source>
        <comment>YubiKey display fields</comment>
        <translation>%1 [%2] - 슬롯 %3, %4</translation>
    </message>
    <message>
        <source>Unknown</source>
        <comment>Unknown hardware key name</comment>
        <translation>알 수 없음</translation>
    </message>
</context>
</TS>
<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="nb">
<context>
    <name>AboutDialog</name>
    <message>
        <source>About KeePassXC</source>
        <translation>Om KeePassXC</translation>
    </message>
    <message>
        <source>About</source>
        <translation>Om</translation>
    </message>
    <message>
        <source>Report bugs at: &lt;a href=&quot;https://github.com/keepassxreboot/keepassxc/issues&quot; style=&quot;text-decoration: underline;&quot;&gt;https://github.com&lt;/a&gt;</source>
        <translation>Rapportér feil på: &lt;a href=&quot;https://github.com/keepassxreboot/keepassxc/issues&quot; style=&quot;text-decoration: underline;&quot;&gt;https://github.com&lt;/a&gt;</translation>
    </message>
    <message>
        <source>KeePassXC is distributed under the terms of the GNU General Public License (GPL) version 2 or (at your option) version 3.</source>
        <translation>KeePassXC distribueres under vilkårene i GNU General Public License (GPL) versjon 2 eller (etter eget valg) versjon 3.</translation>
    </message>
    <message>
        <source>Project Maintainers:</source>
        <translation>Prosjektets vedlikeholdere:</translation>
    </message>
    <message>
        <source>Special thanks from the KeePassXC team go to debfx for creating the original KeePassX.</source>
        <translation>En spesiell takk fra KeePassXC-teamet går til debfx som utviklet det opprinnelige KeePassX.</translation>
    </message>
    <message>
        <source>Contributors</source>
        <translation>Bidragsytere</translation>
    </message>
    <message>
        <source>&lt;a href=&quot;https://github.com/keepassxreboot/keepassxc/graphs/contributors&quot;&gt;See Contributions on GitHub&lt;/a&gt;</source>
        <translation>&lt;a href=&quot;https://github.com/keepassxreboot/keepassxc/graphs/contributors&quot;&gt;Se Bidrag på GitHub&lt;/a&gt;</translation>
    </message>
    <message>
        <source>Debug Info</source>
        <translation>Debuggingsinfo</translation>
    </message>
    <message>
        <source>Include the following information whenever you report a bug:</source>
        <translation>Inkluder følgende informasjon når du rapporterer en feil:</translation>
    </message>
    <message>
        <source>Copy to clipboard</source>
        <translation>Kopier til utklippstavle</translation>
    </message>
</context>
<context>
    <name>AccessControlDialog</name>
    <message>
        <source>KeePassXC -  Access Request</source>
        <translation>KeePassXC – Tilgangsforespørsel</translation>
    </message>
    <message>
        <source>Non-existing/inaccessible executable path. Please double-check the client is legit.</source>
        <translation>Ikke-eksisterende/utilgjengelig kjørbar sti. Dobbeltsjekk om klienten er legitim.</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;%1 &lt;/span&gt;is requesting access to the following entries:&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;%1 &lt;/span&gt;ber om tilgang til følgende oppføringer:&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Navn</translation>
    </message>
    <message>
        <source>PID</source>
        <translation>PID</translation>
    </message>
    <message>
        <source>Executable</source>
        <translation>Kjørbar</translation>
    </message>
    <message>
        <source>Command Line</source>
        <translation>Kommandolinje</translation>
    </message>
    <message>
        <source>Details</source>
        <translation>Detaljer</translation>
    </message>
    <message>
        <source>Your decision will be remembered for the duration while both the requesting client AND KeePassXC are running.</source>
        <translation>Avgjørelsen din blir husket så lenge klienten OG KeePassXC kjører.</translation>
    </message>
    <message>
        <source>Remember</source>
        <translation>Husk</translation>
    </message>
    <message>
        <source>Allow Selected</source>
        <translation>Tillat valgte</translation>
    </message>
    <message>
        <source>Deny All &amp;&amp; Future</source>
        <translation>Nekt alle &amp;&amp; fremtidige</translation>
    </message>
    <message>
        <source>Allow All &amp;&amp; &amp;Future</source>
        <translation>Tillat alle &amp;&amp; &amp;fremtidige</translation>
    </message>
</context>
<context>
    <name>AccessControlDialog::DenyButton</name>
    <message>
        <source>Deny for this program</source>
        <translation>Nekt for dette programmet</translation>
    </message>
</context>
<context>
    <name>AgentSettingsWidget</name>
    <message>
        <source>Enable SSH Agent integration</source>
        <translation>Aktiver SSH-agentintegrasjon</translation>
    </message>
    <message>
        <source>Use Pageant</source>
        <translation>Bruk Pageant</translation>
    </message>
    <message>
        <source>Use OpenSSH</source>
        <translation>Bruk OpenSSH</translation>
    </message>
    <message>
        <source>Use both agents</source>
        <translation>Bruk begge agentene</translation>
    </message>
    <message>
        <source>SSH_AUTH_SOCK override</source>
        <translation>SSH_AUTH_SOCK-overstyring</translation>
    </message>
    <message>
        <source>SSH_AUTH_SOCK value</source>
        <translation>SSH_AUTH_SOCK-verdi</translation>
    </message>
    <message>
        <source>(empty)</source>
        <translation>(tom)</translation>
    </message>
    <message>
        <source>SSH_SK_PROVIDER value</source>
        <translation>SSH_SK_PROVIDER-verdi</translation>
    </message>
    <message>
        <source>SSH_SK_PROVIDER override</source>
        <translation>SSH_SK_PROVIDER-overstyring</translation>
    </message>
    <message>
        <source>No SSH Agent socket available. Either make sure SSH_AUTH_SOCK environment variable exists or set an override.</source>
        <translation>Ingen SSH-agentkontakt tilgjengelig. Du må enten kontrollere at miljøvariabelen SSH_AUTH_SOCK eksisterer eller angi en overstyring.</translation>
    </message>
    <message>
        <source>SSH Agent connection is working!</source>
        <translation>SSH-agentforbindelse fungerer!</translation>
    </message>
</context>
<context>
    <name>AppKit</name>
    <message>
        <source>Window</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Minimize</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Zoom</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Bring All to Front</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>ApplicationSettingsWidget</name>
    <message>
        <source>Application Settings</source>
        <translation>Applikasjonsinnstillinger</translation>
    </message>
    <message>
        <source>General</source>
        <translation>Generelt</translation>
    </message>
    <message>
        <source>Security</source>
        <translation>Sikkerhet</translation>
    </message>
    <message>
        <source>This setting cannot be enabled when minimize on unlock is enabled.</source>
        <translation>Denne innstillingen kan ikke aktiveres når minimering ved opplåsing er aktivert.</translation>
    </message>
    <message>
        <source>Access error for config file %1</source>
        <translation>Feil ved tilgang til konfigurasjonsfilen %1</translation>
    </message>
    <message>
        <source>Icon only</source>
        <translation>Kun ikon</translation>
    </message>
    <message>
        <source>Text only</source>
        <translation>Kun tekst</translation>
    </message>
    <message>
        <source>Text beside icon</source>
        <translation>Tekst ved siden av ikon</translation>
    </message>
    <message>
        <source>Text under icon</source>
        <translation>Tekst under ikon</translation>
    </message>
    <message>
        <source>Follow style</source>
        <translation>Følg stil</translation>
    </message>
    <message>
        <source>Monochrome</source>
        <translation>Ensfarget</translation>
    </message>
    <message>
        <source>Monochrome (light)</source>
        <translation>Ensfarget (lys)</translation>
    </message>
    <message>
        <source>Monochrome (dark)</source>
        <translation>Ensfarget (mørk)</translation>
    </message>
    <message>
        <source>Colorful</source>
        <translation>Fargerik</translation>
    </message>
    <message>
        <source>You must restart the application to set the new language. Would you like to restart now?</source>
        <translation>Du må starte programmet på nytt for å angi det nye språket. Vil du starte på nytt nå?</translation>
    </message>
    <message>
        <source>Select backup storage directory</source>
        <translation>Velg lagringsmappe for sikkerhetskopiering</translation>
    </message>
    <message>
        <source>Confirm Reset</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Are you sure you want to reset all settings to default?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Import KeePassXC Settings</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Failed to import settings from %1, not a valid settings file.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Export KeePassXC Settings</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Small</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Normal</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Medium</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Large</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Custom</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>None</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Restart KeePassXC to apply the Auto-Type desktop portals preference.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>ApplicationSettingsWidgetGeneral</name>
    <message>
        <source>Basic Settings</source>
        <translation>Grunnleggende</translation>
    </message>
    <message>
        <source>Startup</source>
        <translation>Oppstart</translation>
    </message>
    <message>
        <source>Start only a single instance of KeePassXC</source>
        <translation>Kjør kun én instans av KeePassXC om gangen</translation>
    </message>
    <message>
        <source>Automatically launch KeePassXC at system startup</source>
        <translation>Start KeePassXC automatisk ved systemoppstart</translation>
    </message>
    <message>
        <source>Minimize window at application startup</source>
        <translation>Minimer vindu ved programstart</translation>
    </message>
    <message>
        <source>Minimize window after unlocking database</source>
        <translation>Minimer vinduet etter at du har låst opp database</translation>
    </message>
    <message>
        <source>Remember previously used databases</source>
        <translation>Husk tidligere brukte databaser</translation>
    </message>
    <message>
        <source> recent files</source>
        <translation>siste filer</translation>
    </message>
    <message>
        <source>Load previously open databases on startup</source>
        <translation>Last tidligere åpne databaser ved oppstart</translation>
    </message>
    <message>
        <source>Remember database key files and security dongles</source>
        <translation>Husk database nøkkelfiler og sikkerhetsdongler</translation>
    </message>
    <message>
        <source>Check for updates at application startup once per week</source>
        <translation>Se etter oppdateringer ved oppstart av applikasjonen en gang per uke</translation>
    </message>
    <message>
        <source>Include beta releases when checking for updates</source>
        <translation>Ta med betaversjoner når du ser etter oppdateringer</translation>
    </message>
    <message>
        <source>File Management</source>
        <translation>Filhåndtering</translation>
    </message>
    <message>
        <source>Automatically save after every change</source>
        <translation>Lagre automatisk etter hver endring</translation>
    </message>
    <message>
        <source>Automatically save when locking database</source>
        <translation>Lagre automatisk ved låsing av database</translation>
    </message>
    <message>
        <source>Automatically save non-data changes when locking database</source>
        <translation>Lagre ikke-data-endringer ved låsing av database</translation>
    </message>
    <message>
        <source>Automatically reload the database when modified externally</source>
        <translation>Last databasen automatisk på nytt hvis den blir endret eksternt </translation>
    </message>
    <message>
        <source>Backup database file before saving</source>
        <translation>Sikkerhetskopier databasefilen før lagring</translation>
    </message>
    <message>
        <source>{DB_FILENAME}.old.kdbx</source>
        <translation>{DB_FILENAME}.old.kdbx</translation>
    </message>
    <message>
        <source>Use alternative saving method (may solve problems with Dropbox, Google Drive, GVFS, etc.)</source>
        <translation>Bruk alternativ lagringsmetode (kan løse problemer med Dropbox, Google Drive, GVFS, etc.)</translation>
    </message>
    <message>
        <source>Temporary file moved into place</source>
        <translation>Midlertidig fil flyttet på plass</translation>
    </message>
    <message>
        <source>Directly write to database file (dangerous)</source>
        <translation>Skriv direkte til databasefil (farlig)</translation>
    </message>
    <message>
        <source>Entry Management</source>
        <translation>Oppføringshåndtering</translation>
    </message>
    <message>
        <source>Use group icon on entry creation</source>
        <translation>Bruk gruppeikon ved ny oppføring</translation>
    </message>
    <message>
        <source>Minimize when opening a URL</source>
        <translation>Minimer når du åpner en URL</translation>
    </message>
    <message>
        <source>Hide window when copying to clipboard</source>
        <translation>Skjul vindu når du kopierer til utklippstavle</translation>
    </message>
    <message>
        <source>Minimize</source>
        <translation>Minimer</translation>
    </message>
    <message>
        <source>Drop to background</source>
        <translation>Slipp til bakgrunnen</translation>
    </message>
    <message>
        <source>Favicon download timeout:</source>
        <translation>Tidsavbrudd for nedlasting av nettstedsikon:</translation>
    </message>
    <message>
        <source>Website icon download timeout in seconds</source>
        <translation>Tidsavbrudd i sekunder for nedlasting av nettstedsikon</translation>
    </message>
    <message>
        <source> sec</source>
        <comment>Seconds</comment>
        <translation>sek</translation>
    </message>
    <message>
        <source>User Interface</source>
        <translation>Brukergrensesnitt</translation>
    </message>
    <message>
        <source>Toolbar button style</source>
        <translation>Knappestil på verktøylinjen</translation>
    </message>
    <message>
        <source>Movable toolbar</source>
        <translation>Bevegelig verktøylinje</translation>
    </message>
    <message>
        <source>Language selection</source>
        <translation>Valg av språk</translation>
    </message>
    <message>
        <source>Language:</source>
        <translation>Språk:</translation>
    </message>
    <message>
        <source>(restart program to activate)</source>
        <translation>(start programmet på nytt for å aktivere)</translation>
    </message>
    <message>
        <source>Toolbar button style:</source>
        <translation>Knappestil på verktøylinjen:</translation>
    </message>
    <message>
        <source>Show passwords in color</source>
        <translation>Vis passord i farger</translation>
    </message>
    <message>
        <source>Use monospaced font for notes</source>
        <translation>Bruk fastbreddeskrift til notater</translation>
    </message>
    <message>
        <source>Minimize instead of app exit</source>
        <translation>Minimer istedenfor app-avslutning</translation>
    </message>
    <message>
        <source>Show a system tray icon</source>
        <translation>Vis et ikon i systemkurven</translation>
    </message>
    <message>
        <source>Tray icon type</source>
        <translation>Ikontype på oppgavelinje</translation>
    </message>
    <message>
        <source>Tray icon type:</source>
        <translation>Ikontype på oppgavelinje:</translation>
    </message>
    <message>
        <source>Hide window to system tray when minimized</source>
        <translation>Skjul vindu til systemkurven når minimert</translation>
    </message>
    <message>
        <source>Reset settings to default…</source>
        <translation>Tilbakestill til standardinnstillinger…</translation>
    </message>
    <message>
        <source>Auto-Type</source>
        <translation>Autoskriv</translation>
    </message>
    <message>
        <source>Use entry title to match windows for global Auto-Type</source>
        <translation>Bruk tittel i oppføringa for å matche vindu ved global autoskriv</translation>
    </message>
    <message>
        <source>Use entry URL to match windows for global Auto-Type</source>
        <translation>Bruk URL i oppføringa for å matche vindu ved global autoskriv</translation>
    </message>
    <message>
        <source>Always ask before performing Auto-Type</source>
        <translation>Alltid spør før utførelse av autoskriv</translation>
    </message>
    <message>
        <source>Hide expired entries from Auto-Type</source>
        <translation>Skjul utløpte oppføringer fra autoskriv</translation>
    </message>
    <message>
        <source>Re-lock previously locked database after performing Auto-Type</source>
        <translation>Lås tidligere låst database etter utført autoskriv</translation>
    </message>
    <message>
        <source>Auto-Type start delay:</source>
        <translation>Autoskriv startforsinkelse:</translation>
    </message>
    <message>
        <source>Global Auto-Type shortcut:</source>
        <translation>Global autoskriv-hurtigtast:</translation>
    </message>
    <message>
        <source>Auto-type start delay milliseconds</source>
        <translation>Autoskriv startforsinkelse i millisekunder</translation>
    </message>
    <message>
        <source> ms</source>
        <comment>Milliseconds</comment>
        <translation>ms</translation>
    </message>
    <message>
        <source>Auto-Type typing delay:</source>
        <translation>Autoskriv skriveforsinkelse:</translation>
    </message>
    <message>
        <source>Global auto-type shortcut</source>
        <translation>Global autoskriv-hurtigtast</translation>
    </message>
    <message>
        <source>Auto-type character typing delay milliseconds</source>
        <translation>Autoskriv tegn-skriveforsinkelse i millisekunder</translation>
    </message>
    <message>
        <source>Remember last typed entry for:</source>
        <translation>Husk siste inntasta oppføring i:</translation>
    </message>
    <message>
        <source>On database unlock, show entries that will expire within</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>On database unlock, show entries that will expire within </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source> days</source>
        <comment>number of days warning for password expiration</comment>
        <translation> dager</translation>
    </message>
    <message>
        <source>Destination format:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;{DB_FILENAME}&lt;/span&gt; is replaced with the filename of the saved database without extension&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;{TIME:&amp;lt;format&amp;gt;}&lt;/span&gt; is replaced with the specified time format (default: dd_MM_yyyy_hh-mm-ss)&lt;/p&gt;&lt;p&gt;See the User Guide for more details&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Choose folder...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Show confirmation before moving entries to recycle bin</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Copy data on double clicking field in entry view</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Show toolbar</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Show the menu bar by pressing the Alt key</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Show menubar</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Import settings…</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Export settings…</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Font size:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Font size selection</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Skip confirmation for main window Auto-Type actions</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Double-click action for URL:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Double-click action for URL field</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Edit entry</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Open entry URL in browser</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Copy entry URL to clipboard</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Auto-generate password for new entries</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Keep remote desktop connection open after performing Auto-Type</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Remote desktop mode:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Never remember session</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Remember session until exit</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Remember session until revoked by desktop</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>None</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Configure...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Use remote desktop for clipboard access</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Experimental: Prefer desktop portals (Wayland implementation)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Show autocomplete suggestions for username and additional attributes</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>ApplicationSettingsWidgetSecurity</name>
    <message>
        <source>Timeouts</source>
        <translation>Tidsavbrudd</translation>
    </message>
    <message>
        <source>Database lock timeout seconds</source>
        <translation>Tidsavbrudd sekunder for databaselås</translation>
    </message>
    <message>
        <source> sec</source>
        <comment>Seconds</comment>
        <translation>sek</translation>
    </message>
    <message>
        <source>Clear clipboard after</source>
        <translation>Slett utklippstavlen etter</translation>
    </message>
    <message>
        <source>Clear search query after</source>
        <translation>Tøm søket etter</translation>
    </message>
    <message>
        <source> min</source>
        <comment>Minutes</comment>
        <translation> min</translation>
    </message>
    <message>
        <source>Clipboard clear seconds</source>
        <translation>Slett utklippstavle sekund</translation>
    </message>
    <message>
        <source>Lock databases after inactivity of</source>
        <translation>Lås databaser etter inaktivitet i</translation>
    </message>
    <message>
        <source>Convenience</source>
        <translation>Bekvemmelighet</translation>
    </message>
    <message>
        <source>Enable database quick unlock (Touch ID / Windows Hello)</source>
        <translation>Aktiver rask opplåsing av database (berørings-ID / Windows Hello)</translation>
    </message>
    <message>
        <source>Lock databases when session is locked or lid is closed</source>
        <translation>Lås databaser når økta låses eller lokket lukkes</translation>
    </message>
    <message>
        <source>Lock databases after minimizing the window</source>
        <translation>Lås databaser når vinduet minimeres</translation>
    </message>
    <message>
        <source>Hide passwords when editing them</source>
        <translation>Skjul passord ved redigering</translation>
    </message>
    <message>
        <source>Use placeholder for empty password fields</source>
        <translation>Bruk posisjonsmerke for tomme passordfelt</translation>
    </message>
    <message>
        <source>Hide passwords in the entry preview panel</source>
        <translation>Skjul passord i oppføring panelet</translation>
    </message>
    <message>
        <source>Privacy</source>
        <translation>Personvern</translation>
    </message>
    <message>
        <source>Use DuckDuckGo service to download website icons</source>
        <translation>Bruk DuckDuckGo-tjenesten for å laste ned nettstedsikoner</translation>
    </message>
    <message>
        <source>Hide TOTP in the entry preview panel</source>
        <translation>Skjul TOTP i forhåndsvisningspanelet</translation>
    </message>
    <message>
        <source>Lock databases when switching user</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Lock Options</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Hide notes in the entry preview panel</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>AttachmentWidget</name>
    <message>
        <source>Attachment Viewer</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Unknown attachment type</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>AutoType</name>
    <message>
        <source>The requested Auto-Type sequence cannot be used due to an error:</source>
        <translation>Den forespurte autoskriv-sekvensen kan ikke brukes på grunn av en feil:</translation>
    </message>
    <message>
        <source>Auto-Type Error</source>
        <translation>Autoskrivfeil</translation>
    </message>
    <message>
        <source>Permission Required</source>
        <translation>Tillatelse kreves</translation>
    </message>
    <message>
        <source>KeePassXC requires the Accessibility permission in order to perform entry level Auto-Type. If you already granted permission, you may have to restart KeePassXC.</source>
        <translation>KeePassXC krever tilgangstillatelse for å utføre autoskriv på oppføringsnivå. Hvis du allerede har gitt tillatelse, må du kanskje starte KeePassXC på nytt.</translation>
    </message>
    <message>
        <source>KeePassXC requires the Accessibility and Screen Recorder permission in order to perform global Auto-Type. Screen Recording is necessary to use the window title to find entries. If you already granted permission, you may have to restart KeePassXC.</source>
        <translation>KeePassXC krever tilgangs- og skjermopptakertillatelse for å utføre global autoskriv. Skjermopptak er nødvendig for å bruke vindustittelen for å finne oppføringer. Hvis du allerede har gitt tillatelse, må du kanskje starte KeePassXC på nytt.</translation>
    </message>
    <message>
        <source>Invalid entry provided</source>
        <translation>Ugyldig oppføring angitt</translation>
    </message>
    <message>
        <source>Bracket imbalance detected, found extra { or }</source>
        <translation>Parentesubalanse oppdaget, funnet ekstra { eller }</translation>
    </message>
    <message>
        <source>Too many repetitions detected, max is %1: %2</source>
        <translation>For mange repitisjoner oppdaget, maks er %1: %2</translation>
    </message>
    <message>
        <source>Very slow key press detected, max is %1: %2</source>
        <translation>Veldig sakte tastetrykk oppdaget, maks er %1: %2</translation>
    </message>
    <message>
        <source>Very long delay detected, max is %1: %2</source>
        <translation>Veldig lang forsinkelse oppdaget, maks er %1: %2</translation>
    </message>
    <message>
        <source>Entry does not have attribute for PICKCHARS: %1</source>
        <translation>Oppføringen har ikke attributt for PICKCHARS: %1</translation>
    </message>
    <message>
        <source>Invalid placeholder: %1</source>
        <translation>Ugyldig posisjonsmerke: %1</translation>
    </message>
    <message>
        <source>Entry has invalid TOTP settings</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>AutoTypeAssociationsModel</name>
    <message>
        <source>Window</source>
        <translation>Vindu</translation>
    </message>
    <message>
        <source>Sequence</source>
        <translation>Sekvens</translation>
    </message>
    <message>
        <source>(empty)</source>
        <translation>(tom)</translation>
    </message>
    <message>
        <source>Default sequence</source>
        <translation>Standardrekkefølge</translation>
    </message>
</context>
<context>
    <name>AutoTypeMatchModel</name>
    <message>
        <source>Group</source>
        <translation>Gruppe</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>Tittel</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>Brukernavn</translation>
    </message>
    <message>
        <source>Sequence</source>
        <translation>Rekkefølge</translation>
    </message>
</context>
<context>
    <name>AutoTypePlatformWayland</name>
    <message>
        <source>No symbol found for key: &apos;%1&apos;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>No symbol found for character: &apos;%1&apos;</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>AutoTypePlatformX11</name>
    <message>
        <source>Sequence aborted: Caps Lock is on</source>
        <translation>Sekvens avbrutt: Store bokstaver er på</translation>
    </message>
    <message>
        <source>Sequence aborted: Modifier keys held by user</source>
        <translation>Sekvens avbrutt: Modifikatornøkler holdt av bruker</translation>
    </message>
    <message>
        <source>Unable to get valid keycode for key: </source>
        <translation>Mottar ikke gyldig nøkkelkode for nøkkel:</translation>
    </message>
    <message>
        <source>Trying to send invalid keyboard symbol.</source>
        <translation>Forsøker å sende et ugyldig tastatursymbol.</translation>
    </message>
</context>
<context>
    <name>AutoTypeSelectDialog</name>
    <message>
        <source>Auto-Type - KeePassXC</source>
        <translation>Autoskriv - KeePassXC</translation>
    </message>
    <message>
        <source>Double click a row to perform Auto-Type or find an entry using the search:</source>
        <translation>Dobbeltklikk på rad for å utføre autoskriv eller finn en oppføring ved å bruke søket:</translation>
    </message>
    <message>
        <source>Search all open databases</source>
        <translation>Søk i alle åpne databaser</translation>
    </message>
    <message>
        <source>Search…</source>
        <translation>Søk…</translation>
    </message>
    <message>
        <source>Type Sequence</source>
        <translation>Skriverekkefølge</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Avbryt</translation>
    </message>
    <message>
        <source>Type {USERNAME}</source>
        <translation>Skriv {USERNAME}</translation>
    </message>
    <message>
        <source>Type {PASSWORD}</source>
        <translation>Skriv {PASSWORD}</translation>
    </message>
    <message>
        <source>Type {TOTP}</source>
        <translation>Skriv {TOTP}</translation>
    </message>
    <message>
        <source>Copy Username</source>
        <translation>Kopier brukernavn</translation>
    </message>
    <message>
        <source>Copy Password</source>
        <translation>Kopier passord</translation>
    </message>
    <message>
        <source>Copy TOTP</source>
        <translation>Kopier TOTP</translation>
    </message>
    <message>
        <source>Use Virtual Keyboard</source>
        <translation>Bruk virtuelt tastatur</translation>
    </message>
    <message>
        <source>Type {URL}</source>
        <translation>Skriv {URL}</translation>
    </message>
    <message>
        <source>Copy URL</source>
        <translation>Kopier URL</translation>
    </message>
    <message>
        <source>&lt;p&gt;The following shortcuts are available:&lt;br/&gt;
Ctrl+F - Focus search&lt;br/&gt;
Ctrl+1 - Type username&lt;br/&gt;
Ctrl+2 - Type password&lt;br/&gt;
Ctrl+3 - Type TOTP&lt;br/&gt;
Ctrl+4 - Type URL&lt;br/&gt;
Ctrl+5 - Use Virtual Keyboard (Windows Only)&lt;br/&gt;
Ctrl+Shift+1 - Copy username&lt;br/&gt;
Ctrl+Shift+2 - Copy password&lt;br/&gt;
Ctrl+Shift+3 - Copy TOTP&lt;br/&gt;
Ctrl+Shift+4 - Copy URL&lt;br/&gt;
&lt;/p&gt;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>You can use advanced search queries to find any entry in your open databases.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>BinaryStream</name>
    <message>
        <source>Failed to read string data: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>String length exceeds 10 MiB limit (requested %1)</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>BrowserAccessControlDialog</name>
    <message>
        <source>KeePassXC - Browser Access Request</source>
        <translation>KeePassXC - Forespørsel for nettlesertilgang</translation>
    </message>
    <message>
        <source>%1 is requesting access to the following entries:</source>
        <translation>%1 ber om tilgang til følgende oppføringer:</translation>
    </message>
    <message>
        <source>Remember access to checked entries</source>
        <translation>Husk tilgang til valgte oppføringer</translation>
    </message>
    <message>
        <source>Remember</source>
        <translation>Husk</translation>
    </message>
    <message>
        <source>Allow access to entries</source>
        <translation>Tillat tilgang til oppføringer</translation>
    </message>
    <message>
        <source>Allow Selected</source>
        <translation>Tillat valgte</translation>
    </message>
    <message>
        <source>Deny All</source>
        <translation>Nekt alt</translation>
    </message>
    <message>
        <source>Disable for this site</source>
        <translation>Deaktiver for dette nettstedet</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation>Angre</translation>
    </message>
</context>
<context>
    <name>BrowserEntrySaveDialog</name>
    <message>
        <source>Ok</source>
        <translation>Ok</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Avbryt</translation>
    </message>
    <message>
        <source>You have multiple databases open.
Please select the correct database for saving credentials.</source>
        <translation>Du har flere databaser åpne.
Vennligst velg riktig database for å lagre identifikasjon.</translation>
    </message>
    <message>
        <source>KeePassXC - Select Database</source>
        <translation>KeePassXC - velg database</translation>
    </message>
</context>
<context>
    <name>BrowserPasskeysConfirmationDialog</name>
    <message>
        <source>Cancel</source>
        <translation>Avbryt</translation>
    </message>
    <message>
        <source>Update</source>
        <translation>Oppdater</translation>
    </message>
    <message>
        <source>Authenticate</source>
        <translation>Autentiser</translation>
    </message>
    <message>
        <source>Register new</source>
        <translation>Registrer ny</translation>
    </message>
    <message>
        <source>Register</source>
        <translation>Registrer</translation>
    </message>
    <message numerus="yes">
        <source>Timeout in &lt;b&gt;%n&lt;/b&gt; seconds...</source>
        <translation><numerusform>Tidsavbrudd om &lt;b&gt;%n&lt;/b&gt; sekund…</numerusform><numerusform>Tidsavbrudd om &lt;b&gt;%n&lt;/b&gt; sekunder…</numerusform></translation>
    </message>
    <message>
        <source>Relying Party: %1</source>
        <translation>Tiltrodd part: %1</translation>
    </message>
    <message>
        <source>Username: %1</source>
        <translation>Brukernavn: %1</translation>
    </message>
    <message>
        <source>KeePassXC - Passkey credentials</source>
        <translation>KeePassXC - Tilgangsnøkkel-identifikasjon</translation>
    </message>
    <message>
        <source>Add to existing entry</source>
        <translation>Legg til i eksisterende oppføring</translation>
    </message>
    <message>
        <source>Existing passkey found.
Do you want to register a new passkey for:</source>
        <translation>Eksisterende tilgangsnøkkel funnet.
Vil du registrere en ny tilgangsnøkkel for:</translation>
    </message>
    <message>
        <source>Select the existing passkey and press Update to replace it.</source>
        <translation>Velg den eksisterende tilgangsnøkkelen, og trykk oppdater for å erstatte den.</translation>
    </message>
    <message>
        <source>Authenticate passkey credentials for:</source>
        <translation>Godkjenn tilgangsnøkkellegitimasjon for:</translation>
    </message>
    <message>
        <source>Do you want to register a passkey for:</source>
        <translation>Vil du registrere tilgangsnøkkel for:</translation>
    </message>
</context>
<context>
    <name>BrowserService</name>
    <message>
        <source>A request for creating a new group &quot;%1&quot; has been received.
Do you want to create this group?
</source>
        <translation>En forespørsel om å opprette en ny gruppe &quot;%1&quot; er mottatt.
Vil du opprette denne gruppen?</translation>
    </message>
    <message>
        <source>You have received an association request for the following database:
%1

Give the connection a unique name or ID, for example:
chrome-laptop.</source>
        <translation>Du har mottatt en tilknytningsforespørsel for følgende database:
%1

Gi tilkoblingen et unikt navn eller en unik ID, for eksempel:
chrome-laptop.</translation>
    </message>
    <message>
        <source>Save and allow access</source>
        <translation>Lagre og tillat aksess</translation>
    </message>
    <message>
        <source>A shared encryption key with the name &quot;%1&quot; already exists.
Do you want to overwrite it?</source>
        <translation>En delt krypteringsnøkkel med navn &quot;%1&quot; eksisterer fra før.
Vil du overskrive den?</translation>
    </message>
    <message>
        <source>Do you want to update the information in %1 - %2?</source>
        <translation>Vil du oppdatere informasjonen i %1 - %2?</translation>
    </message>
    <message>
        <source>A request for deleting entry &quot;%1&quot; has been received.
Do you want to delete the entry?
</source>
        <translation>En forespørsel om sletting av oppføringen &quot;%1&quot; er mottatt.
Vil du slette oppføringen?</translation>
    </message>
    <message>
        <source>%1 (Passkey)</source>
        <translation>%1 (tilgangsnøkkel)</translation>
    </message>
    <message>
        <source>KeePassXC - Create a new group</source>
        <translation>KeePassXC - Opprett en ny gruppe</translation>
    </message>
    <message>
        <source>Disable</source>
        <translation>Deaktiver</translation>
    </message>
    <message>
        <source>KeePassXC - Overwrite existing key?</source>
        <translation>KeePassXC - Erstatte eksisterende nøkkel?</translation>
    </message>
    <message>
        <source>KeePassXC - Update Entry</source>
        <translation>KeePassXC - Oppdater oppføring</translation>
    </message>
    <message>
        <source>KeePassXC - Delete entry</source>
        <translation>KeePassXC - Slett oppføring</translation>
    </message>
    <message>
        <source>KeePassXC - New key association request</source>
        <translation>KeePassXC - Forespørsel om ny nøkkeltilknytning</translation>
    </message>
    <message>
        <source>Passkey</source>
        <translation>Tilgangsnøkkel</translation>
    </message>
    <message>
        <source>KeePassXC - Passkey credentials</source>
        <translation>KeePassXC - Tilgangsnøkkel-identifikasjon</translation>
    </message>
    <message>
        <source>Register a new passkey to this entry:</source>
        <translation>Registrer ny tilgangsnøkkel på denne oppføringen:</translation>
    </message>
    <message>
        <source>KeePassXC - Update passkey</source>
        <translation>KeePassXC - Oppdater tilgangsnøkkel</translation>
    </message>
    <message>
        <source>Entry already has a passkey.
Do you want to overwrite the passkey in %1 - %2?</source>
        <translation>Oppføringen har allerede en tilgangsnøkkel.
Vil du erstatte tilgangsnøkkelen i %1 - %2?</translation>
    </message>
    <message>
        <source>Register</source>
        <translation>Registrer</translation>
    </message>
</context>
<context>
    <name>BrowserSettingsWidget</name>
    <message>
        <source>Dialog</source>
        <translation>Vindu</translation>
    </message>
    <message>
        <source>This is required for accessing your databases with KeePassXC-Browser</source>
        <translation>Dette er nødvendig for å få tilgang til dine databaser med KeePassXC-Browser</translation>
    </message>
    <message>
        <source>Enable browser integration</source>
        <translation>Aktiver nettleserintegrasjon</translation>
    </message>
    <message>
        <source>General</source>
        <translation>Generelt</translation>
    </message>
    <message>
        <source>Enable integration for these browsers:</source>
        <translation>Bruk tillegget i disse nettleserne:</translation>
    </message>
    <message>
        <source>Vivaldi</source>
        <translation>Vivaldi</translation>
    </message>
    <message>
        <source>&amp;Edge</source>
        <translation>&amp;Edge</translation>
    </message>
    <message>
        <source>Firefox</source>
        <translation>Firefox</translation>
    </message>
    <message>
        <source>Tor Browser</source>
        <translation>Tor nettleser</translation>
    </message>
    <message>
        <source>Brave</source>
        <translation>Brave</translation>
    </message>
    <message>
        <source>Google Chrome</source>
        <translation>Google Chrome</translation>
    </message>
    <message>
        <source>Chromium</source>
        <translation>Chromium</translation>
    </message>
    <message>
        <source>Show a notification when credentials are requested</source>
        <extracomment>Credentials mean login data requested via browser extension</extracomment>
        <translation>Vis et varsel når det bes om identifikasjon</translation>
    </message>
    <message>
        <source>Request to unlock the database if it is locked</source>
        <translation>Forespørsel om å låse opp databasen hvis den er låst</translation>
    </message>
    <message>
        <source>Only entries with the same scheme (http://, https://, …) are returned.</source>
        <translation>Bare oppføringer med samme skjema (http://, https://, …) returneres.</translation>
    </message>
    <message>
        <source>Match URL scheme (e.g., https://example.com)</source>
        <translation>Match URL-skjema (f.eks. https://example.com)</translation>
    </message>
    <message>
        <source>Only returns the best matches for a specific URL instead of all entries for the whole domain.</source>
        <translation>Returnerer bare beste matcher for en spesifikk URL i stedet for alle oppføringer i hele domenet.</translation>
    </message>
    <message>
        <source>Return only best-matching credentials</source>
        <translation>Returner bare beste matchende identifikasjon</translation>
    </message>
    <message>
        <source>Returns expired credentials. String [expired] is added to the title.</source>
        <translation>Returnerer utløpt identifikasjon. Strengen [utløpt] legges til i tittelen.</translation>
    </message>
    <message>
        <source>Allow returning expired credentials</source>
        <translation>Tillat retur av utløpte identifikasjoner</translation>
    </message>
    <message>
        <source>All databases connected to the extension will return matching credentials.</source>
        <translation>Alle databaser koblet til utvidelsen returnerer beste matchende identifikasjon.</translation>
    </message>
    <message>
        <source>Search in all opened databases for matching credentials</source>
        <extracomment>Credentials mean login data requested via browser extension</extracomment>
        <translation>Søk i alle åpnede databaser etter beste matchende identifikasjon</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>Avansert</translation>
    </message>
    <message>
        <source>Never ask before accessing credentials</source>
        <extracomment>Credentials mean login data requested via browser extension</extracomment>
        <translation>Aldri spør før henting av identifikasjon</translation>
    </message>
    <message>
        <source>Never ask before updating credentials</source>
        <extracomment>Credentials mean login data requested via browser extension</extracomment>
        <translation>Aldri spør før oppdatering av identifikasjon</translation>
    </message>
    <message>
        <source>Do not ask permission for HTTP Basic Auth</source>
        <extracomment>An extra HTTP Basic Auth setting</extracomment>
        <translation>Ikke be om tillatelse til HTTP Basic Auth</translation>
    </message>
    <message>
        <source>Automatically creating or updating string fields is not supported.</source>
        <translation>Automatisk registrering eller endring av tekstfelt er ikke støttet.</translation>
    </message>
    <message>
        <source>Return advanced string fields which start with &quot;KPH: &quot;</source>
        <translation>Returner avanserte strengfelter som begynner med &quot;KPH: &quot;</translation>
    </message>
    <message>
        <source>Don&apos;t display the popup suggesting migration of legacy KeePassHTTP settings.</source>
        <translation>Ikke vis popup-vinduet som foreslår overføring av eldre KeePassHTTP-innstillinger.</translation>
    </message>
    <message>
        <source>Do not prompt for KeePassHTTP settings migration.</source>
        <translation>Ikke be om overføring av KeePassHTTP-innstillinger.</translation>
    </message>
    <message>
        <source>Updates KeePassXC or keepassxc-proxy binary path automatically to native messaging scripts on startup.</source>
        <translation>Oppdaterer automatisk KeePassXC eller sti til binær keepassxc-mellomtjener til innebygd meldingsformidlings-skript ved oppstart.</translation>
    </message>
    <message>
        <source>Update native messaging manifest files at startup</source>
        <translation>Oppdater manifestfilene for innebygd meldingsformidling ved oppstart</translation>
    </message>
    <message>
        <source>Use a custom proxy location if you installed a proxy manually.</source>
        <translation>Oppgi en selvvalgt mellomtjener dersom du installerte mellomtjeneren manuelt.</translation>
    </message>
    <message>
        <source>Use a custom proxy location:</source>
        <comment>Meant is the proxy for KeePassXC-Browser</comment>
        <translation>Bruk en egendefinert mellomtjenerplassering:</translation>
    </message>
    <message>
        <source>Custom proxy location field</source>
        <translation>Felt for egendefinert mellomtjenerplassering</translation>
    </message>
    <message>
        <source>Browser for custom proxy file</source>
        <translation>Leser for egendefinert mellomtjenerfil</translation>
    </message>
    <message>
        <source>Browse…</source>
        <extracomment>Button for opening file dialog</extracomment>
        <translation>Bla gjennom...</translation>
    </message>
    <message>
        <source>Use a custom browser configuration location:</source>
        <translation>Bruk en egendefinert plassering for nettleserkonfigurasjon:</translation>
    </message>
    <message>
        <source>Browser type:</source>
        <translation>Type nettleser:</translation>
    </message>
    <message>
        <source>Toolbar button style</source>
        <translation>Knappestil på verktøylinjen</translation>
    </message>
    <message>
        <source>Config Location:</source>
        <translation>Konfigurasjonsplassering:</translation>
    </message>
    <message>
        <source>Custom browser location field</source>
        <translation>Felt for egendefinert nettleserplassering:</translation>
    </message>
    <message>
        <source>Browse for custom browser path</source>
        <translation>Bla gjennom etter sti til egendefinert nettleser</translation>
    </message>
    <message>
        <source>Custom extension ID:</source>
        <translation>Egendefinert utvidelses-ID:</translation>
    </message>
    <message>
        <source>Custom extension ID</source>
        <translation>Egendefinert utvidelses-ID</translation>
    </message>
    <message>
        <source>Executable Files</source>
        <translation>Kjørbare filer</translation>
    </message>
    <message>
        <source>All Files</source>
        <translation>Alle Filer</translation>
    </message>
    <message>
        <source>Select custom proxy location</source>
        <translation>Oppgi en selvvalgt mellomtjerneradresse</translation>
    </message>
    <message>
        <source>Select native messaging host folder location</source>
        <translation>Velg plassering til den innebygde meldingsformidleren</translation>
    </message>
    <message>
        <source>Allow keepassxc-proxy to list all entries with their title, URL and UUID in connected databases.</source>
        <translation>Tillat keepassxc-proxy å liste alle oppføringer med tittel, URL og UUID i tilkoblede databaser.</translation>
    </message>
    <message>
        <source>Allow limited access to all entries in connected databases (ignores site access restrictions)</source>
        <translation>Tillat begrenset tilgang til alle oppføringer i tilkoblede databaser (ignorerer begrensninger for nettstedstilgang)</translation>
    </message>
    <message>
        <source>&lt;b&gt;Warning:&lt;/b&gt; Only adjust these settings if necessary.</source>
        <translation>&lt;b&gt;Advarsel:&lt;/b&gt; Juster disse innstillingene bare om nødvendig.</translation>
    </message>
    <message>
        <source>The custom proxy location does not exist.</source>
        <translation>Den egendefinerte proxy-lokasjonen finnes ikke.</translation>
    </message>
    <message>
        <source>&lt;b&gt;Error:&lt;/b&gt; The custom proxy location does not exist. Correct this in the advanced settings tab.</source>
        <translation>&lt;b&gt;Feil:&lt;/b&gt; Den egendefinerte proxy-lokasjonen finnes ikke. Korriger dette i fanen for avanserte innstillinger.</translation>
    </message>
    <message>
        <source>&lt;b&gt;Error:&lt;/b&gt; The installed proxy executable is missing from the expected location: %1&lt;br/&gt;Please set a custom proxy location in the advanced settings or reinstall the application.</source>
        <translation>&lt;b&gt;Feil:&lt;/b&gt; Den installerte eksekverbare proxyen finnes ikke på den forventede plasseringen: %1&lt;br/&gt;Angi en egendefinert proxy-lokasjon i de avanserte innstillingene, eller installer applikasjonen på nytt.</translation>
    </message>
    <message>
        <source>Allows using insecure http://localhost with passkeys for testing purposes.</source>
        <translation>Tillater bruk av usikre http://localhost med tilgangsnøkler for testformål.</translation>
    </message>
    <message>
        <source>Allow using localhost with passkeys</source>
        <translation>Tillat bruk av localhost med tilgangsnøkler</translation>
    </message>
    <message>
        <source>KeePassXC-Browser is needed for the browser integration to work. &lt;br /&gt;Download it for %1 and %2 and %3.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Browsers installed using Snap or Flatpak are not supported with exception to Firefox installed using Snap.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>CloneDialog</name>
    <message>
        <source>Clone Entry Options</source>
        <translation>Klone oppføringsalternativer</translation>
    </message>
    <message>
        <source>Append &apos; - Clone&apos; to title</source>
        <translation>Tilføy &apos; - Clone&apos; til tittel</translation>
    </message>
    <message>
        <source>Replace username and password with references</source>
        <translation>Bytt ut brukernavn og passord med referanser</translation>
    </message>
    <message>
        <source>Copy history</source>
        <translation>Kopier historie</translation>
    </message>
</context>
<context>
    <name>CsvImportWidget</name>
    <message>
        <source>size, rows, columns</source>
        <translation>størrelse, rader, kolonner</translation>
    </message>
    <message>
        <source>Column Association</source>
        <translation>Kolonnetilknytning</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Passord</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>Brukernavn</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>Tittel</translation>
    </message>
    <message>
        <source>Group</source>
        <translation>Gruppe</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>Notes</source>
        <translation>Notater</translation>
    </message>
    <message>
        <source>TOTP</source>
        <translation>TOTP</translation>
    </message>
    <message>
        <source>Created</source>
        <translation>Opprettet</translation>
    </message>
    <message>
        <source>Last Modified</source>
        <translation>Sist endra</translation>
    </message>
    <message>
        <source>Icon</source>
        <translation>Ikon</translation>
    </message>
    <message>
        <source>Encoding</source>
        <translation>Koding</translation>
    </message>
    <message>
        <source>Codec</source>
        <translation>Kodek</translation>
    </message>
    <message>
        <source>Text is qualified by</source>
        <translation>Tekst er markert med</translation>
    </message>
    <message>
        <source>Text qualification</source>
        <translation>Tekstkvalifisering</translation>
    </message>
    <message>
        <source>Fields are separated by</source>
        <translation>Felt er separert av</translation>
    </message>
    <message>
        <source>Field separation</source>
        <translation>Feltseparasjon</translation>
    </message>
    <message>
        <source>Comments start with</source>
        <translation>Kommentarer starter med</translation>
    </message>
    <message>
        <source>Header lines skipped</source>
        <translation>Hodelinjer hoppet over</translation>
    </message>
    <message>
        <source>Number of header lines to discard</source>
        <translation>Antall hodelinjer som skal forkastes</translation>
    </message>
    <message>
        <source>First line has field names</source>
        <translation>Første linje har feltnavn</translation>
    </message>
    <message>
        <source>Consider &apos;\&apos; an escape character</source>
        <translation>Betrakt &apos;\&apos; som en escape-sekvens</translation>
    </message>
    <message>
        <source>Preview</source>
        <translation>Forhåndsvis</translation>
    </message>
    <message>
        <source>CSV import preview</source>
        <translation>Forhåndsvisning av CSV-import</translation>
    </message>
    <message>
        <source>Not Present</source>
        <translation>Ikke til stede</translation>
    </message>
    <message>
        <source>Column %1</source>
        <translation>Kolonne %1</translation>
    </message>
    <message numerus="yes">
        <source>[%n more message(s) skipped]</source>
        <translation><numerusform>[%n melding hoppet over]</numerusform><numerusform>[%n flere meldinger hoppet over]</numerusform></translation>
    </message>
    <message>
        <source>Failed to parse CSV file: %1</source>
        <translation>Kunne ikke tolke CSV-fil: %1</translation>
    </message>
    <message>
        <source>Imported from CSV file: %1</source>
        <translation>Importert fra CSV-fil: %1</translation>
    </message>
    <message>
        <source>No Title Selected</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>No title column was selected, entries will be hard to tell apart.
Are you sure you want to import?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Tags</source>
        <translation>Tagger</translation>
    </message>
</context>
<context>
    <name>CsvParserModel</name>
    <message numerus="yes">
        <source>%n row(s)</source>
        <comment>CSV row count</comment>
        <translation><numerusform>%n rad</numerusform><numerusform>%n rader</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>%n column(s)</source>
        <comment>CSV column count</comment>
        <translation><numerusform>%n kolonne</numerusform><numerusform>%n kolonner</numerusform></translation>
    </message>
</context>
<context>
    <name>Database</name>
    <message>
        <source>Passwords</source>
        <comment>Root group name</comment>
        <translation>Passord</translation>
    </message>
    <message>
        <source>File %1 does not exist.</source>
        <translation>Filen %1 eksisterer ikke.</translation>
    </message>
    <message>
        <source>Unable to open file %1.</source>
        <translation>Kan ikke åpne fil %1.</translation>
    </message>
    <message>
        <source>Error while reading the database: %1</source>
        <translation>Feil under lesing av databasen: %1</translation>
    </message>
    <message>
        <source>Could not save, database does not point to a valid file.</source>
        <translation>Kunne ikke lagre. Databasen peker ikke til en gyldig fil.</translation>
    </message>
    <message>
        <source>Database save is already in progress.</source>
        <translation>Lagring av databasen pågår allerede.</translation>
    </message>
    <message>
        <source>Could not save, database has not been initialized!</source>
        <translation>Kunne ikke lagre. Databasen er ikke klargjort!</translation>
    </message>
    <message>
        <source>Database file has unmerged changes.</source>
        <translation>Databasefilen har endringer som ikke er slått sammen.</translation>
    </message>
    <message>
        <source>%1
Backup database located at %2</source>
        <translation>%1
Sikkerhetskopi av databasen er lokalisert på %2</translation>
    </message>
    <message>
        <source>Key not transformed. This is a bug, please report it to the developers.</source>
        <translation>Nøkkelen er ikke transformert. Dette er en feil. Vennligst rapporter det til utviklerne.</translation>
    </message>
    <message>
        <source>Recycle Bin</source>
        <translation>Papirkurv</translation>
    </message>
    <message>
        <source>Database file read error.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>No file path was provided.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>DatabaseOpenDialog</name>
    <message>
        <source>Unlock Database - KeePassXC</source>
        <translation>Lås opp database - KeePassXC</translation>
    </message>
</context>
<context>
    <name>DatabaseOpenWidget</name>
    <message>
        <source>Unlock KeePassXC Database</source>
        <translation>Lås opp KeePassXC-database</translation>
    </message>
    <message>
        <source>Enter Password:</source>
        <translation>Oppgi passord:</translation>
    </message>
    <message>
        <source>Password field</source>
        <translation>Passordfelt</translation>
    </message>
    <message>
        <source>Hardware key slot selection</source>
        <translation>Valg av spor i maskinvarenøkkel</translation>
    </message>
    <message>
        <source>Key file to unlock the database</source>
        <translation>Nøkkelfil for å låse opp databasen</translation>
    </message>
    <message>
        <source>Browse for key file</source>
        <translation>Søk etter nøkkelfilen</translation>
    </message>
    <message>
        <source>Browse…</source>
        <translation>Bla gjennom...</translation>
    </message>
    <message>
        <source>Unlock Database</source>
        <translation>Lås opp database</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Avbryt</translation>
    </message>
    <message>
        <source>Unlock</source>
        <translation>Lås opp</translation>
    </message>
    <message>
        <source>Please present or touch your YubiKey to continue…</source>
        <translation>Koble til eller berør YubiKey for å fortsette...</translation>
    </message>
    <message>
        <source>Database Version Mismatch</source>
        <translation>Databaseversjonen stemmer ikke</translation>
    </message>
    <message>
        <source>The database you are trying to open was most likely
created by a newer version of KeePassXC.

You can try to open it anyway, but it may be incomplete
and saving any changes may incur data loss.

We recommend you update your KeePassXC installation.</source>
        <translation>Databasen du prøver å åpne, var mest sannsynlig
opprettet av en nyere versjon av KeePassXC.

Du kan prøve å åpne den likevel, men den kan være ufullstendig
og lagring av endringer kan medføre tap av data.

Vi anbefaler at du oppdaterer KeePassXC-installasjonen.</translation>
    </message>
    <message>
        <source>Open database anyway</source>
        <translation>Åpne databasen likevel</translation>
    </message>
    <message>
        <source>Database unlock canceled.</source>
        <translation>Opplåsing av databasen avbrutt.</translation>
    </message>
    <message>
        <source>Unlock failed and no password given</source>
        <translation>Opplåsing mislyktes og ingen passord gitt</translation>
    </message>
    <message>
        <source>Unlocking the database failed and you did not enter a password.
Do you want to retry with an &quot;empty&quot; password instead?

To prevent this error from appearing, you must go to &quot;Database Settings / Security&quot; and reset your password.</source>
        <translation>Opplåsing av databasen mislyktes, og du skrev ikke inn passord.
Vil du prøve på nytt med et tomt passord i stedet?

For å forhindre at denne feilen vises, må du gå til &quot;Databaseinnstillinger / Sikkerhet&quot; og tilbakestille passordet ditt.</translation>
    </message>
    <message>
        <source>Retry with empty password</source>
        <translation>Prøv igjen med tomt passord</translation>
    </message>
    <message>
        <source>Failed to open key file: %1</source>
        <translation>Kunne ikke åpne nøkkelfil: %1</translation>
    </message>
    <message>
        <source>Old key file format</source>
        <translation>Gammelt nøkkelfilformat</translation>
    </message>
    <message>
        <source>You are using an old key file format which KeePassXC may&lt;br&gt;stop supporting in the future.&lt;br&gt;&lt;br&gt;Please consider generating a new key file by going to:&lt;br&gt;&lt;strong&gt;Database &amp;gt; Database Security &amp;gt; Change Key File.&lt;/strong&gt;&lt;br&gt;</source>
        <translation>Du bruker et gammelt nøkkelfilformat som KeePassXC kan&lt;br&gt;slutte å støtte i fremtiden.&lt;br&gt;&lt;br&gt;Vurder å generere en ny nøkkelfil ved å gå til:&lt;br&gt;&lt;strong&gt;Database &amp;gt; databasesikkerhet &amp;gt; endre nøkkelfil.&lt;/strong&gt;&lt;br&gt;</translation>
    </message>
    <message>
        <source>Don&apos;t show this warning again</source>
        <translation>Ikke vis denne advarselen igjen</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>Alle filer</translation>
    </message>
    <message>
        <source>Key files</source>
        <translation>Nøkkelfiler</translation>
    </message>
    <message>
        <source>Select key file</source>
        <translation>Velg nøkkelfil</translation>
    </message>
    <message>
        <source>Cannot use database file as key file</source>
        <translation>Kan ikke bruke database fil som nøkkelfil</translation>
    </message>
    <message>
        <source>authenticate to access the database</source>
        <translation>autentiser for å få tilgang til databasen</translation>
    </message>
    <message>
        <source>Failed to authenticate with Quick Unlock: %1</source>
        <translation>Autentisering med hurtigopplåsing feilet: %1</translation>
    </message>
    <message>
        <source>Select Key File:</source>
        <translation>Velg nøkkelfil:</translation>
    </message>
    <message>
        <source>&lt;p&gt;In addition to a password, you can use a secret file to enhance the security of your database. This file can be generated in your database&apos;s security settings.&lt;/p&gt;&lt;p&gt;This is &lt;strong&gt;not&lt;/strong&gt; your *.kdbx database file!&lt;/p&gt;</source>
        <translation>&lt;p&gt;I tillegg til passord, kan du bruke en nøkkelfil for å forbedre sikkerheten til databasen. Denne fila kan opprettes i databasens sikkerhetsinnstillinger.&lt;/p&gt; &lt;p&gt;Dette er &lt;strong&gt;ikke&lt;/strong&gt; *.kdbx-databasefilen din!&lt;/p&gt;</translation>
    </message>
    <message>
        <source>Use hardware key [Serial: %1]</source>
        <translation>Bruk hardware-nøkkel</translation>
    </message>
    <message>
        <source>Use hardware key</source>
        <translation>Bruk maskinvarenøkkel</translation>
    </message>
    <message>
        <source>Your database file is NOT a key file!
If you don&apos;t have a key file or don&apos;t know what that is, you don&apos;t have to select one.</source>
        <translation>Database-filen er IKKE en nøkkelfil!
Om du ikke har en nøkkelfil, eller ikke vet hva det er, trenger du ikke velge en.</translation>
    </message>
    <message>
        <source>KeePassXC database file selected</source>
        <translation>KeePassXC-databasefil valgt</translation>
    </message>
    <message>
        <source>The file you selected looks like a database file.
A database file is NOT a key file!

Are you sure you want to continue with this file?.</source>
        <translation>Filen du har valgt ser ut som en databasefil.
En databasefil er IKKE en nøkkelfil!

Er du sikker på at du vil fortsette med denne filen?</translation>
    </message>
    <message>
        <source>No hardware keys found.</source>
        <translation>Finner ingen maskinvarenøkler.</translation>
    </message>
    <message>
        <source>Refresh Hardware Keys</source>
        <translation>Oppdater maskinvarenøkler</translation>
    </message>
    <message>
        <source>Click to add a key file.</source>
        <translation>Trykk for å legge til en nøkkelfil</translation>
    </message>
    <message>
        <source>Hardware keys found, but no slots are configured.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Press ESC again to close this database</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>I have a key file</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>DatabaseSettingWidgetMetaData</name>
    <message>
        <source>Passwords</source>
        <translation>Passord</translation>
    </message>
</context>
<context>
    <name>DatabaseSettingsDialog</name>
    <message>
        <source>General</source>
        <translation>Generelt</translation>
    </message>
    <message>
        <source>Security</source>
        <translation>Sikkerhet</translation>
    </message>
    <message>
        <source>Database Credentials</source>
        <translation>Database-akkreditering</translation>
    </message>
    <message>
        <source>Encryption Settings</source>
        <translation>Krypteringsinnstillinger</translation>
    </message>
    <message>
        <source>Browser Integration</source>
        <translation>Nettlesertillegg</translation>
    </message>
    <message>
        <source>Maintenance</source>
        <translation>Vedlikehold</translation>
    </message>
    <message>
        <source>KeeShare</source>
        <translation>KeeShare</translation>
    </message>
    <message>
        <source>Secret Service Integration</source>
        <translation>Integrasjon av &apos;Secret Service&apos;</translation>
    </message>
    <message>
        <source>Remote Sync</source>
        <translation>Fjernsynkronisering</translation>
    </message>
    <message>
        <source>Database Settings: %1</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>DatabaseSettingsWidgetBrowser</name>
    <message>
        <source>KeePassXC-Browser settings</source>
        <translation>KeePassXC nettleser-innstillinger</translation>
    </message>
    <message>
        <source>Disconnect all browsers</source>
        <translation>Koble fra alle nettlesere</translation>
    </message>
    <message>
        <source>Forget all site-specific settings on entries</source>
        <translation>Glem alle områdespesifikke innstillinger og oppføringer</translation>
    </message>
    <message>
        <source>Refresh database root group ID</source>
        <translation>Oppdater rotgruppe-ID for database</translation>
    </message>
    <message>
        <source>Stored keys</source>
        <translation>Lagrede nøkler</translation>
    </message>
    <message>
        <source>Stored browser keys</source>
        <translation>Lagrede nettlesernøkler</translation>
    </message>
    <message>
        <source>Remove selected key</source>
        <translation>Fjern valgt nøkkel</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Fjern</translation>
    </message>
    <message>
        <source>Delete the selected key?</source>
        <translation>Slette den valgte nøkkelen?</translation>
    </message>
    <message>
        <source>Do you really want to delete the selected key?
This may prevent connection to the browser plugin.</source>
        <translation>Vil du virkelig slette den merkede nøkkelen?
Dette kan forhindre tilkobling for plugin-modulen i nettleseren.</translation>
    </message>
    <message>
        <source>Key</source>
        <translation>Nøkkel</translation>
    </message>
    <message>
        <source>Value</source>
        <translation>Verdi</translation>
    </message>
    <message>
        <source>Created</source>
        <translation>Opprettet</translation>
    </message>
    <message>
        <source>Enable Browser Integration to access these settings.</source>
        <translation>Aktiver nettleserintegrasjon for å få tilgang til disse innstillingene.</translation>
    </message>
    <message>
        <source>Do you really want to disconnect all browsers?
This may prevent connection to the browser plugin.</source>
        <translation>Vil du virkelig koble fra alle nettlesere?
Dette kan forhindre tilkobling for plugin-modulen i nettleseren.</translation>
    </message>
    <message>
        <source>No shared encryption keys found in KeePassXC settings.</source>
        <translation>Ingen delte kryptering nøkkel funnet i KeePassXC-innstillingene.</translation>
    </message>
    <message numerus="yes">
        <source>Successfully removed %n encryption key(s) from KeePassXC settings.</source>
        <translation><numerusform>%n krypteringsnøkkel er fjernet fra KeePassXC-innstillingene.</numerusform><numerusform>%n krypteringsnøkler er fjernet fra KeePassXC-innstillingene.</numerusform></translation>
    </message>
    <message>
        <source>Do you really want forget all site-specific settings on every entry?
Permissions to access entries will be revoked.</source>
        <translation>Vil du virkelig glemme alle områdespesifikke innstillinger for hver oppføring?
Tilgangstillatelser til oppføringer vil bli tilbakekalt.</translation>
    </message>
    <message>
        <source>Removing stored permissions…</source>
        <translation>Fjerner lagrede tillatelser...</translation>
    </message>
    <message>
        <source>Abort</source>
        <translation>Avbryt</translation>
    </message>
    <message numerus="yes">
        <source>Successfully removed permissions from %n entry(s).</source>
        <translation><numerusform>Tillatelsen er fjernet fra %n oppføring.</numerusform><numerusform>Tillatelsene er fjernet fra %n oppføringer.</numerusform></translation>
    </message>
    <message>
        <source>The active database does not contain an entry with permissions.</source>
        <translation>Den aktive databasen inneholder ikke oppsett med tillatelser.</translation>
    </message>
    <message>
        <source>Refresh database ID</source>
        <translation>Oppdater database-ID</translation>
    </message>
    <message>
        <source>Do you really want refresh the database ID?
This is only necessary if your database is a copy of another and the browser extension cannot connect.</source>
        <translation>Vil du virkelig oppdatere database-ID&apos;en?
Dette er bare nødvendig hvis databasen er en kopi av en annen og nettleserutvidelsen ikke kan koble til.</translation>
    </message>
    <message>
        <source>Convert legacy KeePassHTTP attributes to KeePassXC-Browser compatible custom data</source>
        <translation>Konverter eldre KeePassHTTP-attributter til KeePassXC-Browser-kompatible egendefinerte data</translation>
    </message>
    <message>
        <source>No keys found</source>
        <translation>Ingen nøkler funnet</translation>
    </message>
    <message>
        <source>Removed keys from database</source>
        <translation>Fjernet nøkler fra database</translation>
    </message>
    <message>
        <source>Removed permissions</source>
        <translation>Fjernet tillatelser</translation>
    </message>
    <message>
        <source>No entry with permissions found!</source>
        <translation>Ingen oppføring med tillatelser funnet!</translation>
    </message>
</context>
<context>
    <name>DatabaseSettingsWidgetDatabaseKey</name>
    <message>
        <source>Add additional protection…</source>
        <translation>Legg til ekstra beskyttelse...</translation>
    </message>
    <message>
        <source>No password set</source>
        <translation>Passord ikke satt</translation>
    </message>
    <message>
        <source>WARNING! You have not set a password. Using a database without a password is strongly discouraged!

Are you sure you want to continue without a password?</source>
        <translation>ADVARSEL! Du har ikke angitt et passord. Å bruke en database uten passord frarådes sterkt!

Er du sikker på at du vil fortsette uten passord?</translation>
    </message>
    <message>
        <source>Continue without password</source>
        <translation>Fortsett uten passord</translation>
    </message>
    <message>
        <source>No encryption key added</source>
        <translation>Ingen krypteringsnøkkel lagt til</translation>
    </message>
    <message>
        <source>You must add at least one encryption key to secure your database!</source>
        <translation>Du må legge til minst en krypteringsnøkkel for å sikre databasen!</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation>Ukjent feil</translation>
    </message>
    <message>
        <source>Failed to change database credentials</source>
        <translation>Kunne ikke endre database-akkreditering</translation>
    </message>
    <message>
        <source>Weak password</source>
        <translation>Svakt passord</translation>
    </message>
    <message>
        <source>This is a weak password! For better protection of your secrets, you should choose a stronger password.</source>
        <translation>Dette er et svakt passord! For bedre beskyttelse av hemmelighetene dine, bør du velge et sterkere passord.</translation>
    </message>
    <message>
        <source>The provided password does not meet the minimum quality requirement.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>DatabaseSettingsWidgetEncryption</name>
    <message>
        <source>Decryption Time:</source>
        <translation>Krypteringstid:</translation>
    </message>
    <message>
        <source>Decryption time in seconds</source>
        <translation>Dekrypteringstid i sekunder</translation>
    </message>
    <message>
        <source>Higher values offer more protection, but opening the database will take longer.</source>
        <translation>Høyere verdier gir mer beskyttelse, men å åpne databasen vil ta lengre tid.</translation>
    </message>
    <message>
        <source>Database format:</source>
        <translation>Databaseformat:</translation>
    </message>
    <message>
        <source>Database format</source>
        <translation>Databaseformat</translation>
    </message>
    <message>
        <source>Format cannot be changed: Your database uses KDBX 4 features</source>
        <translation>Formatet kan ikke endres: Databasen bruker KDBX 4-funksjoner</translation>
    </message>
    <message>
        <source>Unless you need to open your database with other programs, always use the latest format.</source>
        <translation>Med mindre du må åpne databasen med andre programmer, så bruk alltid det nyeste formatet.</translation>
    </message>
    <message>
        <source>Encryption Algorithm:</source>
        <translation>Krypteringsalgoritme:</translation>
    </message>
    <message>
        <source>Encryption algorithm</source>
        <translation>Kryptering algoritme</translation>
    </message>
    <message>
        <source>AES:  256 Bit   (default)</source>
        <translation>AES: 256 bit (standard)</translation>
    </message>
    <message>
        <source>Twofish:  256 Bit</source>
        <translation>Twofish:  256 Bit</translation>
    </message>
    <message>
        <source>Key Derivation Function:</source>
        <translation>Nøkkelavledningsfunksjon:</translation>
    </message>
    <message>
        <source>Key derivation function</source>
        <translation>Funksjon for nøkkelavledning</translation>
    </message>
    <message>
        <source>Transform rounds:</source>
        <translation>Transformasjonsrunder:</translation>
    </message>
    <message>
        <source>Transform rounds</source>
        <translation>Transformasjonsrunder</translation>
    </message>
    <message>
        <source>Memory Usage:</source>
        <translation>Minnebruk:</translation>
    </message>
    <message>
        <source>Memory usage</source>
        <translation>Minnebruk</translation>
    </message>
    <message>
        <source>Parallelism:</source>
        <translation>Parallellitet:</translation>
    </message>
    <message>
        <source>Parallelism</source>
        <translation>Parallellitet</translation>
    </message>
    <message>
        <source>KDBX 4 (recommended)</source>
        <translation>KDBX 4 (anbefalt)</translation>
    </message>
    <message>
        <source>KDBX 3</source>
        <translation>KDBX 3</translation>
    </message>
    <message>
        <source>Number of rounds too high</source>
        <comment>Key transformation rounds</comment>
        <translation>Antall runder er for høyt</translation>
    </message>
    <message>
        <source>You are using a very high number of key transform rounds with Argon2.

If you keep this number, your database may take hours, days, or even longer to open.</source>
        <translation>Du bruker et svært høyt antall transformasjonsrunder med Argon2.

Hvis du beholder dette antallet kan det ta timer, dager eller enda lenger å åpne databasen.</translation>
    </message>
    <message>
        <source>Understood, keep number</source>
        <translation>Forstått; behold antallet</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Avbryt</translation>
    </message>
    <message>
        <source>Number of rounds too low</source>
        <comment>Key transformation rounds</comment>
        <translation>Antall runder er for lavt</translation>
    </message>
    <message>
        <source>You are using a very low number of key transform rounds with AES-KDF.

If you keep this number, your database will not be protected from brute force attacks.</source>
        <translation>Du bruker et svært lavt antall transformasjonsrunder med AES-KDF.

Hvis du beholder dette antallet vil ikke databasen være beskyttet mot &apos;rå kraft&apos;-angrep.</translation>
    </message>
    <message>
        <source>KDF unchanged</source>
        <translation>KDF uendret</translation>
    </message>
    <message>
        <source>Failed to transform key with new KDF parameters; KDF unchanged.</source>
        <translation>Kunne ikke omskape nøkkel med nye KDF-parametere; KDF uendret.</translation>
    </message>
    <message numerus="yes">
        <source> MiB</source>
        <comment>Abbreviation for Mebibytes (KDF settings)</comment>
        <translation><numerusform>MiB</numerusform><numerusform>MiB</numerusform></translation>
    </message>
    <message numerus="yes">
        <source> thread(s)</source>
        <comment>Threads for parallel execution (KDF settings)</comment>
        <translation><numerusform>tråd(er)</numerusform><numerusform>tråd(er)</numerusform></translation>
    </message>
    <message>
        <source>Encryption Settings:</source>
        <translation>Krypteringsinnstillinger:</translation>
    </message>
    <message>
        <source>Basic</source>
        <translation>Standard</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>Avansert</translation>
    </message>
</context>
<context>
    <name>DatabaseSettingsWidgetFdoSecrets</name>
    <message>
        <source>Exposed Entries</source>
        <translation>Eksponerte oppføringer</translation>
    </message>
    <message>
        <source>Don&apos;t expose this database</source>
        <translation>Ikke vis denne databasen</translation>
    </message>
    <message>
        <source>Expose entries under this group:</source>
        <translation>Vis oppføringer under denne gruppen:</translation>
    </message>
    <message>
        <source>Enable Secret Service to access these settings.</source>
        <translation>Aktiver &apos;secret service&apos; for å få tilgang til disse innstillingene.</translation>
    </message>
</context>
<context>
    <name>DatabaseSettingsWidgetGeneral</name>
    <message>
        <source>Database Metadata</source>
        <translation>Database metadata</translation>
    </message>
    <message>
        <source>Database name:</source>
        <translation>Databasenavn:</translation>
    </message>
    <message>
        <source>Database name field</source>
        <translation>Felt for databasenavn</translation>
    </message>
    <message>
        <source>Database description:</source>
        <translation>Databasebeskrivelse:</translation>
    </message>
    <message>
        <source>Database description field</source>
        <translation>Database-beskrivelsesfelt</translation>
    </message>
    <message>
        <source>Default username:</source>
        <translation>Standard brukernavn:</translation>
    </message>
    <message>
        <source>Default username field</source>
        <translation>Standard brukernavn-felt</translation>
    </message>
    <message>
        <source>History Settings</source>
        <translation>Historikkinnstillinger</translation>
    </message>
    <message>
        <source>Maximum number of history items per entry</source>
        <translation>Maksimalt antall historiske oppføringer per oppføring</translation>
    </message>
    <message>
        <source>Maximum size of history per entry</source>
        <translation>Maksimal størrelse på logg per oppføring</translation>
    </message>
    <message>
        <source> MiB</source>
        <translation> MiB</translation>
    </message>
    <message>
        <source>Use recycle bin</source>
        <translation>Bruk papirkurven</translation>
    </message>
    <message>
        <source>Additional Database Settings</source>
        <translation>Ekstra databaseinnstillinger</translation>
    </message>
    <message>
        <source>Enable compression (recommended)</source>
        <translation>Aktiver komprimering (anbefalt)</translation>
    </message>
    <message>
        <source>Delete Recycle Bin</source>
        <translation>Slett papirkurven</translation>
    </message>
    <message>
        <source>Do you want to delete the current recycle bin and all its contents?
This action is not reversible.</source>
        <translation>Vil du slette papirkurven og alt innholdet i den?
Denne handlingen kan ikke angres.</translation>
    </message>
    <message>
        <source> (old)</source>
        <translation>(gammel)</translation>
    </message>
    <message>
        <source>When saving this setting or editing an entry
the oldest history items of an entry will be
removed such that only the specified amount
of entries remain at most.</source>
        <translation>Når du lagrer denne innstillingen eller redigerer en oppføring
vil de eldste historikkelementene i en oppføring bli
fjernet slik at det maksimalt gjenstår det angitte antall
historikkelementer.</translation>
    </message>
    <message>
        <source>Limit the amount of history items per entry to:</source>
        <translation>Begrens antall historikkelementer per oppføring til:</translation>
    </message>
    <message>
        <source>When saving this setting or editing an entry
the oldest history items of an entry will be
removed such that the remaining history items
add up to the specified amount at most.</source>
        <translation>Når du lagrer denne innstillingen eller redigerer en oppføring
vil de eldste historikkelementene i en oppføring bli
fjernet slik at det maksimalt gjenstår det angitte antall
historikkelementer.</translation>
    </message>
    <message>
        <source>Limit the total size of history items per entry to:</source>
        <translation>Begrens den totale størrelsen på historikkelementer per oppføring til:</translation>
    </message>
    <message>
        <source>Move entries to a recycle bin group
instead of deleting them from the database.
Entries deleted from the recycle bin are
removed from the database.</source>
        <translation>Flytt oppføringer til en papirkurvgruppe
i stedet for å slette dem fra databasen.
Oppføringer som er slettet fra papirkurven er
fjernet fra databasen.</translation>
    </message>
    <message>
        <source>Autosave delay since last change</source>
        <translation>Autolagringsforsinkelse siden siste endring</translation>
    </message>
    <message>
        <source>Autosave delay</source>
        <translation>Autolagringsforsinkelse</translation>
    </message>
    <message>
        <source>Autosave delay since last change in minutes</source>
        <translation>Autolagringsforsinkelse i minutter siden siste endring</translation>
    </message>
    <message>
        <source> min</source>
        <translation> min</translation>
    </message>
    <message>
        <source>Autosave delay since last change checkbox</source>
        <translation>Autolagringsforsinkelse siden siste endring i avkrysningsboksa</translation>
    </message>
    <message>
        <source>Public Database Metadata</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Warning: the following settings are not encrypted.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Display name:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Database public display name</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Display color:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Database public display color chooser</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Clear</source>
        <translation>Tøm</translation>
    </message>
    <message>
        <source>Display icon:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Select Database Icon</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Publicly visible display name used on the unlock dialog</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Publicly visible color used on the unlock dialog</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>DatabaseSettingsWidgetKeeShare</name>
    <message>
        <source>Sharing</source>
        <translation>Deling</translation>
    </message>
    <message>
        <source>Breadcrumb</source>
        <translation>Brødsmule</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Type</translation>
    </message>
    <message>
        <source>Path</source>
        <translation>Sti</translation>
    </message>
    <message>
        <source>Last Signer</source>
        <translation>Siste Signatur</translation>
    </message>
    <message>
        <source>Certificates</source>
        <translation>Sertifikater</translation>
    </message>
    <message>
        <source> &gt; </source>
        <comment>Breadcrumb separator</comment>
        <translation>&gt;</translation>
    </message>
</context>
<context>
    <name>DatabaseSettingsWidgetMaintenance</name>
    <message>
        <source>Manage Custom Icons</source>
        <translation>Behandle egendefinerte ikoner</translation>
    </message>
    <message>
        <source>Delete selected icon(s)</source>
        <translation>Slett valgt(e) ikon(er)</translation>
    </message>
    <message>
        <source>Delete all custom icons not in use by any entry or group</source>
        <translation>Slett alle egendefinerte ikoner som ikke er i bruk av noen oppføringer eller grupper</translation>
    </message>
    <message>
        <source>Purge unused icons</source>
        <translation>Slett ubrukte ikoner</translation>
    </message>
    <message>
        <source>Confirm Deletion</source>
        <translation>Bekreft sletting</translation>
    </message>
    <message>
        <source>At least one of the selected icons is currently in use by at least one entry or group. The icons of all affected entries and groups will be replaced by the default icon. Are you sure you want to delete icons that are currently in use?</source>
        <translation>Minst ett av de valgte ikonene er for øyeblikket i bruk av minst én oppføring eller gruppe. Ikonene for alle berørte oppføringer og grupper erstattes av standardikonet. Er du sikker på at du vil slette ikoner som er i bruk?</translation>
    </message>
    <message>
        <source>Custom Icons Are In Use</source>
        <translation>Egendefinerte ikoner er i bruk</translation>
    </message>
    <message>
        <source>All custom icons are in use by at least one entry or group.</source>
        <translation>Alle egendefinerte ikoner er i bruk av minst en oppføring eller gruppe.</translation>
    </message>
    <message>
        <source>Purged Unused Icons</source>
        <translation>Slettet ubrukte ikoner</translation>
    </message>
    <message numerus="yes">
        <source>Purged %n icon(s) from the database.</source>
        <translation><numerusform>Slettet %n ikon fra databasen.</numerusform><numerusform>Slettet %n ikoner fra databasen.</numerusform></translation>
    </message>
</context>
<context>
    <name>DatabaseSettingsWidgetMetaDataSimple</name>
    <message>
        <source>Database Name:</source>
        <translation>Databasenavn:</translation>
    </message>
    <message>
        <source>Database name field</source>
        <translation>Felt for databasenavn</translation>
    </message>
    <message>
        <source>Description:</source>
        <translation>Beskrivelse:</translation>
    </message>
    <message>
        <source>Database description field</source>
        <translation>Database-beskrivelsesfelt</translation>
    </message>
</context>
<context>
    <name>DatabaseSettingsWidgetRemote</name>
    <message>
        <source>Sync Commands</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Remove</source>
        <translation>Fjern</translation>
    </message>
    <message>
        <source>Command Settings</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Name</source>
        <translation>Navn</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>Lagre</translation>
    </message>
    <message>
        <source>Download</source>
        <translation>Last ned</translation>
    </message>
    <message>
        <source>Command:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Download command field</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>e.g.: &quot;sftp user@hostname&quot; or &quot;scp user@hostname:DatabaseOnRemote.kdbx {TEMP_DATABASE}&quot;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Input:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Download input field</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Upload</source>
        <translation>Last opp</translation>
    </message>
    <message>
        <source>Upload command field</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>e.g.: &quot;sftp user@hostname&quot; or &quot;scp {TEMP_DATABASE} user@hostname:DatabaseOnRemote.kdbx&quot;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Upload input field</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Name cannot be empty.</source>
        <translation>Navn kan ikke være tomt.</translation>
    </message>
    <message>
        <source>Test</source>
        <translation>Test</translation>
    </message>
    <message>
        <source>Download command cannot be empty.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Download failed with error: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Download finished, but file %1 could not be found.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Download successful.</source>
        <translation>Nedlasting fullført.</translation>
    </message>
    <message>
        <source>Save Remote Settings</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>You have unsaved changes. Do you want to save them?</source>
        <translation>Du har endringer som ikke er lagret. Vil du lagre dem?</translation>
    </message>
    <message>
        <source>e.g.:
get DatabaseOnRemote.kdbx {TEMP_DATABASE}
exit
---
{TEMP_DATABASE} is used as placeholder to store the database in a temporary location
The command has to exit. In case of `sftp` as last command `exit` has to be sent
            </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>e.g.:
put {TEMP_DATABASE} DatabaseOnRemote.kdbx
exit
---
{TEMP_DATABASE} is used as placeholder to store the database in a temporary location
The command has to exit. In case of `sftp` as last command `exit` has to be sent
            </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Timeout:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source> seconds</source>
        <translation>sekunder</translation>
    </message>
</context>
<context>
    <name>DatabaseTabWidget</name>
    <message>
        <source>Database creation error</source>
        <translation>Database opprettelsesfeil</translation>
    </message>
    <message>
        <source>The created database has no key or KDF, refusing to save it.
This is definitely a bug, please report it to the developers.</source>
        <translation>Den opprettede database har ingen nøkkel eller KDF, og nekter å lagre den.
Dette er definitivt en feil, rapporter det til utviklerne.</translation>
    </message>
    <message>
        <source>KeePass 2 Database</source>
        <translation>KeePass2-database</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>Alle filer</translation>
    </message>
    <message>
        <source>Open database</source>
        <translation>Åpne database</translation>
    </message>
    <message>
        <source>Failed to open %1. It either does not exist or is not accessible.</source>
        <translation>Kunne ikke åpne %1. Enten eksisterer den ikke eller er ikke tilgjengelig.</translation>
    </message>
    <message>
        <source>CSV file</source>
        <translation>CSV fil</translation>
    </message>
    <message>
        <source>Merge database</source>
        <translation>Slå sammen database</translation>
    </message>
    <message>
        <source>Export database to CSV file</source>
        <translation>Eksporter database til CSV fil</translation>
    </message>
    <message>
        <source>Writing the CSV file failed.</source>
        <translation>Skriving av CSV fil feilet.</translation>
    </message>
    <message>
        <source>Writing the HTML file failed.</source>
        <translation>Skriving av HTML-filen mislyktes.</translation>
    </message>
    <message>
        <source>Export database to XML file</source>
        <translation>Eksporter databasen til XML-fil</translation>
    </message>
    <message>
        <source>XML file</source>
        <translation>XML-fil</translation>
    </message>
    <message>
        <source>Writing the XML file failed</source>
        <translation>Skriving av XML-filen mislyktes</translation>
    </message>
    <message>
        <source>Export Confirmation</source>
        <translation>Eksportbekreftelse</translation>
    </message>
    <message>
        <source>You are about to export your database to an unencrypted file. This will leave your passwords and sensitive information vulnerable! Are you sure you want to continue?</source>
        <translation>Du er i ferd med å eksportere databasen til en ukryptert fil. Dette vil gjøre passordene og sensitiv informasjon sårbar! Er du sikker på at du vil fortsette?</translation>
    </message>
    <message>
        <source>%1 [Locked]</source>
        <comment>Database tab name modifier</comment>
        <translation>%1 [Låst]</translation>
    </message>
    <message>
        <source>%1 [Temporary]</source>
        <comment>Database tab name modifier</comment>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>DatabaseWidget</name>
    <message>
        <source>Searches and Tags</source>
        <translation>Søk og tagger</translation>
    </message>
    <message>
        <source>Searching…</source>
        <translation>Søker...</translation>
    </message>
    <message>
        <source>Shared group…</source>
        <translation>Delt gruppe...</translation>
    </message>
    <message>
        <source>Confirm Auto-Type</source>
        <translation>Bekreft autoskriv</translation>
    </message>
    <message>
        <source>Perform Auto-Type into the previously active window?</source>
        <translation>Utføre autoskriv i det tidligere aktive vinduet?</translation>
    </message>
    <message>
        <source>Execute command?</source>
        <translation>Utfør kommando?</translation>
    </message>
    <message>
        <source>Do you really want to execute the following command?&lt;br&gt;&lt;br&gt;%1&lt;br&gt;</source>
        <translation>Ønsker du virkelig å utføre følgende kommando?&lt;br&gt;&lt;br&gt;%1&lt;br&gt;</translation>
    </message>
    <message>
        <source>Remember my choice</source>
        <translation>Husk mitt valg</translation>
    </message>
    <message>
        <source>Do you really want to move the group &quot;%1&quot; to the recycle bin?</source>
        <translation>Vil du virkelig flytte gruppen &quot;%1&quot; til papirkurven?</translation>
    </message>
    <message>
        <source>Expired entries</source>
        <translation>Utløpte oppføringer</translation>
    </message>
    <message numerus="yes">
        <source>Entries expiring within %1 day(s)</source>
        <translation><numerusform>Oppføringer som utløper innen %1 dag</numerusform><numerusform>Oppføringer som utløper innen %1 dager</numerusform></translation>
    </message>
    <message>
        <source>No current database.</source>
        <translation>Ingen nåværende database.</translation>
    </message>
    <message>
        <source>No source database, nothing to do.</source>
        <translation>Ingen kilde-database, ingenting å gjøre.</translation>
    </message>
    <message>
        <source>Search Results (%1)</source>
        <translation>Søkeresultater (%1)</translation>
    </message>
    <message>
        <source>No Results</source>
        <translation>Ingen resultater</translation>
    </message>
    <message>
        <source>Enter a unique name or overwrite an existing search from the list:</source>
        <translation>Skriv inn et unikt navn, eller erstatt et eksisterende søk fra listen:</translation>
    </message>
    <message>
        <source>Save Search</source>
        <translation>Lagre søk</translation>
    </message>
    <message>
        <source>Lock Database?</source>
        <translation>Låse database?</translation>
    </message>
    <message>
        <source>You are editing an entry. Discard changes and lock anyway?</source>
        <translation>Du redigerer en oppføring. Kast endringer og låse likevel?</translation>
    </message>
    <message>
        <source>&quot;%1&quot; was modified.
Save changes?</source>
        <translation>&quot;%1&quot; er endet.
Lagre endringer?</translation>
    </message>
    <message>
        <source>Database was modified.
Save changes?</source>
        <translation>Database ble endret.
Lagre endringer?</translation>
    </message>
    <message>
        <source>Save changes?</source>
        <translation>Lagre endringer?</translation>
    </message>
    <message>
        <source>File has changed</source>
        <translation>Fil er endret</translation>
    </message>
    <message>
        <source>Disable safe saves?</source>
        <translation>Deaktivere sikker lagring?</translation>
    </message>
    <message>
        <source>KeePassXC has failed to save the database multiple times. This is likely caused by file sync services holding a lock on the save file.
Disable safe saves and try again?</source>
        <translation>KeePassXC har mislykkes i å lagre databasen flere ganger. Dette er trolig forårsaket av at synkroniserings-tjenester har låst lagrings-filen.
Deaktivere sikker lagring og prøve igjen?</translation>
    </message>
    <message>
        <source>Writing the database failed: %1</source>
        <translation>Skriving til databasen mislyktes: %1</translation>
    </message>
    <message>
        <source>Passwords</source>
        <translation>Passord</translation>
    </message>
    <message>
        <source>Save database as</source>
        <translation>Lagre database som</translation>
    </message>
    <message>
        <source>KeePass 2 Database</source>
        <translation>KeePass2-database</translation>
    </message>
    <message>
        <source>Empty recycle bin?</source>
        <translation>Tømme papirkurven?</translation>
    </message>
    <message>
        <source>Are you sure you want to permanently delete everything from your recycle bin?</source>
        <translation>Er du sikker på at du ønsker å permanent slette hele papirkurven?</translation>
    </message>
    <message>
        <source>Could not find database file: %1</source>
        <translation>Kunne ikke finne databasefil: %1</translation>
    </message>
    <message>
        <source>New Database</source>
        <translation>Ny database</translation>
    </message>
    <message>
        <source>%1 [New Database]</source>
        <comment>Database tab name modifier</comment>
        <translation>%1 [Ny Database]</translation>
    </message>
    <message>
        <source>Remote Sync did not contain any download or upload commands.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Remote sync &apos;%1&apos; completed successfully!</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Downloading...</source>
        <translation>Laster ned...</translation>
    </message>
    <message>
        <source>Uploading...</source>
        <translation>Laster opp...</translation>
    </message>
    <message>
        <source>Remote sync &apos;%1&apos; failed: %2</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Syncing...</source>
        <translation>Synkroniserer...</translation>
    </message>
    <message>
        <source>Error while saving database %1: %2</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Remove passkey from entry</source>
        <translation>Fjern tilgangsnøkkel fra oppføringen</translation>
    </message>
    <message>
        <source>Do you want to remove the passkey from this entry?</source>
        <translation>Vil du fjerne tilgangsnøkkelen fra denne oppføringen?</translation>
    </message>
    <message>
        <source>The database file &quot;%1&quot; was modified externally</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Do you want to load the changes?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Reloading database…</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Reload canceled</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Reload successful</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Reload pending user action…</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>The database file &quot;%1&quot; was modified externally.&lt;br&gt;How would you like to proceed?&lt;br&gt;&lt;br&gt;Merge all changes&lt;br&gt;Ignore the changes on disk until save&lt;br&gt;Discard unsaved changes</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>The database file &quot;%1&quot; was modified externally.&lt;br&gt;How would you like to proceed?&lt;br&gt;&lt;br&gt;Merge all changes then save&lt;br&gt;Overwrite the changes on disk&lt;br&gt;Discard unsaved changes</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Reload database</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Database file overwritten.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Database file on disk cannot be unlocked with current credentials.&lt;br&gt;Enter new credentials and/or present hardware key to continue.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Failed to save backup database: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Confirm Delete Group</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Do you really want to permanently delete the group &quot;%1&quot;?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Confirm Recycle Group</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Save</source>
        <translation>Lagre</translation>
    </message>
    <message>
        <source>Save Database Backup</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Successfully merged the selected database.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>No changes were made by the merge operation.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Merge canceled, no changes were made.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>EditEntryAttachmentsDialog</name>
    <message>
        <source>Edit: %1</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>EditEntryWidget</name>
    <message>
        <source>Entry</source>
        <translation>Oppføring</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>Avansert</translation>
    </message>
    <message>
        <source>Icon</source>
        <translation>Ikon</translation>
    </message>
    <message>
        <source>Auto-Type</source>
        <translation>Autoskriv</translation>
    </message>
    <message>
        <source>Browser Integration</source>
        <translation>Nettlesertillegg</translation>
    </message>
    <message>
        <source>&lt;empty URL&gt;</source>
        <translation>&lt;empty URL&gt;</translation>
    </message>
    <message>
        <source>Confirm Removal</source>
        <translation>Bekreft fjerning</translation>
    </message>
    <message>
        <source>Are you sure you want to remove this URL?</source>
        <translation>Er du sikker på at du vil fjerne denne URL-en?</translation>
    </message>
    <message>
        <source>Properties</source>
        <translation>Egenskaper</translation>
    </message>
    <message>
        <source>History</source>
        <translation>Historie</translation>
    </message>
    <message>
        <source>SSH Agent</source>
        <translation>SSH-agent</translation>
    </message>
    <message>
        <source>n/a</source>
        <translation>i/a</translation>
    </message>
    <message>
        <source>Select private key</source>
        <translation>Velg privat nøkkel</translation>
    </message>
    <message>
        <source>Entry history</source>
        <translation>Oppføringshistorikk</translation>
    </message>
    <message>
        <source>Add entry</source>
        <translation>Legg til oppføring</translation>
    </message>
    <message>
        <source>Edit entry</source>
        <translation>Rediger oppføring</translation>
    </message>
    <message>
        <source>Some Browser Integration settings are overridden by group settings.</source>
        <translation>Noen innstillinger for nettleserintegrering overstyres av gruppeinnstillinger.</translation>
    </message>
    <message>
        <source>Invalid Entry</source>
        <translation>Ugyldig oppføring</translation>
    </message>
    <message>
        <source>An external merge operation has invalidated this entry.
Unfortunately, any changes made have been lost.</source>
        <translation>En ekstern fletteoperasjon har gjort denne oppføringen ugyldig.
Dessverre har eventuelle endringer gått tapt.</translation>
    </message>
    <message>
        <source>Auto-Type Validation Error</source>
        <translation>Autoskriv gyldighetskontroll feilet</translation>
    </message>
    <message>
        <source>An error occurred while validating the custom Auto-Type sequence:
%1
Would you like to correct it?</source>
        <translation>En feil oppstod ved gyldighetskontroll av den egendefinerte autoskriv-rekkefølgen:
%1
Vil du rette den?</translation>
    </message>
    <message>
        <source>An error occurred while validating the Auto-Type sequence for &quot;%1&quot;:
%2
Would you like to correct it?</source>
        <translation>En feil oppstod ved gyldighetskontroll av autoskriv-rekkefølgen til %1:
%2
Vil du rette den?</translation>
    </message>
    <message>
        <source>Entry updated successfully.</source>
        <translation>Oppføring oppdatert.</translation>
    </message>
    <message>
        <source>Unsaved Changes</source>
        <translation>Endringer som ikke er lagret</translation>
    </message>
    <message>
        <source>Would you like to save changes to this entry?</source>
        <translation>Vil du lagre endringer i denne oppføringen?</translation>
    </message>
    <message>
        <source>New attribute</source>
        <translation>Ny attributt</translation>
    </message>
    <message>
        <source>New attribute %1</source>
        <translation>Nytt attributt %1</translation>
    </message>
    <message>
        <source>Are you sure you want to remove this attribute?</source>
        <translation>Er du sikker på at du ønsker å fjerne dette attributtet?</translation>
    </message>
    <message>
        <source>Reveal</source>
        <translation>Vis</translation>
    </message>
    <message>
        <source>[PROTECTED] Press Reveal to view or edit</source>
        <translation>[BESKYTTET] Trykk &apos;Vis&apos; for å vise eller endre</translation>
    </message>
    <message>
        <source>Hide</source>
        <translation>Skjul</translation>
    </message>
    <message numerus="yes">
        <source>%n hour(s)</source>
        <translation><numerusform>%n time</numerusform><numerusform>%n timer</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>%n week(s)</source>
        <translation><numerusform>%n uke(r)</numerusform><numerusform>%n uke(r)</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>%n month(s)</source>
        <translation><numerusform>%n måned(er)</numerusform><numerusform>%n måned(er)</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>%n year(s)</source>
        <translation><numerusform>%n år</numerusform><numerusform>%n år</numerusform></translation>
    </message>
    <message>
        <source>Failed to decrypt SSH key, ensure password is correct.</source>
        <translation>Kunne ikke dekryptere SSH-nøkkelen. Sørg for at passordet er korrekt.</translation>
    </message>
</context>
<context>
    <name>EditEntryWidgetAdvanced</name>
    <message>
        <source>Additional attributes</source>
        <translation>Ekstra attributter</translation>
    </message>
    <message>
        <source>Attribute selection</source>
        <translation>Attributtvalg</translation>
    </message>
    <message>
        <source>Attribute value</source>
        <translation>Attributtverdi</translation>
    </message>
    <message>
        <source>Add a new attribute</source>
        <translation>Legg til et nytt attributt</translation>
    </message>
    <message>
        <source>Add</source>
        <translation>Legg til</translation>
    </message>
    <message>
        <source>Remove selected attribute</source>
        <translation>Fjern valgt attributt</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Fjern</translation>
    </message>
    <message>
        <source>Edit attribute name</source>
        <translation>Endre attributtnavn</translation>
    </message>
    <message>
        <source>Edit Name</source>
        <translation>Rediger navn</translation>
    </message>
    <message>
        <source>Toggle attribute protection</source>
        <translation>Attributtbeskyttelse på/av</translation>
    </message>
    <message>
        <source>Protect</source>
        <translation>Beskytt</translation>
    </message>
    <message>
        <source>Show a protected attribute</source>
        <translation>Vis et beskyttet attributt</translation>
    </message>
    <message>
        <source>Reveal</source>
        <translation>Vis</translation>
    </message>
    <message>
        <source>Attachments</source>
        <translation>Vedlegg</translation>
    </message>
    <message>
        <source>If checked, the entry will not appear in reports like Health Check and HIBP even if it doesn&apos;t match the quality requirements.</source>
        <translation>Hvis det er merket av for dette alternativet, vises ikke oppføringen i rapporter som «Tilstandskontroll» og «HIBP» selv om den ikke samsvarer med kvalitetskravene.</translation>
    </message>
    <message>
        <source>Exclude from database reports</source>
        <translation>Utelat fra databaserapporter</translation>
    </message>
    <message>
        <source>Foreground Color:</source>
        <translation>Forgrunnsfarge:</translation>
    </message>
    <message>
        <source>Foreground color selection</source>
        <translation>Valg av forgrunnsfarge</translation>
    </message>
    <message>
        <source>Background Color:</source>
        <translation>Bakgrunnsfarge:</translation>
    </message>
    <message>
        <source>Background color selection</source>
        <translation>Valg av bakgrunnsfarge</translation>
    </message>
</context>
<context>
    <name>EditEntryWidgetAutoType</name>
    <message>
        <source>Enable Auto-Type for this entry</source>
        <translation>Aktiver autoskriv for denne oppføringa</translation>
    </message>
    <message>
        <source>Inherit default Auto-Type sequence from the group</source>
        <translation>Arv standard autoskriv-rekkefølge fra gruppen</translation>
    </message>
    <message>
        <source>Use custom Auto-Type sequence:</source>
        <translation>Bruk egendefinert autoskriv-rekkefølge:</translation>
    </message>
    <message>
        <source>Custom Auto-Type sequence</source>
        <translation>Egendefinert autoskriv-rekkefølge</translation>
    </message>
    <message>
        <source>Open Auto-Type help webpage</source>
        <translation>Åpne web-hjelpeside for autoskriv</translation>
    </message>
    <message>
        <source>Window Associations</source>
        <translation>Vindustilknytninger</translation>
    </message>
    <message>
        <source>Existing window associations</source>
        <translation>Eksisterende vindustilknytninger</translation>
    </message>
    <message>
        <source>Add new window association</source>
        <translation>Legg til ny vindustilknytning</translation>
    </message>
    <message>
        <source>+</source>
        <comment>Add item</comment>
        <translation>+</translation>
    </message>
    <message>
        <source>Remove selected window association</source>
        <translation>Fjern valgte vindustilknytning</translation>
    </message>
    <message>
        <source>-</source>
        <comment>Remove item</comment>
        <translation>-</translation>
    </message>
    <message>
        <source>Window title:</source>
        <translation>Vindustittel:</translation>
    </message>
    <message>
        <source>You can use an asterisk (*) to match everything</source>
        <translation>Du kan bruke en stjerne (*) for å matche alt</translation>
    </message>
    <message>
        <source>Set the window association title</source>
        <translation>Angi tittel på vindustilknytning</translation>
    </message>
    <message>
        <source>You can use an asterisk to match everything</source>
        <translation>Du kan bruke en stjerne for å matche alt</translation>
    </message>
    <message>
        <source>Use a specific sequence for this association:</source>
        <translation>Bruk en spesiell sekvens for denne tilknytningen:</translation>
    </message>
    <message>
        <source>Custom Auto-Type sequence for this window</source>
        <translation>Egendefinert autoskriv-rekkefølge for dette vinduet</translation>
    </message>
</context>
<context>
    <name>EditEntryWidgetBrowser</name>
    <message>
        <source>General</source>
        <translation>Generelt</translation>
    </message>
    <message>
        <source>Hide this entry from the browser extension</source>
        <translation>Skjul denne oppføringen for nettleserutvidelsen</translation>
    </message>
    <message>
        <source>Skip Auto-Submit for this entry</source>
        <translation>Hopp over auto-sending for denne oppføringen</translation>
    </message>
    <message>
        <source>Use this entry only with HTTP Basic Auth</source>
        <translation>Bruk denne oppføringen bare til «HTTP Basic Auth»</translation>
    </message>
    <message>
        <source>Do not use this entry with HTTP Basic Auth</source>
        <translation>Ikke bruk denne oppføringen til «HTTP Basic Auth»</translation>
    </message>
    <message>
        <source>Add</source>
        <translation>Legg til</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Fjern</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Endre</translation>
    </message>
    <message>
        <source>These settings affect the entry&apos;s behaviour with the browser extension.</source>
        <translation>Disse innstillingene påvirker oppføringens atferd med nettleserutvidelsen.</translation>
    </message>
    <message>
        <source>Additional URLs</source>
        <translation>Ytterligere URL-er</translation>
    </message>
    <message>
        <source>Only send this entry to the browser for HTTP Auth dialogs. If enabled, normal login forms will not show this entry for selection.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Do not send this entry to the browser for HTTP Auth dialogs. If enabled, HTTP Auth dialogs will not show this entry for selection.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>EditEntryWidgetHistory</name>
    <message>
        <source>Entry history selection</source>
        <translation>Valg av oppføringshistorikk</translation>
    </message>
    <message>
        <source>Show entry at selected history state</source>
        <translation>Vis oppføring ved valgt historikkelement</translation>
    </message>
    <message>
        <source>Show</source>
        <translation>Vis</translation>
    </message>
    <message>
        <source>Restore entry to selected history state</source>
        <translation>Gjenopprett oppføring til valgte historikkelement</translation>
    </message>
    <message>
        <source>Restore</source>
        <translation>Gjenopprett</translation>
    </message>
    <message>
        <source>Delete selected history state</source>
        <translation>Slett valgt historikkelement</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Slett</translation>
    </message>
    <message>
        <source>Delete all history</source>
        <translation>Slett all historikk</translation>
    </message>
    <message>
        <source>Delete all</source>
        <translation>Slett alt</translation>
    </message>
</context>
<context>
    <name>EditEntryWidgetMain</name>
    <message>
        <source>Edit Entry</source>
        <translation>Endre oppføring</translation>
    </message>
    <message>
        <source>Notes field</source>
        <translation>Notater-felt</translation>
    </message>
    <message>
        <source>Username field</source>
        <translation>Brukernavn-felt</translation>
    </message>
    <message>
        <source>Expiration field</source>
        <translation>Utløpsfelt</translation>
    </message>
    <message>
        <source>Expiration Presets</source>
        <translation>Forhåndsinnstillinger for utløp</translation>
    </message>
    <message>
        <source>Expiration presets</source>
        <translation>Forhåndsinnstillinger for utløp</translation>
    </message>
    <message>
        <source>Presets</source>
        <translation>Hurtigvalg</translation>
    </message>
    <message>
        <source>Url field</source>
        <translation>URL-felt</translation>
    </message>
    <message>
        <source>Download favicon for URL</source>
        <translation>Last ned nettstedsikon for URL</translation>
    </message>
    <message>
        <source>Title field</source>
        <translation>Tittel-felt</translation>
    </message>
    <message>
        <source>Password field</source>
        <translation>Passord felt</translation>
    </message>
    <message>
        <source>Toggle expiration</source>
        <translation>Aktivere/deaktivere utløpsdato og -tid.</translation>
    </message>
    <message>
        <source>Tags list</source>
        <translation>Taggeliste</translation>
    </message>
    <message>
        <source>&amp;Username:</source>
        <translation>&amp;Brukernavn:</translation>
    </message>
    <message>
        <source>&amp;Title:</source>
        <translation>&amp;Tittel:</translation>
    </message>
    <message>
        <source>&amp;Password:</source>
        <translation>&amp;Passord:</translation>
    </message>
    <message>
        <source>UR&amp;L:</source>
        <translation>UR&amp;L:</translation>
    </message>
    <message>
        <source>&amp;Notes:</source>
        <translation>&amp;Notater:</translation>
    </message>
    <message>
        <source>Toggle notes visibility</source>
        <translation>Vis/skjul synlige notater</translation>
    </message>
    <message>
        <source>T&amp;ags:</source>
        <translation>T&amp;agger:</translation>
    </message>
    <message>
        <source>&amp;Expires:</source>
        <translation>&amp;Utløper:</translation>
    </message>
</context>
<context>
    <name>EditEntryWidgetSSHAgent</name>
    <message>
        <source>Form</source>
        <translation>Skjema</translation>
    </message>
    <message>
        <source>Remove key from agent when database is closed/locked</source>
        <translation>Fjern nøkkel fra agent når databasen blir lukket/låst</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>Kommentar</translation>
    </message>
    <message>
        <source>Add key to agent when database is opened/unlocked</source>
        <translation>Legg nøkkel til agent når databasen blir åpnet/opplåst</translation>
    </message>
    <message>
        <source>Decrypt</source>
        <translation>Dekrypter</translation>
    </message>
    <message>
        <source>Fingerprint</source>
        <translation>Fingeravtrykk</translation>
    </message>
    <message>
        <source>Copy to clipboard</source>
        <translation>Kopier til utklippstavle</translation>
    </message>
    <message>
        <source>Public key</source>
        <translation>Offentlig nøkkel</translation>
    </message>
    <message>
        <source>Private key</source>
        <translation>Privat nøkkel</translation>
    </message>
    <message>
        <source>Attachment</source>
        <translation>Vedlegg</translation>
    </message>
    <message>
        <source>External key file</source>
        <translation>Ekstern nøkkelfil</translation>
    </message>
    <message>
        <source>Add to agent</source>
        <translation>Legg til til agent</translation>
    </message>
    <message>
        <source>Remove from agent</source>
        <translation>Fjern fra agent</translation>
    </message>
    <message>
        <source>External file</source>
        <translation>Ekstern fil</translation>
    </message>
    <message>
        <source>Browser for key file</source>
        <translation>Netteser for nøkkelfil</translation>
    </message>
    <message>
        <source>Browse…</source>
        <extracomment>Button for opening file dialog</extracomment>
        <translation>Bla gjennom...</translation>
    </message>
    <message>
        <source>Generate</source>
        <translation>Opprett</translation>
    </message>
    <message>
        <source>Select attachment file</source>
        <translation>Velg vedleggsfil</translation>
    </message>
    <message>
        <source>Require user confirmation when this key is used</source>
        <translation>Krev brukerbekreftelse når denne nøkkelen blir brukt</translation>
    </message>
    <message>
        <source>n/a</source>
        <translation>i/a</translation>
    </message>
    <message>
        <source>Remove key from agent after</source>
        <translation>Fjern nøkkel fra agent etter</translation>
    </message>
    <message>
        <source>Remove key from agent after specified seconds</source>
        <translation>Fjern nøkkel fra agent etter angitte sekunder</translation>
    </message>
    <message>
        <source> seconds</source>
        <translation>sekunder</translation>
    </message>
    <message>
        <source>Clear agent</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>EditGroupWidget</name>
    <message>
        <source>Group</source>
        <translation>Gruppe</translation>
    </message>
    <message>
        <source>Icon</source>
        <translation>Ikon</translation>
    </message>
    <message>
        <source>Properties</source>
        <translation>Egenskaper</translation>
    </message>
    <message>
        <source>Add group</source>
        <translation>Lag ny gruppe</translation>
    </message>
    <message>
        <source>Edit group</source>
        <translation>Rediger gruppe</translation>
    </message>
    <message>
        <source>Group has unsaved changes</source>
        <translation>Gruppen har ulagrede endringer</translation>
    </message>
    <message>
        <source>Browser Integration</source>
        <translation>Nettlesertillegg</translation>
    </message>
    <message>
        <source>Enable</source>
        <translation>Aktiver</translation>
    </message>
    <message>
        <source>Disable</source>
        <translation>Deaktiver</translation>
    </message>
    <message>
        <source>Inherit from parent group (%1)</source>
        <translation>Arv fra foreldre-gruppe (%1)</translation>
    </message>
</context>
<context>
    <name>EditGroupWidgetBrowser</name>
    <message>
        <source>These settings affect to the group&apos;s behaviour with the browser extension.</source>
        <translation>Disse innstillingene påvirker oppføringens funksjon mot nettleserutvidelsen.</translation>
    </message>
    <message>
        <source>Hide entries from browser extension:</source>
        <translation>Skjul oppføringer fra nettleserutvidelse:</translation>
    </message>
    <message>
        <source>Hide entries from browser extension toggle for this and sub groups</source>
        <translation>Skjul oppføringer fra nettleserutvidelse for denne og undergrupper</translation>
    </message>
    <message>
        <source>Skip Auto-Submit for entries:</source>
        <translation>Hopp over automatisk sending for oppføringer:</translation>
    </message>
    <message>
        <source>Skip Auto-Submit toggle for this and sub groups</source>
        <translation>Veksleknapp for hopp over automatisk sending for denne og undergrupper</translation>
    </message>
    <message>
        <source>Use entries only with HTTP Basic Auth:</source>
        <translation>Bruk oppføringer bare med &quot;HTTP Basic Auth&quot;:</translation>
    </message>
    <message>
        <source>Only HTTP Auth toggle for this and sub groups</source>
        <translation>Veksleknapp for bare HTTP Auth for denne og undergrupper</translation>
    </message>
    <message>
        <source>Do not use entries with HTTP Basic Auth:</source>
        <translation>Ikke bruk oppføringer med &quot;HTTP Basic Auth&quot;:</translation>
    </message>
    <message>
        <source>Do not use HTTP Auth toggle for this and sub groups</source>
        <translation>Veksleknapp for ikke bruk &quot;HTTP Auth&quot; for denne og undergrupper</translation>
    </message>
    <message>
        <source>Omit WWW subdomain from matching:</source>
        <translation>Utelat www-underdomene fra matching:</translation>
    </message>
    <message>
        <source>Omit WWW subdomain from matching toggle for this and sub groups</source>
        <translation>Vis/skjul utelat www-underdomene fra matching for denne og undergrupper</translation>
    </message>
    <message>
        <source>Restrict matching to given browser key:</source>
        <translation>Begrens match til oppgitt nettlesernøkkel:</translation>
    </message>
    <message>
        <source>Restrict matching to given browser key toggle for this and sub groups</source>
        <translation>Aktiver/deaktiver begrens match til oppgitt nettlesernøkkel for denne og undergrupper</translation>
    </message>
</context>
<context>
    <name>EditGroupWidgetKeeShare</name>
    <message>
        <source>Sharing mode field</source>
        <translation>Felt for delingsmodus</translation>
    </message>
    <message>
        <source>Password field</source>
        <translation>Passord felt</translation>
    </message>
    <message>
        <source>Type:</source>
        <translation>Type:</translation>
    </message>
    <message>
        <source>Password:</source>
        <translation>Passord:</translation>
    </message>
    <message>
        <source>Path:</source>
        <translation>Sti:</translation>
    </message>
    <message>
        <source>Path to share file field</source>
        <translation>Felt for sti til delt fil</translation>
    </message>
    <message>
        <source>Browse for share file</source>
        <translation>Søk etter delt fil</translation>
    </message>
    <message>
        <source>Browse…</source>
        <translation>Bla gjennom...</translation>
    </message>
    <message>
        <source>Clear fields</source>
        <translation>Tøm felt</translation>
    </message>
    <message>
        <source>Clear</source>
        <translation>Tøm</translation>
    </message>
    <message>
        <source>Inactive</source>
        <translation>Inaktiv</translation>
    </message>
    <message>
        <source>Import</source>
        <translation>Importer</translation>
    </message>
    <message>
        <source>Export</source>
        <translation>Eksporter</translation>
    </message>
    <message>
        <source>Synchronize</source>
        <translation>Synkronisér</translation>
    </message>
    <message>
        <source>Your KeePassXC version does not support sharing this container type.
Supported extensions are: %1.</source>
        <translation>KeePassXC-versjonen din støtter ikke deling av denne beholdertypen.
Støttede utvidelser er: %1.</translation>
    </message>
    <message>
        <source>%1 is already being exported by this database.</source>
        <translation>%1 eksporteres allerede av denne databasen.</translation>
    </message>
    <message>
        <source>%1 is already being imported by this database.</source>
        <translation>%1 importeres allerede av denne databasen.</translation>
    </message>
    <message>
        <source>%1 is being imported and exported by different groups in this database.</source>
        <translation>%1 importeres og eksporteres av forskjellige grupper i denne databasen.</translation>
    </message>
    <message>
        <source>KeeShare is currently disabled. You can enable import/export in the application settings.</source>
        <comment>KeeShare is a proper noun</comment>
        <translation>KeeShare er for øyeblikket deaktivert. Du kan aktivere import/eksport i programinnstillingene.</translation>
    </message>
    <message>
        <source>Database export is currently disabled by application settings.</source>
        <translation>Databaseeksport er for øyeblikket deaktivert av programinnstillinger.</translation>
    </message>
    <message>
        <source>Database import is currently disabled by application settings.</source>
        <translation>Databaseimport er for øyeblikket deaktivert av programinnstillinger.</translation>
    </message>
    <message>
        <source>KeeShare container</source>
        <translation>KeeShare-container</translation>
    </message>
    <message>
        <source>KeeShare signed container</source>
        <translation>KeeShare signert beholder</translation>
    </message>
    <message>
        <source>Select import source</source>
        <translation>Velg kilde for importering</translation>
    </message>
    <message>
        <source>Select export target</source>
        <translation>Velg eksporteringsmål</translation>
    </message>
    <message>
        <source>Select import/export file</source>
        <translation>Velg fil for import/eksport</translation>
    </message>
    <message>
        <source>Maintain group structure with shared database</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Keep Group Structure</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>EditGroupWidgetMain</name>
    <message>
        <source>Edit Group</source>
        <translation>Endre gruppe</translation>
    </message>
    <message>
        <source>Toggle expiration</source>
        <translation>Aktivere/deaktivere utløpsdato og -tid.</translation>
    </message>
    <message>
        <source>Expires:</source>
        <translation>Utløper:</translation>
    </message>
    <message>
        <source>Name field</source>
        <translation>Navn-felt</translation>
    </message>
    <message>
        <source>Expiration field</source>
        <translation>Utløpsfelt</translation>
    </message>
    <message>
        <source>Use default Auto-Type sequence of parent group</source>
        <translation>Bruk standard autoskriv-rekkefølge for overordnet gruppe</translation>
    </message>
    <message>
        <source>Auto-Type:</source>
        <translation>Autoskriv:</translation>
    </message>
    <message>
        <source>Search:</source>
        <translation>Søke:</translation>
    </message>
    <message>
        <source>Auto-Type toggle for this and sub groups</source>
        <translation>Veksle mellom autoskriv for denne og undergrupper</translation>
    </message>
    <message>
        <source>Notes:</source>
        <translation>Notater:</translation>
    </message>
    <message>
        <source>Default auto-type sequence field</source>
        <translation>Felt for standard autoskriv-rekkefølge</translation>
    </message>
    <message>
        <source>Notes field</source>
        <translation>Notater-felt</translation>
    </message>
    <message>
        <source>Name:</source>
        <translation>Navn:</translation>
    </message>
    <message>
        <source>Set default Auto-Type sequence</source>
        <translation>Angi standard autoskriv-rekkefølge</translation>
    </message>
    <message>
        <source>Search toggle for this and sub groups</source>
        <translation>Søkeknapp for denne og undergrupper</translation>
    </message>
</context>
<context>
    <name>EditWidgetIcons</name>
    <message>
        <source>Use default icon</source>
        <translation>Bruk standardikon</translation>
    </message>
    <message>
        <source>Use custom icon</source>
        <translation>Bruk egendefinert ikon</translation>
    </message>
    <message>
        <source>Choose icon…</source>
        <translation>Velg ikon…</translation>
    </message>
    <message>
        <source>Set the URL to use to search for a favicon</source>
        <translation>Angi URL som skal brukes til å søke etter et nettstedsikon</translation>
    </message>
    <message>
        <source>Favicon URL</source>
        <translation>Nettstedsikon URL</translation>
    </message>
    <message>
        <source>Download favicon for URL</source>
        <translation>Last ned nettstedsikon for URL</translation>
    </message>
    <message>
        <source>Download favicon</source>
        <translation>Last ned nettstedsikon</translation>
    </message>
    <message>
        <source>Apply selected icon to subgroups and entries</source>
        <translation>Bruk valgt ikon på undergrupper og oppføringer</translation>
    </message>
    <message>
        <source>Apply icon to…</source>
        <translation>Bruk ikon på...</translation>
    </message>
    <message>
        <source>Apply to this group only</source>
        <translation>Bruk bare på denne gruppen</translation>
    </message>
    <message>
        <source>Also apply to child groups</source>
        <translation>Gjelder også for underordnede grupper</translation>
    </message>
    <message>
        <source>Also apply to child entries</source>
        <translation>Bruk også på underordnede oppføringer</translation>
    </message>
    <message>
        <source>Also apply to all children</source>
        <translation>Gjelder også for alle barn</translation>
    </message>
    <message>
        <source>Unable to fetch favicon.</source>
        <translation>Kan ikke hente nettstedsikon.</translation>
    </message>
    <message>
        <source>Existing icon selected.</source>
        <translation>Eksisterende ikon er valgt.</translation>
    </message>
    <message>
        <source>Images</source>
        <translation>Bilder</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>Alle filer</translation>
    </message>
    <message>
        <source>Select Image(s)</source>
        <translation>Velg Bilde(-r)</translation>
    </message>
    <message numerus="yes">
        <source>Successfully loaded %1 of %n icon(s)</source>
        <translation><numerusform>Lastet inn %1 av %n ikon</numerusform><numerusform>Lastet inn %1 av %n ikoner</numerusform></translation>
    </message>
    <message>
        <source>No icons were loaded</source>
        <translation>Ingen ikoner ble lastet</translation>
    </message>
    <message numerus="yes">
        <source>%n icon(s) already exist in the database</source>
        <translation><numerusform>%n ikon finnes allerede i databasen</numerusform><numerusform>%n ikoner finnes allerede i databasen</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>The following icon(s) failed:</source>
        <translation><numerusform>Følgende ikon mislyktes:</numerusform><numerusform>Følgende ikoner mislyktes:</numerusform></translation>
    </message>
    <message>
        <source>You can enable the DuckDuckGo website icon service under Application Settings -&gt; Security</source>
        <translation>Du kan aktivere DuckDuckGo-nettstedsikontjenesten under Programinnstillinger -&gt; Sikkerhet</translation>
    </message>
</context>
<context>
    <name>EditWidgetProperties</name>
    <message>
        <source>Created:</source>
        <translation>Opprettet:</translation>
    </message>
    <message>
        <source>Datetime created</source>
        <translation>Datotid opprettet</translation>
    </message>
    <message>
        <source>Modified:</source>
        <translation>Endret:</translation>
    </message>
    <message>
        <source>Datetime modified</source>
        <translation>Datotid endret</translation>
    </message>
    <message>
        <source>Uuid:</source>
        <translation>Uuid:</translation>
    </message>
    <message>
        <source>Unique ID</source>
        <translation>Unik ID</translation>
    </message>
    <message>
        <source>Plugin Data</source>
        <translation>Data for programtillegg</translation>
    </message>
    <message>
        <source>Plugin data</source>
        <translation>Plugg inn-data</translation>
    </message>
    <message>
        <source>Remove selected plugin data</source>
        <translation>Fjern valgte plugg inn-data</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Fjern</translation>
    </message>
    <message>
        <source>Delete plugin data?</source>
        <translation>Slett programtillegg-data?</translation>
    </message>
    <message>
        <source>Do you really want to delete the selected plugin data?
This may cause the affected plugins to malfunction.</source>
        <translation>Ønsker du virkelig å slette de valgte programtillegg-dataene?
Dette kan føre til feil for de berørte programtilleggene.</translation>
    </message>
    <message>
        <source>Key</source>
        <translation>Nøkkel</translation>
    </message>
    <message>
        <source>Value</source>
        <translation>Verdi</translation>
    </message>
</context>
<context>
    <name>Entry</name>
    <message>
        <source>%1 - Clone</source>
        <translation>%1 - Klone</translation>
    </message>
    <message>
        <source>Passkey</source>
        <translation>Tilgangsnøkkel</translation>
    </message>
    <message>
        <source>Invalid conversion type: %1</source>
        <translation>Ugyldig konverteringstype: %1</translation>
    </message>
    <message>
        <source>Invalid conversion syntax: %1</source>
        <translation>Ugyldig konverteringssyntaks: %1</translation>
    </message>
    <message>
        <source>Invalid regular expression syntax %1
%2</source>
        <translation>Ugyldig syntaks for regulært uttrykk %1
%2</translation>
    </message>
    <message>
        <source>Title</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Username</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Password</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>URL</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Notes</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Custom Attributes</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Icon</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Color</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Expiration</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>TOTP</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Custom Data</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Attachments</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Auto-Type</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Tags</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>EntryAttachments</name>
    <message>
        <source>Cannot open file &quot;%1&quot;</source>
        <translation>Kan ikke åpne filen %1</translation>
    </message>
</context>
<context>
    <name>EntryAttachmentsModel</name>
    <message>
        <source>Name</source>
        <translation>Navn</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Størrelse</translation>
    </message>
</context>
<context>
    <name>EntryAttachmentsWidget</name>
    <message>
        <source>Form</source>
        <translation>Skjema</translation>
    </message>
    <message>
        <source>Attachments</source>
        <translation>Vedlegg</translation>
    </message>
    <message>
        <source>Add new attachment</source>
        <translation>Legg til nytt vedlegg</translation>
    </message>
    <message>
        <source>Remove selected attachment</source>
        <translation>Fjern valgt vedlegg</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Fjern</translation>
    </message>
    <message>
        <source>Open selected attachment</source>
        <translation>Åpne valgt vedlegg</translation>
    </message>
    <message>
        <source>Open</source>
        <translation>Åpne</translation>
    </message>
    <message>
        <source>Save selected attachment to disk</source>
        <translation>Lagre valgt vedlegg til disk</translation>
    </message>
    <message>
        <source>Select files</source>
        <translation>Velg filer</translation>
    </message>
    <message>
        <source>Confirm remove</source>
        <translation>Bekreft fjerning</translation>
    </message>
    <message numerus="yes">
        <source>Are you sure you want to remove %n attachment(s)?</source>
        <translation><numerusform>Er du sikker på at du vil fjerne %n vedlegg?</numerusform><numerusform>Er du sikker på at du vil fjerne %n vedlegg?</numerusform></translation>
    </message>
    <message>
        <source>Save attachments</source>
        <translation>Lagre vedlegg</translation>
    </message>
    <message>
        <source>Unable to create directory:
%1</source>
        <translation>Kan ikke opprette katalog:
%1</translation>
    </message>
    <message>
        <source>Are you sure you want to overwrite the existing file &quot;%1&quot; with the attachment?</source>
        <translation>Er du sikker på at du ønsker å overskrive eksisterende fil &quot;%1&quot; med vedlegget?</translation>
    </message>
    <message>
        <source>Confirm overwrite</source>
        <translation>Bekreft overskriving</translation>
    </message>
    <message>
        <source>Unable to save attachments:
%1</source>
        <translation>Kan ikke lagre vedlegg:
%1</translation>
    </message>
    <message>
        <source>Unable to open attachment:
%1</source>
        <translation>Kan ikke åpne vedlegg:
%1</translation>
    </message>
    <message>
        <source>Unable to open attachments:
%1</source>
        <translation>Kan ikke åpne vedlegg:
%1</translation>
    </message>
    <message numerus="yes">
        <source>Unable to open file(s):
%1</source>
        <translation><numerusform>Kan ikke åpne fil:
%1</numerusform><numerusform>Kan ikke åpne filene:
%1</numerusform></translation>
    </message>
    <message>
        <source>Confirm Overwrite Attachment</source>
        <translation>Bekreft erstatting av vedlegg</translation>
    </message>
    <message>
        <source>Confirm Attachment</source>
        <translation>Bekreft vedlegg</translation>
    </message>
    <message>
        <source>%1 is a big file (%2 MB).
Your database may get very large and reduce performance.

Are you sure to add this file?</source>
        <translation>%1 er en stor fil (%2 MB).
Databasen kan bli svært stor og redusere ytelsen.

Er du sikker på at du vil legge til denne filen?</translation>
    </message>
    <message>
        <source>Attachment modified</source>
        <translation>Vedlegg endret</translation>
    </message>
    <message>
        <source>The attachment '%1' was modified.
Do you want to save the changes to your database?</source>
        <translation>Vedlegget %1 er endret.
Vil du lagre endringene i databasen?</translation>
    </message>
    <message>
        <source>Saving attachment failed</source>
        <translation>Lagring av vedlegg mislyktes</translation>
    </message>
    <message>
        <source>Saving updated attachment failed.
Error: %1</source>
        <translation>Lagring av oppdatert vedlegg mislyktes.
Feil: %1</translation>
    </message>
    <message>
        <source>Attachment &quot;%1&quot; already exists. 
Would you like to overwrite the existing attachment?</source>
        <translation>Vedlegg %1 finnes allerede. 
Vil du erstatte det eksisterende vedlegget?</translation>
    </message>
    <message>
        <source>Preview</source>
        <translation>Forhåndsvis</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Endre</translation>
    </message>
    <message>
        <source>New Text Document</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Add file…</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Load from Disk…</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Save…</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>New Attachment</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>EntryAttributesModel</name>
    <message>
        <source>Name</source>
        <translation>Navn</translation>
    </message>
</context>
<context>
    <name>EntryHistoryModel</name>
    <message>
        <source>Current (%1)</source>
        <translation>Gjeldende (%1)</translation>
    </message>
    <message>
        <source>Last modified</source>
        <translation>Sist endret</translation>
    </message>
    <message>
        <source>Age</source>
        <translation>Alder</translation>
    </message>
    <message>
        <source>Difference</source>
        <translation>Forskjell</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Størrelse</translation>
    </message>
</context>
<context>
    <name>EntryModel</name>
    <message>
        <source>Ref: </source>
        <comment>Reference abbreviation</comment>
        <translation>Ref:</translation>
    </message>
    <message>
        <source>Never</source>
        <translation>Aldri</translation>
    </message>
    <message>
        <source>Group</source>
        <translation>Gruppe</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>Tittel</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>Brukernavn</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Passord</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>Notes</source>
        <translation>Notater</translation>
    </message>
    <message>
        <source>Expires</source>
        <translation>Utløper</translation>
    </message>
    <message>
        <source>Created</source>
        <translation>Opprettet</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Endret</translation>
    </message>
    <message>
        <source>Attachments</source>
        <translation>Vedlegg</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Størrelse</translation>
    </message>
    <message>
        <source>Group name</source>
        <translation>Navn på gruppe</translation>
    </message>
    <message>
        <source>Entry title</source>
        <translation>Tittel på oppføring</translation>
    </message>
    <message>
        <source>Password Strength</source>
        <translation>Passordstyrke</translation>
    </message>
    <message>
        <source>Entry notes</source>
        <translation>Notater for oppføring</translation>
    </message>
    <message>
        <source>Entry expires at</source>
        <translation>Oppføringen utløper</translation>
    </message>
    <message>
        <source>Creation date</source>
        <translation>Opprettelsesdato</translation>
    </message>
    <message>
        <source>Last modification date</source>
        <translation>Siste endringsdato</translation>
    </message>
    <message>
        <source>Attached files</source>
        <translation>Vedlagte filer</translation>
    </message>
    <message>
        <source>Entry size</source>
        <translation>Størrelse på oppføring</translation>
    </message>
    <message>
        <source>Has attachments</source>
        <translation>Har vedlegg</translation>
    </message>
    <message>
        <source>Has TOTP</source>
        <translation>Har TOTP</translation>
    </message>
    <message>
        <source>Background Color</source>
        <translation>Bakgrunnsfarge</translation>
    </message>
    <message>
        <source>Group Path</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>EntryPreviewWidget</name>
    <message>
        <source>Display current TOTP value</source>
        <translation>Vis gjeldende TOTP-verdi</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Lukk</translation>
    </message>
    <message>
        <source>General</source>
        <translation>Generelt</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Passord</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>Adresse</translation>
    </message>
    <message>
        <source>Expiration</source>
        <translation>Utløp</translation>
    </message>
    <message>
        <source>Tags</source>
        <translation>Tagger</translation>
    </message>
    <message>
        <source>Tags list</source>
        <translation>Taggeliste</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>Brukernavn</translation>
    </message>
    <message>
        <source>Notes</source>
        <translation>Notater</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>Avansert</translation>
    </message>
    <message>
        <source>Attachments</source>
        <translation>Vedlegg</translation>
    </message>
    <message>
        <source>Attributes</source>
        <translation>Attributter</translation>
    </message>
    <message>
        <source>Autotype</source>
        <translation>Autoskriv</translation>
    </message>
    <message>
        <source>Default Sequence</source>
        <translation>Standard rekkefølge</translation>
    </message>
    <message>
        <source>Window</source>
        <translation>Vindu</translation>
    </message>
    <message>
        <source>Sequence</source>
        <translation>Rekkefølge</translation>
    </message>
    <message>
        <source>Searching</source>
        <translation>Søking</translation>
    </message>
    <message>
        <source>Share</source>
        <translation>Del</translation>
    </message>
    <message>
        <source>Search</source>
        <translation>Søk</translation>
    </message>
    <message>
        <source>Clear</source>
        <translation>Tøm</translation>
    </message>
    <message>
        <source>Never</source>
        <translation>Aldri</translation>
    </message>
    <message>
        <source>Double click to copy value</source>
        <translation>Dobbeltklikk for å kopiere verdi</translation>
    </message>
    <message>
        <source>Enabled</source>
        <translation>Aktivert</translation>
    </message>
    <message>
        <source>Disabled</source>
        <translation>Deaktivert</translation>
    </message>
    <message>
        <source>Double click to copy to clipboard</source>
        <translation>Dobbeltklikk for å kopiere til utklippstavlen</translation>
    </message>
</context>
<context>
    <name>EntryURLModel</name>
    <message>
        <source>Invalid URL</source>
        <translation>Ugyldig URL</translation>
    </message>
    <message>
        <source>Duplicate URL</source>
        <translation>Klon URL</translation>
    </message>
</context>
<context>
    <name>EntryView</name>
    <message>
        <source>Fit to window</source>
        <translation>Tilpass til vindu</translation>
    </message>
    <message>
        <source>Fit to contents</source>
        <translation>Tilpass til innhold</translation>
    </message>
    <message>
        <source>Reset to defaults</source>
        <translation>Resett til standardinnstillinger</translation>
    </message>
    <message numerus="yes">
        <source>+ %1 entry(s)...</source>
        <translation><numerusform>+ %1 oppføring…</numerusform><numerusform>+ %1 oppføringer…</numerusform></translation>
    </message>
</context>
<context>
    <name>ExportDialog</name>
    <message>
        <source>Export options</source>
        <translation>Eksportalternativer</translation>
    </message>
    <message>
        <source>Sort entries by...</source>
        <translation>Sorter oppføringer etter…</translation>
    </message>
    <message>
        <source>You are about to export your database to an unencrypted file.
This will leave your passwords and sensitive information vulnerable!
</source>
        <translation>Du er i ferd med å eksportere databasen til en ukryptert fil.
Dette vil gjøre passordene og sensitiv informasjon sårbare!
</translation>
    </message>
    <message>
        <source>database order</source>
        <translation>Databaserekkefølge</translation>
    </message>
    <message>
        <source>name (ascending)</source>
        <translation>navn (stigende)</translation>
    </message>
    <message>
        <source>name (descending)</source>
        <translation>navn (synkende)</translation>
    </message>
    <message>
        <source>Export database to HTML file</source>
        <translation>Eksporter database til HTML-fil</translation>
    </message>
    <message>
        <source>HTML file</source>
        <translation>HTML-fil</translation>
    </message>
    <message>
        <source>invalid sort order</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>FdoSecrets::DBusMgr</name>
    <message>
        <source>Failed to deliver message</source>
        <translation>Kunne ikke levere melding</translation>
    </message>
    <message>
        <source>Failed to send reply on DBus</source>
        <translation>Kunne ikke sende svar på DBus-en</translation>
    </message>
    <message>
        <source>Unknown</source>
        <comment>Unknown PID</comment>
        <translation>Ukjent</translation>
    </message>
    <message>
        <source>Unknown</source>
        <comment>Unknown executable path</comment>
        <translation>Ukjent</translation>
    </message>
    <message>
        <source>&lt;i&gt;PID: %1, Executable: %2&lt;/i&gt;</source>
        <comment>&lt;i&gt;PID: 1234, Executable: /path/to/exe&lt;/i&gt;</comment>
        <translation>&lt;i&gt;PID: %1, kjørbar fil: %2&lt;/i&gt;</translation>
    </message>
    <message>
        <source>Another secret service is running (%1).&lt;br/&gt;Please stop/remove it before re-enabling the Secret Service Integration.</source>
        <translation>En annen «Secret Service» kjører (%1).&lt;br/&gt;Stopp/fjern den før du aktiverer «Secret Service»-integrasjonen på nytt.</translation>
    </message>
    <message>
        <source>Failed to register DBus service at %1.&lt;br/&gt;</source>
        <translation>Kunne ikke registrere DBus-tjenesten på %1.&lt;br/&gt;</translation>
    </message>
    <message>
        <source>Failed to register service on DBus at path &apos;%1&apos;</source>
        <translation>Kunne ikke registrere tjenesten på DBus-en med stien %1</translation>
    </message>
    <message>
        <source>Failed to register database on DBus under the name &apos;%1&apos;</source>
        <translation>Kunne ikke registrere databasen på DBus-en under navnet %1</translation>
    </message>
    <message>
        <source>Failed to register session on DBus at path &apos;%1&apos;</source>
        <translation>Kunne ikke registrere økten på DBus-en med stien %1</translation>
    </message>
    <message>
        <source>Failed to register item on DBus at path &apos;%1&apos;</source>
        <translation>Kunne ikke registrere elementet på DBus-en med stien %1</translation>
    </message>
    <message>
        <source>Failed to register prompt object on DBus at path &apos;%1&apos;</source>
        <translation>Kunne ikke registrere ledetekstobjektet på DBus-en med stien %1</translation>
    </message>
</context>
<context>
    <name>FdoSecrets::Item</name>
    <message>
        <source>Entry &quot;%1&quot; from database &quot;%2&quot; was used by %3</source>
        <translation>Oppføringen &quot;%1&quot; fra database %2 ble brukt av %3</translation>
    </message>
</context>
<context>
    <name>FdoSecrets::Service</name>
    <message numerus="yes">
        <source>%n Entry(s) was used by %1</source>
        <comment>%1 is the name of an application</comment>
        <translation><numerusform>%n Oppføring ble brukt av %1</numerusform><numerusform>%n Oppføringer ble brukt av %1</numerusform></translation>
    </message>
</context>
<context>
    <name>FdoSecrets::SettingsClientModel</name>
    <message>
        <source>Unknown</source>
        <translation>Ukjent</translation>
    </message>
    <message>
        <source>Non-existing/inaccessible executable path. Please double-check the client is legit.</source>
        <translation>Ikke-eksisterende/utilgjengelig kjørbar sti. Dobbeltsjekk om klienten er legitim.</translation>
    </message>
</context>
<context>
    <name>FdoSecrets::SettingsDatabaseModel</name>
    <message>
        <source>Unlock to show</source>
        <translation>Lås opp for å vise</translation>
    </message>
    <message>
        <source>None</source>
        <translation>Ingen</translation>
    </message>
</context>
<context>
    <name>FdoSecrets::UnlockPrompt</name>
    <message>
        <source>%1 (PID: %2)</source>
        <translation>%1 (PID: %2)</translation>
    </message>
</context>
<context>
    <name>FdoSecretsPlugin</name>
    <message>
        <source>&lt;b&gt;Fdo Secret Service:&lt;/b&gt; %1</source>
        <translation>&lt;b&gt;Fdo Secret Service:&lt;/b&gt; %1</translation>
    </message>
</context>
<context>
    <name>GlobalShortcutsPortal</name>
    <message>
        <source>KeePassXC - Global Shortcuts</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>The XDG Desktop Portal for global shortcuts is not available on this system.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Global Auto-Type shortcut is already configured. To change it, open your system settings and navigate to the keyboard or application shortcuts section.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Trigger global Auto-Type</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>Group</name>
    <message>
        <source>[empty]</source>
        <comment>group has no children</comment>
        <translation>[tom]</translation>
    </message>
    <message>
        <source>%1 - Clone</source>
        <translation>%1 - Klone</translation>
    </message>
</context>
<context>
    <name>HibpDownloader</name>
    <message>
        <source>Online password validation failed</source>
        <translation>Online gyldighetskontroll av passord mislyktes</translation>
    </message>
</context>
<context>
    <name>IconDownloaderDialog</name>
    <message>
        <source>Download Favicons</source>
        <translation>Last ned nettstedsikoner</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Avbryt</translation>
    </message>
    <message>
        <source>Having trouble downloading icons?
You can enable the DuckDuckGo website icon service in the security section of the application settings.</source>
        <translation>Har du problemer med å laste ned ikoner?
Du kan aktivere DuckDuckGo-nettstedsikontjenesten i seksjonen for sikkerhet i applikasjonsinnstillingene.</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Lukk</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>Adresse</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Status</translation>
    </message>
    <message>
        <source>Please wait, processing entry list…</source>
        <translation>Vent, behandler listen med oppføringer…</translation>
    </message>
    <message>
        <source>Downloading…</source>
        <translation>Laster ned…</translation>
    </message>
    <message>
        <source>Ok</source>
        <translation>Ok</translation>
    </message>
    <message>
        <source>Already Exists</source>
        <translation>Finnes fra før</translation>
    </message>
    <message>
        <source>Download Failed</source>
        <translation>Nedlasting mislyktes</translation>
    </message>
    <message>
        <source>Downloading favicons (%1/%2)…</source>
        <translation>Laster ned nettstedskoner (%1/%2)…</translation>
    </message>
</context>
<context>
    <name>ImageAttachmentsWidget</name>
    <message>
        <source>Zoom:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Fit</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>ImportWizard</name>
    <message>
        <source>Import Wizard</source>
        <translation>Importeringsveileder</translation>
    </message>
</context>
<context>
    <name>ImportWizardPageReview</name>
    <message>
        <source>WizardPage</source>
        <translation>Veiviserside</translation>
    </message>
    <message>
        <source>Entry count: %1</source>
        <translation>Antall oppføringer: %1</translation>
    </message>
    <message>
        <source>Group</source>
        <translation>Gruppe</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>Tittel</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>Brukernavn</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Passord</translation>
    </message>
    <message>
        <source>Url</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>Could not load key file.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Could not open remote database. Password or key file may be incorrect.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>ImportWizardPageSelect</name>
    <message>
        <source>Form</source>
        <translation>Skjema</translation>
    </message>
    <message>
        <source>Import File Selection</source>
        <translation>Importer filutvalg</translation>
    </message>
    <message>
        <source>Password:</source>
        <translation>Passord:</translation>
    </message>
    <message>
        <source>Key File:</source>
        <translation>Nøkkelfil:</translation>
    </message>
    <message>
        <source>Browse…</source>
        <translation>Bla gjennom...</translation>
    </message>
    <message>
        <source>Import Into:</source>
        <translation>Importer til:</translation>
    </message>
    <message>
        <source>New Database</source>
        <translation>Ny database</translation>
    </message>
    <message>
        <source>No unlocked databases available</source>
        <translation>Ingen åpne databaser tilgjengelig</translation>
    </message>
    <message>
        <source>Existing Database:</source>
        <translation>Eksisterende database:</translation>
    </message>
    <message>
        <source>Import File:</source>
        <translation>Importer fil:</translation>
    </message>
    <message>
        <source>Comma Separated Values (.csv)</source>
        <translation>Kommaseparerte verdier (.csv)</translation>
    </message>
    <message>
        <source>1Password Export (.1pux)</source>
        <translation>Eksporter for 1Password (.1pux)</translation>
    </message>
    <message>
        <source>1Password Vault (.opvault)</source>
        <translation>1Password-hvelv (.opvault)</translation>
    </message>
    <message>
        <source>Bitwarden (.json)</source>
        <translation>Bitwarden (.json)</translation>
    </message>
    <message>
        <source>KeePass 1 Database (.kdb)</source>
        <translation>KeePass 1-database (.kdb)</translation>
    </message>
    <message>
        <source>Open OPVault</source>
        <translation>Åpne OPVault</translation>
    </message>
    <message>
        <source>Select import file</source>
        <translation>Velg fil å importere</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>Alle filer</translation>
    </message>
    <message>
        <source>Key files</source>
        <translation>Nøkkelfiler</translation>
    </message>
    <message>
        <source>Select key file</source>
        <translation>Velg nøkkelfil</translation>
    </message>
    <message>
        <source>Comma Separated Values</source>
        <translation>Kommaseparerte verdier</translation>
    </message>
    <message>
        <source>1Password Export</source>
        <translation>Eksporter for 1Password</translation>
    </message>
    <message>
        <source>Bitwarden JSON Export</source>
        <translation>Eksporter som Bitwarden JSON</translation>
    </message>
    <message>
        <source>1Password Vault</source>
        <translation>1Password-hvelv</translation>
    </message>
    <message>
        <source>KeePass1 Database</source>
        <translation>KeePass1-database</translation>
    </message>
    <message>
        <source>Proton Pass (.json)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Proton Pass JSON Export</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Temporary Database</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Command:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>e.g.: &quot;sftp user@hostname&quot; or &quot;scp user@hostname:DatabaseOnRemote.kdbx {TEMP_DATABASE}&quot;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Input:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>e.g.:
get DatabaseOnRemote.kdbx {TEMP_DATABASE}
exit
---
{TEMP_DATABASE} is used as placeholder to store the database in a temporary location
The command has to exit. In case of `sftp` as last commend `exit` has to be sent
         </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Remote Database (.kdbx)</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>KMessageWidget</name>
    <message>
        <source>&amp;Close</source>
        <translation>&amp;Lukk</translation>
    </message>
    <message>
        <source>Close message</source>
        <translation>Lukk melding</translation>
    </message>
</context>
<context>
    <name>Kdbx3Reader</name>
    <message>
        <source>Missing database headers</source>
        <translation>Manglende databasehoder</translation>
    </message>
    <message>
        <source>Unable to calculate database key</source>
        <translation>Kan ikke beregne databasenøkkel</translation>
    </message>
    <message>
        <source>Unable to issue challenge-response: %1</source>
        <translation>Kan ikke utstede utfordrerrespons: %1</translation>
    </message>
    <message>
        <source>Invalid credentials were provided, please try again.
If this reoccurs, then your database file may be corrupt.</source>
        <translation>Det ble angitt ugyldig identifikasjon, prøv igjen.
Hvis dette gjentar seg kan databasefilen være skadet.</translation>
    </message>
    <message>
        <source>Header doesn&apos;t match hash</source>
        <translation>Hode samsvarer ikke med hash-koden</translation>
    </message>
    <message>
        <source>Invalid header id size</source>
        <translation>Ugyldig størrelse på hode-id</translation>
    </message>
    <message>
        <source>Invalid header field length: field %1</source>
        <translation>Ugyldig hodefeltlengde: felt %1</translation>
    </message>
    <message>
        <source>Invalid header data length: field %1, %2 expected, %3 found</source>
        <translation>Ugyldig lengde på hodedata: felt %1, %2 forventet, %3 funnet</translation>
    </message>
</context>
<context>
    <name>Kdbx3Writer</name>
    <message>
        <source>Invalid symmetric cipher IV size.</source>
        <comment>IV = Initialization Vector for symmetric cipher</comment>
        <translation>Ugyldig symmetrisk chiffer IV-størrelse.</translation>
    </message>
    <message>
        <source>Unable to issue challenge-response: %1</source>
        <translation>Kan ikke utstede utfordrerrespons: %1</translation>
    </message>
    <message>
        <source>Unable to calculate database key</source>
        <translation>Kan ikke beregne databasenøkkel</translation>
    </message>
</context>
<context>
    <name>Kdbx4Reader</name>
    <message>
        <source>missing database headers</source>
        <translation>manglende databasehoder</translation>
    </message>
    <message>
        <source>Unable to calculate database key: %1</source>
        <translation>Kan ikke beregne databasenøkkel: %1</translation>
    </message>
    <message>
        <source>Invalid header checksum size</source>
        <translation>Ugyldig størrelse på kontrollsum for hode</translation>
    </message>
    <message>
        <source>Header SHA256 mismatch</source>
        <translation>SHA256 samsvarer ikke i hode</translation>
    </message>
    <message>
        <source>Invalid credentials were provided, please try again.
If this reoccurs, then your database file may be corrupt.</source>
        <translation>Det ble angitt ugyldig identifikasjon, prøv igjen.
Hvis dette gjentar seg kan databasefilen være skadet.</translation>
    </message>
    <message>
        <source>(HMAC mismatch)</source>
        <translation>(HMAC samsvarer ikke)</translation>
    </message>
    <message>
        <source>Unknown cipher</source>
        <translation>Ukjent chiffer</translation>
    </message>
    <message>
        <source>Invalid header id size</source>
        <translation>Ugyldig størrelse på hode-id</translation>
    </message>
    <message>
        <source>Invalid header field length: field %1</source>
        <translation>Ugyldig hodefeltlengde: felt %1</translation>
    </message>
    <message>
        <source>Invalid header data length: field %1, %2 expected, %3 found</source>
        <translation>Ugyldig lengde på hodedata: felt %1, %2 forventet, %3 funnet</translation>
    </message>
    <message>
        <source>Failed to open buffer for KDF parameters in header</source>
        <translation>Kunne ikke åpne buffer for KDF-parametere i hode</translation>
    </message>
    <message>
        <source>Unsupported key derivation function (KDF) or invalid parameters</source>
        <translation>Ikke støttet funksjon for nøkkelavledning (KDF) eller ugyldige parametre</translation>
    </message>
    <message>
        <source>Legacy header fields found in KDBX4 file.</source>
        <translation>Eldre hodefelt funnet i KDBX4-fil.</translation>
    </message>
    <message>
        <source>Invalid inner header id size</source>
        <translation>Ugyldig størrelse på indre hode-id</translation>
    </message>
    <message>
        <source>Invalid inner header field length: field %1</source>
        <translation>Ugyldig lengde på indre hodefelt: felt %1</translation>
    </message>
    <message>
        <source>Invalid inner header data length: field %1, %2 expected, %3 found</source>
        <translation>Ugyldig datalengde for indre hode: felt %1, %2 forventet, %3 funnet</translation>
    </message>
    <message>
        <source>Invalid inner header binary size</source>
        <translation>Ugyldig binær størrelse for indre hode</translation>
    </message>
    <message>
        <source>Unsupported KeePass variant map version.</source>
        <extracomment>Translation: variant map = data structure for storing meta data</extracomment>
        <translation>Ikke støttet KeePass variant-map versjon.</translation>
    </message>
    <message>
        <source>Invalid variant map entry name length</source>
        <extracomment>Translation: variant map = data structure for storing meta data</extracomment>
        <translation>Ugyldig: Variant map entry name length</translation>
    </message>
    <message>
        <source>Invalid variant map entry name data</source>
        <extracomment>Translation: variant map = data structure for storing meta data</extracomment>
        <translation>Ugyldig: Variant map entry name data</translation>
    </message>
    <message>
        <source>Invalid variant map entry value length</source>
        <extracomment>Translation: variant map = data structure for storing meta data</extracomment>
        <translation>Ugyldig: Variant map entry value length</translation>
    </message>
    <message>
        <source>Invalid variant map entry value data</source>
        <extracomment>Translation comment: variant map = data structure for storing meta data</extracomment>
        <translation>Ugyldig: Variant map entry value data</translation>
    </message>
    <message>
        <source>Invalid variant map Bool entry value length</source>
        <extracomment>Translation: variant map = data structure for storing meta data</extracomment>
        <translation>Ugyldig: Variant map Bool entry value length</translation>
    </message>
    <message>
        <source>Invalid variant map Int32 entry value length</source>
        <extracomment>Translation: variant map = data structure for storing meta data</extracomment>
        <translation>Ugyldig: Variant map Int32 entry value length</translation>
    </message>
    <message>
        <source>Invalid variant map UInt32 entry value length</source>
        <extracomment>Translation: variant map = data structure for storing meta data</extracomment>
        <translation>Ugyldig: Variant map UInt32 entry value length</translation>
    </message>
    <message>
        <source>Invalid variant map Int64 entry value length</source>
        <extracomment>Translation: variant map = data structure for storing meta data</extracomment>
        <translation>Ugyldig: Variant map Int64 entry value length</translation>
    </message>
    <message>
        <source>Invalid variant map UInt64 entry value length</source>
        <extracomment>Translation: variant map = data structure for storing meta data</extracomment>
        <translation>Ugyldig: Variant map UInt64 entry value length</translation>
    </message>
    <message>
        <source>Invalid variant map entry type</source>
        <extracomment>Translation: variant map = data structure for storing meta data</extracomment>
        <translation>Ugyldig: Variant map entry type</translation>
    </message>
    <message>
        <source>Invalid variant map field type size</source>
        <extracomment>Translation: variant map = data structure for storing meta data</extracomment>
        <translation>Ugyldig: Variant map field type size</translation>
    </message>
</context>
<context>
    <name>Kdbx4Writer</name>
    <message>
        <source>Invalid symmetric cipher algorithm.</source>
        <translation>Ugyldig: Symmetric cipher algorithm.</translation>
    </message>
    <message>
        <source>Invalid symmetric cipher IV size.</source>
        <comment>IV = Initialization Vector for symmetric cipher</comment>
        <translation>Ugyldig: Symmetric cipher IV size.</translation>
    </message>
    <message>
        <source>Unable to calculate database key: %1</source>
        <translation>Kan ikke beregne databasenøkkel: %1</translation>
    </message>
    <message>
        <source>Failed to serialize KDF parameters variant map</source>
        <extracomment>Translation comment: variant map = data structure for storing meta data</extracomment>
        <translation>Kunne ikke serialisere KDF-parametre variant-map</translation>
    </message>
</context>
<context>
    <name>KdbxReader</name>
    <message>
        <source>Invalid cipher uuid length: %1 (length=%2)</source>
        <translation>Ugyldig lengde på chifferkode-uuid: %1 (lengde=%2)</translation>
    </message>
    <message>
        <source>Unable to parse UUID: %1</source>
        <translation>Kan ikke analysere UUID: %1</translation>
    </message>
    <message>
        <source>Unsupported cipher</source>
        <translation>Ikke støttet chiffer</translation>
    </message>
    <message>
        <source>Invalid compression flags length</source>
        <translation>Ugyldig: Compression flags length</translation>
    </message>
    <message>
        <source>Unsupported compression algorithm</source>
        <translation>Ikke støttet komprimeringsalgoritme</translation>
    </message>
    <message>
        <source>Invalid master seed size</source>
        <translation>Ugyldig: Master seed size</translation>
    </message>
    <message>
        <source>Invalid transform seed size</source>
        <translation>Ugyldig: Transform seed size</translation>
    </message>
    <message>
        <source>Invalid transform rounds size</source>
        <translation>Ugyldig: Transform rounds size</translation>
    </message>
    <message>
        <source>Invalid start bytes size</source>
        <translation>Ugyldig: Start bytes size</translation>
    </message>
    <message>
        <source>Invalid random stream id size</source>
        <translation>Ugyldig: Random stream id size</translation>
    </message>
    <message>
        <source>Invalid inner random stream cipher</source>
        <translation>Ugyldig: Inner random stream cipher</translation>
    </message>
    <message>
        <source>Failed to read database file.</source>
        <translation>Kunne ikke lese database filen.</translation>
    </message>
    <message>
        <source>The selected file is an old KeePass 1 database (.kdb).

You can import it by clicking on Database &gt; 'Import KeePass 1 database…'.
This is a one-way migration. You won&apos;t be able to open the imported database with the old KeePassX 0.4 version.</source>
        <translation>Den valgte filen er en gammel KeePass 1-database (.kdb).

Du kan importere den ved å klikke på Database &gt; Importer KeePass 1-database…
Dette er en enveis-migrasjon. Du kan ikke åpne den importerte databasen med den gamle KeePassX 0.4-versjonen.</translation>
    </message>
    <message>
        <source>Not a KeePass database.</source>
        <translation>Ikke en KeePass-database.</translation>
    </message>
    <message>
        <source>Unsupported KeePass 2 database version.</source>
        <translation>Ikke støttet KeePass2-databaseversjon.</translation>
    </message>
</context>
<context>
    <name>KdbxXmlReader</name>
    <message>
        <source>XML parsing failure: %1</source>
        <translation>XML-parsingfeil: %1</translation>
    </message>
    <message>
        <source>No root group</source>
        <translation>Ingen root-gruppe</translation>
    </message>
    <message>
        <source>XML error:
%1
Line %2, column %3</source>
        <translation>XML-feil:
%1
Linje %2, kolonne %3</translation>
    </message>
    <message>
        <source>Missing icon uuid or data</source>
        <translation>Mangler: Icon uuid or data</translation>
    </message>
    <message>
        <source>Missing custom data key or value</source>
        <translation>Mangler: Custom data key or value</translation>
    </message>
    <message>
        <source>Multiple group elements</source>
        <translation>Flere gruppe-elementer</translation>
    </message>
    <message>
        <source>Null group uuid</source>
        <translation>Null: Group uuid</translation>
    </message>
    <message>
        <source>Invalid group icon number</source>
        <translation>Ugyldig: Group icon number</translation>
    </message>
    <message>
        <source>Invalid EnableAutoType value</source>
        <translation>Ugyldig: EnableAutoType value</translation>
    </message>
    <message>
        <source>Invalid EnableSearching value</source>
        <translation>Ugyldig: EnableSearching value</translation>
    </message>
    <message>
        <source>No group uuid found</source>
        <translation>Ikke funnet: group uuid</translation>
    </message>
    <message>
        <source>Null DeleteObject uuid</source>
        <translation>Null: DeleteObject uuid</translation>
    </message>
    <message>
        <source>Missing DeletedObject uuid or time</source>
        <translation>Mangler: DeletedObject uuid or time</translation>
    </message>
    <message>
        <source>Null entry uuid</source>
        <translation>Null: Entry uuid</translation>
    </message>
    <message>
        <source>Invalid entry icon number</source>
        <translation>Ugyldig: Entry icon number</translation>
    </message>
    <message>
        <source>History element in history entry</source>
        <translation>Historikkelement i historikkoppføring</translation>
    </message>
    <message>
        <source>No entry uuid found</source>
        <translation>Ikke funnet: Entry uuid</translation>
    </message>
    <message>
        <source>History element with different uuid</source>
        <translation>Historikkelement med forskjellige uuid</translation>
    </message>
    <message>
        <source>Duplicate custom attribute found</source>
        <translation>Duplisert egendefinert attributt funnet</translation>
    </message>
    <message>
        <source>Entry string key or value missing</source>
        <translation>Mangler: Entry string key or value</translation>
    </message>
    <message>
        <source>Entry binary key or value missing</source>
        <translation>Mangler: Entry binary key or value</translation>
    </message>
    <message>
        <source>Auto-type association window or sequence missing</source>
        <translation>Mangler: Auto-type association window or sequence</translation>
    </message>
    <message>
        <source>Invalid bool value</source>
        <translation>Ugyldig: Bool value</translation>
    </message>
    <message>
        <source>Invalid date time value</source>
        <translation>Ugyldig: date time value</translation>
    </message>
    <message>
        <source>Invalid color value</source>
        <translation>Ugyldig: Color value</translation>
    </message>
    <message>
        <source>Invalid color rgb part</source>
        <translation>Ugyldig: Color rgb part</translation>
    </message>
    <message>
        <source>Invalid number value</source>
        <translation>Ugyldig: Number value</translation>
    </message>
    <message>
        <source>Invalid uuid value</source>
        <translation>Ugyldig: Uuid value</translation>
    </message>
    <message>
        <source>Unable to decompress binary</source>
        <extracomment>Translator meant is a binary data inside an entry</extracomment>
        <translation>Kan ikke dekryptere binær</translation>
    </message>
</context>
<context>
    <name>KeeAgentSettings</name>
    <message>
        <source>Invalid KeeAgent settings file structure.</source>
        <translation>Ugyldig filstruktur i KeeAgent-innstillingene.</translation>
    </message>
    <message>
        <source>Private key is an attachment but no attachments provided.</source>
        <translation>Privatnøkkel er et vedlegg, men ingen vedlegg følger med.</translation>
    </message>
    <message>
        <source>Private key is empty</source>
        <translation>Privatnøkkelen er tom</translation>
    </message>
    <message>
        <source>File too large to be a private key</source>
        <translation>Fil for stor til å være privat nøkkel</translation>
    </message>
    <message>
        <source>Failed to open private key</source>
        <translation>Kunne ikke åpne den private nøkkelen</translation>
    </message>
</context>
<context>
    <name>KeePass1Reader</name>
    <message>
        <source>Unable to read keyfile.</source>
        <translation>Kan ikke lese nøkkelfil.</translation>
    </message>
    <message>
        <source>Not a KeePass database.</source>
        <translation>Ikke en KeePass-database.</translation>
    </message>
    <message>
        <source>Unsupported encryption algorithm.</source>
        <translation>Ikke støttet krypteringsalgoritme.</translation>
    </message>
    <message>
        <source>Unsupported KeePass database version.</source>
        <translation>Ikke støttet KeePass databaseversion.</translation>
    </message>
    <message>
        <source>Unable to read encryption IV</source>
        <comment>IV = Initialization Vector for symmetric cipher</comment>
        <translation>Kan ikke lese krypterings-IV</translation>
    </message>
    <message>
        <source>Invalid number of groups</source>
        <translation>Ugyldig antall grupper</translation>
    </message>
    <message>
        <source>Invalid number of entries</source>
        <translation>Ugyldig antall oppføringer</translation>
    </message>
    <message>
        <source>Invalid content hash size</source>
        <translation>Ugyldig: Content hash size</translation>
    </message>
    <message>
        <source>Invalid transform seed size</source>
        <translation>Ugyldig: Transform seed size</translation>
    </message>
    <message>
        <source>Invalid number of transform rounds</source>
        <translation>Ugyldig: Number of transform rounds</translation>
    </message>
    <message>
        <source>Unable to construct group tree</source>
        <translation>Kan ikke opprette gruppe-tre</translation>
    </message>
    <message>
        <source>Root</source>
        <translation>Rot</translation>
    </message>
    <message>
        <source>Unable to calculate database key</source>
        <translation>Kan ikke beregne databasenøkkel</translation>
    </message>
    <message>
        <source>unable to seek to content position</source>
        <translation>kan ikke søke fram posisjonen til innholdet</translation>
    </message>
    <message>
        <source>Invalid credentials were provided, please try again.
If this reoccurs, then your database file may be corrupt.</source>
        <translation>Det ble angitt ugyldig identifikasjon, prøv igjen.
Hvis dette gjentar seg kan databasefilen være skadet.</translation>
    </message>
    <message>
        <source>Key transformation failed</source>
        <translation>Nøkkeltransformasjon feila</translation>
    </message>
    <message>
        <source>Invalid group field type number</source>
        <translation>Ugyldig: Group field type number</translation>
    </message>
    <message>
        <source>Invalid group field size</source>
        <translation>Ugyldig: Group field size</translation>
    </message>
    <message>
        <source>Read group field data doesn&apos;t match size</source>
        <translation>Lest gruppefeltdata matcher ikke størrelsen</translation>
    </message>
    <message>
        <source>Incorrect group id field size</source>
        <translation>Feil: Group id field size</translation>
    </message>
    <message>
        <source>Incorrect group creation time field size</source>
        <translation>Feil: Group creation time field size</translation>
    </message>
    <message>
        <source>Incorrect group modification time field size</source>
        <translation>Feil: Group modification time field size</translation>
    </message>
    <message>
        <source>Incorrect group access time field size</source>
        <translation>Feil: Group access time field size</translation>
    </message>
    <message>
        <source>Incorrect group expiry time field size</source>
        <translation>Feil: Group expiry time field size</translation>
    </message>
    <message>
        <source>Incorrect group icon field size</source>
        <translation>Feil: Group icon field size</translation>
    </message>
    <message>
        <source>Incorrect group level field size</source>
        <translation>Feil: Group level field size</translation>
    </message>
    <message>
        <source>Invalid group field type</source>
        <translation>Ugyldig: Group field type</translation>
    </message>
    <message>
        <source>Missing group id or level</source>
        <translation>Mangler: group id or level</translation>
    </message>
    <message>
        <source>Missing entry field type number</source>
        <translation>Mangler: Entry field type number</translation>
    </message>
    <message>
        <source>Invalid entry field size</source>
        <translation>Ugyldig: Entry field size</translation>
    </message>
    <message>
        <source>Read entry field data doesn&apos;t match size</source>
        <translation>Lest felt i oppføring matcher ikke størrelse</translation>
    </message>
    <message>
        <source>Invalid entry UUID field size</source>
        <translation>Ugyldig UUID-feltstørrelse for oppføringen</translation>
    </message>
    <message>
        <source>Invalid entry group id field size</source>
        <translation>Ugyldig: Entry group id field size</translation>
    </message>
    <message>
        <source>Invalid entry icon field size</source>
        <translation>Ugyldig: Entry icon field size</translation>
    </message>
    <message>
        <source>Invalid entry creation time field size</source>
        <translation>Ugyldig: Entry creation time field size</translation>
    </message>
    <message>
        <source>Invalid entry modification time field size</source>
        <translation>Ugyldig: Entry modification time field size</translation>
    </message>
    <message>
        <source>Invalid entry expiry time field size</source>
        <translation>Ugyldig: Entry expiry time field size</translation>
    </message>
    <message>
        <source>Invalid entry field type</source>
        <translation>Ugyldig: Entry field type</translation>
    </message>
</context>
<context>
    <name>KeeShare</name>
    <message>
        <source>Invalid sharing reference</source>
        <translation>Ugyldig delingsreferanse</translation>
    </message>
    <message>
        <source>Inactive share %1</source>
        <translation>Inaktiv deling %1</translation>
    </message>
    <message>
        <source>Imported from %1</source>
        <translation>Importert fra %1</translation>
    </message>
    <message>
        <source>Exported to %1</source>
        <translation>Eksportert til %1</translation>
    </message>
    <message>
        <source>Synchronized with %1</source>
        <translation>Synkronisert med %1</translation>
    </message>
    <message>
        <source>Import is disabled in settings</source>
        <translation>Import er deaktivert i innstillingene</translation>
    </message>
    <message>
        <source>Export is disabled in settings</source>
        <translation>Eksport er deaktivert i innstillingene</translation>
    </message>
    <message>
        <source>Inactive share</source>
        <translation>Inaktiv deling</translation>
    </message>
    <message>
        <source>Imported from</source>
        <translation>Importert fra</translation>
    </message>
    <message>
        <source>Exported to</source>
        <translation>Eksportert til</translation>
    </message>
    <message>
        <source>Synchronized with</source>
        <translation>Synkronisert med</translation>
    </message>
</context>
<context>
    <name>KeyComponentWidget</name>
    <message>
        <source>Key Component</source>
        <translation>Nøkkelkomponent</translation>
    </message>
    <message>
        <source>Key Component Description</source>
        <translation>Beskrivelse av nøkkelkomponent</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Avbryt</translation>
    </message>
    <message>
        <source>Key Component set, click to change or remove</source>
        <translation>Nøkkelkomponentsett, klikk for å endre eller fjerne</translation>
    </message>
</context>
<context>
    <name>KeyFileEditWidget</name>
    <message>
        <source>Generate a new key file</source>
        <translation>Opprett en ny nøkkelfil</translation>
    </message>
    <message>
        <source>Generate</source>
        <translation>Opprett</translation>
    </message>
    <message>
        <source>Generate a new key file or choose an existing one to protect your database.</source>
        <translation>Opprett en ny nøkkelfil, eller velg en eksisterende nøkkelfil for å beskytte databasen.</translation>
    </message>
    <message>
        <source>Note: Do NOT use a file that may change as that will prevent you from unlocking your database.</source>
        <translation>Merk: IKKE bruk en fil som kan endres, da det vil hindre deg i å låse opp databasen.</translation>
    </message>
    <message>
        <source>Browse for key file</source>
        <translation>Søk etter nøkkelfilen</translation>
    </message>
    <message>
        <source>Browse…</source>
        <translation>Bla gjennom...</translation>
    </message>
    <message>
        <source>Old key file format</source>
        <translation>Gammelt nøkkelfilformat</translation>
    </message>
    <message>
        <source>You selected a key file in an old format which KeePassXC&lt;br&gt;may stop supporting in the future.&lt;br&gt;&lt;br&gt;Please consider generating a new key file instead.</source>
        <translation>Du valgte en nøkkelfil i et gammelt format som KeePassXC&lt;br&gt;kan slutte å støtte i fremtiden.&lt;br&gt;&lt;br&gt;Vurder å opprette en ny nøkkelfil i stedet.</translation>
    </message>
    <message>
        <source>Error loading the key file '%1'
Message: %2</source>
        <translation>Feil under lasting av nøkkelfilen &apos;%1&apos;
Melding: %2</translation>
    </message>
    <message>
        <source>Key File</source>
        <translation>Nøkkelfil</translation>
    </message>
    <message>
        <source>Add Key File</source>
        <translation>Legg til nøkkelfil</translation>
    </message>
    <message>
        <source>Change Key File</source>
        <translation>Endre nøkkelfil</translation>
    </message>
    <message>
        <source>Remove Key File</source>
        <translation>Fjern nøkkelfil</translation>
    </message>
    <message>
        <source>Key File set, click to change or remove</source>
        <translation>Nøkkelfilsett, klikk for å endre eller fjerne</translation>
    </message>
    <message>
        <source>&lt;p&gt;You can add a key file containing random bytes for additional security.&lt;/p&gt;&lt;p&gt;You must keep it secret and never lose it or you will be locked out.&lt;/p&gt;</source>
        <translation>&lt;p&gt;Du kan legge til en nøkkelfil som inneholder tilfeldige byter for ekstra sikkerhet.&lt;/p&gt;&lt;p&gt;Du må holde den hemmelig og aldri miste den, ellers vil du bli låst ute.&lt;/p&gt;</translation>
    </message>
    <message>
        <source>Key files</source>
        <translation>Nøkkelfiler</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>Alle filer</translation>
    </message>
    <message>
        <source>Create Key File…</source>
        <translation>Opprett nøkkelfil…</translation>
    </message>
    <message>
        <source>Error creating key file</source>
        <translation>Feil ved oppretting av nøkkelfil</translation>
    </message>
    <message>
        <source>Unable to create key file: %1</source>
        <translation>Kunne ikke opprette nøkkelfil: %1</translation>
    </message>
    <message>
        <source>Select a key file</source>
        <translation>Velg en nøkkelfil</translation>
    </message>
    <message>
        <source>Invalid Key File</source>
        <translation>Ugyldig nøkkelfil</translation>
    </message>
    <message>
        <source>You cannot use the current database as its own keyfile. Please choose a different file or generate a new key file.</source>
        <translation>Du kan ikke bruke gjeldende database som sin egen nøkkelfil. Velg en annen fil, eller opprett en ny nøkkelfil.</translation>
    </message>
    <message>
        <source>Suspicious Key File</source>
        <translation>Mistenkelig nøkkelfil</translation>
    </message>
    <message>
        <source>The chosen key file looks like a password database file. A key file must be a static file that never changes or you will lose access to your database forever.
Are you sure you want to continue with this file?</source>
        <translation>Den valgte nøkkelfilen ser ut som en passorddatabasefil. En nøkkelfil må være en statisk fil som aldri endres, ellers mister du tilgangen til databasen for alltid.
Er du sikker på at du vil fortsette med denne filen?</translation>
    </message>
</context>
<context>
    <name>MacUtils</name>
    <message>
        <source>Invalid key code</source>
        <translation>Ugyldig nøkkelkode</translation>
    </message>
    <message>
        <source>Global shortcut already registered to %1</source>
        <translation>Global hurtigtast er allerede registrert på %1</translation>
    </message>
    <message>
        <source>Could not register global shortcut</source>
        <translation>Kunne ikke registrere global hurtigtast</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>&amp;Database</source>
        <translation>&amp;Database</translation>
    </message>
    <message>
        <source>&amp;Recent Databases</source>
        <translation>&amp;Nylige databaser</translation>
    </message>
    <message>
        <source>&amp;Export</source>
        <translation>&amp;Eksporter</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>&amp;Hjelp</translation>
    </message>
    <message>
        <source>&amp;Entries</source>
        <translation>&amp;Oppføringer</translation>
    </message>
    <message>
        <source>Copy Att&amp;ribute</source>
        <translation>Kopier att&amp;ributt</translation>
    </message>
    <message>
        <source>TOTP</source>
        <translation>TOTP</translation>
    </message>
    <message>
        <source>Tags</source>
        <translation>Tagger</translation>
    </message>
    <message>
        <source>&amp;Groups</source>
        <translation>&amp;Grupper</translation>
    </message>
    <message>
        <source>&amp;Tools</source>
        <translation>&amp;Verktøy</translation>
    </message>
    <message>
        <source>View</source>
        <translation>Vis</translation>
    </message>
    <message>
        <source>Theme</source>
        <translation>Tema</translation>
    </message>
    <message>
        <source>&amp;Quit</source>
        <translation>&amp;Avslutt</translation>
    </message>
    <message>
        <source>&amp;About</source>
        <translation>&amp;Om</translation>
    </message>
    <message>
        <source>&amp;Check for Updates</source>
        <translation>&amp;Se etter oppdateringer</translation>
    </message>
    <message>
        <source>&amp;Open Database…</source>
        <translation>&amp;Åpne database…</translation>
    </message>
    <message>
        <source>&amp;Save Database</source>
        <translation>&amp;Lagre database</translation>
    </message>
    <message>
        <source>&amp;Close Database</source>
        <translation>&amp;Lukk database</translation>
    </message>
    <message>
        <source>&amp;New Database…</source>
        <translation>&amp;Ny database…</translation>
    </message>
    <message>
        <source>&amp;Merge From Database…</source>
        <translation>&amp;Slå sammen fra database…</translation>
    </message>
    <message>
        <source>&amp;New Entry…</source>
        <translation>&amp;Ny oppføring…</translation>
    </message>
    <message>
        <source>&amp;Edit Entry…</source>
        <translation>&amp;Endre oppføring…</translation>
    </message>
    <message>
        <source>&amp;New Group…</source>
        <translation>&amp;Ny gruppe…</translation>
    </message>
    <message>
        <source>&amp;Edit Group…</source>
        <translation>&amp;Endre gruppe…</translation>
    </message>
    <message>
        <source>&amp;Delete Group…</source>
        <translation>&amp;Slett gruppe…</translation>
    </message>
    <message>
        <source>Download All &amp;Favicons…</source>
        <translation>Last ned alle &amp;nettstedsikoner…</translation>
    </message>
    <message>
        <source>Sort &amp;A-Z</source>
        <translation>Sorter &amp;A-Å</translation>
    </message>
    <message>
        <source>Sort &amp;Z-A</source>
        <translation>Sorter &amp;Å-A</translation>
    </message>
    <message>
        <source>Sa&amp;ve Database As…</source>
        <translation>Lagre database som…</translation>
    </message>
    <message>
        <source>Database &amp;Security…</source>
        <translation>Databasesikkerhet…</translation>
    </message>
    <message>
        <source>Database &amp;Reports…</source>
        <translation>Databaserapporter…</translation>
    </message>
    <message>
        <source>&amp;Database Settings…</source>
        <translation>&amp;Databaseinnstillinger…</translation>
    </message>
    <message>
        <source>&amp;Clone Entry…</source>
        <translation>&amp;Klone oppføring…</translation>
    </message>
    <message>
        <source>Move u&amp;p</source>
        <translation>Flytt o&amp;pp</translation>
    </message>
    <message>
        <source>Move do&amp;wn</source>
        <translation>Flytt &amp;ned</translation>
    </message>
    <message>
        <source>Copy &amp;Username</source>
        <translation>Kopier &amp;brukernavn</translation>
    </message>
    <message>
        <source>Copy &amp;Password</source>
        <translation>Kopier &amp;passord</translation>
    </message>
    <message>
        <source>&amp;Settings</source>
        <translation>&amp;Oppsett</translation>
    </message>
    <message>
        <source>&amp;Password Generator</source>
        <translation>&amp;Passordgenerator</translation>
    </message>
    <message>
        <source>Perform &amp;Auto-Type</source>
        <translation>Utfør &amp;autoskriv</translation>
    </message>
    <message>
        <source>Download &amp;Favicon</source>
        <translation>Last ned &amp;nettstedsikon</translation>
    </message>
    <message>
        <source>Open &amp;URL</source>
        <translation>Åpne &amp;URL</translation>
    </message>
    <message>
        <source>&amp;Lock Database</source>
        <translation>&amp;Lås database</translation>
    </message>
    <message>
        <source>Lock &amp;All Databases</source>
        <translation>Lås &amp;alle databaser</translation>
    </message>
    <message>
        <source>&amp;Title</source>
        <translation>&amp;Tittel</translation>
    </message>
    <message>
        <source>Copy &amp;URL</source>
        <translation>Kopier &amp;URL</translation>
    </message>
    <message>
        <source>&amp;Notes</source>
        <translation>&amp;Notater</translation>
    </message>
    <message>
        <source>&amp;CSV File…</source>
        <translation>&amp;CSV-fil…</translation>
    </message>
    <message>
        <source>&amp;HTML File…</source>
        <translation>&amp;HTML-fil...</translation>
    </message>
    <message>
        <source>KeePass 1 Database…</source>
        <translation>KeePass 1-database…</translation>
    </message>
    <message>
        <source>1Password Vault…</source>
        <translation>1Password-hvelv…</translation>
    </message>
    <message>
        <source>CSV File…</source>
        <translation>CSV-fil…</translation>
    </message>
    <message>
        <source>Show TOTP</source>
        <translation>Vis TOTP</translation>
    </message>
    <message>
        <source>Show QR Code</source>
        <translation>Vis QR-kode</translation>
    </message>
    <message>
        <source>Set up TOTP…</source>
        <translation>Oppsett TOTP…</translation>
    </message>
    <message>
        <source>Copy &amp;TOTP</source>
        <translation>Kopier &amp;TOTP</translation>
    </message>
    <message>
        <source>Copy Password and TOTP</source>
        <translation>Kopier passord og TOTP</translation>
    </message>
    <message>
        <source>E&amp;mpty recycle bin</source>
        <translation>&amp;Tøm papirkurven</translation>
    </message>
    <message>
        <source>&amp;Donate</source>
        <translation>&amp;Donér</translation>
    </message>
    <message>
        <source>Report a &amp;Bug</source>
        <translation>Rapporter en &amp;feil</translation>
    </message>
    <message>
        <source>&amp;Getting Started</source>
        <translation>&amp;Komme i gang</translation>
    </message>
    <message>
        <source>Open Getting Started Guide</source>
        <translation>Åpne Komme i gang-veiledning</translation>
    </message>
    <message>
        <source>&amp;Online Help</source>
        <translation>&amp;Online hjelp</translation>
    </message>
    <message>
        <source>&amp;User Guide</source>
        <translation>&amp;Brukerveiledning</translation>
    </message>
    <message>
        <source>Open User Guide</source>
        <translation>Åpne brukerveiledning</translation>
    </message>
    <message>
        <source>&amp;Keyboard Shortcuts</source>
        <translation>&amp;Hurtigtaster</translation>
    </message>
    <message>
        <source>Save Database Backup…</source>
        <translation>Lagre sikkerhetskopi av database…</translation>
    </message>
    <message>
        <source>Add key to SSH Agent</source>
        <translation>Legg til nøkkel i SSH-agent</translation>
    </message>
    <message>
        <source>Remove key from SSH Agent</source>
        <translation>Fjern nøkkel fra SSH-agent</translation>
    </message>
    <message>
        <source>Compact Mode</source>
        <translation>Kompakt modus</translation>
    </message>
    <message>
        <source>Automatic</source>
        <translation>Automatisk</translation>
    </message>
    <message>
        <source>Light</source>
        <translation>Lys</translation>
    </message>
    <message>
        <source>Dark</source>
        <translation>Mørk</translation>
    </message>
    <message>
        <source>Classic (Platform-native)</source>
        <translation>Klassisk (plattformbasert)</translation>
    </message>
    <message>
        <source>Show Menubar</source>
        <translation>Vis menylinje</translation>
    </message>
    <message>
        <source>Show Toolbar</source>
        <translation>Vis verktøylinje</translation>
    </message>
    <message>
        <source>Show Preview Panel</source>
        <translation>Vis Forhåndsvisning-panelet</translation>
    </message>
    <message>
        <source>Always on Top</source>
        <translation>Alltid øverst</translation>
    </message>
    <message>
        <source>Hide Usernames</source>
        <translation>Skjul brukernavn</translation>
    </message>
    <message>
        <source>Hide Passwords</source>
        <translation>Skjul passord</translation>
    </message>
    <message>
        <source>Clone Group...</source>
        <translation>Klone gruppe…</translation>
    </message>
    <message>
        <source>&amp;XML File…</source>
        <translation>&amp;XML-fil…</translation>
    </message>
    <message>
        <source>Clear history</source>
        <translation>Slett historikk</translation>
    </message>
    <message>
        <source>Access error for config file %1</source>
        <translation>Feil ved tilgang for konfigurasjonsfilen %1</translation>
    </message>
    <message>
        <source>Don&apos;t show again for this version</source>
        <translation>Ikke vis igjen for denne versjonen</translation>
    </message>
    <message>
        <source>No Tags</source>
        <translation>Ingen tagger</translation>
    </message>
    <message numerus="yes">
        <source>Restore Entry(s)</source>
        <translation><numerusform>Gjenopprett oppføring</numerusform><numerusform>Gjenopprett oppføringer</numerusform></translation>
    </message>
    <message>
        <source>Settings</source>
        <translation>Oppsett</translation>
    </message>
    <message>
        <source>Check for updates on startup?</source>
        <translation>Sjekk etter oppdateringer ved oppstart?</translation>
    </message>
    <message>
        <source>Would you like KeePassXC to check for updates on startup?</source>
        <translation>Vil du at KeePassXC skal se etter oppdateringer ved oppstart?</translation>
    </message>
    <message>
        <source>You can always check for updates manually from the application menu.</source>
        <translation>Du kan alltid sjekke om oppdateringer manuelt fra programmenyen.</translation>
    </message>
    <message>
        <source>Toggle window</source>
        <translation>Vis vinduet</translation>
    </message>
    <message>
        <source>Quit KeePassXC</source>
        <translation>Avslutt KeePassXC</translation>
    </message>
    <message numerus="yes">
        <source>%1 Entry(s)</source>
        <translation><numerusform>%1 oppføring</numerusform><numerusform>%1 oppføringer</numerusform></translation>
    </message>
    <message>
        <source>Please present or touch your YubiKey to continue…</source>
        <translation>Kobl til og/eller berør YubiKey for å fortsette…</translation>
    </message>
    <message>
        <source>Restart Application?</source>
        <translation>Starte programmet på nytt?</translation>
    </message>
    <message>
        <source>You must restart the application to apply this setting. Would you like to restart now?</source>
        <translation>Du må starte programmet på nytt for å bruke denne innstillingen. Vil du starte på nytt nå?</translation>
    </message>
    <message>
        <source>Allow Screen Capture</source>
        <translation>Tillat skjermopptak</translation>
    </message>
    <message>
        <source>1Password 1PUX...</source>
        <translation>1Password 1PUX</translation>
    </message>
    <message>
        <source>Import a 1Password 1PUX file</source>
        <translation>Importer en 1Password 1PUX-fil</translation>
    </message>
    <message>
        <source>Import…</source>
        <translation>Importer…</translation>
    </message>
    <message>
        <source>Passkeys…</source>
        <translation>Tilgangsnøkler...</translation>
    </message>
    <message>
        <source>Import Passkey</source>
        <translation>Importer tilgangsnøkkel</translation>
    </message>
    <message>
        <source>Remote S&amp;ync…</source>
        <translation>Fjernsynkronisering...</translation>
    </message>
    <message>
        <source>Quit Application</source>
        <translation>Avslutt programmet</translation>
    </message>
    <message>
        <source>Open About Dialog</source>
        <translation>Åpne om-dialogboks</translation>
    </message>
    <message>
        <source>Open Database</source>
        <translation>Åpne database</translation>
    </message>
    <message>
        <source>Create Database</source>
        <translation>Opprett database</translation>
    </message>
    <message>
        <source>Merge From Database</source>
        <translation>Slå sammen fra database</translation>
    </message>
    <message>
        <source>Edit Entry</source>
        <translation>Endre oppføring</translation>
    </message>
    <message>
        <source>Delete Entry</source>
        <translation>Slett oppføring</translation>
    </message>
    <message>
        <source>Create Group</source>
        <translation>Opprett gruppe</translation>
    </message>
    <message>
        <source>Edit Group</source>
        <translation>Endre gruppe</translation>
    </message>
    <message>
        <source>Delete Group</source>
        <translation>Slett gruppe</translation>
    </message>
    <message>
        <source>Download All Favicons</source>
        <translation>Last ned alle nettstedsikoner</translation>
    </message>
    <message>
        <source>Sort Groups A-Z</source>
        <translation>Sorter grupper A-Å</translation>
    </message>
    <message>
        <source>Sort Groups Z-A</source>
        <translation>Sorter grupper Å-A</translation>
    </message>
    <message>
        <source>Save Database As</source>
        <translation>Lagre database som</translation>
    </message>
    <message>
        <source>Show Database Security</source>
        <translation>Vis databasesikkerhet</translation>
    </message>
    <message>
        <source>Show Database Reports</source>
        <translation>Vis databaserapporter</translation>
    </message>
    <message>
        <source>Show Database Settings</source>
        <translation>Vis databaseinnstillinger</translation>
    </message>
    <message>
        <source>Show Passkeys</source>
        <translation>Vis tilgangsnøkler</translation>
    </message>
    <message>
        <source>Clone Entry</source>
        <translation>Klon oppføring</translation>
    </message>
    <message>
        <source>Move Entry Up</source>
        <translation>Flytt oppføring opp</translation>
    </message>
    <message>
        <source>Move Entry Down</source>
        <translation>Flytt oppføring ned</translation>
    </message>
    <message>
        <source>Copy Username</source>
        <translation>Kopier brukernavn</translation>
    </message>
    <message>
        <source>Copy Password</source>
        <translation>Kopier passord</translation>
    </message>
    <message>
        <source>Show Application Settings</source>
        <translation>Vis applikasjonsinnstillinger</translation>
    </message>
    <message>
        <source>Show Password Generator</source>
        <translation>Vis passordgenerator</translation>
    </message>
    <message>
        <source>Remove Passkey From Entry</source>
        <translation>Slett tilgangsnøkkel fra oppføring</translation>
    </message>
    <message>
        <source>Perform Auto-Type: {USERNAME}</source>
        <translation>Utfør autoskriv: {BRUKERNAVN}</translation>
    </message>
    <message>
        <source>Perform Auto-Type: {USERNAME}{ENTER}</source>
        <translation>Utfør autoskriv: {BRUKERNAVN}{ENTER}</translation>
    </message>
    <message>
        <source>Perform Auto-Type: {PASSWORD}</source>
        <translation>Utfør autoskriv: {PASSORD}</translation>
    </message>
    <message>
        <source>Perform Auto-Type: {PASSWORD}{ENTER}</source>
        <translation>Utfør autoskriv: {PASSORD}{ENTER}</translation>
    </message>
    <message>
        <source>Perform Auto-Type: {TOTP}</source>
        <translation>Utfør autoskriv: {TOTP}</translation>
    </message>
    <message>
        <source>Copy Title</source>
        <translation>Kopier tittel</translation>
    </message>
    <message>
        <source>Copy URL</source>
        <translation>Kopier URL</translation>
    </message>
    <message>
        <source>Copy Notes</source>
        <translation>Kopier notater</translation>
    </message>
    <message>
        <source>Export to CSV</source>
        <translation>Eksporter til CSV</translation>
    </message>
    <message>
        <source>Export to HTML</source>
        <translation>Eksporter til HTML</translation>
    </message>
    <message>
        <source>Import KeePass1 Database</source>
        <translation>Importer KeePass 1-database</translation>
    </message>
    <message>
        <source>Import 1Password Vault</source>
        <translation>Importer 1Password-hvelv</translation>
    </message>
    <message>
        <source>Import CSV File</source>
        <translation>Importer CSV-fil</translation>
    </message>
    <message>
        <source>Show TOTP QR Code</source>
        <translation>Vis TOTP QR-kode</translation>
    </message>
    <message>
        <source>Set up TOTP</source>
        <translation>Sett opp TOTP</translation>
    </message>
    <message>
        <source>Empty Recycle Bin</source>
        <translation>Tøm papirkurv</translation>
    </message>
    <message>
        <source>Open Donation Website</source>
        <translation>Åpne donasjonsnettsted</translation>
    </message>
    <message>
        <source>Open Bug Report</source>
        <translation>Åpne feilrapport</translation>
    </message>
    <message>
        <source>Open Online Documentation</source>
        <translation>Åpne online-dokumentasjon</translation>
    </message>
    <message>
        <source>Open Keyboard Shortcuts Guide</source>
        <translation>Åpne hurtigtast-guiden</translation>
    </message>
    <message>
        <source>Save Database Backup</source>
        <translation>Lagre database-backup</translation>
    </message>
    <message>
        <source>SSH Agent: Add Key</source>
        <translation>SSH-agent: Legg til nøkkel</translation>
    </message>
    <message>
        <source>SSH Agent: Remove Key</source>
        <translation>SSH-agent: Fjern nøkkel</translation>
    </message>
    <message>
        <source>Toggle Compact Mode</source>
        <translation>Veksle kompakt modus av/på</translation>
    </message>
    <message>
        <source>Set Theme: Automatic</source>
        <translation>Angi tema: automatisk</translation>
    </message>
    <message>
        <source>Set Theme: Light</source>
        <translation>Angi tema: lys</translation>
    </message>
    <message>
        <source>Set Theme: Dark</source>
        <translation>Angi tema: mørk</translation>
    </message>
    <message>
        <source>Set Theme: Classic</source>
        <translation>Angi tema: klassisk</translation>
    </message>
    <message>
        <source>Toggle Show Menubar</source>
        <translation>Vis/skjul menylinje</translation>
    </message>
    <message>
        <source>Toggle Show Toolbar</source>
        <translation>Vis/skjul verktøylinje</translation>
    </message>
    <message>
        <source>Toggle Show Preview Panel</source>
        <translation>Vis/skjul forhåndsvisningspanelet</translation>
    </message>
    <message>
        <source>Toggle Always on Top</source>
        <translation>Veksle alltid på toppen av/på</translation>
    </message>
    <message>
        <source>Toggle Hide Usernames</source>
        <translation>Vis/skjul brukernavn</translation>
    </message>
    <message>
        <source>Toggle Hide Passwords</source>
        <translation>Vis/skjul passord</translation>
    </message>
    <message>
        <source>Export to XML</source>
        <translation>Eksporter til XML</translation>
    </message>
    <message>
        <source>Toggle Allow Screen Capture</source>
        <translation>Veksle tillat skjermopptak av/på</translation>
    </message>
    <message>
        <source>Show Group Panel</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Toggle Show Group Panel</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Setup Remote Sync…</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>WARNING: You are using a development snapshot build of KeePassXC.
Maintain a backup of your databases in the event of unknown bugs.
This version is not meant for production use.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Clear SSH Agent</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Clear all identities in ssh-agent</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>New Entry</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Password Generator</source>
        <translation>Passordgenerator</translation>
    </message>
    <message>
        <source>Edit Entry…</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>E&amp;xpire Entry</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Expire Entry</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>&amp;Delete Entry</source>
        <translation type="unfinished"/>
    </message>
    <message numerus="yes">
        <source>Move selected entry(s) to the recycle bin</source>
        <translation type="unfinished"><numerusform></numerusform><numerusform></numerusform></translation>
    </message>
    <message numerus="yes">
        <source>Permanently delete the selected entry(s)</source>
        <translation type="unfinished"><numerusform></numerusform><numerusform></numerusform></translation>
    </message>
</context>
<context>
    <name>ManageDatabase</name>
    <message>
        <source>Database settings</source>
        <translation>Databaseoppsett</translation>
    </message>
    <message>
        <source>Edit database settings</source>
        <translation>Endre databaseinnstillinger</translation>
    </message>
    <message>
        <source>Unlock database</source>
        <translation>Lås opp databasen</translation>
    </message>
    <message>
        <source>Unlock database to show more information</source>
        <translation>Lås opp databasen for å vise mer informasjon</translation>
    </message>
    <message>
        <source>Lock database</source>
        <translation>Lås database</translation>
    </message>
</context>
<context>
    <name>ManageSession</name>
    <message>
        <source>Disconnect</source>
        <translation>Koble fra</translation>
    </message>
    <message>
        <source>Disconnect this application</source>
        <translation>Koble fra dette programmet</translation>
    </message>
    <message>
        <source>Reset</source>
        <translation>Tilbakestill</translation>
    </message>
    <message>
        <source>Reset any remembered decisions for this application</source>
        <translation>Tilbakestill huskede beslutninger for dette programmet</translation>
    </message>
</context>
<context>
    <name>MergeDialog</name>
    <message>
        <source>Database Merge Confirmation</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Merge</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Group</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Title</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>UUID</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Details</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Change</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>Merger</name>
    <message>
        <source>Changed deleted objects</source>
        <translation>Endret slettede objekter</translation>
    </message>
    <message>
        <source>Removed custom data %1 [%2]</source>
        <translation>Fjernet egendefinerte data %1 [%2]</translation>
    </message>
    <message>
        <source>Adding custom data %1 [%2]</source>
        <translation>Legger til egendefinerte data %1 [%2]</translation>
    </message>
    <message>
        <source>Added</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Modified</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Moved</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Deleted</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Previous location: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Number of entries in group: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Group name</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Notes</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Icon (UUID)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Icon (Number)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Expiry time</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Modification time</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>%1 (Add local modifications to new entry)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>%1 (Add new modifications to existing entry)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Explicit deletion</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Implicit deletion (e.g. removal of parent group)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Adding new icon %1</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>NewDatabaseWizard</name>
    <message>
        <source>Create a new KeePassXC database…</source>
        <translation>Opprett en ny KeePassXC-database…</translation>
    </message>
    <message>
        <source>Root</source>
        <comment>Root group</comment>
        <translation>Rot</translation>
    </message>
</context>
<context>
    <name>NewDatabaseWizardPage</name>
    <message>
        <source>WizardPage</source>
        <translation>Veiviserside</translation>
    </message>
    <message>
        <source>Encryption Settings</source>
        <translation>Krypteringsinnstillinger</translation>
    </message>
    <message>
        <source>Here you can adjust the database encryption settings. Don&apos;t worry, you can change them later in the database settings.</source>
        <translation>Her kan du justere innstillingene for databasekryptering. Ikke bekymre deg, du kan endre dem senere i databaseinnstillingene.</translation>
    </message>
</context>
<context>
    <name>NewDatabaseWizardPageDatabaseKey</name>
    <message>
        <source>Database Credentials</source>
        <translation>Database-akkreditering</translation>
    </message>
    <message>
        <source>A set of credentials known only to you that protects your database.</source>
        <translation>Et sett med akkreditiv som bare er kjent for deg, som beskytter databasen.</translation>
    </message>
</context>
<context>
    <name>NewDatabaseWizardPageEncryption</name>
    <message>
        <source>Encryption Settings</source>
        <translation>Krypteringsinnstillinger</translation>
    </message>
    <message>
        <source>Here you can adjust the database encryption settings. Don&apos;t worry, you can change them later in the database settings.</source>
        <translation>Her kan du justere innstillingene for databasekryptering. Ikke bekymre deg, du kan endre dem senere i databaseinnstillingene.</translation>
    </message>
</context>
<context>
    <name>NewDatabaseWizardPageMetaData</name>
    <message>
        <source>General Database Information</source>
        <translation>Generell databaseinformasjon</translation>
    </message>
    <message>
        <source>Please fill in the display name and an optional description for your new database:</source>
        <translation>Fyll ut visningsnavnet og en valgfri beskrivelse av den nye databasen:</translation>
    </message>
</context>
<context>
    <name>NixUtils</name>
    <message>
        <source>Password Manager</source>
        <translation>Passordbehandler</translation>
    </message>
    <message>
        <source>Global shortcut already registered to %1</source>
        <translation>Global hurtigtast er allerede registrert på %1</translation>
    </message>
    <message>
        <source>Could not register global shortcut</source>
        <translation>Kunne ikke registrere global hurtigtast</translation>
    </message>
</context>
<context>
    <name>OpData01</name>
    <message>
        <source>Invalid OpData01, does not contain header</source>
        <translation>Ugyldig OpData01, inneholder ikke hode</translation>
    </message>
    <message>
        <source>Unable to read all IV bytes, wanted 16 but got %1</source>
        <translation>Kan ikke lese alle IV-byte, ønsket 16, men fikk %1</translation>
    </message>
    <message>
        <source>Unable to init cipher for opdata01: %1</source>
        <translation>Kan ikke initialisere chiffer for opdata01: %1</translation>
    </message>
    <message>
        <source>Unable to read all HMAC signature bytes</source>
        <translation>Kan ikke lese alle HMAC-signaturbyte</translation>
    </message>
    <message>
        <source>Malformed OpData01 due to a failed HMAC</source>
        <translation>Deformert OpData01 på grunn av en mislykket HMAC</translation>
    </message>
    <message>
        <source>Unable to process clearText in place</source>
        <translation>Kan ikke behandle klartekst på stedet</translation>
    </message>
    <message>
        <source>Expected %1 bytes of clear-text, found %2</source>
        <translation>Forventet %1 byte med klartekst, funnet %2</translation>
    </message>
</context>
<context>
    <name>OpVaultReader</name>
    <message>
        <source>Directory .opvault must exist</source>
        <translation>Mappe .opvault må eksistere</translation>
    </message>
    <message>
        <source>Directory .opvault must be readable</source>
        <translation>Mappe .opvault må være lesbar</translation>
    </message>
    <message>
        <source>Directory .opvault/default must exist</source>
        <translation>Mappe &apos;.opvault/default&apos; må eksistere</translation>
    </message>
    <message>
        <source>Directory .opvault/default must be readable</source>
        <translation>Mappe &apos;.opvault/default&apos; må være lesbar</translation>
    </message>
    <message>
        <source>Unable to decode masterKey: %1</source>
        <translation>Kan ikke dekode hovednøkkel: %1</translation>
    </message>
    <message>
        <source>Unable to derive master key: %1</source>
        <translation>Kan ikke avlede hovednøkkel: %1</translation>
    </message>
</context>
<context>
    <name>OpenSSHKey</name>
    <message>
        <source>Invalid key file, expecting an OpenSSH key</source>
        <translation>Ugyldig nøkkelfil, forventer OpenSSH-nøkkel</translation>
    </message>
    <message>
        <source>PEM boundary mismatch</source>
        <translation>PEM-grense samsvarer ikke</translation>
    </message>
    <message>
        <source>Base64 decoding failed</source>
        <translation>Base64 dekryptering feila</translation>
    </message>
    <message>
        <source>Key file way too small.</source>
        <translation>Nøkkelfil er alt for liten.</translation>
    </message>
    <message>
        <source>Key file magic header id invalid</source>
        <translation>Nøkkelfilens filtypesignatur-id er ugyldig</translation>
    </message>
    <message>
        <source>Found zero keys</source>
        <translation>Fant null nøkler</translation>
    </message>
    <message>
        <source>Corrupted key file, reading private key failed</source>
        <translation>Skadet nøkkelfil, lesing av privat nøkkel feilet</translation>
    </message>
    <message>
        <source>Unsupported key type: %1</source>
        <translation>Ikke støttet nøkkeltype: %1</translation>
    </message>
    <message>
        <source>No private key payload to decrypt</source>
        <translation>Ingen private nøkkeldata å dekryptere</translation>
    </message>
    <message>
        <source>Unknown cipher: %1</source>
        <translation>Ukjent chiffer: %1</translation>
    </message>
    <message>
        <source>AES-256/GCM is currently not supported</source>
        <translation>AES-256/GCM støttes for øyeblikket ikke</translation>
    </message>
    <message>
        <source>Passphrase is required to decrypt this key</source>
        <translation>Passordfrase er nødvendig for å dekryptere denne nøkkelen</translation>
    </message>
    <message>
        <source>Key derivation failed: %1</source>
        <translation>Nøkkelavledning mislyktes: %1</translation>
    </message>
    <message>
        <source>Cipher IV is too short for MD5 kdf</source>
        <translation>Chiffer IV er for kort for MD5 kdf</translation>
    </message>
    <message>
        <source>Unknown KDF: %1</source>
        <translation>Ukjent KDF: %1</translation>
    </message>
    <message>
        <source>Failed to initialize cipher: %1</source>
        <translation>Klarte ikke å klargjøre chifferet: %1</translation>
    </message>
    <message>
        <source>Decryption failed: %1</source>
        <translation>Dekryptering mislyktes: %1</translation>
    </message>
    <message>
        <source>Decryption failed, wrong passphrase?</source>
        <translation>Dekryptering feilet, feil passordfrase?</translation>
    </message>
    <message>
        <source>Unexpected EOF while reading key</source>
        <translation>Uventet EOF ved lesing av nøkkel</translation>
    </message>
    <message>
        <source>Unsupported key part</source>
        <translation>Nøkkeldel støttes ikke</translation>
    </message>
    <message>
        <source>Unexpected EOF while reading public key</source>
        <translation>Uventet EOF ved lesing av offentlig nøkkel</translation>
    </message>
    <message>
        <source>Unknown key type: %1</source>
        <translation>Ukjent nøkkeltype: %1</translation>
    </message>
    <message>
        <source>Unexpected EOF while reading private key</source>
        <translation>Uventet EOF ved lesing av privat nøkkel</translation>
    </message>
    <message>
        <source>Can&apos;t write public key as it is empty</source>
        <translation>Kan ikke skrive offentlig nøkkel fordi den er tom</translation>
    </message>
    <message>
        <source>Unexpected EOF when writing public key</source>
        <translation>Uventet EOF ved skriving av offentlig nøkkel</translation>
    </message>
    <message>
        <source>Can&apos;t write private key as it is empty</source>
        <translation>Kan ikke skrive privat nøkkel fordi den er tom</translation>
    </message>
    <message>
        <source>Unexpected EOF when writing private key</source>
        <translation>Uventet EOF ved skriving av privat nøkkel</translation>
    </message>
    <message>
        <source>(encrypted)</source>
        <translation>(kryptert)</translation>
    </message>
    <message>
        <source>Failed to read key file: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Failed to read public key: %1</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>OpenSSHKeyGenDialog</name>
    <message>
        <source>SSH Key Generator</source>
        <translation>SSH nøkkelgenerator</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Type</translation>
    </message>
    <message>
        <source>Bits</source>
        <translation>Biter</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>Kommentar</translation>
    </message>
</context>
<context>
    <name>PasskeyExportDialog</name>
    <message>
        <source>KeePassXC - Passkey Export</source>
        <translation>KeePassXC - Eksport av tilgangsnøkkel</translation>
    </message>
    <message>
        <source>Filenames will be generated with title and .passkey file extension.</source>
        <translation>Filnavn vil bli generert med tittel og .passkey-filtype.</translation>
    </message>
    <message>
        <source>Export entries</source>
        <translation>Eksporter oppføringer</translation>
    </message>
    <message>
        <source>Export Selected</source>
        <translation>Eksporter valgte</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Avbryt</translation>
    </message>
    <message>
        <source>Export to folder</source>
        <translation>Eksporter til mappe</translation>
    </message>
    <message>
        <source>Export the following passkey entries.</source>
        <translation>Eksporter følgende tilgangsnøkkeloppføringer.</translation>
    </message>
</context>
<context>
    <name>PasskeyExporter</name>
    <message>
        <source>File &quot;%1.passkey&quot; already exists.
Do you want to overwrite it?
</source>
        <translation>Filen &quot;%1.passkey&quot; finnes allerede.
Vil du erstatte den?</translation>
    </message>
    <message>
        <source>Cannot open file</source>
        <translation>Kan ikke åpne fil</translation>
    </message>
    <message>
        <source>Cannot open file &quot;%1&quot; for writing.</source>
        <translation>Kan ikke åpne fil &quot;%1&quot; for skriving.</translation>
    </message>
    <message>
        <source>Cannot write to file</source>
        <translation>Kan ikke skrive til fil</translation>
    </message>
    <message>
        <source>Overwrite Existing File?</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>PasskeyImportDialog</name>
    <message>
        <source>KeePassXC - Passkey Import</source>
        <translation>KeePassXC - Import av tilgangsnøkkel</translation>
    </message>
    <message>
        <source>Username: %1</source>
        <translation>Brukernavn: %1</translation>
    </message>
    <message>
        <source>Group</source>
        <translation>Gruppe</translation>
    </message>
    <message>
        <source>Database</source>
        <translation>Database</translation>
    </message>
    <message>
        <source>Import Passkey</source>
        <translation>Importer tilgangsnøkkel</translation>
    </message>
    <message>
        <source>Import</source>
        <translation>Importer</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Avbryt</translation>
    </message>
    <message>
        <source>Entry</source>
        <translation>Oppføring</translation>
    </message>
    <message>
        <source>Create new entry</source>
        <translation>Opprett ny oppføring</translation>
    </message>
    <message>
        <source>Relying Party: %1</source>
        <translation>Tiltrodd part: %1</translation>
    </message>
    <message>
        <source>Import the following passkey:</source>
        <translation>Importer følgende tilgangsnøkkel:</translation>
    </message>
    <message>
        <source>Import the following passkey to this entry:</source>
        <translation>Importer følgende tilgangsnøkkel til denne oppføringen:</translation>
    </message>
    <message>
        <source>Default passkeys group (Imported Passkeys)</source>
        <translation>Standardgruppe for tilgangsnøkler (importerte tilgangsnøkler)</translation>
    </message>
</context>
<context>
    <name>PasskeyImporter</name>
    <message>
        <source>Passkey file</source>
        <translation>Tilgangsnøkkelfil</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>Alle filer</translation>
    </message>
    <message>
        <source>Cannot open file</source>
        <translation>Kan ikke åpne fil</translation>
    </message>
    <message>
        <source>Cannot open file &quot;%1&quot; for reading.</source>
        <translation>Kan ikke åpne filen &quot;%1&quot; for lesing.</translation>
    </message>
    <message>
        <source>Cannot import passkey file &quot;%1&quot;. Data is missing.</source>
        <translation>Kan ikke importere tilgangsnøkkelfil &quot;%1&quot;. Data mangler.</translation>
    </message>
    <message>
        <source>Cannot import passkey file &quot;%1&quot;.
The following data is missing:
%2</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Cannot import passkey file &quot;%1&quot;. Private key is missing or malformed.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Open Passkey File</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Passkey Import Failed</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>PasswordEditWidget</name>
    <message>
        <source>Enter password:</source>
        <translation>Angi passord:</translation>
    </message>
    <message>
        <source>Password field</source>
        <translation>Passord felt</translation>
    </message>
    <message>
        <source>Confirm password:</source>
        <translation>Bekreft passord:</translation>
    </message>
    <message>
        <source>Repeat password field</source>
        <translation>Felt gjenta passord</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Passord</translation>
    </message>
    <message>
        <source>Add Password</source>
        <translation>Legg til passord</translation>
    </message>
    <message>
        <source>Change Password</source>
        <translation>Endre passord</translation>
    </message>
    <message>
        <source>Remove Password</source>
        <translation>Fjern passord</translation>
    </message>
    <message>
        <source>Password set, click to change or remove</source>
        <translation>Passord er satt, klikk for å endre eller fjerne</translation>
    </message>
    <message>
        <source>&lt;p&gt;A password is the primary method for securing your database.&lt;/p&gt;&lt;p&gt;Good passwords are long and unique. KeePassXC can generate one for you.&lt;/p&gt;</source>
        <translation>&lt;p&gt;Et passord er den primære metoden for å sikre databasen.&lt;/p&gt;&lt;p&gt;Gode passord er lange og unike. KeePassXC kan opprette et for deg.&lt;/p&gt;</translation>
    </message>
    <message>
        <source>Passwords do not match.</source>
        <translation>Passordene er ikke like.</translation>
    </message>
</context>
<context>
    <name>PasswordGeneratorWidget</name>
    <message>
        <source>Generate Password</source>
        <translation>Opprett passord</translation>
    </message>
    <message>
        <source>strength</source>
        <comment>Password strength</comment>
        <translation>styrke</translation>
    </message>
    <message>
        <source>entropy</source>
        <translation>entropi</translation>
    </message>
    <message>
        <source>Generated password</source>
        <translation>Opprettet passord</translation>
    </message>
    <message>
        <source>%p%</source>
        <translation>%p%</translation>
    </message>
    <message>
        <source>Regenerate password</source>
        <translation>Regenerer passord</translation>
    </message>
    <message>
        <source>Copy password</source>
        <translation>Kopier passord</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Passord</translation>
    </message>
    <message>
        <source>&amp;Length:</source>
        <translation>&amp;Lengde</translation>
    </message>
    <message>
        <source>Password length</source>
        <translation>Passord lengde</translation>
    </message>
    <message>
        <source>Switch to advanced mode</source>
        <translation>Bytt til avansert modus</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>Avansert</translation>
    </message>
    <message>
        <source>Character Types</source>
        <translation>Tegntyper</translation>
    </message>
    <message>
        <source>Special characters</source>
        <translation>Spesialtegn</translation>
    </message>
    <message>
        <source>Quotes</source>
        <translation>Anførselstegn</translation>
    </message>
    <message>
        <source>Punctuation</source>
        <translation>Skilletegn</translation>
    </message>
    <message>
        <source>Dashes and Slashes</source>
        <translation>Streker og skråstreker</translation>
    </message>
    <message>
        <source>Upper-case letters</source>
        <translation>Store bokstaver</translation>
    </message>
    <message>
        <source>Numbers</source>
        <translation>Tall</translation>
    </message>
    <message>
        <source>Lower-case letters</source>
        <translation>Små bokstaver</translation>
    </message>
    <message>
        <source>Math Symbols</source>
        <translation>Matematiske symboler</translation>
    </message>
    <message>
        <source>Extended ASCII</source>
        <translation>Utvida ASCII</translation>
    </message>
    <message>
        <source>Braces</source>
        <translation>Parenteser</translation>
    </message>
    <message>
        <source>Do not include:</source>
        <translation>Ikke ta med:</translation>
    </message>
    <message>
        <source>Additional characters to use for the generated password</source>
        <translation>Flere tegn som skal brukes i det oppretta passordet</translation>
    </message>
    <message>
        <source>Additional characters</source>
        <translation>Flere tegn</translation>
    </message>
    <message>
        <source>Add non-hex letters to &quot;do not include&quot; list</source>
        <translation>Legg til ikke-heksadesimale bokstaver</translation>
    </message>
    <message>
        <source>Hex Passwords</source>
        <translation>Hexadesimale passord</translation>
    </message>
    <message>
        <source>Hex</source>
        <translation>Hex</translation>
    </message>
    <message>
        <source>Character set to exclude from generated password</source>
        <translation>Tegnsett som skal ekskluderes fra opprettet passord</translation>
    </message>
    <message>
        <source>Excluded characters</source>
        <translation>Ekskluderte tegn</translation>
    </message>
    <message>
        <source>Also choose from:</source>
        <translation>Velg også mellom:</translation>
    </message>
    <message>
        <source>Exclude look-alike characters</source>
        <translation>Ekskluder tegn som er nesten makne</translation>
    </message>
    <message>
        <source>Pick characters from every group</source>
        <translation>Velg tegn fra hver gruppe</translation>
    </message>
    <message>
        <source>Passphrase</source>
        <translation>Passordfrase</translation>
    </message>
    <message>
        <source>Word Separator:</source>
        <translation>Ord-skilletegn:</translation>
    </message>
    <message>
        <source>Wordlist:</source>
        <translation>Ordliste:</translation>
    </message>
    <message>
        <source>Word Count:</source>
        <translation>Antall ord:</translation>
    </message>
    <message>
        <source>Word Case:</source>
        <translation>Ord-format:</translation>
    </message>
    <message>
        <source>Delete selected wordlist</source>
        <translation>Slett den valgte ordlisten</translation>
    </message>
    <message>
        <source>Add custom wordlist</source>
        <translation>Legg til egendefinert ordliste</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Lukk</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
    <message>
        <source>Apply Password</source>
        <translation>Bruk passord</translation>
    </message>
    <message>
        <source>Regenerate password (%1)</source>
        <translation>Regenerer passord (%1)</translation>
    </message>
    <message>
        <source>lower case</source>
        <translation>små bokstaver</translation>
    </message>
    <message>
        <source>UPPER CASE</source>
        <translation>STORE BOKSTAVER</translation>
    </message>
    <message>
        <source>Title Case</source>
        <translation>Overskrifts-format</translation>
    </message>
    <message>
        <source>(SYSTEM)</source>
        <translation>(SYSTEM)</translation>
    </message>
    <message>
        <source>Entropy: %1 bit</source>
        <translation>Entropi: %1 bit</translation>
    </message>
    <message>
        <source>Password Quality: %1</source>
        <translation>Passordkvalitet: %1</translation>
    </message>
    <message>
        <source>Poor</source>
        <comment>Password quality</comment>
        <translation>Dårlig</translation>
    </message>
    <message>
        <source>Weak</source>
        <comment>Password quality</comment>
        <translation>Svak</translation>
    </message>
    <message>
        <source>Good</source>
        <comment>Password quality</comment>
        <translation>Bra</translation>
    </message>
    <message>
        <source>Excellent</source>
        <comment>Password quality</comment>
        <translation>Utmerket</translation>
    </message>
    <message>
        <source>Failed to delete wordlist</source>
        <translation>Kan ikke slette ordlisten</translation>
    </message>
    <message>
        <source>Wordlists</source>
        <translation>Ordlister</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>Alle filer</translation>
    </message>
    <message>
        <source>Select Custom Wordlist</source>
        <translation>Velg egendefinert ordliste</translation>
    </message>
    <message>
        <source>Overwrite Wordlist?</source>
        <translation>Vil du erstatte ordlisten?</translation>
    </message>
    <message>
        <source>Wordlist &quot;%1&quot; already exists as a custom wordlist.
Do you want to overwrite it?</source>
        <translation>Ordlisten &quot;%1&quot; finnes allerede som en egendefinert ordliste.
Vil du erstatte den?</translation>
    </message>
    <message>
        <source>Failed to add wordlist</source>
        <translation>Kan ikke legge til ordliste</translation>
    </message>
    <message>
        <source>Logograms</source>
        <translation>Logogram</translation>
    </message>
    <message>
        <source>Special Characters</source>
        <translation>Spesialtegn</translation>
    </message>
    <message>
        <source>passwordLength</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Characters: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>MIXED case</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Excluded characters: &quot;0&quot;, &quot;1&quot;, &quot;l&quot;, &quot;I&quot;, &quot;O&quot;, &quot;|&quot;, &quot;﹒&quot;, &quot;B&quot;, &quot;8&quot;, &quot;G&quot;, &quot;6&quot;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Warning: the chosen wordlist is smaller than the minimum recommended size!</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Confirm Remove Wordlist</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Do you really want to remove the wordlist &quot;%1&quot;?</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>PasswordWidget</name>
    <message>
        <source>Passwords do not match</source>
        <translation>Passordene er ikke like</translation>
    </message>
    <message>
        <source>Passwords match so far</source>
        <translation>Passordmatch så langt</translation>
    </message>
    <message>
        <source>Toggle Password (%1)</source>
        <translation>Vis/skjul passord (%1)</translation>
    </message>
    <message>
        <source>Generate Password (%1)</source>
        <translation>Opprette passord (%1)</translation>
    </message>
    <message>
        <source>Warning: Caps Lock enabled!</source>
        <translation>Advarsel: Store bokstaver aktivert!</translation>
    </message>
    <message>
        <source>Quality: %1</source>
        <translation>Kvalitet: %1</translation>
    </message>
    <message>
        <source>Poor</source>
        <comment>Password quality</comment>
        <translation>Dårlig</translation>
    </message>
    <message>
        <source>Weak</source>
        <comment>Password quality</comment>
        <translation>Svak</translation>
    </message>
    <message>
        <source>Good</source>
        <comment>Password quality</comment>
        <translation>Bra</translation>
    </message>
    <message>
        <source>Excellent</source>
        <comment>Password quality</comment>
        <translation>Utmerket</translation>
    </message>
    <message>
        <source>Toggle password visibility using Control + H. Open the password generator using Control + G.</source>
        <translation>Vis/skjul synlig passord med Control + H. Åpne passordgeneratoren med Control + G.</translation>
    </message>
</context>
<context>
    <name>PickcharsDialog</name>
    <message>
        <source>KeePassXC - Pick Characters</source>
        <translation>KeePassXC - Velg tegn</translation>
    </message>
    <message>
        <source>Select characters to type, navigate with arrow keys, Ctrl + S submits.</source>
        <translation>Velg tegn du vil skrive inn, naviger med piltastene, Ctrl + S sender.</translation>
    </message>
    <message>
        <source>Press &amp;Tab between characters</source>
        <translation>Trykk &amp;Tab mellom tegn</translation>
    </message>
</context>
<context>
    <name>PreviewEntryAttachmentsDialog</name>
    <message>
        <source>Form</source>
        <translation>Skjema</translation>
    </message>
    <message>
        <source>Preview: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Save…</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>QMessageBox</name>
    <message>
        <source>Overwrite</source>
        <translation>Erstatte</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Slett</translation>
    </message>
    <message>
        <source>Move</source>
        <translation>Flytt</translation>
    </message>
    <message>
        <source>Empty</source>
        <translation>Tom</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Fjern</translation>
    </message>
    <message>
        <source>Skip</source>
        <translation>Hopp over</translation>
    </message>
    <message>
        <source>Disable</source>
        <translation>Deaktiver</translation>
    </message>
    <message>
        <source>Merge</source>
        <translation>Slå sammen</translation>
    </message>
    <message>
        <source>Continue</source>
        <translation>Fortsett</translation>
    </message>
    <message>
        <source>Continue with weak password</source>
        <translation>Fortsett med svakt passord</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Database not opened</source>
        <translation>Database ikke åpnet</translation>
    </message>
    <message>
        <source>Database hash not available</source>
        <translation>Database-hash er ikke tilgjengelig</translation>
    </message>
    <message>
        <source>Client public key not received</source>
        <translation>Klients offentlige nøkkel ikke mottatt</translation>
    </message>
    <message>
        <source>Cannot decrypt message</source>
        <translation>Kan ikke dekryptere melding</translation>
    </message>
    <message>
        <source>Action cancelled or denied</source>
        <translation>Handlingen er kansellert eller avvist</translation>
    </message>
    <message>
        <source>Message encryption failed.</source>
        <translation>Meldingskryptering mislyktes.</translation>
    </message>
    <message>
        <source>KeePassXC association failed, try again</source>
        <translation>Assosiering av KeePassXC mislyktes, prøv igjen</translation>
    </message>
    <message>
        <source>Encryption key is not recognized</source>
        <translation>Krypteringsnøkkel er ikke gjenkjent</translation>
    </message>
    <message>
        <source>Incorrect action</source>
        <translation>Feil handling</translation>
    </message>
    <message>
        <source>Empty message received</source>
        <translation>Tom melding mottatt</translation>
    </message>
    <message>
        <source>No URL provided</source>
        <translation>Ingen URL oppgitt</translation>
    </message>
    <message>
        <source>No logins found</source>
        <translation>Ingen innlogginger funnet</translation>
    </message>
    <message>
        <source>No groups found</source>
        <translation>Ingen grupper funnet</translation>
    </message>
    <message>
        <source>Cannot create new group</source>
        <translation>Kan ikke opprette ny gruppe</translation>
    </message>
    <message>
        <source>No valid UUID provided</source>
        <translation>Ingen gyldig UUID er angitt</translation>
    </message>
    <message>
        <source>Username or password cannot contain references</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Unknown error</source>
        <translation>Ukjent feil</translation>
    </message>
    <message>
        <source>Browser Integration</source>
        <translation>Nettlesertillegg</translation>
    </message>
    <message>
        <source>Browser Plugin Failure</source>
        <translation>Feil i nettleser-plugin</translation>
    </message>
    <message>
        <source>Could not save the native messaging script file for %1.</source>
        <translation>Kunne ikke lagre skriptfilen til den innebygde meldingsformidleren for %1.</translation>
    </message>
    <message>
        <source>Username for the entry.</source>
        <translation>Brukernavn for oppføringen.</translation>
    </message>
    <message>
        <source>username</source>
        <translation>brukernavn</translation>
    </message>
    <message>
        <source>URL for the entry.</source>
        <translation>URL for oppføringa.</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>Notes for the entry.</source>
        <translation>Notater til oppføringen.</translation>
    </message>
    <message>
        <source>Notes</source>
        <translation>Notater</translation>
    </message>
    <message>
        <source>Prompt for the entry&apos;s password.</source>
        <translation>Spør etter oppføringens passord.</translation>
    </message>
    <message>
        <source>Generate a password for the entry.</source>
        <translation>Opprett et passord i oppføringa.</translation>
    </message>
    <message>
        <source>Add a new entry to a database.</source>
        <translation>Legg til en ny oppføring til en database.</translation>
    </message>
    <message>
        <source>Path of the entry to add.</source>
        <translation>Sti til oppføringa som skal legges til.</translation>
    </message>
    <message>
        <source>Cannot generate a password and prompt at the same time.</source>
        <translation>Kan ikke opprette et passord og spørre samtidig.</translation>
    </message>
    <message>
        <source>Could not create entry with path %1.</source>
        <translation>Kan ikke opprette oppføring med bane %1.</translation>
    </message>
    <message>
        <source>Enter password for new entry: </source>
        <translation>Skriv inn passord for ny oppføring: </translation>
    </message>
    <message>
        <source>Writing the database failed %1.</source>
        <translation>Kunne ikke skrive databasen %1.</translation>
    </message>
    <message>
        <source>Successfully added entry %1.</source>
        <translation>Oppføringen %1 ble lagt til.</translation>
    </message>
    <message>
        <source>Adds a new group to a database.</source>
        <translation>Legger til en ny gruppe i en database.</translation>
    </message>
    <message>
        <source>Path of the group to add.</source>
        <translation>Sti til gruppen som skal legges til.</translation>
    </message>
    <message>
        <source>Group %1 already exists!</source>
        <translation>Gruppen %1 finnes allerede!</translation>
    </message>
    <message>
        <source>Group %1 not found.</source>
        <translation>Gruppen %1 ikke funnet.</translation>
    </message>
    <message>
        <source>Successfully added group %1.</source>
        <translation>Gruppen %1 er lagt til.</translation>
    </message>
    <message>
        <source>Check if any passwords have been publicly leaked. FILENAME must be the path of a file listing SHA-1 hashes of leaked passwords in HIBP format, as available from https://haveibeenpwned.com/Passwords.</source>
        <translation>Sjekk om noen passord er offentlig lekket. FILNAVN må være stien til en fil som viser SHA-1-hashkoder med lekkede passord i HIBP-format, som er tilgjengelig fra https://haveibeenpwned.com/Passwords.</translation>
    </message>
    <message>
        <source>FILENAME</source>
        <translation>FILNAVN</translation>
    </message>
    <message>
        <source>Path to okon-cli to search a formatted HIBP file</source>
        <translation>Sti til &apos;okon-cli&apos; for å søke i en formatert HIBP-fil</translation>
    </message>
    <message>
        <source>okon-cli</source>
        <translation>okon-cli</translation>
    </message>
    <message>
        <source>Analyze passwords for weaknesses and problems.</source>
        <translation>Analyser passord for svakheter og problemer.</translation>
    </message>
    <message>
        <source>Cannot find HIBP file: %1</source>
        <translation>Finner ikke HIBP-fil: %1</translation>
    </message>
    <message>
        <source>Evaluating database entries using okon…</source>
        <translation>Evaluerer databaseoppføringer ved hjelp av okon...</translation>
    </message>
    <message>
        <source>Failed to open HIBP file %1: %2</source>
        <translation>Kunne ikke åpne HIBP-filen %1: %2</translation>
    </message>
    <message>
        <source>Evaluating database entries against HIBP file, this will take a while…</source>
        <translation>Evaluerer oppføringer i databasen mot HIBP-fil, dette vil ta en stund…</translation>
    </message>
    <message numerus="yes">
        <source>Password for &apos;%1&apos; has been leaked %2 time(s)!</source>
        <translation><numerusform>Passordet for %1 er lekket %2 gang!</numerusform><numerusform>Passordet for %1 er lekket %2 ganger!</numerusform></translation>
    </message>
    <message>
        <source>Password for &apos;%1&apos; has been leaked!</source>
        <translation>Passordene for %1 er lekket.</translation>
    </message>
    <message>
        <source>Export an attachment of an entry.</source>
        <translation>Eksportere et vedlegg for en oppføring.</translation>
    </message>
    <message>
        <source>Path of the entry with the target attachment.</source>
        <translation>Stien til oppføringen med mål-vedlegget.</translation>
    </message>
    <message>
        <source>Name of the attachment to be exported.</source>
        <translation>Navn på vedlegget som skal eksporteres.</translation>
    </message>
    <message>
        <source>Path to which the attachment should be exported.</source>
        <translation>Sti som vedlegget skal eksporteres til.</translation>
    </message>
    <message>
        <source>Could not find entry with path %1.</source>
        <translation>Kunne ikke finne oppføring med bane %1.</translation>
    </message>
    <message>
        <source>Could not find attachment with name %1.</source>
        <translation>Finner ikke vedlegg med navnet %1.</translation>
    </message>
    <message>
        <source>No export target given. Please use &apos;--stdout&apos; or specify an &apos;export-file&apos;.</source>
        <translation>Eksport-mål er ikke angitt. Bruk &apos;--stdout&apos;, eller angi en eksportfil.</translation>
    </message>
    <message>
        <source>Could not open output file %1.</source>
        <translation>Kunne ikke åpne utdatafilen %1.</translation>
    </message>
    <message>
        <source>Successfully exported attachment %1 of entry %2 to %3.</source>
        <translation>Eksporterte vedlegg %1 i oppføring %2 til %3.</translation>
    </message>
    <message>
        <source>Overwrite existing attachments.</source>
        <translation>Erstatt eksisterende vedlegg.</translation>
    </message>
    <message>
        <source>Imports an attachment to an entry.</source>
        <translation>Importerer et vedlegg til en oppføring.</translation>
    </message>
    <message>
        <source>Path of the entry.</source>
        <translation>Sti til oppføringen.</translation>
    </message>
    <message>
        <source>Name of the attachment to be added.</source>
        <translation>Navn på vedlegget som skal legges til.</translation>
    </message>
    <message>
        <source>Path of the attachment to be imported.</source>
        <translation>Sti til vedlegget som skal importeres.</translation>
    </message>
    <message>
        <source>Attachment %1 already exists for entry %2.</source>
        <translation>Vedlegg %1 finnes allerede for oppføring %2.</translation>
    </message>
    <message>
        <source>Could not open attachment file %1.</source>
        <translation>Kunne ikke åpne fil-vedlegget %1.</translation>
    </message>
    <message>
        <source>Successfully imported attachment %1 as %2 to entry %3.</source>
        <translation>Importerte vedlegg %1 som %2 til oppføring %3.</translation>
    </message>
    <message>
        <source>Remove an attachment of an entry.</source>
        <translation>Fjern et vedlegg i en oppføring.</translation>
    </message>
    <message>
        <source>Name of the attachment to be removed.</source>
        <translation>Navn på vedlegget som skal fjernes.</translation>
    </message>
    <message>
        <source>Successfully removed attachment %1 from entry %2.</source>
        <translation>Vedlegg %1 er fjernet fra oppføring %2.</translation>
    </message>
    <message>
        <source>Copy the given attribute to the clipboard. Defaults to &quot;password&quot; if not specified.</source>
        <comment>Don't translate &quot;password&quot;, it refers to the attribute.</comment>
        <translation>Kopier det angitte attributtet til utklippstavlen. Standard er &quot;passord&quot; hvis det ikke er angitt.</translation>
    </message>
    <message>
        <source>Copy the current TOTP to the clipboard (equivalent to &quot;-a totp&quot;).</source>
        <translation>Kopier gjeldende TOTP til utklippstavlen (tilsvarende &quot;-a totp&quot;).</translation>
    </message>
    <message>
        <source>Must match only one entry, otherwise a list of possible matches is shown.</source>
        <translation>Må bare samsvare med én oppføring, ellers vises en liste over mulige treff.</translation>
    </message>
    <message>
        <source>Copy an entry&apos;s attribute to the clipboard.</source>
        <translation>Kopier oppførings-attributtet til utklippstavlen.</translation>
    </message>
    <message>
        <source>Path of the entry to clip.</source>
        <comment>clip = copy to clipboard</comment>
        <translation>Sti til oppføring som skal klippes ut.</translation>
    </message>
    <message>
        <source>Timeout before clearing the clipboard (default is %1 seconds, set to 0 for unlimited).</source>
        <translation>Tidsavbrudd for tømming av utklippstavlen (standardinnstilling er %1 sekunder, sett til 0 for ubegrenset).</translation>
    </message>
    <message>
        <source>Invalid timeout value %1.</source>
        <translation>Ugyldig tidsavbruddsverdi %1.</translation>
    </message>
    <message>
        <source>Multiple entries matching:</source>
        <translation>Flere oppføringer samsvarer:</translation>
    </message>
    <message>
        <source>Using matching entry: %1</source>
        <translation>Bruker samsvarende oppføring: %1</translation>
    </message>
    <message>
        <source>Entry %1 not found.</source>
        <translation>Oppføring %1 ikke funnet.</translation>
    </message>
    <message>
        <source>ERROR: Please specify one of --attribute or --totp, not both.</source>
        <translation>FEIL: Angi ett av --attributt eller --totp, ikke begge.</translation>
    </message>
    <message>
        <source>Entry with path %1 has no TOTP set up.</source>
        <translation>Oppføring med bane %1 har ingen TOTP konfigurert.</translation>
    </message>
    <message>
        <source>ERROR: attribute %1 is ambiguous, it matches %2.</source>
        <translation>FEIL: Attributtet %1 er tvetydig, det samsvarer med %2.</translation>
    </message>
    <message>
        <source>Attribute &quot;%1&quot; not found.</source>
        <translation>Attributtet %1 er ikke funnet.</translation>
    </message>
    <message>
        <source>Entry&apos;s &quot;%1&quot; attribute copied to the clipboard!</source>
        <translation>Oppføringens &quot;%1&quot;-attributt er kopiert til utklippstavlen!</translation>
    </message>
    <message numerus="yes">
        <source>Clearing the clipboard in %1 second(s)...</source>
        <translation><numerusform>Tømmer utklippstavlen på %1 sekund...</numerusform><numerusform>Tømmer utklippstavlen på %1 sekunder...</numerusform></translation>
    </message>
    <message>
        <source>Clipboard cleared!</source>
        <translation>Utklippstavle ryddet!</translation>
    </message>
    <message>
        <source>Close the currently opened database.</source>
        <translation>Lukk den åpne databasen.</translation>
    </message>
    <message>
        <source>Display this help.</source>
        <translation>Vis denne hjelpen.</translation>
    </message>
    <message>
        <source>Silence password prompt and other secondary outputs.</source>
        <translation>Slå av passordforespørsel og andre sekundære utdata.</translation>
    </message>
    <message>
        <source>Key file of the database.</source>
        <translation>Nøkkelfil til databasen.</translation>
    </message>
    <message>
        <source>path</source>
        <translation>sti</translation>
    </message>
    <message>
        <source>Deactivate password key for the database.</source>
        <translation>Deaktiver passordnøkkel for databasen.</translation>
    </message>
    <message>
        <source>Yubikey slot and optional serial used to access the database (e.g., 1:7370001).</source>
        <translation>Yubikey-spor og valgfritt serienummer som brukes til å få tilgang til databasen (f.eks. 1:7370001).</translation>
    </message>
    <message>
        <source>slot[:serial]</source>
        <translation>spor[:serienr]</translation>
    </message>
    <message>
        <source>Missing positional argument(s).</source>
        <translation>Mangler posisjons-argument(er).</translation>
    </message>
    <message>
        <source>Too many arguments provided.</source>
        <translation>Det er angitt for mange argumenter.</translation>
    </message>
    <message>
        <source>Path of the database.</source>
        <translation>Database-sti.</translation>
    </message>
    <message>
        <source>Target decryption time in MS for the database.</source>
        <translation>Ønsket dekrypteringstid i ms for databasen.</translation>
    </message>
    <message>
        <source>time</source>
        <translation>tid</translation>
    </message>
    <message>
        <source>Set the key file for the database.</source>
        <translation>Angi nøkkelfilen for databasen.</translation>
    </message>
    <message>
        <source>Set a password for the database.</source>
        <translation>Angi et passord for databasen.</translation>
    </message>
    <message>
        <source>Create a new database.</source>
        <translation>Opprett en ny database.</translation>
    </message>
    <message>
        <source>Invalid decryption time %1.</source>
        <translation>Ugyldig dekrypteringstid %1.</translation>
    </message>
    <message>
        <source>Target decryption time must be between %1 and %2.</source>
        <translation>Ønsket dekrypteringstid må være mellom %1 og %2.</translation>
    </message>
    <message>
        <source>Failed to set database password.</source>
        <translation>Kunne ikke sette databasepassord.</translation>
    </message>
    <message>
        <source>Loading the key file failed</source>
        <translation>Innlasting av nøkkelfilen mislyktes</translation>
    </message>
    <message>
        <source>No key is set. Aborting database creation.</source>
        <translation>Ingen nøkkel er angitt. Avbryter oppretting av database.</translation>
    </message>
    <message>
        <source>Benchmarking key derivation function for %1ms delay.</source>
        <translation>Måle %1ms forsinkelse på nøkkelavledningsfunksjonen</translation>
    </message>
    <message>
        <source>Setting %1 rounds for key derivation function.</source>
        <translation>Stille inn %1 runder for nøkkelavledningsfunksjonen.</translation>
    </message>
    <message>
        <source>error while setting database key derivation settings.</source>
        <translation>Feil ved innstilling av nøkkelavledning for databasen.</translation>
    </message>
    <message>
        <source>File %1 already exists.</source>
        <translation>Filen %1 eksisterer allerede.</translation>
    </message>
    <message>
        <source>Failed to save the database: %1.</source>
        <translation>Kunne ikke lagre databasen: %1.</translation>
    </message>
    <message>
        <source>Successfully created new database.</source>
        <translation>Opprettet ny database.</translation>
    </message>
    <message>
        <source>Unset the password for the database.</source>
        <translation>Slett passordet for databasen.</translation>
    </message>
    <message>
        <source>Unset the key file for the database.</source>
        <translation>Slett nøkkelfilen for databasen.</translation>
    </message>
    <message>
        <source>Edit a database.</source>
        <translation>Redigere en database.</translation>
    </message>
    <message>
        <source>Cannot use %1 and %2 at the same time.</source>
        <translation>Kan ikke bruke %1 og %2 samtidig.</translation>
    </message>
    <message>
        <source>Could not change the database key.</source>
        <translation>Kunne ikke endre databasenøkkelen.</translation>
    </message>
    <message>
        <source>Database was not modified.</source>
        <translation>Databasen ble ikke endret.</translation>
    </message>
    <message>
        <source>Writing the database failed: %1</source>
        <translation>Skriving til databasen mislyktes: %1</translation>
    </message>
    <message>
        <source>Successfully edited the database.</source>
        <translation>Vellykket redigering av databasen.</translation>
    </message>
    <message>
        <source>Cannot remove password: The database does not have a password.</source>
        <translation>Kan ikke fjerne passordet: Databasen har ikke passord.</translation>
    </message>
    <message>
        <source>Cannot remove file key: The database does not have a file key.</source>
        <translation>Kan ikke fjerne nøkkelfilen: Databasen har ikke en nøkkelfil.</translation>
    </message>
    <message>
        <source>Loading the new key file failed: %1</source>
        <translation>Lasting av den nye nøkkelfilen mislyktes: %1</translation>
    </message>
    <message>
        <source>Found unexpected Key type %1</source>
        <translation>Fant uventet nøkkeltype %1</translation>
    </message>
    <message>
        <source>Cannot remove all the keys from a database.</source>
        <translation>Kan ikke fjerne alle nøklene fra en database.</translation>
    </message>
    <message>
        <source>Show a database&apos;s information.</source>
        <translation>Vise informasjon om en database.</translation>
    </message>
    <message>
        <source>UUID: </source>
        <translation>UUID: </translation>
    </message>
    <message>
        <source>Name: </source>
        <translation>Navn: </translation>
    </message>
    <message>
        <source>Description: </source>
        <translation>Beskrivelse: </translation>
    </message>
    <message>
        <source>Cipher: </source>
        <translation>Chiffer:</translation>
    </message>
    <message>
        <source>KDF: </source>
        <translation>KDF: </translation>
    </message>
    <message>
        <source>Recycle bin is enabled.</source>
        <translation>Papirkurven er aktivert.</translation>
    </message>
    <message>
        <source>Recycle bin is not enabled.</source>
        <translation>Papirkurven er ikke aktivert.</translation>
    </message>
    <message>
        <source>Location</source>
        <translation>Plassering</translation>
    </message>
    <message>
        <source>Database created</source>
        <translation>Database opprettet</translation>
    </message>
    <message>
        <source>Last saved</source>
        <translation>Sist lagret</translation>
    </message>
    <message>
        <source>Unsaved changes</source>
        <translation>Ikke lagrede endringer</translation>
    </message>
    <message>
        <source>yes</source>
        <translation>ja</translation>
    </message>
    <message>
        <source>no</source>
        <translation>nei</translation>
    </message>
    <message>
        <source>Number of groups</source>
        <translation>Antall grupper</translation>
    </message>
    <message>
        <source>Number of entries</source>
        <translation>Antall oppføringer</translation>
    </message>
    <message>
        <source>Number of expired entries</source>
        <translation>Antall utløpte oppføringer</translation>
    </message>
    <message>
        <source>Unique passwords</source>
        <translation>Unike passord</translation>
    </message>
    <message>
        <source>Non-unique passwords</source>
        <translation>Dupliserte passord</translation>
    </message>
    <message>
        <source>Maximum password reuse</source>
        <translation>Maksimal gjenbruk av passord</translation>
    </message>
    <message>
        <source>Number of short passwords</source>
        <translation>Antall korte passord</translation>
    </message>
    <message>
        <source>Number of weak passwords</source>
        <translation>Antall svake passord</translation>
    </message>
    <message>
        <source>Entries excluded from reports</source>
        <translation>Oppføringer som er utelatt fra rapporter</translation>
    </message>
    <message>
        <source>Average password length</source>
        <translation>Gjennomsnittlig passordlengde</translation>
    </message>
    <message>
        <source>Number of passkeys</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Entries with TOTP setup</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Word count for the diceware passphrase.</source>
        <translation>Antall ord i ordpassordfrasen.</translation>
    </message>
    <message>
        <source>count</source>
        <comment>CLI parameter</comment>
        <translation>Antall</translation>
    </message>
    <message>
        <source>Wordlist for the diceware generator.
[Default: EFF English]</source>
        <translation>Ordliste for ordgeneratoren.
[Standard: EFF engelsk]</translation>
    </message>
    <message>
        <source>Generate a new random diceware passphrase.</source>
        <translation>Opprett en ny tilfeldig ordpassordfrase.</translation>
    </message>
    <message>
        <source>Invalid word count %1</source>
        <translation>Ugyldig ordtelling %1</translation>
    </message>
    <message>
        <source>Title for the entry.</source>
        <translation>Tittel for oppføringa.</translation>
    </message>
    <message>
        <source>title</source>
        <translation>tittel</translation>
    </message>
    <message>
        <source>Edit an entry.</source>
        <translation>Rediger oppføring.</translation>
    </message>
    <message>
        <source>Path of the entry to edit.</source>
        <translation>Sti til oppføringa som skal redigeres.</translation>
    </message>
    <message>
        <source>Not changing any field for entry %1.</source>
        <translation>Endrer ingen felt for oppføring %1.</translation>
    </message>
    <message>
        <source>Enter new password for entry: </source>
        <translation>Skriv inn nytt passord for oppføring: </translation>
    </message>
    <message>
        <source>Successfully edited entry %1.</source>
        <translation>Endring av oppføring %1 er fullført.</translation>
    </message>
    <message>
        <source>Perform advanced analysis on the password.</source>
        <translation>Utfør avansert analyse på passordet.</translation>
    </message>
    <message>
        <source>Password for which to estimate the entropy.</source>
        <translation>Passord for beregning av entropi.</translation>
    </message>
    <message>
        <source>Estimate the entropy of a password.</source>
        <translation>Beregn entropien til et passord.</translation>
    </message>
    <message>
        <source>Length %1</source>
        <translation>Lengde %1</translation>
    </message>
    <message>
        <source>Entropy %1</source>
        <translation>Entropi %1</translation>
    </message>
    <message>
        <source>Log10 %1</source>
        <translation>Log10 %1</translation>
    </message>
    <message>
        <source>Multi-word extra bits %1</source>
        <translation>Multi-ord ekstra biter %1</translation>
    </message>
    <message>
        <source>Type: Bruteforce</source>
        <translation>Type: Rå kraft</translation>
    </message>
    <message>
        <source>Type: Dictionary</source>
        <translation>Type: Ordliste</translation>
    </message>
    <message>
        <source>Type: Dict+Leet</source>
        <translation>Type: Ordliste + erstatning</translation>
    </message>
    <message>
        <source>Type: User Words</source>
        <translation>Type: Egendefinerte ord</translation>
    </message>
    <message>
        <source>Type: User+Leet</source>
        <translation>Type: Egendefinerte ord + erstatning</translation>
    </message>
    <message>
        <source>Type: Repeated</source>
        <translation>Type: Gjentatt</translation>
    </message>
    <message>
        <source>Type: Sequence</source>
        <translation>Type: Sekvens</translation>
    </message>
    <message>
        <source>Type: Spatial</source>
        <translation>Type: Mellomrom</translation>
    </message>
    <message>
        <source>Type: Date</source>
        <translation>Type: Dato</translation>
    </message>
    <message>
        <source>Type: Bruteforce(Rep)</source>
        <translation>Type: Rå kraft (rep.)</translation>
    </message>
    <message>
        <source>Type: Dictionary(Rep)</source>
        <translation>Type: Ordliste (rep.)</translation>
    </message>
    <message>
        <source>Type: Dict+Leet(Rep)</source>
        <translation>Type: Ordliste + erstatning (rep.)</translation>
    </message>
    <message>
        <source>Type: User Words(Rep)</source>
        <translation>Type: Egendefinerte ord (rep.)</translation>
    </message>
    <message>
        <source>Type: User+Leet(Rep)</source>
        <translation>Type: Egendefinerte ord + erstatning (rep.)</translation>
    </message>
    <message>
        <source>Type: Repeated(Rep)</source>
        <translation>Type: Gjentatte (rep.)</translation>
    </message>
    <message>
        <source>Type: Sequence(Rep)</source>
        <translation>Type: Sekvens (rep.)</translation>
    </message>
    <message>
        <source>Type: Spatial(Rep)</source>
        <translation>Type: Mellomrom (rep.)</translation>
    </message>
    <message>
        <source>Type: Date(Rep)</source>
        <translation>Type: Dato (rep.)</translation>
    </message>
    <message>
        <source>Type: Unknown (%1)</source>
        <translation>Type: Ukjent (%1)</translation>
    </message>
    <message>
        <source>Entropy %1 (%2)</source>
        <translation>Entropi %1 (%2)</translation>
    </message>
    <message>
        <source>*** Password length (%1) != sum of length of parts (%2) ***</source>
        <translation>*** Passordlengde (%1) != summen av lengden på deler (%2) ***</translation>
    </message>
    <message>
        <source>Exit interactive mode.</source>
        <translation>Avslutt interaktiv modus.</translation>
    </message>
    <message>
        <source>Exports the content of a database to standard output in the specified format.</source>
        <translation>Eksporterer innholdet av en database til standard output i det angitte formatet.</translation>
    </message>
    <message>
        <source>Unable to export database to XML: %1</source>
        <translation>Kan ikke eksportere databasen til XML: %1</translation>
    </message>
    <message>
        <source>Unsupported format %1</source>
        <translation>Ikke støttet format %1</translation>
    </message>
    <message>
        <source>Length of the generated password</source>
        <translation>Lengden på det oppretta passordet</translation>
    </message>
    <message>
        <source>length</source>
        <translation>lengde</translation>
    </message>
    <message>
        <source>Use lowercase characters</source>
        <translation>Bruk små bokstaver</translation>
    </message>
    <message>
        <source>Use uppercase characters</source>
        <translation>Bruk store bokstaver</translation>
    </message>
    <message>
        <source>Use numbers</source>
        <translation>Bruk tall</translation>
    </message>
    <message>
        <source>Use special characters</source>
        <translation>Bruk spesialtegn</translation>
    </message>
    <message>
        <source>Use extended ASCII</source>
        <translation>Bruk utvidet ASCII</translation>
    </message>
    <message>
        <source>Exclude character set</source>
        <translation>Ekskluder tegnsett</translation>
    </message>
    <message>
        <source>chars</source>
        <translation>tegn</translation>
    </message>
    <message>
        <source>Use custom character set</source>
        <translation>Bruk egendefinert tegnsett</translation>
    </message>
    <message>
        <source>Exclude similar looking characters</source>
        <translation>Ekskluder tegn som ser like ut</translation>
    </message>
    <message>
        <source>Include characters from every selected group</source>
        <translation>Inkluder tegn fra alle valgte grupper</translation>
    </message>
    <message>
        <source>Generate a new random password.</source>
        <translation>Opprett et nytt tilfeldig passord.</translation>
    </message>
    <message>
        <source>Invalid password length %1</source>
        <translation>Ugyldig passordlengde %1</translation>
    </message>
    <message>
        <source>Invalid password generator after applying all options</source>
        <translation>Ugyldig passordgenerator etter bruk av alle alternativer</translation>
    </message>
    <message>
        <source>Display command help.</source>
        <translation>Vis hjelp for kommandoer.</translation>
    </message>
    <message>
        <source>Available commands:</source>
        <translation>Tilgjengelige kommandoer:</translation>
    </message>
    <message>
        <source>Import the contents of an XML database.</source>
        <translation>Importer innholdet av en XML-database.</translation>
    </message>
    <message>
        <source>Path of the XML database export.</source>
        <translation>Sti til XML-databaseeksporten.</translation>
    </message>
    <message>
        <source>Path of the new database.</source>
        <translation>Sti til den nye databasen.</translation>
    </message>
    <message>
        <source>Unable to import XML database: %1</source>
        <translation>Kan ikke importere XML-database: %1</translation>
    </message>
    <message>
        <source>Successfully imported database.</source>
        <translation>Databasen er importert.</translation>
    </message>
    <message>
        <source>Unknown command %1</source>
        <translation>Ukjent kommando %1</translation>
    </message>
    <message>
        <source>

Available commands:
</source>
        <translation>

Tilgjengelige kommandoer:
</translation>
    </message>
    <message>
        <source>Name of the command to execute.</source>
        <translation>Navn på kommandoen som skal utføres.</translation>
    </message>
    <message>
        <source>Displays debugging information.</source>
        <translation>Viser feilsøkingsinformasjon.</translation>
    </message>
    <message>
        <source>Invalid command %1.</source>
        <translation>Ugyldig kommando %1.</translation>
    </message>
    <message>
        <source>Recursively list the elements of the group.</source>
        <translation>List opp elementene i gruppen rekursivt.</translation>
    </message>
    <message>
        <source>Flattens the output to single lines.</source>
        <translation>Flater ut output til enkle linjer.</translation>
    </message>
    <message>
        <source>List database entries.</source>
        <translation>Liste databaseoppføringer.</translation>
    </message>
    <message>
        <source>Path of the group to list. Default is /</source>
        <translation>Sti til gruppen som skal listes. Standardinnstilling er /</translation>
    </message>
    <message>
        <source>Cannot find group %1.</source>
        <translation>Kan ikke finne gruppe %1 .</translation>
    </message>
    <message>
        <source>Use the same credentials for both database files.</source>
        <translation>Bruk samme identifikasjon til begge databasefilene.</translation>
    </message>
    <message>
        <source>Key file of the database to merge from.</source>
        <translation>Nøkkelfil til databasen det skal slås sammen fra.</translation>
    </message>
    <message>
        <source>Deactivate password key for the database to merge from.</source>
        <translation>Deaktiver passordnøkkelen til databasen det skal flettes fra.</translation>
    </message>
    <message>
        <source>Only print the changes detected by the merge operation.</source>
        <translation>Bare skriv ut endringene som er oppdaget av fletteoperasjonen.</translation>
    </message>
    <message>
        <source>Yubikey slot for the second database.</source>
        <translation>Yubikey-spor for den andre databasen.</translation>
    </message>
    <message>
        <source>slot</source>
        <translation>spor</translation>
    </message>
    <message>
        <source>Merge two databases.</source>
        <translation>Slå sammen to databaser.</translation>
    </message>
    <message>
        <source>Path of the database to merge from.</source>
        <translation>Sti til databasen det skal slås sammen fra.</translation>
    </message>
    <message>
        <source>Error reading merge file:
%1</source>
        <translation>Feil ved lesing av flettefil:
%1</translation>
    </message>
    <message>
        <source>Unable to save database to file : %1</source>
        <translation>Kan ikke lagre databasen til fil : %1</translation>
    </message>
    <message>
        <source>Successfully merged %1 into %2.</source>
        <translation>Slått sammen %1 inn i %2.</translation>
    </message>
    <message>
        <source>Database was not modified by merge operation.</source>
        <translation>Databasen ble ikke endret av fletteoperasjonen.</translation>
    </message>
    <message>
        <source>Moves an entry to a new group.</source>
        <translation>Flytter en oppføring til en ny gruppe.</translation>
    </message>
    <message>
        <source>Path of the entry to move.</source>
        <translation>Sti til oppføringen som skal flyttes.</translation>
    </message>
    <message>
        <source>Path of the destination group.</source>
        <translation>Sti til målgruppen.</translation>
    </message>
    <message>
        <source>Could not find group with path %1.</source>
        <translation>Kunne ikke finne gruppe med sti %1.</translation>
    </message>
    <message>
        <source>Entry is already in group %1.</source>
        <translation>Oppføringen er allerede i gruppen %1.</translation>
    </message>
    <message>
        <source>Successfully moved entry %1 to group %2.</source>
        <translation>Flyttet oppføring %1 til gruppen %2.</translation>
    </message>
    <message>
        <source>Open a database.</source>
        <translation>Åpne en database.</translation>
    </message>
    <message>
        <source>Path of the entry to remove.</source>
        <translation>Sti til oppføring som skal fjernes.</translation>
    </message>
    <message>
        <source>Unable to save database to file: %1</source>
        <translation>Kan ikke lagre databasen til fil: %1</translation>
    </message>
    <message>
        <source>Successfully recycled entry %1.</source>
        <translation>Resirkulerte oppføring %1.</translation>
    </message>
    <message>
        <source>Successfully deleted entry %1.</source>
        <translation>Slettet oppføring %1.</translation>
    </message>
    <message>
        <source>Path of the group to remove.</source>
        <translation>Sti til gruppen som skal fjernes.</translation>
    </message>
    <message>
        <source>Cannot remove root group from database.</source>
        <translation>Kan ikke fjerne rotgruppe fra database.</translation>
    </message>
    <message>
        <source>Successfully recycled group %1.</source>
        <translation>Resirkulerte gruppe %1.</translation>
    </message>
    <message>
        <source>Successfully deleted group %1.</source>
        <translation>Slettet gruppe %1.</translation>
    </message>
    <message>
        <source>Find entries quickly.</source>
        <translation>Finn oppføring fort.</translation>
    </message>
    <message>
        <source>Search term.</source>
        <translation>Søkeord.</translation>
    </message>
    <message>
        <source>Show the entry&apos;s current TOTP.</source>
        <translation>Vis oppføringens gjeldende TOTP.</translation>
    </message>
    <message>
        <source>Show the protected attributes in clear text.</source>
        <translation>Vis de beskyttede attributtene i klartekst.</translation>
    </message>
    <message>
        <source>Show all the attributes of the entry.</source>
        <translation>Vis alle attributtene for oppføringen.</translation>
    </message>
    <message>
        <source>Show the attachments of the entry.</source>
        <translation>Vise vedleggene til oppføringen.</translation>
    </message>
    <message>
        <source>Names of the attributes to show. This option can be specified more than once, with each attribute shown one-per-line in the given order. If no attributes are specified, a summary of the default attributes is given.</source>
        <translation>Navn på attributtene som skal vises. Dette alternativet kan spesifiseres mer enn en gang, med hvert attributt vist ett per linje i den oppgitte rekkefølgen. Hvis ingen attributter er oppgitt, blir det gitt en oppsummering av standardattributtene.</translation>
    </message>
    <message>
        <source>attribute</source>
        <translation>attributt</translation>
    </message>
    <message>
        <source>Show an entry&apos;s information.</source>
        <translation>Vis informasjon i oppføringen.</translation>
    </message>
    <message>
        <source>Name of the entry to show.</source>
        <translation>Navn på oppføring som skal vises</translation>
    </message>
    <message>
        <source>ERROR: unknown attribute %1.</source>
        <translation>FEIL: Ukjent attributt %1.</translation>
    </message>
    <message>
        <source>No attachments present.</source>
        <translation>Det finnes ingen vedlegg.</translation>
    </message>
    <message>
        <source>Attachments:</source>
        <translation>Vedlegg:</translation>
    </message>
    <message>
        <source>Failed to open database file %1: not found</source>
        <translation>Kunne ikke åpne databasefilen %1: ble ikke funnet</translation>
    </message>
    <message>
        <source>Failed to open database file %1: not a plain file</source>
        <translation>Kunne ikke åpne databasefilen %1: ikke en vanlig fil</translation>
    </message>
    <message>
        <source>Failed to open database file %1: not readable</source>
        <translation>Kunne ikke åpne databasefilen %1: kan ikke leses</translation>
    </message>
    <message>
        <source>Enter password to unlock %1: </source>
        <translation>Skriv inn passord for å låse opp %1:</translation>
    </message>
    <message>
        <source>Failed to load key file %1: %2</source>
        <translation>Kunne ikke laste nøkkelfilen %1: %2</translation>
    </message>
    <message>
        <source>WARNING: You are using an old key file format which KeePassXC may
stop supporting in the future.

Please consider generating a new key file.</source>
        <translation>ADVARSEL: Du bruker et gammelt nøkkelfilformat som KeePassXC kan
slutte å støtte i fremtiden.

Vurder å lage en ny nøkkelfil.</translation>
    </message>
    <message>
        <source>Invalid YubiKey slot %1</source>
        <translation>Ugyldig YubiKey-spor %1</translation>
    </message>
    <message>
        <source>Invalid YubiKey serial %1</source>
        <translation>Ugyldig YubiKey-serienummer %1</translation>
    </message>
    <message>
        <source>Please present or touch your YubiKey to continue.</source>
        <translation>Koble til eller berør YubiKey for å fortsette.</translation>
    </message>
    <message>
        <source>Enter password to encrypt database (optional): </source>
        <translation>Skriv inn passord for å kryptere databasen (valgfritt): </translation>
    </message>
    <message>
        <source>Do you want to create a database with an empty password? [y/N]: </source>
        <translation>Vil du opprette en database med tomt passord? [y/N]: </translation>
    </message>
    <message>
        <source>Repeat password: </source>
        <translation>Gjenta passord: </translation>
    </message>
    <message>
        <source>Error: Passwords do not match.</source>
        <translation>Feil: Passordene stemmer ikke overens.</translation>
    </message>
    <message>
        <source>No program defined for clipboard manipulation</source>
        <translation>Ingen program definert for manipulering av utklippstavle</translation>
    </message>
    <message>
        <source>All clipping programs failed. Tried %1
</source>
        <translation>Alle beskjæringsprogrammer mislyktes. Prøvde %1
</translation>
    </message>
    <message>
        <source>Creating KeyFile %1 failed: %2</source>
        <translation>Oppretting av nøkkelfil %1 mislyktes: %2</translation>
    </message>
    <message>
        <source>Loading KeyFile %1 failed: %2</source>
        <translation>Innlasting av nøkkelfil %1 mislyktes: %2</translation>
    </message>
    <message>
        <source>HIBP file, line %1: parse error</source>
        <translation>HIBP-fil, linje %1: lesefeil</translation>
    </message>
    <message>
        <source>To use okon, you must provide a post-processed file (e.g. file.okon)</source>
        <translation>Hvis du vil bruke okon så må du oppgi en etterbehandlet fil (f.eks. fil.okon)</translation>
    </message>
    <message>
        <source>Could not start okon process: %1</source>
        <translation>Kunne ikke starte okon-prosess: %1</translation>
    </message>
    <message>
        <source>Error: okon process did not finish</source>
        <translation>Feil: okon-prosessen ble ikke fullført</translation>
    </message>
    <message>
        <source>Failed to load okon processed database: %1</source>
        <translation>Innlasting av okon-behandlet database feilet: %1</translation>
    </message>
    <message>
        <source>Very weak password</source>
        <translation>Veldig svakt passord</translation>
    </message>
    <message>
        <source>Password entropy is %1 bits</source>
        <translation>Passord-entropi er %1 bit</translation>
    </message>
    <message>
        <source>Weak password</source>
        <translation>Svakt passord</translation>
    </message>
    <message>
        <source>Used in %1/%2</source>
        <translation>Brukes i %1/%2</translation>
    </message>
    <message numerus="yes">
        <source>Password is used %1 time(s)</source>
        <translation><numerusform>Passordet brukes %1 gang</numerusform><numerusform>Passordet brukes %1 ganger</numerusform></translation>
    </message>
    <message>
        <source>Password has expired</source>
        <translation>Passordet er utløpt</translation>
    </message>
    <message>
        <source>Password expiry was %1</source>
        <translation>Passordets utløpstidspunktet var %1</translation>
    </message>
    <message>
        <source>Password expires on %1</source>
        <translation>Passordet utløper %1</translation>
    </message>
    <message>
        <source>Password is about to expire</source>
        <translation>Passordet er i ferd med å utløpe</translation>
    </message>
    <message numerus="yes">
        <source>Password expires in %1 day(s)</source>
        <translation><numerusform>Passordet utløper om %1 dag</numerusform><numerusform>Passordet utløper om %1 dager</numerusform></translation>
    </message>
    <message>
        <source>Password will expire soon</source>
        <translation>Passordet utløper snart</translation>
    </message>
    <message>
        <source>Version %1</source>
        <translation>Versjon %1</translation>
    </message>
    <message>
        <source>Build Type: %1</source>
        <translation>Byggetype: %1</translation>
    </message>
    <message>
        <source>Revision: %1</source>
        <translation>Revisjon: %1</translation>
    </message>
    <message>
        <source>Distribution: %1</source>
        <translation>Distribusjon: %1</translation>
    </message>
    <message>
        <source>Debugging mode is disabled.</source>
        <translation>Feilsøkingsmodus er deaktivert.</translation>
    </message>
    <message>
        <source>Debugging mode is enabled.</source>
        <translation>Feilsøkingsmodus er aktivert.</translation>
    </message>
    <message>
        <source>Operating system: %1
CPU architecture: %2
Kernel: %3 %4</source>
        <translation>Operativsystem: %1
CPU-arkitektur: %2
Kjerne: %3 %4</translation>
    </message>
    <message>
        <source>Auto-Type</source>
        <translation>Autoskriv</translation>
    </message>
    <message>
        <source>SSH Agent</source>
        <translation>SSH-agent</translation>
    </message>
    <message>
        <source>KeeShare</source>
        <translation>KeeShare</translation>
    </message>
    <message>
        <source>Quick Unlock</source>
        <translation>Rask opplåsing</translation>
    </message>
    <message>
        <source>Secret Service Integration</source>
        <translation>Integrasjon av &apos;Secret Service&apos;</translation>
    </message>
    <message>
        <source>Enabled extensions:</source>
        <translation>Aktive utvidelser:</translation>
    </message>
    <message numerus="yes">
        <source>over %1 year(s)</source>
        <translation><numerusform>over %1 år</numerusform><numerusform>over %1 år</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>about %1 month(s)</source>
        <translation><numerusform>omtrent %1 måned</numerusform><numerusform>omtrent %1 måneder</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>%1 week(s)</source>
        <translation><numerusform>%1 uke</numerusform><numerusform>%1 uker</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>%1 day(s)</source>
        <translation><numerusform>%1 dag</numerusform><numerusform>%1 dager</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>%1 hour(s)</source>
        <translation><numerusform>%1 time</numerusform><numerusform>%1 timer</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>%1 minute(s)</source>
        <translation><numerusform>%1 minutt</numerusform><numerusform>%1 minutter</numerusform></translation>
    </message>
    <message>
        <source>Botan library must be at least %1, found %2.%3.%4</source>
        <translation>Botanbiblioteket må være minst %1, funnet %2.%3.%4</translation>
    </message>
    <message>
        <source>Cryptographic libraries:</source>
        <translation>Kryptografiske bibliotek:</translation>
    </message>
    <message>
        <source>AES (%1 rounds)</source>
        <translation>AES (%1 runder)</translation>
    </message>
    <message>
        <source>Argon2%1 (%2 rounds, %3 KB)</source>
        <translation>Argon2%1 (%2 runder, %3 kB)</translation>
    </message>
    <message>
        <source>SymmetricCipher::init: Invalid cipher mode.</source>
        <translation>SymmetricCipher::init: Ugyldig chiffermodus.</translation>
    </message>
    <message>
        <source>SymmetricCipher::init: Invalid IV size of %1 for %2.</source>
        <translation>SymmetricCipher::init: Ugyldig IV-størrelse på %1 for %2.</translation>
    </message>
    <message>
        <source>Cipher not initialized prior to use.</source>
        <translation>Chiffer ble ikke klargjort før bruk.</translation>
    </message>
    <message>
        <source>Cannot process 0 length data.</source>
        <translation>Kan ikke behandle data med 0 lengde.</translation>
    </message>
    <message>
        <source>unknown executable (DBus address %1)</source>
        <translation>ukjent kjørbar fil (DBus-adresse %1)</translation>
    </message>
    <message>
        <source>%1 (invalid executable path)</source>
        <translation>%1 (ugyldig kjørbar sti)</translation>
    </message>
    <message>
        <source>NULL device</source>
        <translation>NULL-enhet</translation>
    </message>
    <message>
        <source>error reading from device</source>
        <translation>Feil ved lesing fra enhet</translation>
    </message>
    <message>
        <source>file empty</source>
        <translation>fil tom</translation>
    </message>
    <message>
        <source>AES 256-bit</source>
        <translation>AES 256-bit</translation>
    </message>
    <message>
        <source>Twofish 256-bit</source>
        <translation>Twofish 256-bit</translation>
    </message>
    <message>
        <source>ChaCha20 256-bit</source>
        <translation>ChaCha20 256-biter</translation>
    </message>
    <message>
        <source>Argon2d (KDBX 4 – recommended)</source>
        <translation>Argon2d (KDBX 4 – anbefalt)</translation>
    </message>
    <message>
        <source>Argon2id (KDBX 4)</source>
        <translation>Argon2id (KDBX 4)</translation>
    </message>
    <message>
        <source>AES-KDF (KDBX 4)</source>
        <translation>AES-KDF (KDBX 4)</translation>
    </message>
    <message>
        <source>AES-KDF (KDBX 3)</source>
        <translation>AES-KDF (KDBX 3)</translation>
    </message>
    <message>
        <source>Existing single-instance lock file is invalid. Launching new instance.</source>
        <translation>Eksisterende enbrukermodus låsefil er ugyldig. Starter ny instans.</translation>
    </message>
    <message>
        <source>The lock file could not be created. Single-instance mode disabled.</source>
        <translation>Låsefilen kunne ikke opprettes. Enbrukermodus deaktivert.</translation>
    </message>
    <message numerus="yes">
        <source>Clearing the clipboard in %1 second(s)…</source>
        <translation><numerusform>Tømmer utklippstavlen på %1 sekund...</numerusform><numerusform>Tømmer utklippstavlen på %1 sekunder...</numerusform></translation>
    </message>
    <message>
        <source>Group</source>
        <translation>Gruppe</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>Tittel</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>Brukernavn</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Passord</translation>
    </message>
    <message>
        <source>TOTP</source>
        <translation>TOTP</translation>
    </message>
    <message>
        <source>Icon</source>
        <translation>Ikon</translation>
    </message>
    <message>
        <source>Last Modified</source>
        <translation>Sist endra</translation>
    </message>
    <message>
        <source>Created</source>
        <translation>Opprettet</translation>
    </message>
    <message>
        <source>Benchmark %1 delay</source>
        <translation>Måling av %1 forsinkelse</translation>
    </message>
    <message numerus="yes">
        <source>%1 ms</source>
        <comment>milliseconds</comment>
        <translation><numerusform>%1 ms</numerusform><numerusform>%1 ms</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>%1 s</source>
        <comment>seconds</comment>
        <translation><numerusform>%1 s</numerusform><numerusform>%1 s</numerusform></translation>
    </message>
    <message>
        <source>Do you really want to move entry &quot;%1&quot; to the recycle bin?</source>
        <translation>Vil du virkelig flytte oppføring %1 til papirkurven?</translation>
    </message>
    <message numerus="yes">
        <source>Do you really want to move %n entry(s) to the recycle bin?</source>
        <translation><numerusform>Vil du virkelig flytte %n oppføring til papirkurven?</numerusform><numerusform>Vil du virkelig flytte %n oppføringer til papirkurven?</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>Entry &quot;%1&quot; has %2 reference(s). Do you want to overwrite references with values, skip this entry, or delete anyway?</source>
        <translation><numerusform>Oppføringen %1 har %2 referanse. Vil du overskrive referansen med verdi, hoppe over denne oppføringen eller slette likevel?</numerusform><numerusform>Oppføringen %1 har %2 referanser. Vil du overskrive referansene med verdier, hoppe over denne oppføringen eller slette likevel?</numerusform></translation>
    </message>
    <message>
        <source>User name</source>
        <translation>Brukernavn</translation>
    </message>
    <message>
        <source>Browser Statistics</source>
        <translation>Nettleserstatistikk</translation>
    </message>
    <message>
        <source>Health Check</source>
        <translation>Helsesjekk</translation>
    </message>
    <message>
        <source>HIBP</source>
        <translation>HIBP</translation>
    </message>
    <message>
        <source>Statistics</source>
        <translation>Statistikk</translation>
    </message>
    <message>
        <source>Unsupported key file version: %1</source>
        <translation>Støtter ikke nøkkelfil-versjon: %1</translation>
    </message>
    <message>
        <source>Checksum mismatch! Key file may be corrupt.</source>
        <translation>Sjekksum samsvarer ikke! Nøkkelfilen kan være skadet.</translation>
    </message>
    <message>
        <source>Unexpected key file data! Key file may be corrupt.</source>
        <translation>Uventede nøkkelfil-data! Nøkkelfilen kan være skadet.</translation>
    </message>
    <message>
        <source>KeePassXC - cross-platform password manager</source>
        <translation>KeePassXC - multiplattform passordbehandler</translation>
    </message>
    <message>
        <source>filenames of the password databases to open (*.kdbx)</source>
        <translation>filnavn på passorddatabasene som skal åpnes (*.kdbx)</translation>
    </message>
    <message>
        <source>path to a custom config file</source>
        <translation>sti til tilpasset konfigurasjonsfil</translation>
    </message>
    <message>
        <source>path to a custom local config file</source>
        <translation>Sti til en egendefinert lokal konfigurasjonsfil</translation>
    </message>
    <message>
        <source>lock all open databases</source>
        <translation>låse alle åpne databaser</translation>
    </message>
    <message>
        <source>key file of the database</source>
        <translation>database-nøkkelfil</translation>
    </message>
    <message>
        <source>read password of the database from stdin</source>
        <translation>les database-passord fra &apos;stdin&apos;</translation>
    </message>
    <message>
        <source>Database failed to lock.</source>
        <translation>Databasen kunne ikke låses.</translation>
    </message>
    <message>
        <source>Another instance of KeePassXC is already running.</source>
        <translation>En annen instans av KeePassXC kjører allerede.</translation>
    </message>
    <message>
        <source>KeePassXC is not running. No open database to lock</source>
        <translation>KeePassXC kjører ikke. Ingen åpen database å låse</translation>
    </message>
    <message>
        <source>Fatal error while testing the cryptographic functions.</source>
        <translation>Alvorlig feil ved testing av de kryptografiske funksjonene.</translation>
    </message>
    <message>
        <source>KeePassXC - Error</source>
        <translation>KeePassXC - Feil</translation>
    </message>
    <message>
        <source>Database password: </source>
        <translation>Databasepassord: </translation>
    </message>
    <message>
        <source>Invalid Settings</source>
        <comment>TOTP</comment>
        <translation>Ugyldige innstillinger</translation>
    </message>
    <message>
        <source>Invalid Key</source>
        <comment>TOTP</comment>
        <translation>Ugyldig nøkkel</translation>
    </message>
    <message>
        <source>Failed to create Windows Hello credential.</source>
        <translation>Kan ikke opprette Windows Hello-identifikasjon.</translation>
    </message>
    <message>
        <source>Failed to sign challenge using Windows Hello.</source>
        <translation>Signering av utfordring ved hjelp av Windows Hello feilet.</translation>
    </message>
    <message>
        <source>Warning: Failed to block screenshot capture on a top-level window.</source>
        <translation>Advarsel: Kunne ikke blokkere skjermbildeopptak i et vindu på øverste nivå.</translation>
    </message>
    <message>
        <source>Invalid Cipher</source>
        <translation>Ugyldig chiffer</translation>
    </message>
    <message>
        <source>Invalid KDF</source>
        <translation>Ugyldig KDF</translation>
    </message>
    <message>
        <source>Access to all entries is denied</source>
        <translation>Tilgang til alle oppføringer nektes</translation>
    </message>
    <message>
        <source>allow screenshots and app recording (Windows/macOS)</source>
        <translation>tillat skjermdumper og app-opptak (Windows/macOS)</translation>
    </message>
    <message>
        <source>Set the key file for the database.
This option is deprecated, use --set-key-file instead.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Databases have been locked.</source>
        <translation>Databasen har blitt låst.</translation>
    </message>
    <message>
        <source>Attestation not supported</source>
        <translation>Attestasjon støttes ikke</translation>
    </message>
    <message>
        <source>Credential is excluded</source>
        <translation>Identifikasjon er utelatt</translation>
    </message>
    <message>
        <source>Passkeys request canceled</source>
        <translation>Forespørsel om tilgangsnøkler kansellert</translation>
    </message>
    <message>
        <source>Invalid user verification</source>
        <translation>Ugyldig brukerverifikasjon</translation>
    </message>
    <message>
        <source>Empty public key</source>
        <translation>Tom offentlig nøkkel</translation>
    </message>
    <message>
        <source>Invalid URL provided</source>
        <translation>Angitt URL er ugyldig</translation>
    </message>
    <message>
        <source>Passkeys</source>
        <translation>Tilgangsnøkler</translation>
    </message>
    <message>
        <source>AES initialization failed</source>
        <translation>AES-initialisering mislyktes</translation>
    </message>
    <message>
        <source>AES encrypt failed</source>
        <translation>AES-kryptering mislyktes</translation>
    </message>
    <message>
        <source>Failed to store in Linux Keyring</source>
        <translation>Kunne ikke lagre i Linux-nøkkelring</translation>
    </message>
    <message>
        <source>Polkit returned an error: %1</source>
        <translation>Polkit returnerte en feil: %1</translation>
    </message>
    <message>
        <source>Could not locate key in keyring</source>
        <translation>Kunne ikke finne nøkkel i nøkkelring</translation>
    </message>
    <message>
        <source>Could not read key in keyring</source>
        <translation>Kunne ikke lese nøkkel i nøkkelring</translation>
    </message>
    <message>
        <source>AES decrypt failed</source>
        <translation>AES-dekryptering mislyktes</translation>
    </message>
    <message>
        <source>No Polkit authentication agent was available</source>
        <translation>Ingen Polkit-autentiseringsagent var tilgjengelig</translation>
    </message>
    <message>
        <source>Polkit authorization failed</source>
        <translation>Polkit-autorisasjon mislyktes</translation>
    </message>
    <message>
        <source>No Quick Unlock provider is available</source>
        <translation>Ingen hurtigopplåsings-tjeneste er tilgjengelig</translation>
    </message>
    <message>
        <source>Failed to init KeePassXC crypto.</source>
        <translation>Initialisering av KeePassXC krypto feilet.</translation>
    </message>
    <message>
        <source>Failed to encrypt key data.</source>
        <translation>Kryptering av nøkkeldata feilet.</translation>
    </message>
    <message>
        <source>Failed to get Windows Hello credential.</source>
        <translation>Henting av identifikasjon fra Windows Hello feilet.</translation>
    </message>
    <message>
        <source>Failed to decrypt key data.</source>
        <translation>Dekryptering av nøkkeldata feilet.</translation>
    </message>
    <message>
        <source>Origin is empty or not allowed</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Effective domain is not a valid domain</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Origin and RP ID do not match</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>No supported algorithms were provided</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Wait for timer to expire</source>
        <translation>Vent til tidtakeren utløper</translation>
    </message>
    <message>
        <source>Challenge is shorter than required minimum length</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>user.id does not match the required length</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Favorite</source>
        <comment>Tag for favorite entries</comment>
        <translation>Favoritt</translation>
    </message>
    <message>
        <source>File does not exist.</source>
        <translation>Filen eksisterer ikke.</translation>
    </message>
    <message>
        <source>Cannot open file: %1</source>
        <translation>Kunne ikke åpne fil: %1</translation>
    </message>
    <message>
        <source>Cannot parse file: %1 at position %2</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Failed to decrypt json file: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Invalid encKeyValidation field</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Invalid cipher list within encKeyValidation field</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Wrong password</source>
        <translation>Feil passord</translation>
    </message>
    <message>
        <source>Invalid encrypted data field</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Invalid cipher list within encrypted data field</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Cannot initialize cipher</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Cannot decrypt data</source>
        <translation>Kan ikke dekryptere data</translation>
    </message>
    <message>
        <source>Bitwarden Import</source>
        <translation>Importer fra Bitwarden</translation>
    </message>
    <message>
        <source>Archived</source>
        <comment>Tag for archived entries</comment>
        <translation>Arkivert</translation>
    </message>
    <message>
        <source>Invalid 1PUX file format: Not a valid ZIP file.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Invalid 1PUX file format: Missing export.data</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>1Password Import</source>
        <translation>Importer fra 1Password</translation>
    </message>
    <message>
        <source>Enter Shortcut</source>
        <translation>Skriv in snarvei</translation>
    </message>
    <message>
        <source>Action</source>
        <translation>Handling</translation>
    </message>
    <message>
        <source>Shortcuts</source>
        <translation>Snarveier</translation>
    </message>
    <message>
        <source>Unknown passkeys error</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Invalid KDF iterations, cannot decrypt json file</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Unsupported format, ensure your Bitwarden export is password-protected</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Only PBKDF and Argon2 are supported, cannot decrypt json file</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Hardware Keys</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Passkey</source>
        <translation>Tilgangsnøkkel</translation>
    </message>
    <message>
        <source>Reset Shortcuts</source>
        <translation>Tilbakestill snarveier</translation>
    </message>
    <message>
        <source>Double click an action to change its shortcut</source>
        <translation>Dobbeltrykk på en handling for å endre snarveien</translation>
    </message>
    <message>
        <source>Filter...</source>
        <translation>Filtrer...</translation>
    </message>
    <message>
        <source>Shortcut Conflict</source>
        <translation>Snarveikonflikt</translation>
    </message>
    <message>
        <source>Shortcut %1 conflicts with &apos;%2&apos;. Overwrite shortcut?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Format to use when exporting. Available choices are &apos;xml&apos;, &apos;csv&apos; or &apos;html&apos;. Defaults to &apos;xml&apos;.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>malformed string, possible unescaped delimiter</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>missing closing delimiter</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>%1, row: %2, column: %3</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Encrypted files are not supported.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Proton Pass Import</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Tags</source>
        <translation>Tagger</translation>
    </message>
    <message>
        <source>start minimized to the system tray</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Warning: the chosen wordlist is smaller than the minimum recommended size!</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Invalid Step</source>
        <comment>TOTP</comment>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Invalid Digits</source>
        <comment>TOTP</comment>
        <translation type="unfinished"/>
    </message>
    <message numerus="yes">
        <source>%1 character(s)</source>
        <translation type="unfinished"><numerusform></numerusform><numerusform></numerusform></translation>
    </message>
    <message>
        <source>Do you really want to permanently delete the entry &quot;%1&quot;?</source>
        <translation type="unfinished"/>
    </message>
    <message numerus="yes">
        <source>Do you really want to permanently delete %n entry(s)?</source>
        <translation type="unfinished"><numerusform></numerusform><numerusform></numerusform></translation>
    </message>
    <message numerus="yes">
        <source>Confirm Delete Entry(s)</source>
        <translation type="unfinished"><numerusform></numerusform><numerusform></numerusform></translation>
    </message>
    <message numerus="yes">
        <source>Confirm Recycle Entry(s)</source>
        <translation type="unfinished"><numerusform></numerusform><numerusform></numerusform></translation>
    </message>
    <message>
        <source>Confirm Delete Plugin Data</source>
        <translation type="unfinished"/>
    </message>
    <message numerus="yes">
        <source>Delete plugin data from the selected entry(s)?</source>
        <translation type="unfinished"><numerusform></numerusform><numerusform></numerusform></translation>
    </message>
    <message>
        <source>Confirm Replace Entry References</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>QtIOCompressor</name>
    <message>
        <source>Internal zlib error when compressing: </source>
        <translation>Intern zlib-feil under pakking:</translation>
    </message>
    <message>
        <source>Error writing to underlying device: </source>
        <translation>Feil ved skriving til underliggende enhet:</translation>
    </message>
    <message>
        <source>Error opening underlying device: </source>
        <translation>Feil ved åpning av underliggende enhet:</translation>
    </message>
    <message>
        <source>Error reading data from underlying device: </source>
        <translation>Feil ved lesing av data fra underliggende enhet:</translation>
    </message>
    <message>
        <source>Internal zlib error when decompressing: </source>
        <translation>Intern zlib-feil under utpakking:</translation>
    </message>
</context>
<context>
    <name>QtIOCompressor::open</name>
    <message>
        <source>The gzip format not supported in this version of zlib.</source>
        <translation>Gzip-formatet er ikke støttet i denne versjonen av zlib.</translation>
    </message>
    <message>
        <source>Internal zlib error: </source>
        <translation>Intern zlib-feil:</translation>
    </message>
</context>
<context>
    <name>RemoteDesktopPortal</name>
    <message>
        <source>Remote desktop session is not active</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Session closed</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>User cancelled the interaction</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>User interaction was canceled for unknown reason</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Remote desktop session handle does not match expected path</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>RemoteHandler</name>
    <message>
        <source>Command `%1` did not finish in time. Process was killed.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Failed to upload merged database. Command `%1` did not finish in time. Process was killed.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Invalid download parameters provided.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Command `%1` failed to download database.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Invalid database pointer or upload parameters provided.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Command `%1` exited with status code: %2</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Failed to upload merged database. Command `%1` exited with status code: %2</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>ReportsWidgetBrowserStatistics</name>
    <message>
        <source>Double-click entries to edit.</source>
        <translation>Dobbeltklikk på oppføringer som skal endres.</translation>
    </message>
    <message>
        <source>List of entry URLs</source>
        <translation>Liste over URL&apos;er i oppføringer</translation>
    </message>
    <message>
        <source>Entry has no URLs set</source>
        <translation>Oppføringen har ingen registrerte URL&apos;er</translation>
    </message>
    <message>
        <source>Allowed URLs</source>
        <translation>Tillatte URL&apos;er</translation>
    </message>
    <message>
        <source>Entry has no Browser Integration settings</source>
        <translation>Oppføringen har ingen innstillinger for nettleserintegrering</translation>
    </message>
    <message>
        <source>Denied URLs</source>
        <translation>Nektede URL-adresser</translation>
    </message>
    <message>
        <source> (Excluded)</source>
        <translation> (Ekskludert)</translation>
    </message>
    <message>
        <source>This entry is being excluded from reports</source>
        <translation>Denne oppføringen utelates fra rapporter</translation>
    </message>
    <message>
        <source>Please wait, browser statistics is being calculated…</source>
        <translation>Vent litt, nettleserstatistikk beregnes…</translation>
    </message>
    <message>
        <source>No entries with a URL, or none has browser extension settings saved.</source>
        <translation>Ingen oppføringer med registrert URL, eller innstillingene for nettleserutvidelse er ikke lagret.</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>Tittel</translation>
    </message>
    <message>
        <source>Path</source>
        <translation>Sti</translation>
    </message>
    <message>
        <source>URLs</source>
        <translation>URL&apos;er</translation>
    </message>
    <message>
        <source>Edit Entry…</source>
        <translation>Endre oppføring…</translation>
    </message>
    <message numerus="yes">
        <source>Delete Entry(s)…</source>
        <translation type="unfinished"><numerusform></numerusform><numerusform>Slett oppføringer...</numerusform></translation>
    </message>
    <message>
        <source>Exclude from reports</source>
        <translation>Utelat fra rapporter</translation>
    </message>
    <message numerus="yes">
        <source>Expire Entry(s)…</source>
        <translation type="unfinished"><numerusform></numerusform><numerusform></numerusform></translation>
    </message>
    <message>
        <source>Only show entries that have a URL</source>
        <translation>Vis bare oppføringer som har en URL</translation>
    </message>
    <message>
        <source>Only show entries that have been explicitly allowed or denied</source>
        <translation>Vis kun oppføringer som har blitt eksplisitt tillatt eller nektet</translation>
    </message>
    <message>
        <source>Show expired entries</source>
        <translation>Vis utløpte oppføringer</translation>
    </message>
    <message>
        <source> (Expired)</source>
        <translation> (Utløpt)</translation>
    </message>
    <message numerus="yes">
        <source>Delete plugin data from Entry(s)…</source>
        <translation type="unfinished"><numerusform></numerusform><numerusform></numerusform></translation>
    </message>
</context>
<context>
    <name>ReportsWidgetHealthcheck</name>
    <message>
        <source>Show expired entries</source>
        <translation>Vis utløpte oppføringer</translation>
    </message>
    <message>
        <source> (Expired)</source>
        <translation> (Utløpt)</translation>
    </message>
    <message>
        <source>Hover over reason to show additional details. Double-click entries to edit.</source>
        <translation>Hold pekeren over årsaken for å vise flere detaljer. Dobbeltklikk på oppføringer for å redigere.</translation>
    </message>
    <message>
        <source>Bad — password must be changed</source>
        <translation>Utilfredsstillende – passordet må endres</translation>
    </message>
    <message>
        <source>Poor — password should be changed</source>
        <translation>Dårlig – passordet bør endres</translation>
    </message>
    <message>
        <source>Weak — consider changing the password</source>
        <translation>Svakt – vurder å endre passordet</translation>
    </message>
    <message>
        <source> (Excluded)</source>
        <translation> (Ekskludert)</translation>
    </message>
    <message>
        <source>This entry is being excluded from reports</source>
        <translation>Denne oppføringen utelates fra rapporter</translation>
    </message>
    <message>
        <source>Please wait, health data is being calculated…</source>
        <translation>Vent litt, tilstandsdata beregnes…</translation>
    </message>
    <message>
        <source>Congratulations, everything is healthy!</source>
        <translation>Gratulerer, alt er tilfredsstillende!</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>Tittel</translation>
    </message>
    <message>
        <source>Path</source>
        <translation>Sti</translation>
    </message>
    <message>
        <source>Score</source>
        <translation>Skår</translation>
    </message>
    <message>
        <source>Reason</source>
        <translation>Årsak</translation>
    </message>
    <message>
        <source>Edit Entry…</source>
        <translation>Endre oppføring…</translation>
    </message>
    <message numerus="yes">
        <source>Delete Entry(s)…</source>
        <translation><numerusform>Slett oppføring...</numerusform><numerusform>Slett oppføringer...</numerusform></translation>
    </message>
    <message>
        <source>Exclude from reports</source>
        <translation>Utelat fra rapporter</translation>
    </message>
    <message numerus="yes">
        <source>Expire Entry(s)…</source>
        <translation type="unfinished"><numerusform></numerusform><numerusform></numerusform></translation>
    </message>
    <message>
        <source>Show entries that have been excluded from reports</source>
        <translation>Vis oppføringer som er ekskluderte fra rapporter</translation>
    </message>
</context>
<context>
    <name>ReportsWidgetHibp</name>
    <message>
        <source>CAUTION: This report requires sending information to the Have I Been Pwned online service (https://haveibeenpwned.com). If you proceed, your database passwords will be cryptographically hashed and the first five characters of those hashes will be sent securely to this service. Your database remains secure and cannot be reconstituted from this information. However, the number of passwords you send and your IP address will be exposed to this service.</source>
        <translation>FORSIKTIG: Denne rapporten krever innsending av informasjon til den elektroniske tjenesten Have I Been Pwned (https://haveibeenpwned.com). Hvis du fortsetter hashes databasepassordene kryptografisk, og de fem første tegnene i disse nøkkelkodene sendes på sikker måte til denne tjenesten. Databasen forblir sikker og kan ikke rekonstrueres ut fra denne informasjonen. Imidlertid vil antall passord du sender og IP-adressen din bli avslørt for denne tjenesten.</translation>
    </message>
    <message>
        <source>Perform Online Analysis</source>
        <translation>Utfør analyse online</translation>
    </message>
    <message>
        <source>Also show entries that have been excluded from reports</source>
        <translation>Vis også oppføringer som er utelatt fra rapporter</translation>
    </message>
    <message>
        <source>This build of KeePassXC does not have network functions. Networking is required to check your passwords against Have I Been Pwned databases.</source>
        <translation>Denne versjonen av KeePassXC har ikke nettverksfunksjoner. Nettverk kreves for å kontrollere passordene dine mot har-jeg-blitt-overvunnet-databaser (HIBP).</translation>
    </message>
    <message>
        <source>Congratulations, no exposed passwords!</source>
        <translation>Gratulerer, ingen eksponerte passord!</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>Tittel</translation>
    </message>
    <message>
        <source>Path</source>
        <translation>Sti</translation>
    </message>
    <message>
        <source>Password exposed…</source>
        <translation>Passord avslørt…</translation>
    </message>
    <message>
        <source> (Excluded)</source>
        <translation> (Ekskludert)</translation>
    </message>
    <message>
        <source>This entry is being excluded from reports</source>
        <translation>Denne oppføringen blir utelatt fra rapporter</translation>
    </message>
    <message>
        <source>once</source>
        <comment>Password exposure amount</comment>
        <translation>en gang</translation>
    </message>
    <message>
        <source>up to 10 times</source>
        <comment>Password exposure amount</comment>
        <translation>opptil 10 ganger</translation>
    </message>
    <message>
        <source>up to 100 times</source>
        <comment>Password exposure amount</comment>
        <translation>opptil 100 ganger</translation>
    </message>
    <message>
        <source>up to 1000 times</source>
        <comment>Password exposure amount</comment>
        <translation>opptil 1.000 ganger</translation>
    </message>
    <message>
        <source>up to 10,000 times</source>
        <comment>Password exposure amount</comment>
        <translation>opptil 10.000 ganger</translation>
    </message>
    <message>
        <source>up to 100,000 times</source>
        <comment>Password exposure amount</comment>
        <translation>opptil 100.000 ganger</translation>
    </message>
    <message>
        <source>up to a million times</source>
        <comment>Password exposure amount</comment>
        <translation>opptil en million ganger</translation>
    </message>
    <message>
        <source>millions of times</source>
        <comment>Password exposure amount</comment>
        <translation>millioner av ganger</translation>
    </message>
    <message>
        <source>Edit Entry…</source>
        <translation>Endre oppføring…</translation>
    </message>
    <message numerus="yes">
        <source>Delete Entry(s)…</source>
        <translation><numerusform>Slett oppføring...</numerusform><numerusform>Slett oppføringer...</numerusform></translation>
    </message>
    <message>
        <source>Exclude from reports</source>
        <translation>Utelat fra rapporter</translation>
    </message>
    <message numerus="yes">
        <source>Expire Entry(s)…</source>
        <translation type="unfinished"><numerusform></numerusform><numerusform></numerusform></translation>
    </message>
</context>
<context>
    <name>ReportsWidgetPasskeys</name>
    <message>
        <source>Export</source>
        <translation>Eksporter</translation>
    </message>
    <message>
        <source>Import</source>
        <translation>Importer</translation>
    </message>
    <message>
        <source>List of entry URLs</source>
        <translation>Liste over URL&apos;er i oppføringer</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>Tittel</translation>
    </message>
    <message>
        <source>Path</source>
        <translation>Sti</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>Brukernavn</translation>
    </message>
    <message>
        <source>URLs</source>
        <translation>URL&apos;er</translation>
    </message>
    <message>
        <source>Edit Entry…</source>
        <translation>Endre oppføring…</translation>
    </message>
    <message numerus="yes">
        <source>Delete Entry(s)…</source>
        <translation><numerusform>Slett oppføring...</numerusform><numerusform>Slett oppføringer...</numerusform></translation>
    </message>
    <message>
        <source>Relying Party</source>
        <translation>Tiltrodd part</translation>
    </message>
    <message>
        <source>Show expired entries</source>
        <translation>Vis utløpte oppføringer</translation>
    </message>
    <message>
        <source> (Expired)</source>
        <translation> (Utløpt)</translation>
    </message>
    <message>
        <source>Export Confirmation</source>
        <translation>Eksportbekreftelse</translation>
    </message>
    <message>
        <source>The passkey file will be vulnerable to theft and unauthorized use, if left unsecured. Are you sure you want to continue?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Please wait, list of entries with passkeys is being updated…</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>No entries with passkeys.</source>
        <translation>Ingen oppføringer med tilgangsnøkler.</translation>
    </message>
</context>
<context>
    <name>ReportsWidgetStatistics</name>
    <message>
        <source>Hover over lines with error icons for further information.</source>
        <translation>Hold pekeren over linjer med advarsels-ikoner for mer informasjon.</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Navn</translation>
    </message>
    <message>
        <source>Value</source>
        <translation>Verdi</translation>
    </message>
    <message>
        <source>Please wait, database statistics are being calculated…</source>
        <translation>Vent litt, databasestatistikk blir beregnet…</translation>
    </message>
    <message>
        <source>Database name</source>
        <translation>Databasenavn</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Beskrivelse</translation>
    </message>
    <message>
        <source>Location</source>
        <translation>Plassering</translation>
    </message>
    <message>
        <source>Database created</source>
        <translation>Database opprettet</translation>
    </message>
    <message>
        <source>Last saved</source>
        <translation>Sist lagret</translation>
    </message>
    <message>
        <source>Unsaved changes</source>
        <translation>Ikke lagrede endringer</translation>
    </message>
    <message>
        <source>yes</source>
        <translation>ja</translation>
    </message>
    <message>
        <source>no</source>
        <translation>nei</translation>
    </message>
    <message>
        <source>The database was modified, but the changes have not yet been saved to disk.</source>
        <translation>Databasen ble endret, men endringene er ennå ikke lagret til disk.</translation>
    </message>
    <message>
        <source>Number of groups</source>
        <translation>Antall grupper</translation>
    </message>
    <message>
        <source>Number of entries</source>
        <translation>Antall oppføringer</translation>
    </message>
    <message>
        <source>Number of expired entries</source>
        <translation>Antall utløpte oppføringer</translation>
    </message>
    <message>
        <source>The database contains entries that have expired.</source>
        <translation>Databasen inneholder oppføringer som er utløpt.</translation>
    </message>
    <message>
        <source>Unique passwords</source>
        <translation>Unike passord</translation>
    </message>
    <message>
        <source>Non-unique passwords</source>
        <translation>Dupliserte passord</translation>
    </message>
    <message>
        <source>More than 10% of passwords are reused. Use unique passwords when possible.</source>
        <translation>Mer enn 10% av passordene er brukt flere steder. Bruk unike passord når det er mulig.</translation>
    </message>
    <message>
        <source>Maximum password reuse</source>
        <translation>Maksimal gjenbruk av passord</translation>
    </message>
    <message>
        <source>Some passwords are used more than three times. Use unique passwords when possible.</source>
        <translation>Noen passord gjenbrukes mer enn tre ganger. Bruk unike passord når det er mulig.</translation>
    </message>
    <message>
        <source>Number of short passwords</source>
        <translation>Antall korte passord</translation>
    </message>
    <message>
        <source>Recommended minimum password length is at least 8 characters.</source>
        <translation>Anbefalt minimum passordlengde er minst 8 tegn.</translation>
    </message>
    <message>
        <source>Number of weak passwords</source>
        <translation>Antall svake passord</translation>
    </message>
    <message>
        <source>Recommend using long, randomized passwords with a rating of &apos;good&apos; or &apos;excellent&apos;.</source>
        <translation>Anbefaler å bruke lange, tilfeldige passord med en vurdering av &apos;bra&apos; eller &apos;utmerket&apos;.</translation>
    </message>
    <message>
        <source>Entries excluded from reports</source>
        <translation>Oppføringer som er utelatt fra rapporter</translation>
    </message>
    <message>
        <source>Excluding entries from reports, e. g. because they are known to have a poor password, isn&apos;t necessarily a problem but you should keep an eye on them.</source>
        <translation>Å ekskludere oppføringer fra rapporter, f. eks. fordi de er kjente for å ha dårlige passord, er ikke nødvendigvis et problem, men du bør følge med på dem.</translation>
    </message>
    <message>
        <source>Average password length</source>
        <translation>Gjennomsnittlig passordlengde</translation>
    </message>
    <message>
        <source>Average password length is less than ten characters. Longer passwords provide more security.</source>
        <translation>Gjennomsnittlig passordlengde er mindre enn ti tegn. Lengre passord gir bedre sikkerhet.</translation>
    </message>
    <message>
        <source>Number of passkeys</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Entries with TOTP setup</source>
        <translation type="unfinished"/>
    </message>
    <message numerus="yes">
        <source>%1 character(s)</source>
        <translation type="unfinished"><numerusform></numerusform><numerusform></numerusform></translation>
    </message>
</context>
<context>
    <name>SSHAgent</name>
    <message>
        <source>Agent connection failed.</source>
        <translation>Agentforbindelse mislyktes.</translation>
    </message>
    <message>
        <source>Agent protocol error.</source>
        <translation>Agent protokollfeil.</translation>
    </message>
    <message>
        <source>No agent running, cannot add identity.</source>
        <translation>Ingen agent kjører. Kan ikke identifisere.</translation>
    </message>
    <message>
        <source>Key identity ownership conflict. Refusing to add.</source>
        <translation>Konflikt i eierskap av nøkkel-identitet. Blir ikke lagt til.</translation>
    </message>
    <message>
        <source>Agent refused this identity. Possible reasons include:</source>
        <translation>Agent nektet denne identiteten. Mulige grunner er:</translation>
    </message>
    <message>
        <source>The key has already been added.</source>
        <translation>Nøkkelen er alt blitt lagt til.</translation>
    </message>
    <message>
        <source>Restricted lifetime is not supported by the agent (check options).</source>
        <translation>Begrenset levetid støttes ikke av agenten (sjekk alternativene).</translation>
    </message>
    <message>
        <source>A confirmation request is not supported by the agent (check options).</source>
        <translation>En bekreftelsesforespørsel støttes ikke av agenten (sjekk alternativene).</translation>
    </message>
    <message>
        <source>Security keys are not supported by the agent or the security key provider is unavailable.</source>
        <translation>Sikkerhetsnøkler støttes ikke av agenten, eller leverandøren av sikkerhetsnøkkelen er ikke tilgjengelig.</translation>
    </message>
    <message>
        <source>No agent running, cannot remove identity.</source>
        <translation>Ingen agent kjører, kan ikke fjerne identitet.</translation>
    </message>
    <message>
        <source>No agent running, cannot list identities.</source>
        <translation>Ingen agent kjører, kan ikke liste opp identiteter.</translation>
    </message>
    <message>
        <source>Failed to remove all SSH identities from agent.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>All SSH identities removed from agent.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>SearchHelpWidget</name>
    <message>
        <source>Search Help</source>
        <translation>Søkehjelp</translation>
    </message>
    <message>
        <source>Search terms are as follows: [modifiers][field:][&quot;]term[&quot;]</source>
        <translation>Søkebegrep er som følger: [modifikatorer][felt:][&quot;]søkestreng[&quot;]</translation>
    </message>
    <message>
        <source>Every search term must match (ie, logical AND)</source>
        <translation>Alle søkebegrep må oppfylles (dvs. logisk AND)</translation>
    </message>
    <message>
        <source>Modifiers</source>
        <translation>Modifikatorer</translation>
    </message>
    <message>
        <source>exclude term from results</source>
        <translation>utelat term fra resultater</translation>
    </message>
    <message>
        <source>match term exactly</source>
        <translation>match søkestreng eksakt</translation>
    </message>
    <message>
        <source>use regex in term</source>
        <translation>bruk regulært uttrykk i søkestreng</translation>
    </message>
    <message>
        <source>Fields</source>
        <translation>Felt</translation>
    </message>
    <message>
        <source>Term Wildcards</source>
        <translation>Jokertegn i søkestrenger</translation>
    </message>
    <message>
        <source>match anything</source>
        <translation>match alle tegn</translation>
    </message>
    <message>
        <source>match one</source>
        <translation>match ett tegn</translation>
    </message>
    <message>
        <source>logical OR</source>
        <translation>logisk ELLER</translation>
    </message>
    <message>
        <source>Examples</source>
        <translation>Eksempler</translation>
    </message>
</context>
<context>
    <name>SearchWidget</name>
    <message>
        <source>Search</source>
        <translation>Søk</translation>
    </message>
    <message>
        <source>Search Help</source>
        <translation>Søkehjelp</translation>
    </message>
    <message>
        <source>Save Search</source>
        <translation>Lagre søk</translation>
    </message>
    <message>
        <source>Search (%1)…</source>
        <comment>Search placeholder text, %1 is the keyboard shortcut</comment>
        <translation>Søk (%1)…</translation>
    </message>
    <message>
        <source>Case sensitive</source>
        <translation>Versalsensitiv</translation>
    </message>
    <message>
        <source>Limit search to selected group</source>
        <translation>Avgrens søket til valgt gruppe</translation>
    </message>
    <message>
        <source>Press Enter to search</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>SettingsClientModel</name>
    <message>
        <source>Application</source>
        <translation>Applikasjon</translation>
    </message>
    <message>
        <source>PID</source>
        <translation>PID</translation>
    </message>
    <message>
        <source>DBus Address</source>
        <translation>DBus-adresse</translation>
    </message>
    <message>
        <source>Manage</source>
        <translation>Administrere</translation>
    </message>
</context>
<context>
    <name>SettingsDatabaseModel</name>
    <message>
        <source>File Name</source>
        <translation>Filnavn</translation>
    </message>
    <message>
        <source>Group</source>
        <translation>Gruppe</translation>
    </message>
    <message>
        <source>Manage</source>
        <translation>Administrere</translation>
    </message>
</context>
<context>
    <name>SettingsWidgetFdoSecrets</name>
    <message>
        <source>Options</source>
        <translation>Alternativer</translation>
    </message>
    <message>
        <source>Enable KeepassXC Freedesktop.org Secret Service integration</source>
        <translation>Aktiver KeepassXC &apos;Freedesktop.org Secret Service&apos;-integrasjon</translation>
    </message>
    <message>
        <source>General</source>
        <translation>Generelt</translation>
    </message>
    <message>
        <source>Show notification when passwords are retrieved by clients</source>
        <translation>Vis varsling når passord hentes av klienter</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;If enabled, any attempt to read a password must be confirmed. Otherwise, clients can read passwords without confirmation when the database is unlocked.&lt;/p&gt;&lt;p&gt;This option only covers the access to the password of an entry. Clients can always enumerate the items of exposed databases and query their attributes.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Hvis aktivert, må alle forsøk på å lese et passord bekreftes. Ellers kan klienter lese passord uten bekreftelse når databasen er opplåst.&lt;/p&gt;&lt;p&gt;Dette alternativet gjelder bare tilgangen til passordet for en oppføring. Klienter kan alltid liste opp elementene i eksponerte databaser og spørre om attributtene.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Confirm when passwords are retrieved by clients</source>
        <translation>Bekreft når passord hentes av klienter</translation>
    </message>
    <message>
        <source>Confirm when clients request entry deletion</source>
        <translation>Bekreft når klienter ber om sletting av oppføring</translation>
    </message>
    <message>
        <source>Prompt to unlock database before searching</source>
        <translation>Spør om å låse opp databasen før søking</translation>
    </message>
    <message>
        <source>Exposed database groups:</source>
        <translation>Eksponerte databasegrupper:</translation>
    </message>
    <message>
        <source>Authorization</source>
        <translation>Autorisasjon</translation>
    </message>
    <message>
        <source>These applications are currently connected:</source>
        <translation>Disse programmene er for øyeblikket koblet til:</translation>
    </message>
    <message>
        <source>&lt;b&gt;Warning:&lt;/b&gt; </source>
        <translation>&lt;b&gt;Advarsel:&lt;/b&gt; </translation>
    </message>
    <message>
        <source>Save current changes to activate the plugin and enable editing of this section.</source>
        <translation>Lagre gjeldende endringer for å aktivere utvidelsen og aktivere redigering av denne delen.</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;This setting does not override disabling recycle bin prompts &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;This improves compatibility with certain applications which search for password without unlocking the database first.&lt;/p&gt;&lt;p&gt;But enabling this may also crash the client if the database can not be unlocked within a certain timeout. (Usually 25s, but may be a different value set in applications.) &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Dette forbedrer kompatibiliteten med enkelte programmer som søker etter passord uten å først låse opp databasen.&lt;/p&gt;&lt;p&gt;Men å aktivere dette kan også føre til at klienten krasjer, hvis databasen ikke kan låses opp i løpet av et gitt tidsrom. (Vanligvis 25 sekunder, men kan være en annen verdi angitt i programmene).&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
</context>
<context>
    <name>SettingsWidgetKeeShare</name>
    <message>
        <source>Active</source>
        <translation>Aktiv</translation>
    </message>
    <message>
        <source>Allow KeeShare imports</source>
        <translation>Tillat KeeShare-import</translation>
    </message>
    <message>
        <source>Allow import</source>
        <translation>Tillat import</translation>
    </message>
    <message>
        <source>Allow KeeShare exports</source>
        <translation>Tillat KeeShare-eksport</translation>
    </message>
    <message>
        <source>Allow export</source>
        <translation>Tillat eksport</translation>
    </message>
    <message>
        <source>Only show warnings and errors</source>
        <translation>Vis bare advarsler og feil</translation>
    </message>
    <message>
        <source>Own certificate</source>
        <translation>Egne sertifikat</translation>
    </message>
    <message>
        <source>Signer:</source>
        <translation>Underskriver:</translation>
    </message>
    <message>
        <source>Generate new certificate</source>
        <translation>Opprett nytt sertifikat</translation>
    </message>
    <message>
        <source>Generate</source>
        <translation>Opprett</translation>
    </message>
    <message>
        <source>Fingerprint:</source>
        <translation>Fingeravtrykk:</translation>
    </message>
    <message>
        <source>Signer name field</source>
        <translation>Navnefelt for underskriver</translation>
    </message>
    <message>
        <source>Fingerprint</source>
        <translation>Fingeravtrykk</translation>
    </message>
</context>
<context>
    <name>ShareExport</name>
    <message>
        <source>Could not write export container.</source>
        <translation>Kunne ikke skrive eksport-container.</translation>
    </message>
</context>
<context>
    <name>ShareImport</name>
    <message>
        <source>Successful import</source>
        <translation>Vellykket import</translation>
    </message>
</context>
<context>
    <name>ShareObserver</name>
    <message>
        <source>Import from %1 failed (%2)</source>
        <translation>Import fra %1 mislyktes (%2)</translation>
    </message>
    <message>
        <source>Import from %1 successful (%2)</source>
        <translation>Import fra %1 fullført (%2)</translation>
    </message>
    <message>
        <source>Imported from %1</source>
        <translation>Importert fra %1</translation>
    </message>
    <message>
        <source>Multiple import source path to %1 in %2</source>
        <translation>Sti for flere importkilder til %1 i %2</translation>
    </message>
    <message>
        <source>Conflicting export target path %1 in %2</source>
        <translation>Konflikt i eksport-målsti %1 i %2</translation>
    </message>
    <message>
        <source>Export to %1 failed (%2)</source>
        <translation>Eksport til %1 feilet (%2)</translation>
    </message>
    <message>
        <source>Export to %1 successful (%2)</source>
        <translation>Eksport til %1 vellykket (%2)</translation>
    </message>
    <message>
        <source>Export to %1</source>
        <translation>Eksporter til %1</translation>
    </message>
</context>
<context>
    <name>TagModel</name>
    <message>
        <source>Clear Search</source>
        <translation>Tøm søk</translation>
    </message>
    <message>
        <source>All Entries</source>
        <translation>Alle oppføringer</translation>
    </message>
    <message>
        <source>Expired</source>
        <translation>Utløpt</translation>
    </message>
    <message>
        <source>Weak Passwords</source>
        <translation>Svake passord</translation>
    </message>
    <message>
        <source>TOTP Entries</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>TagView</name>
    <message>
        <source>Remove Search</source>
        <translation>Fjern søk</translation>
    </message>
    <message>
        <source>Remove Tag</source>
        <translation>Fjern taggen</translation>
    </message>
    <message>
        <source>Confirm Remove Tag</source>
        <translation>Bekreft fjerning av taggen</translation>
    </message>
    <message>
        <source>Remove tag &quot;%1&quot; from all entries in this database?</source>
        <translation>Fjern taggen &quot;%1&quot; fra alle oppføringer i denne databasen?</translation>
    </message>
</context>
<context>
    <name>TextAttachmentsEditWidget</name>
    <message>
        <source>Preview</source>
        <translation>Forhåndsvis</translation>
    </message>
</context>
<context>
    <name>TextAttachmentsPreviewWidget</name>
    <message>
        <source>Form</source>
        <translation>Skjema</translation>
    </message>
    <message>
        <source>Type:</source>
        <translation>Type:</translation>
    </message>
</context>
<context>
    <name>TotpDialog</name>
    <message>
        <source>Timed Password</source>
        <translation>Tidsbasert passord</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Kopier</translation>
    </message>
    <message numerus="yes">
        <source>Expires in &lt;b&gt;%n&lt;/b&gt; second(s)</source>
        <translation><numerusform>Utløper om %n sekund</numerusform><numerusform>Utløper om &lt;b&gt;%n&lt;/b&gt; sekunder</numerusform></translation>
    </message>
</context>
<context>
    <name>TotpExportSettingsDialog</name>
    <message>
        <source>Copy</source>
        <translation>Kopier</translation>
    </message>
    <message>
        <source>NOTE: These TOTP settings are custom and may not work with other authenticators.</source>
        <comment>TOTP QR code dialog warning</comment>
        <translation>MERK: Disse TOTP-innstillingene er egendefinerte og fungerer kanskje ikke med andre autentifikatorer.</translation>
    </message>
    <message>
        <source>There was an error creating the QR code.</source>
        <translation>Feil ved opprettelse av QR-koden.</translation>
    </message>
    <message>
        <source>Closing in %1 seconds.</source>
        <translation>Lukker om %1 sekunder.</translation>
    </message>
</context>
<context>
    <name>TotpSetupDialog</name>
    <message>
        <source>Setup TOTP</source>
        <translation>Oppsett TOTP</translation>
    </message>
    <message>
        <source>Secret Key:</source>
        <translation>Hemmelig nøkkel:</translation>
    </message>
    <message>
        <source>Secret key must be in Base32 format</source>
        <translation>Hemmelig nøkkel må være i Base32-format</translation>
    </message>
    <message>
        <source>Secret key field</source>
        <translation>Felt for hemmelig nøkkel</translation>
    </message>
    <message>
        <source>Default settings (RFC 6238)</source>
        <translation>Standardinnstillinger (RFC 6238)</translation>
    </message>
    <message>
        <source>Steam® settings</source>
        <translation>Steam®-innstillinger</translation>
    </message>
    <message>
        <source>Custom settings:</source>
        <translation>Egendefinerte innstillinger:</translation>
    </message>
    <message>
        <source>Custom Settings</source>
        <translation>Egendefinerte innstillinger</translation>
    </message>
    <message>
        <source>Algorithm:</source>
        <translation>Algoritme:</translation>
    </message>
    <message>
        <source>Time step:</source>
        <translation>Tidstrinn:</translation>
    </message>
    <message>
        <source>Time step field</source>
        <translation>Felt for tidstrinn</translation>
    </message>
    <message>
        <source> sec</source>
        <comment>Seconds</comment>
        <translation>sek</translation>
    </message>
    <message>
        <source>Code size:</source>
        <translation>Kodestørrelse:</translation>
    </message>
    <message>
        <source> digits</source>
        <translation> sifre</translation>
    </message>
    <message>
        <source>Invalid TOTP Secret</source>
        <translation>Ugyldig TOTP hemmelig nøkkel</translation>
    </message>
    <message>
        <source>You have entered an invalid secret key. The key must be in Base32 format.
Example: JBSWY3DPEHPK3PXP</source>
        <translation>Du har angitt en ugyldig hemmelig nøkkel. Nøkkelen må være i Base32-format.
Eksempel: JBSWY3DPEHPK3PXP</translation>
    </message>
    <message>
        <source>Confirm Remove TOTP Settings</source>
        <translation>Bekreft fjerning av TOTP-innstillinger</translation>
    </message>
    <message>
        <source>Are you sure you want to delete TOTP settings for this entry?</source>
        <translation>Er du sikker på at du vil slette TOTP-innstillinger for denne oppføringen?</translation>
    </message>
    <message>
        <source>Error: secret key is invalid</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>URLEdit</name>
    <message>
        <source>Invalid URL</source>
        <translation>Ugyldig URL</translation>
    </message>
</context>
<context>
    <name>UpdateCheckDialog</name>
    <message>
        <source>Checking for updates</source>
        <translation>Sjekker for oppdateringer</translation>
    </message>
    <message>
        <source>Checking for updates…</source>
        <translation>Ser etter oppdateringer…</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Lukk</translation>
    </message>
    <message>
        <source>Software Update</source>
        <translation>Programvareoppdatering</translation>
    </message>
    <message>
        <source>An error occurred when trying to retrieve update information, please try again later.</source>
        <translation>Det oppstod en feil under forsøk på å hente oppdateringsinformasjon, prøv igjen senere.</translation>
    </message>
    <message>
        <source>&lt;strong&gt;A new version is available.&lt;/strong&gt;&lt;br/&gt;KeePassXC %1 can be &lt;a href=&quot;https://keepassxc.org/download/&quot;&gt;downloaded here&lt;/a&gt;.</source>
        <translation>&lt;strong&gt;En ny versjon er tilgjengelig.&lt;/strong&gt;&lt;br/&gt;KeePassXC %1 kan &lt;a href=&quot;https://keepassxc.org/download/&quot;&gt;lastes ned her&lt;/a&gt;.</translation>
    </message>
    <message>
        <source>You have the latest version of KeePassXC</source>
        <translation>Du har den siste versjonen av KeePassXC</translation>
    </message>
</context>
<context>
    <name>WelcomeWidget</name>
    <message>
        <source>Start storing your passwords securely in a KeePassXC database</source>
        <translation>Begynn å lagre passordene dine i en trygg KeePassXC-database</translation>
    </message>
    <message>
        <source>Recent databases</source>
        <translation>Nylige databaser</translation>
    </message>
    <message>
        <source>Open a recent database</source>
        <translation>Åpne en nylig database</translation>
    </message>
    <message>
        <source>Welcome to KeePassXC %1</source>
        <translation>Velkommen til KeePassXC %1</translation>
    </message>
    <message>
        <source>Create Database</source>
        <translation>Opprett database</translation>
    </message>
    <message>
        <source>Open Database</source>
        <translation>Åpne database</translation>
    </message>
    <message>
        <source>Import File</source>
        <translation>Importer fil</translation>
    </message>
</context>
<context>
    <name>WinUtils</name>
    <message>
        <source>Invalid key code</source>
        <translation>Ugyldig nøkkelkode</translation>
    </message>
    <message>
        <source>Global shortcut already registered to %1</source>
        <translation>Global hurtigtast er allerede registrert på %1</translation>
    </message>
    <message>
        <source>Could not register global shortcut</source>
        <translation>Kunne ikke registrere global hurtigtast</translation>
    </message>
</context>
<context>
    <name>YubiKey</name>
    <message>
        <source>Could not find hardware key with serial number %1. Please connect it to continue.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>YubiKeyEditWidget</name>
    <message>
        <source>Hardware key slot selection</source>
        <translation>Valg av spor i maskinvarenøkkel</translation>
    </message>
    <message>
        <source>Could not find any hardware keys!</source>
        <translation>Fant ingen maskinvarenøkler!</translation>
    </message>
    <message>
        <source>Selected hardware key slot does not support challenge-response!</source>
        <translation>Valgt spor på maskinvarenøkkel støtter ikke utfordrerrespons!</translation>
    </message>
    <message>
        <source>Challenge-Response</source>
        <translation>Utfordrerrespons</translation>
    </message>
    <message>
        <source>Add Challenge-Response</source>
        <translation>Legg til utfordrerrespons</translation>
    </message>
    <message>
        <source>Change Challenge-Response</source>
        <translation>Endre utfordrerrespons</translation>
    </message>
    <message>
        <source>Remove Challenge-Response</source>
        <translation>Fjern utfordrerrespons</translation>
    </message>
    <message>
        <source>Challenge-Response set, click to change or remove</source>
        <translation>Utfordrerrespons angitt, klikk for å endre eller fjerne</translation>
    </message>
    <message>
        <source>Detecting hardware keys…</source>
        <translation>Oppdager maskinvarenøkler …</translation>
    </message>
    <message>
        <source>No hardware keys detected</source>
        <translation>Finner ingen maskinvarenøkler</translation>
    </message>
    <message>
        <source>Refresh hardware keys</source>
        <translation>Oppdater maskinvarenøkler</translation>
    </message>
    <message>
        <source>&lt;p&gt;If you own a &lt;a href=&quot;https://www.yubico.com/&quot;&gt;YubiKey&lt;/a&gt; or &lt;a href=&quot;https://onlykey.io&quot;&gt;OnlyKey&lt;/a&gt;, you can use it for additional security.&lt;/p&gt;&lt;p&gt;The key requires one of its slots to be programmed with &lt;a href=&quot;https://keepassxc.org/docs/#faq-yubikey-howto&quot;&gt;Challenge-Response&lt;/a&gt;.&lt;/p&gt;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Hardware keys found, but no slots are configured</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>YubiKeyInterfacePCSC</name>
    <message>
        <source>Hardware key is locked or timed out. Unlock or re-present it to continue.</source>
        <translation>Maskinvarenøkkelen er låst eller tidsavbrutt. Lås opp eller koble den til på nytt for å fortsette.</translation>
    </message>
    <message>
        <source>Hardware key was not found or is not configured.</source>
        <translation>Maskinvarenøkkelen ble ikke funnet eller er ikke konfigurert.</translation>
    </message>
    <message>
        <source>(NFC) %1 [%2] - Slot %3, %4</source>
        <comment>YubiKey display fields</comment>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Press</source>
        <comment>USB Challenge-Response Key interaction request</comment>
        <translation>Trykk</translation>
    </message>
    <message>
        <source>Passive</source>
        <comment>USB Challenge-Response Key no interaction required</comment>
        <translation>Passiv</translation>
    </message>
    <message>
        <source>The YubiKey PC/SC interface has not been initialized.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Failed to complete a challenge-response, the PC/SC error code was: %1</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>YubiKeyInterfaceUSB</name>
    <message>
        <source>Press</source>
        <comment>USB Challenge-Response Key interaction request</comment>
        <translation>Trykk</translation>
    </message>
    <message>
        <source>Passive</source>
        <comment>USB Challenge-Response Key no interaction required</comment>
        <translation>Passiv</translation>
    </message>
    <message>
        <source>The YubiKey USB interface has not been initialized.</source>
        <translation>USB-grensesnittet til YubiKey er ikke blitt klargjort.</translation>
    </message>
    <message>
        <source>Could not find hardware key with serial number %1. Please plug it in to continue.</source>
        <translation>Kunne ikke finne maskinvarenøkkel med serienummer %1. Koble den til for å fortsette.</translation>
    </message>
    <message>
        <source>Hardware key timed out waiting for user interaction.</source>
        <translation>Maskinvarenøkkelen ble tidsavbrutt ventende på brukerrespons.</translation>
    </message>
    <message>
        <source>A USB error occurred when accessing the hardware key: %1</source>
        <translation>En USB-feil oppstod ved tilgang til maskinvarenøkkelen: %1</translation>
    </message>
    <message>
        <source>Failed to complete a challenge-response, the specific error was: %1</source>
        <translation>Kunne ikke fullføre utfordrerrespons, den spesifikke feilen var: %1</translation>
    </message>
    <message>
        <source>%1 [%2] - Slot %3</source>
        <comment>YubiKey NEO display fields</comment>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>%1 [%2] - Slot %3, %4</source>
        <comment>YubiKey display fields</comment>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Unknown</source>
        <comment>Unknown hardware key name</comment>
        <translation type="unfinished"/>
    </message>
</context>
</TS>
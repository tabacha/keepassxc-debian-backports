<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="he">
<context>
    <name>AboutDialog</name>
    <message>
        <source>About KeePassXC</source>
        <translation>על אודות KeepPassXC</translation>
    </message>
    <message>
        <source>About</source>
        <translation>על אודות</translation>
    </message>
    <message>
        <source>Report bugs at: &lt;a href=&quot;https://github.com/keepassxreboot/keepassxc/issues&quot; style=&quot;text-decoration: underline;&quot;&gt;https://github.com&lt;/a&gt;</source>
        <translation>דווח על תקלים בכתובת: &lt;a href=&quot;https://github.com/keepassxreboot/keepassxc/issues&quot; style=&quot;text-decoration: תחתון ;&quot;&gt; https://github.com &lt;/a&gt;</translation>
    </message>
    <message>
        <source>KeePassXC is distributed under the terms of the GNU General Public License (GPL) version 2 or (at your option) version 3.</source>
        <translation>KeePassXC מופץ בתנאי הרשיון של (GNU General License (GPL גרסה 2 או (לבחירה) גרסה 3.</translation>
    </message>
    <message>
        <source>Project Maintainers:</source>
        <translation>מתחזקי המייזם:</translation>
    </message>
    <message>
        <source>Special thanks from the KeePassXC team go to debfx for creating the original KeePassX.</source>
        <translation>תודה מיוחדת מצוות KeePassXC, נא לעבור אל debfx ליצירת ה־KeePassX המקורי.</translation>
    </message>
    <message>
        <source>Contributors</source>
        <translation>תורמים</translation>
    </message>
    <message>
        <source>&lt;a href=&quot;https://github.com/keepassxreboot/keepassxc/graphs/contributors&quot;&gt;See Contributions on GitHub&lt;/a&gt;</source>
        <translation>&lt;a href=&quot;https://github.com/keepassxreboot/keepassxc/graphs/contributors&quot;&gt; צפיה בתרומות ב־GitHub &lt;/a&gt;</translation>
    </message>
    <message>
        <source>Debug Info</source>
        <translation>מידע ניפוי־תקלים</translation>
    </message>
    <message>
        <source>Include the following information whenever you report a bug:</source>
        <translation>הכללת המידע הבא בכל דווח על תקל:</translation>
    </message>
    <message>
        <source>Copy to clipboard</source>
        <translation>העתקה ללוח־הגזירים</translation>
    </message>
</context>
<context>
    <name>AccessControlDialog</name>
    <message>
        <source>KeePassXC -  Access Request</source>
        <translation>בקשת גישה - KeePassXC</translation>
    </message>
    <message>
        <source>Non-existing/inaccessible executable path. Please double-check the client is legit.</source>
        <translation>נתיב הפעלה לא קיים/נגיש. נא לבדוק שנית את חוקיות הלקוח.</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;%1 &lt;/span&gt;is requesting access to the following entries:&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>בקשת גישה מ־&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;%1 &lt;/span&gt; לרשומות הבאות:&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>שם</translation>
    </message>
    <message>
        <source>PID</source>
        <translation>קוד מזהה אישי</translation>
    </message>
    <message>
        <source>Executable</source>
        <translation>קובץ הפעלה</translation>
    </message>
    <message>
        <source>Command Line</source>
        <translation>שורת פקודה</translation>
    </message>
    <message>
        <source>Details</source>
        <translation>פרטים</translation>
    </message>
    <message>
        <source>Your decision will be remembered for the duration while both the requesting client AND KeePassXC are running.</source>
        <translation>החלטתך תיזכר למשך הזמן בו גם הלקוח המבקש וגם KeePassXC פועלים.</translation>
    </message>
    <message>
        <source>Remember</source>
        <translation>זכירה</translation>
    </message>
    <message>
        <source>Allow Selected</source>
        <translation>אפשור נבחרים</translation>
    </message>
    <message>
        <source>Deny All &amp;&amp; Future</source>
        <translation>דחיית הכול וגם בעתיד</translation>
    </message>
    <message>
        <source>Allow All &amp;&amp; &amp;Future</source>
        <translation>אפשור הכול וגם בעתיד</translation>
    </message>
</context>
<context>
    <name>AccessControlDialog::DenyButton</name>
    <message>
        <source>Deny for this program</source>
        <translation>דחייה לתוכנית זו</translation>
    </message>
</context>
<context>
    <name>AgentSettingsWidget</name>
    <message>
        <source>Enable SSH Agent integration</source>
        <translation>אפשור שילוב סוכן SSH</translation>
    </message>
    <message>
        <source>Use Pageant</source>
        <translation>שימוש בפג&apos;יאנט</translation>
    </message>
    <message>
        <source>Use OpenSSH</source>
        <translation>שימוש באופן־אס.אס.איץ&apos;</translation>
    </message>
    <message>
        <source>Use both agents</source>
        <translation>שימוש בשני הסוכנים</translation>
    </message>
    <message>
        <source>SSH_AUTH_SOCK override</source>
        <translation>עקיפת SSH_AUTH_SOCK</translation>
    </message>
    <message>
        <source>SSH_AUTH_SOCK value</source>
        <translation>ערך SSH_AUTH_SOCK</translation>
    </message>
    <message>
        <source>(empty)</source>
        <translation>(ריק)</translation>
    </message>
    <message>
        <source>SSH_SK_PROVIDER value</source>
        <translation>ערך SSH_SK_PROVIDER</translation>
    </message>
    <message>
        <source>SSH_SK_PROVIDER override</source>
        <translation>עקיפת SSH_SK_PROVIDER</translation>
    </message>
    <message>
        <source>No SSH Agent socket available. Either make sure SSH_AUTH_SOCK environment variable exists or set an override.</source>
        <translation>אין שקע סוכן SSH זמין. נא לוודא שמשתנה הסביבה SSH_AUTH_SOCK קיים או לקבוע עקיפה.</translation>
    </message>
    <message>
        <source>SSH Agent connection is working!</source>
        <translation>חיבור סוכן SSH פועל!</translation>
    </message>
</context>
<context>
    <name>AppKit</name>
    <message>
        <source>Window</source>
        <translation>חלון</translation>
    </message>
    <message>
        <source>Minimize</source>
        <translation>מזעור</translation>
    </message>
    <message>
        <source>Zoom</source>
        <translation>מיקוד:</translation>
    </message>
    <message>
        <source>Bring All to Front</source>
        <translation>להביא הכל לקידמה</translation>
    </message>
</context>
<context>
    <name>ApplicationSettingsWidget</name>
    <message>
        <source>Application Settings</source>
        <translation>הגדרות יישום</translation>
    </message>
    <message>
        <source>General</source>
        <translation>כללי</translation>
    </message>
    <message>
        <source>Security</source>
        <translation>אבטחה</translation>
    </message>
    <message>
        <source>This setting cannot be enabled when minimize on unlock is enabled.</source>
        <translation>לא ניתן לאפשר הגדרה זו כאשר האפשרות &apos;מזעור בעת שחרור נעילה&apos; מאופשרת.</translation>
    </message>
    <message>
        <source>Access error for config file %1</source>
        <translation>שגיאת גישה לקובץ התצורה %1</translation>
    </message>
    <message>
        <source>Icon only</source>
        <translation>סמל בלבד</translation>
    </message>
    <message>
        <source>Text only</source>
        <translation>מלל בלבד</translation>
    </message>
    <message>
        <source>Text beside icon</source>
        <translation>מלל לצד סמל</translation>
    </message>
    <message>
        <source>Text under icon</source>
        <translation>מלל מתחת לסמל</translation>
    </message>
    <message>
        <source>Follow style</source>
        <translation>עקוב אחר הסגנון</translation>
    </message>
    <message>
        <source>Monochrome</source>
        <translation>מונוכרום</translation>
    </message>
    <message>
        <source>Monochrome (light)</source>
        <translation>מונוכרום (בהיר)</translation>
    </message>
    <message>
        <source>Monochrome (dark)</source>
        <translation>מונוכרום (כהה)</translation>
    </message>
    <message>
        <source>Colorful</source>
        <translation>צבעוני</translation>
    </message>
    <message>
        <source>You must restart the application to set the new language. Would you like to restart now?</source>
        <translation>נא לאתחל את היישום כדי להגדיר את השפה החדשה. האם ברצונך לאתחל כעת?</translation>
    </message>
    <message>
        <source>Select backup storage directory</source>
        <translation>בחירת מחיצת אחסן גיבוי</translation>
    </message>
    <message>
        <source>Confirm Reset</source>
        <translation>אישור איפוס</translation>
    </message>
    <message>
        <source>Are you sure you want to reset all settings to default?</source>
        <translation>האם הנך בטוח/ה כי ברצונך לאפס את כל ההגדרות לברירת מחדל?</translation>
    </message>
    <message>
        <source>Import KeePassXC Settings</source>
        <translation>ייבוא הגדרות KeePassXC</translation>
    </message>
    <message>
        <source>Failed to import settings from %1, not a valid settings file.</source>
        <translation>ייבוא הגדרות מ־%1 כשל, לא קובץ הגדרות תקין.</translation>
    </message>
    <message>
        <source>Export KeePassXC Settings</source>
        <translation>ייצוא הגדרות KeePassXC</translation>
    </message>
    <message>
        <source>Small</source>
        <translation>קטן</translation>
    </message>
    <message>
        <source>Normal</source>
        <translation>רגיל</translation>
    </message>
    <message>
        <source>Medium</source>
        <translation>בינוני</translation>
    </message>
    <message>
        <source>Large</source>
        <translation>גדול</translation>
    </message>
    <message>
        <source>Custom</source>
        <translation>מותאם אישית</translation>
    </message>
    <message>
        <source>None</source>
        <translation>ללא</translation>
    </message>
    <message>
        <source>Restart KeePassXC to apply the Auto-Type desktop portals preference.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>ApplicationSettingsWidgetGeneral</name>
    <message>
        <source>Basic Settings</source>
        <translation>הגדרות בסיסיות</translation>
    </message>
    <message>
        <source>Startup</source>
        <translation>איתחול</translation>
    </message>
    <message>
        <source>Start only a single instance of KeePassXC</source>
        <translation>איתחול אֶדְגָּם־יחיד של KeePassXC בלבד</translation>
    </message>
    <message>
        <source>Automatically launch KeePassXC at system startup</source>
        <translation>שיגור KeePassXC אוטומטית בעת איתחול המערכת</translation>
    </message>
    <message>
        <source>Minimize window at application startup</source>
        <translation>מזעור החלון בעת איתחול היישום</translation>
    </message>
    <message>
        <source>Minimize window after unlocking database</source>
        <translation>מזעור החלון לאחר שחרור נעילת מסד הנתונים</translation>
    </message>
    <message>
        <source>Remember previously used databases</source>
        <translation>זכירת מסדי־נתונים ששימשו בעבר</translation>
    </message>
    <message>
        <source> recent files</source>
        <translation>קבצים אחרונים</translation>
    </message>
    <message>
        <source>Load previously open databases on startup</source>
        <translation>טעינת מסדי־נתונים שנפתחו בעבר בעת האיתחול</translation>
    </message>
    <message>
        <source>Remember database key files and security dongles</source>
        <translation>זכירת קבצי מפתח־מסד־נתונים ותקיעי אבטחה</translation>
    </message>
    <message>
        <source>Check for updates at application startup once per week</source>
        <translation>בדיקת עדכונים בעת איתחול היישום פעם בשבוע</translation>
    </message>
    <message>
        <source>Include beta releases when checking for updates</source>
        <translation>בבדיקת עדכונים, לכלול גםגרסאות בטא </translation>
    </message>
    <message>
        <source>File Management</source>
        <translation>ניהול קבצים</translation>
    </message>
    <message>
        <source>Automatically save after every change</source>
        <translation>שמירה אוטומטית לאחר כל שינוי</translation>
    </message>
    <message>
        <source>Automatically save when locking database</source>
        <translation>שמירה אוטומטית בעת נעילת מסד־נתונים</translation>
    </message>
    <message>
        <source>Automatically save non-data changes when locking database</source>
        <translation>שמירה שינויים שטרם נשמרו אוטומטית בעת נעילת מסד־נתונים</translation>
    </message>
    <message>
        <source>Automatically reload the database when modified externally</source>
        <translation>טעינה חוזרת אוטומטית של מסד הנתונים בזמן הסגלה ממקור חיצוני</translation>
    </message>
    <message>
        <source>Backup database file before saving</source>
        <translation>גיבוי קובץ מסד־נתונים לפני שמירה</translation>
    </message>
    <message>
        <source>{DB_FILENAME}.old.kdbx</source>
        <translation>{DB_FILENAME}.old.kdbx</translation>
    </message>
    <message>
        <source>Use alternative saving method (may solve problems with Dropbox, Google Drive, GVFS, etc.)</source>
        <translation>שימוש בשיטת שמירה חלופית (עשוי לפתור בעיות עם דרופבוקס, גוגל דרייב, GVFS ודומיהם).</translation>
    </message>
    <message>
        <source>Temporary file moved into place</source>
        <translation>קובץ זמני הועבר למקום</translation>
    </message>
    <message>
        <source>Directly write to database file (dangerous)</source>
        <translation>כתיבה ישירה לקובץ מסד־נתונים (מסוכן)</translation>
    </message>
    <message>
        <source>Entry Management</source>
        <translation>ניהול רשומות</translation>
    </message>
    <message>
        <source>Use group icon on entry creation</source>
        <translation>שימוש בסמל הקבוצה ביצירת רשומה</translation>
    </message>
    <message>
        <source>Minimize when opening a URL</source>
        <translation>מזעור בעת פתיחת כתובת אתר</translation>
    </message>
    <message>
        <source>Hide window when copying to clipboard</source>
        <translation>הסתרת חלון בעת העתקה ללוח־הגזירים</translation>
    </message>
    <message>
        <source>Minimize</source>
        <translation>מזעור</translation>
    </message>
    <message>
        <source>Drop to background</source>
        <translation>שחרור לרקע</translation>
    </message>
    <message>
        <source>Favicon download timeout:</source>
        <translation>פסק זמן להורדת פביקון:</translation>
    </message>
    <message>
        <source>Website icon download timeout in seconds</source>
        <translation>פסק זמן להורדת סמל האתר בשניות</translation>
    </message>
    <message>
        <source> sec</source>
        <comment>Seconds</comment>
        <translation> שניות</translation>
    </message>
    <message>
        <source>User Interface</source>
        <translation>מנשק המשתמש</translation>
    </message>
    <message>
        <source>Toolbar button style</source>
        <translation>סגנון לחצן סרגל כלים</translation>
    </message>
    <message>
        <source>Movable toolbar</source>
        <translation>סרגל כלים ניתן להזזה</translation>
    </message>
    <message>
        <source>Language selection</source>
        <translation>בחירת שפה</translation>
    </message>
    <message>
        <source>Language:</source>
        <translation>שפה:</translation>
    </message>
    <message>
        <source>(restart program to activate)</source>
        <translation>(יש לאתחל את התוכנית כדי להפעיל)</translation>
    </message>
    <message>
        <source>Toolbar button style:</source>
        <translation>סגנון לחצן סרגל כלים:</translation>
    </message>
    <message>
        <source>Show passwords in color</source>
        <translation>הצגת סיסמאות בצבע</translation>
    </message>
    <message>
        <source>Use monospaced font for notes</source>
        <translation>שימוש בגופן ברוחב אחיד להערות</translation>
    </message>
    <message>
        <source>Minimize instead of app exit</source>
        <translation>מזעור במקום יציאה מהיישום</translation>
    </message>
    <message>
        <source>Show a system tray icon</source>
        <translation>הצגת סמל מגש מערכת</translation>
    </message>
    <message>
        <source>Tray icon type</source>
        <translation>סוג סמל מגש</translation>
    </message>
    <message>
        <source>Tray icon type:</source>
        <translation>סוג סמל מגש:</translation>
    </message>
    <message>
        <source>Hide window to system tray when minimized</source>
        <translation>הסתרת חלון למגש המערכת במזעור</translation>
    </message>
    <message>
        <source>Reset settings to default…</source>
        <translation>איפוס הגדרות לברירת מחדל...</translation>
    </message>
    <message>
        <source>Auto-Type</source>
        <translation>הקלדה־אוטומטית</translation>
    </message>
    <message>
        <source>Use entry title to match windows for global Auto-Type</source>
        <translation>שימוש בכותרת רשומה להתאמת חלונות להקלדה־אוטומטית כללית</translation>
    </message>
    <message>
        <source>Use entry URL to match windows for global Auto-Type</source>
        <translation>שימוש בכתובת URL של רשומה להתאמת חלונות להקלדה־אוטומטית כללית</translation>
    </message>
    <message>
        <source>Always ask before performing Auto-Type</source>
        <translation>לשאול תמיד לפני ביצוע הקלדה־אוטומטית</translation>
    </message>
    <message>
        <source>Hide expired entries from Auto-Type</source>
        <translation>הסתרת רשומות שפג תוקפם מהקלדה־אוטומטית</translation>
    </message>
    <message>
        <source>Re-lock previously locked database after performing Auto-Type</source>
        <translation>לנעול מחדש מסד־נתונים שננעל בעבר לאחר ביצוע הקלדה־אוטומטית</translation>
    </message>
    <message>
        <source>Auto-Type start delay:</source>
        <translation>השהיית התחלת הקלדה־אוטומטית:</translation>
    </message>
    <message>
        <source>Global Auto-Type shortcut:</source>
        <translation>קיצור דרך כללי להקלדה־אוטומטית:</translation>
    </message>
    <message>
        <source>Auto-type start delay milliseconds</source>
        <translation>השהיית התחלת הקלדה־אוטומטית באלפיות השנייה</translation>
    </message>
    <message>
        <source> ms</source>
        <comment>Milliseconds</comment>
        <translation>אלפיות שנייה</translation>
    </message>
    <message>
        <source>Auto-Type typing delay:</source>
        <translation>השהיית הקלדת הקלדה־אוטומטית:</translation>
    </message>
    <message>
        <source>Global auto-type shortcut</source>
        <translation>קיצור דרך כללי להקלדה־אוטומטית</translation>
    </message>
    <message>
        <source>Auto-type character typing delay milliseconds</source>
        <translation>השהיית הקלדה־אוטומטית של תווים באלפיות השנייה</translation>
    </message>
    <message>
        <source>Remember last typed entry for:</source>
        <translation>זכירת הרשומה האחרונה שהוקלדה למשך:</translation>
    </message>
    <message>
        <source>On database unlock, show entries that will expire within</source>
        <translation>עם שחרור נעילת מסד־נתונים, יש להציג רשומות שתוקפן יפוג בתוך</translation>
    </message>
    <message>
        <source>On database unlock, show entries that will expire within </source>
        <translation>עם שחרור נעילת מסד־נתונים, יש להציג רשומות שתוקפן יפוג בתוך</translation>
    </message>
    <message>
        <source> days</source>
        <comment>number of days warning for password expiration</comment>
        <translation>ימים</translation>
    </message>
    <message>
        <source>Destination format:</source>
        <translation>תסדיר יעד:</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;{DB_FILENAME}&lt;/span&gt; is replaced with the filename of the saved database without extension&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;{TIME:&amp;lt;format&amp;gt;}&lt;/span&gt; is replaced with the specified time format (default: dd_MM_yyyy_hh-mm-ss)&lt;/p&gt;&lt;p&gt;See the User Guide for more details&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;{שם_קובץ_מסד_נתונים}&lt;/span&gt;מוחלף עם שם הקובץ של מסד הנתונים שנשמר ללא סיומת &lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;{זמן:&amp;gt;תסדיר&amp;lt;}&lt;/span&gt; מוחלף עם תסדיר הזמן המצוין (ברירת מחדל: dd_MM_yyyy_hh-mm-ss)&lt;/p&gt;&lt;p&gt;יש לראות את מדריך המשתמש עבור עוד פרטים&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Choose folder...</source>
        <translation>בחירת תיקייה...</translation>
    </message>
    <message>
        <source>Show confirmation before moving entries to recycle bin</source>
        <translation>הצגת אישור לפני העברת רשומות לסל מחזור</translation>
    </message>
    <message>
        <source>Copy data on double clicking field in entry view</source>
        <translation>העתקת נתונים בלחיצה כפולה על שדה בתצוגת רשומה</translation>
    </message>
    <message>
        <source>Show toolbar</source>
        <translation>הצגת סרגל כלים</translation>
    </message>
    <message>
        <source>Show the menu bar by pressing the Alt key</source>
        <translation>הצגת סרגל תפריט באמצעות לחיצה על המקש Alt</translation>
    </message>
    <message>
        <source>Show menubar</source>
        <translation>הצגת סרגל תפריט</translation>
    </message>
    <message>
        <source>Import settings…</source>
        <translation>ייבוא הגדרות...</translation>
    </message>
    <message>
        <source>Export settings…</source>
        <translation>ייצוא הגדרות...</translation>
    </message>
    <message>
        <source>Font size:</source>
        <translation>גודל גופן:</translation>
    </message>
    <message>
        <source>Font size selection</source>
        <translation>בחירת גודל גופן</translation>
    </message>
    <message>
        <source>Skip confirmation for main window Auto-Type actions</source>
        <translation>דילוג על אימות בפעולות הקלדה אוטומטית בחלון הראשי</translation>
    </message>
    <message>
        <source>Double-click action for URL:</source>
        <translation>םעולת הקשה כפולה ל־URL:</translation>
    </message>
    <message>
        <source>Double-click action for URL field</source>
        <translation>פעולת הקשה כפולה לשדה URL</translation>
    </message>
    <message>
        <source>Edit entry</source>
        <translation>עריכת רשומה</translation>
    </message>
    <message>
        <source>Open entry URL in browser</source>
        <translation>פתיחת רשומת URL בדפדפן</translation>
    </message>
    <message>
        <source>Copy entry URL to clipboard</source>
        <translation>העתקת מען URL ללוח־הגזירים</translation>
    </message>
    <message>
        <source>Auto-generate password for new entries</source>
        <translation>איטמוט חילול סיסמה עבור רשומות חדשות</translation>
    </message>
    <message>
        <source>Keep remote desktop connection open after performing Auto-Type</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Remote desktop mode:</source>
        <translation>מצב שולחן־עבודה מרוחק:</translation>
    </message>
    <message>
        <source>Never remember session</source>
        <translation>לא לזכור שיח לעולם</translation>
    </message>
    <message>
        <source>Remember session until exit</source>
        <translation>לזכור שיח עד יציאה</translation>
    </message>
    <message>
        <source>Remember session until revoked by desktop</source>
        <translation>לזכור שיח עג שיבוטל על־ידי שולחן־עבודה</translation>
    </message>
    <message>
        <source>None</source>
        <translation>ללא</translation>
    </message>
    <message>
        <source>Configure...</source>
        <translation>תצור...</translation>
    </message>
    <message>
        <source>Use remote desktop for clipboard access</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Experimental: Prefer desktop portals (Wayland implementation)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Show autocomplete suggestions for username and additional attributes</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>ApplicationSettingsWidgetSecurity</name>
    <message>
        <source>Timeouts</source>
        <translation>פסקי זמן</translation>
    </message>
    <message>
        <source>Database lock timeout seconds</source>
        <translation>פסק זמן בשניות לנעילת מסד־נתונים</translation>
    </message>
    <message>
        <source> sec</source>
        <comment>Seconds</comment>
        <translation> שנ&apos;</translation>
    </message>
    <message>
        <source>Clear clipboard after</source>
        <translation>ניקוי לוח גזירים לאחר</translation>
    </message>
    <message>
        <source>Clear search query after</source>
        <translation>ניקוי שאילתת חיפוש לאחר</translation>
    </message>
    <message>
        <source> min</source>
        <comment>Minutes</comment>
        <translation>דק&apos;</translation>
    </message>
    <message>
        <source>Clipboard clear seconds</source>
        <translation>ניקוי לוח גזירים בשניות</translation>
    </message>
    <message>
        <source>Lock databases after inactivity of</source>
        <translation>נעילת מסדי־נתונים לאחר חוסר פעילות של</translation>
    </message>
    <message>
        <source>Convenience</source>
        <translation>נוחות</translation>
    </message>
    <message>
        <source>Enable database quick unlock (Touch ID / Windows Hello)</source>
        <translation>אפשור שחרור נעילת מסד נתונים מהיר (Touch ID / Windows Hello)</translation>
    </message>
    <message>
        <source>Lock databases when session is locked or lid is closed</source>
        <translation>נעילת מסדי־נתונים כאשר ההפעלה נעולה או המכסה סגור</translation>
    </message>
    <message>
        <source>Lock databases after minimizing the window</source>
        <translation>נעילת מסדי־נתונים לאחר מזעור החלון</translation>
    </message>
    <message>
        <source>Hide passwords when editing them</source>
        <translation>הסתרת סיסמאות בעת עריכתן</translation>
    </message>
    <message>
        <source>Use placeholder for empty password fields</source>
        <translation>יש להשתמש בשומר מקום עבור שדות סיסמה ריקים</translation>
    </message>
    <message>
        <source>Hide passwords in the entry preview panel</source>
        <translation>הסתרת סיסמאות בלוח תצוגת רשומות מקדימה</translation>
    </message>
    <message>
        <source>Privacy</source>
        <translation>פרטיות</translation>
    </message>
    <message>
        <source>Use DuckDuckGo service to download website icons</source>
        <translation>יש להשתמש בשירות DuckDuckGo כדי להוריד סמלי אתרים</translation>
    </message>
    <message>
        <source>Hide TOTP in the entry preview panel</source>
        <translation>הסתרת TOTP בלוחית תצוגת רשומות מקדימה</translation>
    </message>
    <message>
        <source>Lock databases when switching user</source>
        <translation>נעילת מסדי־נתונים בעת החלפת משתמש</translation>
    </message>
    <message>
        <source>Lock Options</source>
        <translation>אפשרויות נעילה</translation>
    </message>
    <message>
        <source>Hide notes in the entry preview panel</source>
        <translation>הסתרת הערות בלוח תצוגת רשומות מקדימה</translation>
    </message>
</context>
<context>
    <name>AttachmentWidget</name>
    <message>
        <source>Attachment Viewer</source>
        <translation>משקף צרופות</translation>
    </message>
    <message>
        <source>Unknown attachment type</source>
        <translation>סוג צרופה לא ידוע</translation>
    </message>
</context>
<context>
    <name>AutoType</name>
    <message>
        <source>The requested Auto-Type sequence cannot be used due to an error:</source>
        <translation>לא ניתן להשתמש ברצף הקלדה־אוטומטית המבוקש עקב שגיאה:</translation>
    </message>
    <message>
        <source>Auto-Type Error</source>
        <translation>שגיאת הקלדה־אוטומטית</translation>
    </message>
    <message>
        <source>Permission Required</source>
        <translation>נדרשת הרשאה</translation>
    </message>
    <message>
        <source>KeePassXC requires the Accessibility permission in order to perform entry level Auto-Type. If you already granted permission, you may have to restart KeePassXC.</source>
        <translation>ל־KeePassXC נדרשת הרשאת נגישות על מנת לבצע הקלדה־אוטומטית ברמה בסיסית. אם כבר הוענקה הרשאה, ייתכן שצריך לאתחל את KeePassXC.</translation>
    </message>
    <message>
        <source>KeePassXC requires the Accessibility and Screen Recorder permission in order to perform global Auto-Type. Screen Recording is necessary to use the window title to find entries. If you already granted permission, you may have to restart KeePassXC.</source>
        <translation>ל־KeePassXC נדרשת הרשאת נגישות ומקליט מסך על מנת לבצע הקלדה־אוטומטית כללית. הקלטת מסך נחוצה כדי להשתמש בכותרת החלון כדי למצוא רשומות. אם כבר הוענקה הרשאה, ייתכן שצריך לאתחל את KeePassXC.</translation>
    </message>
    <message>
        <source>Invalid entry provided</source>
        <translation>סופקה רשומה לא תקינה</translation>
    </message>
    <message>
        <source>Bracket imbalance detected, found extra { or }</source>
        <translation>זוהה חוסר איזון בסוגריים, נמצאו { או } נוספים</translation>
    </message>
    <message>
        <source>Too many repetitions detected, max is %1: %2</source>
        <translation>זוהו חזרות רבות מדי, המרב הוא %1: %2</translation>
    </message>
    <message>
        <source>Very slow key press detected, max is %1: %2</source>
        <translation>זוהתה הקשת מקש איטית מאוד, המרב הוא %1: %2</translation>
    </message>
    <message>
        <source>Very long delay detected, max is %1: %2</source>
        <translation>זוהתה השהיה ארוכה מאוד, המרב הוא %1: %2</translation>
    </message>
    <message>
        <source>Entry does not have attribute for PICKCHARS: %1</source>
        <translation>לרשומה אין תכונה עבור PICKCHARS: %1</translation>
    </message>
    <message>
        <source>Invalid placeholder: %1</source>
        <translation>שומר מקום לא תקין: %1</translation>
    </message>
    <message>
        <source>Entry has invalid TOTP settings</source>
        <translation>raunv עם הגדרות TOTP לא תקינות</translation>
    </message>
</context>
<context>
    <name>AutoTypeAssociationsModel</name>
    <message>
        <source>Window</source>
        <translation>חלון</translation>
    </message>
    <message>
        <source>Sequence</source>
        <translation>רצף</translation>
    </message>
    <message>
        <source>(empty)</source>
        <translation>(ריק)</translation>
    </message>
    <message>
        <source>Default sequence</source>
        <translation>רצף ברירת מחדל</translation>
    </message>
</context>
<context>
    <name>AutoTypeMatchModel</name>
    <message>
        <source>Group</source>
        <translation>קבוצה</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>כותרת</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>שם משתמש</translation>
    </message>
    <message>
        <source>Sequence</source>
        <translation>רצף</translation>
    </message>
</context>
<context>
    <name>AutoTypePlatformWayland</name>
    <message>
        <source>No symbol found for key: &apos;%1&apos;</source>
        <translation>לא נימצא סמל עבור מפתח:  &apos;%1&apos;</translation>
    </message>
    <message>
        <source>No symbol found for character: &apos;%1&apos;</source>
        <translation>לא נמצא סמל עבור תו:  &apos;%1&apos;</translation>
    </message>
</context>
<context>
    <name>AutoTypePlatformX11</name>
    <message>
        <source>Sequence aborted: Caps Lock is on</source>
        <translation>הרצף בוטל: Caps Lock מופעל</translation>
    </message>
    <message>
        <source>Sequence aborted: Modifier keys held by user</source>
        <translation>הרצף בוטל: מקשי הצירוף מוחזקים על־ידי המשתמש</translation>
    </message>
    <message>
        <source>Unable to get valid keycode for key: </source>
        <translation>לא ניתן לקבל קוד מפתח תקין למפתח: </translation>
    </message>
    <message>
        <source>Trying to send invalid keyboard symbol.</source>
        <translation>ניסיון לשלוח סמל מקלדת לא תקין.</translation>
    </message>
</context>
<context>
    <name>AutoTypeSelectDialog</name>
    <message>
        <source>Auto-Type - KeePassXC</source>
        <translation>הקלדה־אוטומטית - KeePassXC</translation>
    </message>
    <message>
        <source>Double click a row to perform Auto-Type or find an entry using the search:</source>
        <translation>יש להקיש הקשה כפולה על שורה כדי לבצע הקלדה־אוטומטית או כדי למצוא רשומה באמצעות החיפוש:</translation>
    </message>
    <message>
        <source>Search all open databases</source>
        <translation>חיפוש בכל מסדי הנתונים הפתוחים</translation>
    </message>
    <message>
        <source>Search…</source>
        <translation>חיפוש...</translation>
    </message>
    <message>
        <source>Type Sequence</source>
        <translation>הקלדת רצף</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>ביטול</translation>
    </message>
    <message>
        <source>Type {USERNAME}</source>
        <translation>סוג {שם משתמש}</translation>
    </message>
    <message>
        <source>Type {PASSWORD}</source>
        <translation>סוג {סיסמה}</translation>
    </message>
    <message>
        <source>Type {TOTP}</source>
        <translation>סוג {TOTP}</translation>
    </message>
    <message>
        <source>Copy Username</source>
        <translation>העתקת שם משתמש</translation>
    </message>
    <message>
        <source>Copy Password</source>
        <translation>העתקת סיסמה</translation>
    </message>
    <message>
        <source>Copy TOTP</source>
        <translation>העתקת TOTP</translation>
    </message>
    <message>
        <source>Use Virtual Keyboard</source>
        <translation>שימוש במקלדת מדומה</translation>
    </message>
    <message>
        <source>Type {URL}</source>
        <translation>סוג {סיסמה}</translation>
    </message>
    <message>
        <source>Copy URL</source>
        <translation>להעתיק מען URL</translation>
    </message>
    <message>
        <source>&lt;p&gt;The following shortcuts are available:&lt;br/&gt;
Ctrl+F - Focus search&lt;br/&gt;
Ctrl+1 - Type username&lt;br/&gt;
Ctrl+2 - Type password&lt;br/&gt;
Ctrl+3 - Type TOTP&lt;br/&gt;
Ctrl+4 - Type URL&lt;br/&gt;
Ctrl+5 - Use Virtual Keyboard (Windows Only)&lt;br/&gt;
Ctrl+Shift+1 - Copy username&lt;br/&gt;
Ctrl+Shift+2 - Copy password&lt;br/&gt;
Ctrl+Shift+3 - Copy TOTP&lt;br/&gt;
Ctrl+Shift+4 - Copy URL&lt;br/&gt;
&lt;/p&gt;</source>
        <translation>&lt;p&gt;זמינים קיצורי המקלדת הבאים:&lt;br/&gt;
Ctrl+F - חיפוש ממוקד&lt;br/&gt;
Ctrl+1 - הזנת שם משתמש&lt;br/&gt;
Ctrl+2 - הזנת סיסמה&lt;br/&gt;
Ctrl+3 - הזנת TOTP&lt;br/&gt;
Ctrl+4 - הזנת URL&lt;br/&gt;
Ctrl+5 - שימוש במקלדת מדומה (Windows Only)&lt;br/&gt;
Ctrl+Shift+1 - העתקת שם משתמש&lt;br/&gt;
Ctrl+Shift+2 - העתקת סיסמה&lt;br/&gt;
Ctrl+Shift+3 - העתקת TOTP&lt;br/&gt;
Ctrl+Shift+4 - העתקת URL&lt;br/&gt;
&lt;/p&gt;</translation>
    </message>
    <message>
        <source>You can use advanced search queries to find any entry in your open databases.</source>
        <translation>ניתן להשתמש בשאילתות חיפוש מתקדם למציאת רשומה כלשהיא במסד הנתונים שפתוח כעת.</translation>
    </message>
</context>
<context>
    <name>BinaryStream</name>
    <message>
        <source>Failed to read string data: %1</source>
        <translation>כשל בקריאת נתוני מחרוזת: %1</translation>
    </message>
    <message>
        <source>String length exceeds 10 MiB limit (requested %1)</source>
        <translation>אורך מחרוזת חורג ממגבלת 10 מ&quot;ב (נתבקש %1)</translation>
    </message>
</context>
<context>
    <name>BrowserAccessControlDialog</name>
    <message>
        <source>KeePassXC - Browser Access Request</source>
        <translation>KeePassXC - בקשת גישה לדפדפן</translation>
    </message>
    <message>
        <source>%1 is requesting access to the following entries:</source>
        <translation>נתקבלה בקשת גישה מ־%1 לרשומות הבאות:</translation>
    </message>
    <message>
        <source>Remember access to checked entries</source>
        <translation>זכירת גישה לרשומות שסומנו</translation>
    </message>
    <message>
        <source>Remember</source>
        <translation>זכירה</translation>
    </message>
    <message>
        <source>Allow access to entries</source>
        <translation>אפשור גישה לרשומות</translation>
    </message>
    <message>
        <source>Allow Selected</source>
        <translation>אפשור נבחרים</translation>
    </message>
    <message>
        <source>Deny All</source>
        <translation>דחיית הכול</translation>
    </message>
    <message>
        <source>Disable for this site</source>
        <translation>השבתה עבור אתר זה</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation>ביטול פעולה</translation>
    </message>
</context>
<context>
    <name>BrowserEntrySaveDialog</name>
    <message>
        <source>Ok</source>
        <translation>בסדר</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>ביטול</translation>
    </message>
    <message>
        <source>You have multiple databases open.
Please select the correct database for saving credentials.</source>
        <translation>יש לך מספר מסדי־נתונים פתוחים.
נא לבחור את מסד הנתונים הנכון לשמירת נתוני האמנה.</translation>
    </message>
    <message>
        <source>KeePassXC - Select Database</source>
        <translation>KeePassXC - בחירת מסד־נתונים</translation>
    </message>
</context>
<context>
    <name>BrowserPasskeysConfirmationDialog</name>
    <message>
        <source>Cancel</source>
        <translation>ביטול</translation>
    </message>
    <message>
        <source>Update</source>
        <translation>עדכון</translation>
    </message>
    <message>
        <source>Authenticate</source>
        <translation>אימות</translation>
    </message>
    <message>
        <source>Register new</source>
        <translation>רישום חדש</translation>
    </message>
    <message>
        <source>Register</source>
        <translation>רישום</translation>
    </message>
    <message numerus="yes">
        <source>Timeout in &lt;b&gt;%n&lt;/b&gt; seconds...</source>
        <translation><numerusform>פסק זמן בתוך שניה &lt;b&gt;%n&lt;/b&gt;...</numerusform><numerusform>פסק זמן בתוך &lt;b&gt;%n&lt;/b&gt; שניות...</numerusform><numerusform>פסק זמן תוך &lt;b&gt;%n&lt;/b&gt; שניות...</numerusform></translation>
    </message>
    <message>
        <source>Relying Party: %1</source>
        <translation>צד מסתמך: %1</translation>
    </message>
    <message>
        <source>Username: %1</source>
        <translation>שם משתמש: %1</translation>
    </message>
    <message>
        <source>KeePassXC - Passkey credentials</source>
        <translation>KeePassXC - נתוני האמנה של מפתח גישה</translation>
    </message>
    <message>
        <source>Add to existing entry</source>
        <translation>הוספה לרשומה קיימת</translation>
    </message>
    <message>
        <source>Existing passkey found.
Do you want to register a new passkey for:</source>
        <translation>נמצא מפתח גישה קיים.
האם ברצונך לרשום מפתח גישה חדש עבור:</translation>
    </message>
    <message>
        <source>Select the existing passkey and press Update to replace it.</source>
        <translation>יש לבחור את מפתח הגישה הקיים וללחוץ על עדכון כדי להחליפו.</translation>
    </message>
    <message>
        <source>Authenticate passkey credentials for:</source>
        <translation>אימות נתוני האמנה של מפתח גישה עבור:</translation>
    </message>
    <message>
        <source>Do you want to register a passkey for:</source>
        <translation>האם ברצונך לרשום מפתח גישה עבור:</translation>
    </message>
</context>
<context>
    <name>BrowserService</name>
    <message>
        <source>A request for creating a new group &quot;%1&quot; has been received.
Do you want to create this group?
</source>
        <translation>בקשה ליצור קבוצה חדשה &quot;%1&quot; התקבלה.
האם ליצור קבוצה זו?
</translation>
    </message>
    <message>
        <source>You have received an association request for the following database:
%1

Give the connection a unique name or ID, for example:
chrome-laptop.</source>
        <translation>התקבלה בקשת שיוך עבור מסד הנתונים הבא:
%1

יש לתת לחיבור שם או מזהה ייחודיים, לדוגמה:
מחשב נייד-כרום.</translation>
    </message>
    <message>
        <source>Save and allow access</source>
        <translation>שמירה ואפשור גישה</translation>
    </message>
    <message>
        <source>A shared encryption key with the name &quot;%1&quot; already exists.
Do you want to overwrite it?</source>
        <translation>קיים כבר מפתח הצפנה משותף עם השם &quot;%1&quot;. האם לכתוב על הכתוב?</translation>
    </message>
    <message>
        <source>Do you want to update the information in %1 - %2?</source>
        <translation>האם ברצונך לעדכן את המידע ב־%1 - %2?</translation>
    </message>
    <message>
        <source>A request for deleting entry &quot;%1&quot; has been received.
Do you want to delete the entry?
</source>
        <translation>בקשה למחיקת רשומה &quot;%1&quot; התקבלה.
האם למחוק רשומה זו?
</translation>
    </message>
    <message>
        <source>%1 (Passkey)</source>
        <translation>%1 (מפתח גישה)</translation>
    </message>
    <message>
        <source>KeePassXC - Create a new group</source>
        <translation>KeePassXC - יצירת קבוצה חדשה</translation>
    </message>
    <message>
        <source>Disable</source>
        <translation>מושבת</translation>
    </message>
    <message>
        <source>KeePassXC - Overwrite existing key?</source>
        <translation>KeePassXC - לכתוב על מפתח קיים?</translation>
    </message>
    <message>
        <source>KeePassXC - Update Entry</source>
        <translation>KeePassXC - עדכון רשומה</translation>
    </message>
    <message>
        <source>KeePassXC - Delete entry</source>
        <translation>KeePassXC - מחיקת רשומה</translation>
    </message>
    <message>
        <source>KeePassXC - New key association request</source>
        <translation>KeePassXC - בקשת שיוך מפתח חדש</translation>
    </message>
    <message>
        <source>Passkey</source>
        <translation>מפתח גישה</translation>
    </message>
    <message>
        <source>KeePassXC - Passkey credentials</source>
        <translation>KeePassXC - נתוני האמנה של מפתח גישה</translation>
    </message>
    <message>
        <source>Register a new passkey to this entry:</source>
        <translation>רישום מפתח גישה חדש לרשומה זו:</translation>
    </message>
    <message>
        <source>KeePassXC - Update passkey</source>
        <translation>KeePassXC - עדכון מפתח גישה</translation>
    </message>
    <message>
        <source>Entry already has a passkey.
Do you want to overwrite the passkey in %1 - %2?</source>
        <translation>לרשומה זו כבר יש מפתח גישה.
האם ברצונך לכתוב על מפתח הגישה ב־%1 - %2?</translation>
    </message>
    <message>
        <source>Register</source>
        <translation>רישום</translation>
    </message>
</context>
<context>
    <name>BrowserSettingsWidget</name>
    <message>
        <source>Dialog</source>
        <translation>דו־שיח</translation>
    </message>
    <message>
        <source>This is required for accessing your databases with KeePassXC-Browser</source>
        <translation>נדרש עבור גישה למסדי הנתונים באמצעות דפדפן־KeePassXC</translation>
    </message>
    <message>
        <source>Enable browser integration</source>
        <translation>אפשור שילוב דפדפן</translation>
    </message>
    <message>
        <source>General</source>
        <translation>כללי</translation>
    </message>
    <message>
        <source>Enable integration for these browsers:</source>
        <translation>אפשור שילוב עם דפדפנים אלה:</translation>
    </message>
    <message>
        <source>Vivaldi</source>
        <translation>Vivaldi</translation>
    </message>
    <message>
        <source>&amp;Edge</source>
        <translation>&amp;Edge</translation>
    </message>
    <message>
        <source>Firefox</source>
        <translation>Firefox</translation>
    </message>
    <message>
        <source>Tor Browser</source>
        <translation>דפדפן Tor</translation>
    </message>
    <message>
        <source>Brave</source>
        <translation>Brave</translation>
    </message>
    <message>
        <source>Google Chrome</source>
        <translation>Google Chrome</translation>
    </message>
    <message>
        <source>Chromium</source>
        <translation>Chromium</translation>
    </message>
    <message>
        <source>Show a notification when credentials are requested</source>
        <extracomment>Credentials mean login data requested via browser extension</extracomment>
        <translation>הצגת הודעה כאשר נדרשים נתוני האמנה</translation>
    </message>
    <message>
        <source>Request to unlock the database if it is locked</source>
        <translation>יש לבקש לשחרר את נעילת מסד הנתונים אם הוא נעול</translation>
    </message>
    <message>
        <source>Only entries with the same scheme (http://, https://, …) are returned.</source>
        <translation>רק רשומות עם אותה הסכמה (http://, https://, …) מוחזרות.</translation>
    </message>
    <message>
        <source>Match URL scheme (e.g., https://example.com)</source>
        <translation>התאמת סכמת URL (לדוגמה, https://example.com)</translation>
    </message>
    <message>
        <source>Only returns the best matches for a specific URL instead of all entries for the whole domain.</source>
        <translation>החזרת ההתאמות הטובות ביותר בלבד עבור כתובת אתר מסויימת במקום כל הרשומות עבור כל תחום.</translation>
    </message>
    <message>
        <source>Return only best-matching credentials</source>
        <translation>החזרת נתוני האמנה המתאימים ביותר בלבד</translation>
    </message>
    <message>
        <source>Returns expired credentials. String [expired] is added to the title.</source>
        <translation>מחזיר נתוני האמנה שפג תוקפם. מחרוזת [פג תוקף] נוספת לכותרת.</translation>
    </message>
    <message>
        <source>Allow returning expired credentials</source>
        <translation>אפשור החזרת נתוני האמנה שפג תוקפם</translation>
    </message>
    <message>
        <source>All databases connected to the extension will return matching credentials.</source>
        <translation>כל מסדי הנתונים המחוברים להרחבה יחזירו נתוני האמנה תואמים.</translation>
    </message>
    <message>
        <source>Search in all opened databases for matching credentials</source>
        <extracomment>Credentials mean login data requested via browser extension</extracomment>
        <translation>חיפוש נתוני האמנה תואמים בכל מסדי הנתונים הפתוחים</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>מתקדם</translation>
    </message>
    <message>
        <source>Never ask before accessing credentials</source>
        <extracomment>Credentials mean login data requested via browser extension</extracomment>
        <translation>לעולם לא לשאול לפני גישה לנתוני האמנה</translation>
    </message>
    <message>
        <source>Never ask before updating credentials</source>
        <extracomment>Credentials mean login data requested via browser extension</extracomment>
        <translation>לעולם לא לשאול לפני עדכון נתוני האמנה</translation>
    </message>
    <message>
        <source>Do not ask permission for HTTP Basic Auth</source>
        <extracomment>An extra HTTP Basic Auth setting</extracomment>
        <translation>לא לבקש רשות עבור אימות בסיסי של HTTP</translation>
    </message>
    <message>
        <source>Automatically creating or updating string fields is not supported.</source>
        <translation>יצירה או עדכון אוטומטיים של שדות מחרוזת אינם נתמכים.</translation>
    </message>
    <message>
        <source>Return advanced string fields which start with &quot;KPH: &quot;</source>
        <translation>החזרת שדות מחרוזת מתקדמים המתחילים ב־&quot;KPH: &quot;</translation>
    </message>
    <message>
        <source>Don&apos;t display the popup suggesting migration of legacy KeePassHTTP settings.</source>
        <translation>לא להציג חלונות־צצים המציעים הגירת הגדרות KeePassHTTP מדור קודם.</translation>
    </message>
    <message>
        <source>Do not prompt for KeePassHTTP settings migration.</source>
        <translation>לא להציג הנחיה להעברת הגדרות KeePassHTTP.</translation>
    </message>
    <message>
        <source>Updates KeePassXC or keepassxc-proxy binary path automatically to native messaging scripts on startup.</source>
        <translation>עדכון הנתיב הבינארי KeePassXC או keepassxc־proxy בינאריים באופן אוטומטי לתסריטים להודעות מקוריות בעת האיתחול.</translation>
    </message>
    <message>
        <source>Update native messaging manifest files at startup</source>
        <translation>עדכון קבצי מניפסט להודעות מקוריות בעת האיתחול</translation>
    </message>
    <message>
        <source>Use a custom proxy location if you installed a proxy manually.</source>
        <translation>שימוש במיקום שרת מתווך מותאם אישית אם השרת המתווך הותקן באופן ידני.</translation>
    </message>
    <message>
        <source>Use a custom proxy location:</source>
        <comment>Meant is the proxy for KeePassXC-Browser</comment>
        <translation>שימוש במיקום שרת מתווך מותאם אישית:</translation>
    </message>
    <message>
        <source>Custom proxy location field</source>
        <translation>שדה מיקום שרת מתווך מותאם אישית</translation>
    </message>
    <message>
        <source>Browser for custom proxy file</source>
        <translation>דפדפן עבור קובץ שרת מתווך מותאם אישית</translation>
    </message>
    <message>
        <source>Browse…</source>
        <extracomment>Button for opening file dialog</extracomment>
        <translation>עיון...</translation>
    </message>
    <message>
        <source>Use a custom browser configuration location:</source>
        <translation>שימוש במיקום תצורת דפדפן מותאם אישית:</translation>
    </message>
    <message>
        <source>Browser type:</source>
        <translation>סוג דפדפן:</translation>
    </message>
    <message>
        <source>Toolbar button style</source>
        <translation>סגנון לחצן סרגל כלים</translation>
    </message>
    <message>
        <source>Config Location:</source>
        <translation>תצורת מיקום:</translation>
    </message>
    <message>
        <source>Custom browser location field</source>
        <translation>שדה מיקום דפדפן מותאם אישית</translation>
    </message>
    <message>
        <source>Browse for custom browser path</source>
        <translation>עיון עבור נתיב דפדפן מותאם אישית</translation>
    </message>
    <message>
        <source>Custom extension ID:</source>
        <translation>מזהה הרחבה מותאם אישית:</translation>
    </message>
    <message>
        <source>Custom extension ID</source>
        <translation>מזהה הרחבה מותאם אישית</translation>
    </message>
    <message>
        <source>Executable Files</source>
        <translation>קבצי הפעלה</translation>
    </message>
    <message>
        <source>All Files</source>
        <translation>כל הקבצים</translation>
    </message>
    <message>
        <source>Select custom proxy location</source>
        <translation>בחירת מיקום שרת מתווך מותאם אישית</translation>
    </message>
    <message>
        <source>Select native messaging host folder location</source>
        <translation>בחירת מיקום תיקיית מארח שרות הודעות מובנה</translation>
    </message>
    <message>
        <source>Allow keepassxc-proxy to list all entries with their title, URL and UUID in connected databases.</source>
        <translation>לאפשר למתווך KeePassXC להציג רשית כל הרשומות עם הכותרות שלהן, מעני URI ו־UUID ממסד־הנתונים המקושר.</translation>
    </message>
    <message>
        <source>Allow limited access to all entries in connected databases (ignores site access restrictions)</source>
        <translation>לאפשר גישה מוגבלת לכל הרשומות ממסד־הנתונים המקושר (להתעלם ממגבלות גישה לאתרים)</translation>
    </message>
    <message>
        <source>&lt;b&gt;Warning:&lt;/b&gt; Only adjust these settings if necessary.</source>
        <translation>&lt;b&gt;אזהרה:&lt;/b&gt; לכוונן הגדרות אלו בלבד ככוש שנדרש.</translation>
    </message>
    <message>
        <source>The custom proxy location does not exist.</source>
        <translation>מיקום מתווך מותאם אישית לא קיים.</translation>
    </message>
    <message>
        <source>&lt;b&gt;Error:&lt;/b&gt; The custom proxy location does not exist. Correct this in the advanced settings tab.</source>
        <translation>&lt;b&gt;שגיאה:&lt;/b&gt; מיקום המתווך המותאם אישית לא קיים. נא לתקן זאת בלשונית הגדרות מתקדמות.</translation>
    </message>
    <message>
        <source>&lt;b&gt;Error:&lt;/b&gt; The installed proxy executable is missing from the expected location: %1&lt;br/&gt;Please set a custom proxy location in the advanced settings or reinstall the application.</source>
        <translation>&lt;b&gt;שגיאה:&lt;/b&gt; המתווך הבציע המותקן חסר במיקום הצפוי: %1&lt;br/&gt; נא לקבוע מיקום מתווך מותאם אישית בהגדרות מתקדמות או להתקין מחדש את היישום.</translation>
    </message>
    <message>
        <source>Allows using insecure http://localhost with passkeys for testing purposes.</source>
        <translation>אפשור שימוש ב־http://localhost לא מאובטח למטרות בדיקה.</translation>
    </message>
    <message>
        <source>Allow using localhost with passkeys</source>
        <translation>אפשור שימוש ב־localhost עם passkeys</translation>
    </message>
    <message>
        <source>KeePassXC-Browser is needed for the browser integration to work. &lt;br /&gt;Download it for %1 and %2 and %3.</source>
        <translation>דפדפן – KeePassXC נדרש כדי שתכלול דפדפן יפעל. &lt;br /&gt; ניתן להורידו עבור %1 ו־%2 ו־%3.</translation>
    </message>
    <message>
        <source>Browsers installed using Snap or Flatpak are not supported with exception to Firefox installed using Snap.</source>
        <translation>דפדפנים שהותקנו באמצעות Snap או Flatpak אינם נתמכים למעט Firefox שהותקן באמצעות Snap.</translation>
    </message>
</context>
<context>
    <name>CloneDialog</name>
    <message>
        <source>Clone Entry Options</source>
        <translation>שכפול אפשרויות רשומה</translation>
    </message>
    <message>
        <source>Append &apos; - Clone&apos; to title</source>
        <translation>צירוף &apos; - שיבוט&apos; לכותרת</translation>
    </message>
    <message>
        <source>Replace username and password with references</source>
        <translation>החלפת שם משתמש וססמה בהפניות</translation>
    </message>
    <message>
        <source>Copy history</source>
        <translation>העתק הסטוריה</translation>
    </message>
</context>
<context>
    <name>CsvImportWidget</name>
    <message>
        <source>size, rows, columns</source>
        <translation>גודל, שורות, עמודות</translation>
    </message>
    <message>
        <source>Column Association</source>
        <translation>שיוך עמודות</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>ססמה</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>שם משתמש</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>כותרת</translation>
    </message>
    <message>
        <source>Group</source>
        <translation>קבוצה</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>מען url</translation>
    </message>
    <message>
        <source>Notes</source>
        <translation>הערות</translation>
    </message>
    <message>
        <source>TOTP</source>
        <translation>TOTP</translation>
    </message>
    <message>
        <source>Created</source>
        <translation>נוצר</translation>
    </message>
    <message>
        <source>Last Modified</source>
        <translation>הוסגל לאחרונה</translation>
    </message>
    <message>
        <source>Icon</source>
        <translation>סמל</translation>
    </message>
    <message>
        <source>Encoding</source>
        <translation>קידוד</translation>
    </message>
    <message>
        <source>Codec</source>
        <translation>קודק</translation>
    </message>
    <message>
        <source>Text is qualified by</source>
        <translation>מלל הוכשר על־ידי</translation>
    </message>
    <message>
        <source>Text qualification</source>
        <translation>הכשרת מלל</translation>
    </message>
    <message>
        <source>Fields are separated by</source>
        <translation>שדות מופרדים באמצעות</translation>
    </message>
    <message>
        <source>Field separation</source>
        <translation>הפרדת שדות</translation>
    </message>
    <message>
        <source>Comments start with</source>
        <translation>הערות מתחילות עם</translation>
    </message>
    <message>
        <source>Header lines skipped</source>
        <translation>המערכת דלגה על שורות כותרת עליונה</translation>
    </message>
    <message>
        <source>Number of header lines to discard</source>
        <translation>מספר שורות הכותרת שיש למחוק</translation>
    </message>
    <message>
        <source>First line has field names</source>
        <translation>לשורה הראשונה יש שמות שדות</translation>
    </message>
    <message>
        <source>Consider &apos;\&apos; an escape character</source>
        <translation>נא לשקול תו החלצות  &apos;\&apos;</translation>
    </message>
    <message>
        <source>Preview</source>
        <translation>תצוגה מקדימה</translation>
    </message>
    <message>
        <source>CSV import preview</source>
        <translation>תצוגה מקדימה ייבוא CSV</translation>
    </message>
    <message>
        <source>Not Present</source>
        <translation>לא קיים</translation>
    </message>
    <message>
        <source>Column %1</source>
        <translation>עמודה %1</translation>
    </message>
    <message numerus="yes">
        <source>[%n more message(s) skipped]</source>
        <translation><numerusform>[דילוג על הודעות נוספות %n]</numerusform><numerusform>[דילוג על %n הודעות נוספות]</numerusform><numerusform>[דלוג על %n הודעות נוספות]</numerusform></translation>
    </message>
    <message>
        <source>Failed to parse CSV file: %1</source>
        <translation>ניתוך קובץ CSV כשל: %1</translation>
    </message>
    <message>
        <source>Imported from CSV file: %1</source>
        <translation>יובא מקובץ CSV: %1</translation>
    </message>
    <message>
        <source>No Title Selected</source>
        <translation>לא נבחרה כותרת</translation>
    </message>
    <message>
        <source>No title column was selected, entries will be hard to tell apart.
Are you sure you want to import?</source>
        <translation>לא נבחרה כותרת עמודה, יהיה קשה להבחין בין רשומות.
האם לייבוא?</translation>
    </message>
    <message>
        <source>Tags</source>
        <translation>תגים</translation>
    </message>
</context>
<context>
    <name>CsvParserModel</name>
    <message numerus="yes">
        <source>%n row(s)</source>
        <comment>CSV row count</comment>
        <translation><numerusform>שורה %n</numerusform><numerusform>%n שורות</numerusform><numerusform>%n שורות</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>%n column(s)</source>
        <comment>CSV column count</comment>
        <translation><numerusform>עמודה %n</numerusform><numerusform>%n עמודות</numerusform><numerusform>%n עמודות</numerusform></translation>
    </message>
</context>
<context>
    <name>Database</name>
    <message>
        <source>Passwords</source>
        <comment>Root group name</comment>
        <translation>ססמאות</translation>
    </message>
    <message>
        <source>File %1 does not exist.</source>
        <translation>קובץ %1 לא קיים.</translation>
    </message>
    <message>
        <source>Unable to open file %1.</source>
        <translation>לא יכול לפתוח את הקובץ %1.</translation>
    </message>
    <message>
        <source>Error while reading the database: %1</source>
        <translation>שגיאה בזמן קריאת מסד־נתונים: %1</translation>
    </message>
    <message>
        <source>Could not save, database does not point to a valid file.</source>
        <translation>לא ניתן לשמור, מסד הנתונים לא מצביע על קובץ תקין.</translation>
    </message>
    <message>
        <source>Database save is already in progress.</source>
        <translation>שמירת מסד־נתונים כבר בתהליך.</translation>
    </message>
    <message>
        <source>Could not save, database has not been initialized!</source>
        <translation>לא ניתן לשמור, מסד הנתונים לא אותחל!</translation>
    </message>
    <message>
        <source>Database file has unmerged changes.</source>
        <translation>בקובץ מסד הנתונים קיימים שינויים שלא מוזגו.</translation>
    </message>
    <message>
        <source>%1
Backup database located at %2</source>
        <translation>%1
גיבוי מסד־נתונים הממוקם ב־%2</translation>
    </message>
    <message>
        <source>Key not transformed. This is a bug, please report it to the developers.</source>
        <translation>מפתח לא הומר. זהו תקל, נא לדווח עליו לצוות הפתוח.</translation>
    </message>
    <message>
        <source>Recycle Bin</source>
        <translation>סל המחזור</translation>
    </message>
    <message>
        <source>Database file read error.</source>
        <translation>שגיאת קריאת קובץ מסד־נתונים</translation>
    </message>
    <message>
        <source>No file path was provided.</source>
        <translation>לא סופק נתיב קובץ.</translation>
    </message>
</context>
<context>
    <name>DatabaseOpenDialog</name>
    <message>
        <source>Unlock Database - KeePassXC</source>
        <translation>שחרור נעילת מסד־נתונים - KeePassXC</translation>
    </message>
</context>
<context>
    <name>DatabaseOpenWidget</name>
    <message>
        <source>Unlock KeePassXC Database</source>
        <translation>שחרור נעילת מסד־נתונים KeePassXC</translation>
    </message>
    <message>
        <source>Enter Password:</source>
        <translation>הזנת ססמה:</translation>
    </message>
    <message>
        <source>Password field</source>
        <translation>שדה ססמה</translation>
    </message>
    <message>
        <source>Hardware key slot selection</source>
        <translation>בחירת עמדה למפתח חומרה</translation>
    </message>
    <message>
        <source>Key file to unlock the database</source>
        <translation>קובץ מפתח לשחרור נעילת מסד־הנתונים</translation>
    </message>
    <message>
        <source>Browse for key file</source>
        <translation>דפדוף לקובץ מפתח</translation>
    </message>
    <message>
        <source>Browse…</source>
        <translation>עיון...</translation>
    </message>
    <message>
        <source>Unlock Database</source>
        <translation>שחרור נעילת מסד הנתונים</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>ביטול</translation>
    </message>
    <message>
        <source>Unlock</source>
        <translation>שחרור נעילה</translation>
    </message>
    <message>
        <source>Please present or touch your YubiKey to continue…</source>
        <translation>נא להציג או לגעת ב־YubiKey על מנת להמשך...</translation>
    </message>
    <message>
        <source>Database Version Mismatch</source>
        <translation>אין תאימות בגרסאות מסד־נתונים</translation>
    </message>
    <message>
        <source>The database you are trying to open was most likely
created by a newer version of KeePassXC.

You can try to open it anyway, but it may be incomplete
and saving any changes may incur data loss.

We recommend you update your KeePassXC installation.</source>
        <translation>מסד הנתונים אותו נעשה ניסיון לפתוח נוצר קרוב לוודאי
 על ידי גרסת Keepassxc חדשה יות

ניתן לנסות לפתוח אותו למרות זאת, אך עשוי הוא עשוי להיות חלקי
ושמירת שינויים למסד הנתונים שנפתח, עלולה לגרום לאובדן נתונים.

אנו ממליצים לעדכן את התקנת KeepassXC שבמחשב.</translation>
    </message>
    <message>
        <source>Open database anyway</source>
        <translation>פתיחת מסד־נתונים בכול זאת</translation>
    </message>
    <message>
        <source>Database unlock canceled.</source>
        <translation>שחרור נעילת מסד־נתונים בוטלה</translation>
    </message>
    <message>
        <source>Unlock failed and no password given</source>
        <translation>שחרור נעילה כשל ולא סופקה ססמה</translation>
    </message>
    <message>
        <source>Unlocking the database failed and you did not enter a password.
Do you want to retry with an &quot;empty&quot; password instead?

To prevent this error from appearing, you must go to &quot;Database Settings / Security&quot; and reset your password.</source>
        <translation>שחרור נעילת מסד־הנתונים כשל ולא הזנה ססמה.
האם לנסות שוב עם ססמה &quot;ריקה&quot; במקום?

כדי למנוע הופעת שגיאה זו, נא לעבור אל &quot;הגדרות מסד־נתונים / אבטחה&quot; ולאפס את הססמה.</translation>
    </message>
    <message>
        <source>Retry with empty password</source>
        <translation>נסה שוב עם ססמה ריקה</translation>
    </message>
    <message>
        <source>Failed to open key file: %1</source>
        <translation>כשל בפתיחת קובץ מפתח: %1</translation>
    </message>
    <message>
        <source>Old key file format</source>
        <translation>תסדיר קובץ מפתח ישן</translation>
    </message>
    <message>
        <source>You are using an old key file format which KeePassXC may&lt;br&gt;stop supporting in the future.&lt;br&gt;&lt;br&gt;Please consider generating a new key file by going to:&lt;br&gt;&lt;strong&gt;Database &amp;gt; Database Security &amp;gt; Change Key File.&lt;/strong&gt;&lt;br&gt;</source>
        <translation>נעשה שימוש בתסדיר קובץ מפתח ישן ש־KeePassXC עשוי&lt;br&gt;להפסיק לתמוך בעתיד.&lt;br&gt;&lt;br&gt;נא שקול ליצור קובץ מפתח חדש מהתפריט:&lt;br&gt;&lt;strong&gt;מסד־נתונים -&gt; אבטחת מסד־נתונים -&gt; שינוי קובץ מפתח.&lt;/strong&gt;&lt;br&gt;</translation>
    </message>
    <message>
        <source>Don&apos;t show this warning again</source>
        <translation>לא להציג הזהרה זו שוב</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>כל הקבצים</translation>
    </message>
    <message>
        <source>Key files</source>
        <translation>קבצי מפתח</translation>
    </message>
    <message>
        <source>Select key file</source>
        <translation>בחירת קובץ ססמה</translation>
    </message>
    <message>
        <source>Cannot use database file as key file</source>
        <translation>לא ניתן להשתמש בקובץ מסד־נתונים כקובץ מפתח</translation>
    </message>
    <message>
        <source>authenticate to access the database</source>
        <translation>נא לאמת לגישה למסד הנתונים</translation>
    </message>
    <message>
        <source>Failed to authenticate with Quick Unlock: %1</source>
        <translation>אימות עם שחרור נעילה מהיר כשל: %1</translation>
    </message>
    <message>
        <source>Select Key File:</source>
        <translation>בחירת קובץ מפתח:</translation>
    </message>
    <message>
        <source>&lt;p&gt;In addition to a password, you can use a secret file to enhance the security of your database. This file can be generated in your database&apos;s security settings.&lt;/p&gt;&lt;p&gt;This is &lt;strong&gt;not&lt;/strong&gt; your *.kdbx database file!&lt;/p&gt;</source>
        <translation>&lt;p&gt; בנוסף לססמה, ניתן להשתמש בקובץ סודי להעצמת ביטחון מסד הנתונים. ניתן לחולל קובץ זה מהגדרות אבטחת מסד הנתונים.&lt;/p&gt;&lt;p&gt;זה &lt;strong&gt;לא&lt;/strong&gt; קובץ מסד נתונים *.kdbx.</translation>
    </message>
    <message>
        <source>Use hardware key [Serial: %1]</source>
        <translation>שימוש במפתח חומרה  [Serial: %1]</translation>
    </message>
    <message>
        <source>Use hardware key</source>
        <translation>שימוש במפתח חומרה</translation>
    </message>
    <message>
        <source>Your database file is NOT a key file!
If you don&apos;t have a key file or don&apos;t know what that is, you don&apos;t have to select one.</source>
        <translation>קובץ מסד נתונים הוא לא קובץ מפתח.
אם אין קובץ מפתח או לא ברור מה זה, לא נדרש לקבוע כזה.</translation>
    </message>
    <message>
        <source>KeePassXC database file selected</source>
        <translation>קובץ מסד נתונים KeePassXC</translation>
    </message>
    <message>
        <source>The file you selected looks like a database file.
A database file is NOT a key file!

Are you sure you want to continue with this file?.</source>
        <translation>הקובץ שנבחר נראה כמו קובץ מסד נתונים.
קובץ מסד נתונים הוא לא קובץ מפתח!

האם להמשיך עם קובץ זה?</translation>
    </message>
    <message>
        <source>No hardware keys found.</source>
        <translation>לא נמצאו מפתחות חומרה.</translation>
    </message>
    <message>
        <source>Refresh Hardware Keys</source>
        <translation>רענון מפתחות חומרה</translation>
    </message>
    <message>
        <source>Click to add a key file.</source>
        <translation>הקשה להוספת קובץ מפתח חדש.</translation>
    </message>
    <message>
        <source>Hardware keys found, but no slots are configured.</source>
        <translation>נמצאו מפתחות חומרה, אבל לא הוגדרו חריצים.</translation>
    </message>
    <message>
        <source>Press ESC again to close this database</source>
        <translation>לחיצה חוזרת על מקש ESC לסגירת מסד־נתונים זה</translation>
    </message>
    <message>
        <source>I have a key file</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>DatabaseSettingWidgetMetaData</name>
    <message>
        <source>Passwords</source>
        <translation>ססמאות</translation>
    </message>
</context>
<context>
    <name>DatabaseSettingsDialog</name>
    <message>
        <source>General</source>
        <translation>כללי</translation>
    </message>
    <message>
        <source>Security</source>
        <translation>אבטחה</translation>
    </message>
    <message>
        <source>Database Credentials</source>
        <translation>אישורי מסד־נתונים</translation>
    </message>
    <message>
        <source>Encryption Settings</source>
        <translation>הצנת ההגדרות</translation>
    </message>
    <message>
        <source>Browser Integration</source>
        <translation>שילוב דפדפן</translation>
    </message>
    <message>
        <source>Maintenance</source>
        <translation>תחזוקה</translation>
    </message>
    <message>
        <source>KeeShare</source>
        <translation>KeeShare</translation>
    </message>
    <message>
        <source>Secret Service Integration</source>
        <translation>שילוב שירות חשאי</translation>
    </message>
    <message>
        <source>Remote Sync</source>
        <translation>סנכרון מרחוק</translation>
    </message>
    <message>
        <source>Database Settings: %1</source>
        <translation>הגדרות מסד־נתונים: %1</translation>
    </message>
</context>
<context>
    <name>DatabaseSettingsWidgetBrowser</name>
    <message>
        <source>KeePassXC-Browser settings</source>
        <translation>הגדרות דפדפן KeePassXC</translation>
    </message>
    <message>
        <source>Disconnect all browsers</source>
        <translation>ניתוק כל הדפדפנים</translation>
    </message>
    <message>
        <source>Forget all site-specific settings on entries</source>
        <translation>לשכוח את כל ההגדרות המסוימות לאתר ברשומות</translation>
    </message>
    <message>
        <source>Refresh database root group ID</source>
        <translation>רענון מזהה קבוצת שורש מסד־נתונים</translation>
    </message>
    <message>
        <source>Stored keys</source>
        <translation>אחסן ססמאות</translation>
    </message>
    <message>
        <source>Stored browser keys</source>
        <translation>מפתחות דפדפן מאוחסנים</translation>
    </message>
    <message>
        <source>Remove selected key</source>
        <translation>הסרת מפתחות שנבחרו</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>הסרה</translation>
    </message>
    <message>
        <source>Delete the selected key?</source>
        <translation>האם למחוק את המפתח שנבחר?</translation>
    </message>
    <message>
        <source>Do you really want to delete the selected key?
This may prevent connection to the browser plugin.</source>
        <translation>האם למחוק את המפתח שנבחר?
פעולה זו עשויה למנוע חיבור למתקע הדפדפן.</translation>
    </message>
    <message>
        <source>Key</source>
        <translation>מפתח</translation>
    </message>
    <message>
        <source>Value</source>
        <translation>ערך</translation>
    </message>
    <message>
        <source>Created</source>
        <translation>נוצר</translation>
    </message>
    <message>
        <source>Enable Browser Integration to access these settings.</source>
        <translation>אפשור שילוב דפדפנים לגישה להגדרות.</translation>
    </message>
    <message>
        <source>Do you really want to disconnect all browsers?
This may prevent connection to the browser plugin.</source>
        <translation>האם לנתק את כל הדפדפנים?
פעולה זו עשויה למנוע חיבור למתקע הדפדפן.</translation>
    </message>
    <message>
        <source>No shared encryption keys found in KeePassXC settings.</source>
        <translation>לא נמצאו מפתחות הצפנה משותפים בהגדרות KeePassXC.</translation>
    </message>
    <message numerus="yes">
        <source>Successfully removed %n encryption key(s) from KeePassXC settings.</source>
        <translation><numerusform>מפתח הצפנה משותף %n הוסר בהצלחה מהגדרות KeePassXC.</numerusform><numerusform>%n מפתחות הצפנה משותפים הוסרו בהצלחה מהגדרות KeePassXC.</numerusform><numerusform>%n מפתחות הצפנה משותפים הוסרו בהצלחה מהגדרות KeePassXC.</numerusform></translation>
    </message>
    <message>
        <source>Do you really want forget all site-specific settings on every entry?
Permissions to access entries will be revoked.</source>
        <translation>האם לשכוח הגדרות מסוימות לאתרים בכל הרשומות?
הרשאות גישה לרשומות יוסרו.</translation>
    </message>
    <message>
        <source>Removing stored permissions…</source>
        <translation>מסיר הרשאות מאוחסנות...</translation>
    </message>
    <message>
        <source>Abort</source>
        <translation>הפסק וצא</translation>
    </message>
    <message numerus="yes">
        <source>Successfully removed permissions from %n entry(s).</source>
        <translation><numerusform>הרשאה הוסרה בהצלחה מ־%n רשומות.</numerusform><numerusform>הרשאות הוסרו בהצלחה מ־%n רשומות.</numerusform><numerusform>הרשאות הוסרו בהצלחה מ־%n רשומות.</numerusform></translation>
    </message>
    <message>
        <source>The active database does not contain an entry with permissions.</source>
        <translation>מסד הנתונים הפעיל לא מכיל רשומה עם הרשאות.</translation>
    </message>
    <message>
        <source>Refresh database ID</source>
        <translation>רענון מזהה מסד־נתונים</translation>
    </message>
    <message>
        <source>Do you really want refresh the database ID?
This is only necessary if your database is a copy of another and the browser extension cannot connect.</source>
        <translation>האם לרענן את מזהה מסד הנתונים? נחוץ רק אם מסד הנתונים הוא עותק של מסד־נתונים אחר ומתקע הדפדפן לא מתחבר.</translation>
    </message>
    <message>
        <source>Convert legacy KeePassHTTP attributes to KeePassXC-Browser compatible custom data</source>
        <translation>המרת מאפייני תוכנת־מורשת KeePassHTTP לנתוני דפדפן KeePassXC תואמים.</translation>
    </message>
    <message>
        <source>No keys found</source>
        <translation>לא נמצאו מפתחות</translation>
    </message>
    <message>
        <source>Removed keys from database</source>
        <translation>מפתחות שהוסרו ממסד הנתונים</translation>
    </message>
    <message>
        <source>Removed permissions</source>
        <translation>התרים שהוסרו</translation>
    </message>
    <message>
        <source>No entry with permissions found!</source>
        <translation>לא נמצאה רשומה עם התרים!</translation>
    </message>
</context>
<context>
    <name>DatabaseSettingsWidgetDatabaseKey</name>
    <message>
        <source>Add additional protection…</source>
        <translation>הוספת הגנה נוספת...</translation>
    </message>
    <message>
        <source>No password set</source>
        <translation>לא הוגדרה ססמה</translation>
    </message>
    <message>
        <source>WARNING! You have not set a password. Using a database without a password is strongly discouraged!

Are you sure you want to continue without a password?</source>
        <translation>אזהרה! לא הוגדרה ססמה. השימוש במסד נתונים ללא ססמה לא מומלץ!

האם להמשיך ללא ססמה?</translation>
    </message>
    <message>
        <source>Continue without password</source>
        <translation>המשך ללא ססמה</translation>
    </message>
    <message>
        <source>No encryption key added</source>
        <translation>לא התווסף מפתח הצפנה</translation>
    </message>
    <message>
        <source>You must add at least one encryption key to secure your database!</source>
        <translation>נא להוסיף לפחות מפתח הצפנה אחד לאבטחת מסד הנתונים!</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation>שגיאה לא ידועה</translation>
    </message>
    <message>
        <source>Failed to change database credentials</source>
        <translation>שינוי אישורי מסד־נתונים כשל</translation>
    </message>
    <message>
        <source>Weak password</source>
        <translation>ססמה חלשה</translation>
    </message>
    <message>
        <source>This is a weak password! For better protection of your secrets, you should choose a stronger password.</source>
        <translation>זוהי ססמה חלשה! להגנה טובה יותר על קבצים חשאיים נא לבחור בססמה חזקה יותר.</translation>
    </message>
    <message>
        <source>The provided password does not meet the minimum quality requirement.</source>
        <translation>הססמה שסופקה לא עומדת בדרישת האיכות המזערית.</translation>
    </message>
</context>
<context>
    <name>DatabaseSettingsWidgetEncryption</name>
    <message>
        <source>Decryption Time:</source>
        <translation>זמן פענוח:</translation>
    </message>
    <message>
        <source>Decryption time in seconds</source>
        <translation>זמן פענוח בשניות</translation>
    </message>
    <message>
        <source>Higher values offer more protection, but opening the database will take longer.</source>
        <translation>ערכים גבוהים יותר מציעים הגנה טובה יותר, אך פתיחת מסד הנתונים תימשך זמן רב יותר.</translation>
    </message>
    <message>
        <source>Database format:</source>
        <translation>תסדיר מסד־נתונים:</translation>
    </message>
    <message>
        <source>Database format</source>
        <translation>תסדיר מסד־נתונים</translation>
    </message>
    <message>
        <source>Format cannot be changed: Your database uses KDBX 4 features</source>
        <translation>לא ניתן לשנות תסדיר: מסד הנתונים משתמש בתכונות KDBX 4</translation>
    </message>
    <message>
        <source>Unless you need to open your database with other programs, always use the latest format.</source>
        <translation>יש להשתמש תמיד במבנה האחרון (העדכני ביותר). אלא אם יידרש לפתוח את מסד הנתונים גם באמצעות תוכנות אחרות.</translation>
    </message>
    <message>
        <source>Encryption Algorithm:</source>
        <translation>אלגוריתם הצפנה:</translation>
    </message>
    <message>
        <source>Encryption algorithm</source>
        <translation>אלגוריתם הצפנה</translation>
    </message>
    <message>
        <source>AES:  256 Bit   (default)</source>
        <translation>AES: 256 סיביות (ברירת מחדל)</translation>
    </message>
    <message>
        <source>Twofish:  256 Bit</source>
        <translation>Twofish:  256 ביט</translation>
    </message>
    <message>
        <source>Key Derivation Function:</source>
        <translation>פעולת נגזרות מפתח:</translation>
    </message>
    <message>
        <source>Key derivation function</source>
        <translation>פעולת נגזרות מפתח</translation>
    </message>
    <message>
        <source>Transform rounds:</source>
        <translation>סבבי המרה:</translation>
    </message>
    <message>
        <source>Transform rounds</source>
        <translation>סבבי המרה</translation>
    </message>
    <message>
        <source>Memory Usage:</source>
        <translation>שימוש בזיכרון:</translation>
    </message>
    <message>
        <source>Memory usage</source>
        <translation>שימוש בזיכרון</translation>
    </message>
    <message>
        <source>Parallelism:</source>
        <translation>הקבלה:</translation>
    </message>
    <message>
        <source>Parallelism</source>
        <translation>הקבלה</translation>
    </message>
    <message>
        <source>KDBX 4 (recommended)</source>
        <translation>KDBX 4 (מומלץ)</translation>
    </message>
    <message>
        <source>KDBX 3</source>
        <translation>KDBX 3</translation>
    </message>
    <message>
        <source>Number of rounds too high</source>
        <comment>Key transformation rounds</comment>
        <translation>מספר הסבבים גבוה מדי</translation>
    </message>
    <message>
        <source>You are using a very high number of key transform rounds with Argon2.

If you keep this number, your database may take hours, days, or even longer to open.</source>
        <translation>נעשה שימוש במספר גבוה מאוד של סבבי המרת מפתח עם ארגון2.

אם מספר זה יישמר, פתיחת מסד הנתונים עשויה להימשך שעות או ימים או אפילו יותר.</translation>
    </message>
    <message>
        <source>Understood, keep number</source>
        <translation>מובן, שמרת מספר</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>ביטול</translation>
    </message>
    <message>
        <source>Number of rounds too low</source>
        <comment>Key transformation rounds</comment>
        <translation>מספר סבבים נמוך מדי</translation>
    </message>
    <message>
        <source>You are using a very low number of key transform rounds with AES-KDF.

If you keep this number, your database will not be protected from brute force attacks.</source>
        <translation>נעשה שימוש במספר נמוך מאוד של סבבי המרת מפתח עם AES-KDF.

אם מספר זה ישמר, מסד הנתונים לא יהיה מוגן מפני תְּקִיפָה כּוֹחָנִית.</translation>
    </message>
    <message>
        <source>KDF unchanged</source>
        <translation>KDF ללא שינוי</translation>
    </message>
    <message>
        <source>Failed to transform key with new KDF parameters; KDF unchanged.</source>
        <translation>המרת מפתח באמצעות פרמטרים חדשים של KDF כשלה; KDF נשאר ללא שינוי.</translation>
    </message>
    <message numerus="yes">
        <source> MiB</source>
        <comment>Abbreviation for Mebibytes (KDF settings)</comment>
        <translation><numerusform> מיל.</numerusform><numerusform> מיל.</numerusform><numerusform> מיב</numerusform></translation>
    </message>
    <message numerus="yes">
        <source> thread(s)</source>
        <comment>Threads for parallel execution (KDF settings)</comment>
        <translation><numerusform>שִׁרְשׁוּר</numerusform><numerusform>שִׁרְשׁוּרים</numerusform><numerusform>שִׁרְשׁוּרים</numerusform></translation>
    </message>
    <message>
        <source>Encryption Settings:</source>
        <translation>הגדרות קידוד:</translation>
    </message>
    <message>
        <source>Basic</source>
        <translation>בסיסי</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>מתקדם</translation>
    </message>
</context>
<context>
    <name>DatabaseSettingsWidgetFdoSecrets</name>
    <message>
        <source>Exposed Entries</source>
        <translation>רשומות חשופות</translation>
    </message>
    <message>
        <source>Don&apos;t expose this database</source>
        <translation>לא לחשוף מסד־נתונים זה</translation>
    </message>
    <message>
        <source>Expose entries under this group:</source>
        <translation>חשיפת רשומות בקבוצה זו:</translation>
    </message>
    <message>
        <source>Enable Secret Service to access these settings.</source>
        <translation>איפשור גישות השירות החשאי להגדרות אלה.</translation>
    </message>
</context>
<context>
    <name>DatabaseSettingsWidgetGeneral</name>
    <message>
        <source>Database Metadata</source>
        <translation>נתוני־על מסד־נתונים</translation>
    </message>
    <message>
        <source>Database name:</source>
        <translation>שם מסד־נתונים:</translation>
    </message>
    <message>
        <source>Database name field</source>
        <translation>שדה שם מסד־נתונים</translation>
    </message>
    <message>
        <source>Database description:</source>
        <translation>תיאור מסד הנתונים:</translation>
    </message>
    <message>
        <source>Database description field</source>
        <translation>שדה תיאור מסד־נתונים</translation>
    </message>
    <message>
        <source>Default username:</source>
        <translation>שם משתמש ברירת מחדל:</translation>
    </message>
    <message>
        <source>Default username field</source>
        <translation>שדה שם משתמש ברירת מחדל</translation>
    </message>
    <message>
        <source>History Settings</source>
        <translation>הגדרות היסטוריה</translation>
    </message>
    <message>
        <source>Maximum number of history items per entry</source>
        <translation>מספר מרבי של פרטי היסטוריה לרשומה</translation>
    </message>
    <message>
        <source>Maximum size of history per entry</source>
        <translation>גודל היסטוריה מרבי לרשומה</translation>
    </message>
    <message>
        <source> MiB</source>
        <translation> מיב</translation>
    </message>
    <message>
        <source>Use recycle bin</source>
        <translation>שימוש בסל־מחזור</translation>
    </message>
    <message>
        <source>Additional Database Settings</source>
        <translation>הגדרות מסד־נתונים נוספות</translation>
    </message>
    <message>
        <source>Enable compression (recommended)</source>
        <translation>איפור דחיסה (מומלץ)</translation>
    </message>
    <message>
        <source>Delete Recycle Bin</source>
        <translation>מחיקת סל־מחזור</translation>
    </message>
    <message>
        <source>Do you want to delete the current recycle bin and all its contents?
This action is not reversible.</source>
        <translation>האם למחוק את סל־המיחזור הנוכחי ואת כל תוכנו?
פעולה זו אינה הפיכה.</translation>
    </message>
    <message>
        <source> (old)</source>
        <translation> (ישן)</translation>
    </message>
    <message>
        <source>When saving this setting or editing an entry
the oldest history items of an entry will be
removed such that only the specified amount
of entries remain at most.</source>
        <translation>בעת שמירת גדרה זו או עריכת רשומה
פריטי ההיסטורית רשומה היישנים ביותר יוסרו
כך שלכול היותר תיוותר רק כמות הרשומות שצוינה.</translation>
    </message>
    <message>
        <source>Limit the amount of history items per entry to:</source>
        <translation>הגבלת כמות ההיסטוריה לרשומה ל:</translation>
    </message>
    <message>
        <source>When saving this setting or editing an entry
the oldest history items of an entry will be
removed such that the remaining history items
add up to the specified amount at most.</source>
        <translation>בעת שמירת גדרה זו או עריכת רשומה
פריטי ההיסטורית־רשומה היישנים ביותר יוסרו
כך שפרטי ההיסטוריה שיוותרו יסתכמו בכמות הרשומות שצוינה.</translation>
    </message>
    <message>
        <source>Limit the total size of history items per entry to:</source>
        <translation>הגבלת כמות ההיסטוריה הכוללת לרשומה ל:</translation>
    </message>
    <message>
        <source>Move entries to a recycle bin group
instead of deleting them from the database.
Entries deleted from the recycle bin are
removed from the database.</source>
        <translation>העברת רשומות לקבוצת סל מיחזור
במקום מחיקתם ממסד הנתונים.
רשומות שימחקו מסל המיחזור 
יוסרו ממסד הנתונים.</translation>
    </message>
    <message>
        <source>Autosave delay since last change</source>
        <translation>השהיית שמירה אוטומטית מאז השינוי האחרון</translation>
    </message>
    <message>
        <source>Autosave delay</source>
        <translation>השהיית שמירה אוטומטית</translation>
    </message>
    <message>
        <source>Autosave delay since last change in minutes</source>
        <translation>השהית שמירה אוטומטית בדקות מאז שינוי אחרון</translation>
    </message>
    <message>
        <source> min</source>
        <translation> דקה</translation>
    </message>
    <message>
        <source>Autosave delay since last change checkbox</source>
        <translation>תיבת סימון השהית שמירה אוטומטית בדקות מאז שינוי אחרון</translation>
    </message>
    <message>
        <source>Public Database Metadata</source>
        <translation>מטא־נתונים של מסד־נתונים ציבורי</translation>
    </message>
    <message>
        <source>Warning: the following settings are not encrypted.</source>
        <translation>אזהרה: ההגדרות הבאות אינן מוצפנות.</translation>
    </message>
    <message>
        <source>Display name:</source>
        <translation>שם מצג:</translation>
    </message>
    <message>
        <source>Database public display name</source>
        <translation>שם תצוגה ציבורי של מסד־נתונים</translation>
    </message>
    <message>
        <source>Display color:</source>
        <translation>צבע תצוגה:</translation>
    </message>
    <message>
        <source>Database public display color chooser</source>
        <translation>בוחר צבע תצוגה ציבורי של מסד־נתונים</translation>
    </message>
    <message>
        <source>Clear</source>
        <translation>נקה</translation>
    </message>
    <message>
        <source>Display icon:</source>
        <translation>סמל תצוגה:</translation>
    </message>
    <message>
        <source>Select Database Icon</source>
        <translation>בחירת סמל מסד־נתונים</translation>
    </message>
    <message>
        <source>Publicly visible display name used on the unlock dialog</source>
        <translation>שם תצוגה גלוי לכול שמשמש בדו־שיח שחרור נעילה</translation>
    </message>
    <message>
        <source>Publicly visible color used on the unlock dialog</source>
        <translation>צבע גלוי לכול שמשמש בדו־שיח שחרור נעילה</translation>
    </message>
</context>
<context>
    <name>DatabaseSettingsWidgetKeeShare</name>
    <message>
        <source>Sharing</source>
        <translation>שיתוף</translation>
    </message>
    <message>
        <source>Breadcrumb</source>
        <translation>סימני דרך</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>סוג</translation>
    </message>
    <message>
        <source>Path</source>
        <translation>נתיב</translation>
    </message>
    <message>
        <source>Last Signer</source>
        <translation>חותם אחרון</translation>
    </message>
    <message>
        <source>Certificates</source>
        <translation>אישורים</translation>
    </message>
    <message>
        <source> &gt; </source>
        <comment>Breadcrumb separator</comment>
        <translation> &gt; </translation>
    </message>
</context>
<context>
    <name>DatabaseSettingsWidgetMaintenance</name>
    <message>
        <source>Manage Custom Icons</source>
        <translation>ניהול סמלים מותאמים אישית</translation>
    </message>
    <message>
        <source>Delete selected icon(s)</source>
        <translation>מחיקת סמלים שנבחרו</translation>
    </message>
    <message>
        <source>Delete all custom icons not in use by any entry or group</source>
        <translation>מחיקת כל הסמלים המותאמים אישית שאינם בשימוש על־ידי רשומה או קבוצה כלשהם</translation>
    </message>
    <message>
        <source>Purge unused icons</source>
        <translation>ניקוי סמלים שאינם בשימוש</translation>
    </message>
    <message>
        <source>Confirm Deletion</source>
        <translation>אישור מחיקה</translation>
    </message>
    <message>
        <source>At least one of the selected icons is currently in use by at least one entry or group. The icons of all affected entries and groups will be replaced by the default icon. Are you sure you want to delete icons that are currently in use?</source>
        <translation>לפחות אחד מהסמלים שנבחרו נמצא כעת בשימוש רשומה או קבוצה אחת לפחות. סמלי כל הרשומות והקבוצות המושפעים יוחלפו בסמל ברירת המחדל. האם למחוק סמלים הנמצאים כעת בשימוש?</translation>
    </message>
    <message>
        <source>Custom Icons Are In Use</source>
        <translation>סמלים מותאמים אישית נמצאים בשימוש</translation>
    </message>
    <message>
        <source>All custom icons are in use by at least one entry or group.</source>
        <translation>כל הסמלים המותאמים אישית בשימוש לפחות על־ידי רשומה או קבוצה אחת.</translation>
    </message>
    <message>
        <source>Purged Unused Icons</source>
        <translation>סמלים לא בשימוש שנמחקו</translation>
    </message>
    <message numerus="yes">
        <source>Purged %n icon(s) from the database.</source>
        <translation><numerusform>סמל %n נמחק ממסד הנתונים.</numerusform><numerusform>%n סמלים נמחקו ממסד הנתונים.</numerusform><numerusform>%n סמלים נמחקו ממסד הנתונים.</numerusform></translation>
    </message>
</context>
<context>
    <name>DatabaseSettingsWidgetMetaDataSimple</name>
    <message>
        <source>Database Name:</source>
        <translation>שם מסד־נתונים:</translation>
    </message>
    <message>
        <source>Database name field</source>
        <translation>שדה שם מסד־נתונים</translation>
    </message>
    <message>
        <source>Description:</source>
        <translation>תיאור:</translation>
    </message>
    <message>
        <source>Database description field</source>
        <translation>שדה תיאור מסד־נתונים</translation>
    </message>
</context>
<context>
    <name>DatabaseSettingsWidgetRemote</name>
    <message>
        <source>Sync Commands</source>
        <translation>פקודות סנכרון</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>הסרה</translation>
    </message>
    <message>
        <source>Command Settings</source>
        <translation>הגדרות פקודה</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>שם</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>שמירה</translation>
    </message>
    <message>
        <source>Download</source>
        <translation>הורדה</translation>
    </message>
    <message>
        <source>Command:</source>
        <translation>פקודה:</translation>
    </message>
    <message>
        <source>Download command field</source>
        <translation>הורדת שדה פקודה</translation>
    </message>
    <message>
        <source>e.g.: &quot;sftp user@hostname&quot; or &quot;scp user@hostname:DatabaseOnRemote.kdbx {TEMP_DATABASE}&quot;</source>
        <translation>לדוגמה: &quot;sftp user@hostname&quot; או  &quot;scp user@hostname:DatabaseOnRemote.kdbx {TEMP_DATABASE}&quot;</translation>
    </message>
    <message>
        <source>Input:</source>
        <translation>קלט:</translation>
    </message>
    <message>
        <source>Download input field</source>
        <translation>הורדת שדה קלט</translation>
    </message>
    <message>
        <source>Upload</source>
        <translation>האלעה</translation>
    </message>
    <message>
        <source>Upload command field</source>
        <translation>העלאת שדה פקודה</translation>
    </message>
    <message>
        <source>e.g.: &quot;sftp user@hostname&quot; or &quot;scp {TEMP_DATABASE} user@hostname:DatabaseOnRemote.kdbx&quot;</source>
        <translation>לדוגמה:  &quot;sftp user@hostname&quot; או &quot;scp {TEMP_DATABASE} user@hostname:DatabaseOnRemote.kdbx&quot;</translation>
    </message>
    <message>
        <source>Upload input field</source>
        <translation>העלאת שדה קלט</translation>
    </message>
    <message>
        <source>Name cannot be empty.</source>
        <translation>שם לא יכול להיות ריק</translation>
    </message>
    <message>
        <source>Test</source>
        <translation>בדיקה</translation>
    </message>
    <message>
        <source>Download command cannot be empty.</source>
        <translation>פקודת הורדה לא יכול להיות ריק</translation>
    </message>
    <message>
        <source>Download failed with error: %1</source>
        <translation>פקודת הורדה עם שגיאה: %1</translation>
    </message>
    <message>
        <source>Download finished, but file %1 could not be found.</source>
        <translation>הורדת קבצים שהסתיימו, אבל קובץ %1 לא נמצא.</translation>
    </message>
    <message>
        <source>Download successful.</source>
        <translation>הורדה צלחה.</translation>
    </message>
    <message>
        <source>Save Remote Settings</source>
        <translation>שמירת הגדרות מרוחקות</translation>
    </message>
    <message>
        <source>You have unsaved changes. Do you want to save them?</source>
        <translation>קיימים שינויים שלא נשמרו. האם לשמור אותם?</translation>
    </message>
    <message>
        <source>e.g.:
get DatabaseOnRemote.kdbx {TEMP_DATABASE}
exit
---
{TEMP_DATABASE} is used as placeholder to store the database in a temporary location
The command has to exit. In case of `sftp` as last command `exit` has to be sent
            </source>
        <translation>לדוגמה:
get DatabaseOnRemote.kdbx {TEMP_DATABASE}
exit
---
{TEMP_DATABASE} משמש כשומר מקום לאחסון מסד הנתונים במיקום זמני.
הפקודה אמורה להסתיים ב&apos;יציאה&apos;. במקרה של `sftp` כפקודה אחרונה, יש לשלוח פקודת `exit`
            </translation>
    </message>
    <message>
        <source>e.g.:
put {TEMP_DATABASE} DatabaseOnRemote.kdbx
exit
---
{TEMP_DATABASE} is used as placeholder to store the database in a temporary location
The command has to exit. In case of `sftp` as last command `exit` has to be sent
            </source>
        <translation>לדוגמה:
put {TEMP_DATABASE} DatabaseOnRemote.kdbx
exit
---
{TEMP_DATABASE} משמש כשומר מקום לאחסון מסד הנתונים במיקום זמני.
הפקודה אמורה להסתיים ב&apos;יציאה&apos;. במקרה של `sftp` כפקודה אחרונה, יש לשלוח פקודת `exit`
            </translation>
    </message>
    <message>
        <source>Timeout:</source>
        <translation>פסק זמן:</translation>
    </message>
    <message>
        <source> seconds</source>
        <translation> שניות</translation>
    </message>
</context>
<context>
    <name>DatabaseTabWidget</name>
    <message>
        <source>Database creation error</source>
        <translation>שגיאת יצירת מסד־נתונים</translation>
    </message>
    <message>
        <source>The created database has no key or KDF, refusing to save it.
This is definitely a bug, please report it to the developers.</source>
        <translation>למסד הנתונים שנוצר אין מפתח או ש־KDF מסרב לקבל אותו.
זהו בהחלט תקל, נא לדווח עליו לצוות הפתוח.</translation>
    </message>
    <message>
        <source>KeePass 2 Database</source>
        <translation>מסד נתוני KeePass 2</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>כל הקבצים</translation>
    </message>
    <message>
        <source>Open database</source>
        <translation>פתיחת מסד־נתונים</translation>
    </message>
    <message>
        <source>Failed to open %1. It either does not exist or is not accessible.</source>
        <translation>פתיחת %1 כשלה. יתכן והוא לא קיים או לא נגיש.</translation>
    </message>
    <message>
        <source>CSV file</source>
        <translation>קובץ CSV</translation>
    </message>
    <message>
        <source>Merge database</source>
        <translation>מיזוג מסד־נתונים</translation>
    </message>
    <message>
        <source>Export database to CSV file</source>
        <translation>ייצוא מסד־נתונים לקובץ CSV</translation>
    </message>
    <message>
        <source>Writing the CSV file failed.</source>
        <translation>כתיבת קובץ ה־CSV כשלה.</translation>
    </message>
    <message>
        <source>Writing the HTML file failed.</source>
        <translation>כתיבת קובץ ה־HTML כשלה.</translation>
    </message>
    <message>
        <source>Export database to XML file</source>
        <translation>ייצוא מסד נתונים לקובץ XML</translation>
    </message>
    <message>
        <source>XML file</source>
        <translation>קובץ XML</translation>
    </message>
    <message>
        <source>Writing the XML file failed</source>
        <translation>כתיבה לקובץ HTML כשלה.</translation>
    </message>
    <message>
        <source>Export Confirmation</source>
        <translation>אישור ייצוא</translation>
    </message>
    <message>
        <source>You are about to export your database to an unencrypted file. This will leave your passwords and sensitive information vulnerable! Are you sure you want to continue?</source>
        <translation>מסד הנתונים עומד להיות מיוצא לקובץ לא מוצפן. פעולה זו תשאיר את ססמאות ומידע רגיש, פגיעים! האם להמשיך?</translation>
    </message>
    <message>
        <source>%1 [Locked]</source>
        <comment>Database tab name modifier</comment>
        <translation>%1 [נעול]</translation>
    </message>
    <message>
        <source>%1 [Temporary]</source>
        <comment>Database tab name modifier</comment>
        <translation>%1 [זמני]</translation>
    </message>
</context>
<context>
    <name>DatabaseWidget</name>
    <message>
        <source>Searches and Tags</source>
        <translation>חיפוש ותיוג</translation>
    </message>
    <message>
        <source>Searching…</source>
        <translation>חיפוש...</translation>
    </message>
    <message>
        <source>Shared group…</source>
        <translation>קבוצה משותפת...</translation>
    </message>
    <message>
        <source>Confirm Auto-Type</source>
        <translation>אישור הקלדה־אוטומטית</translation>
    </message>
    <message>
        <source>Perform Auto-Type into the previously active window?</source>
        <translation>האם לבצע הקלדה־אוטומטית בחלון הפעיל הקודם?</translation>
    </message>
    <message>
        <source>Execute command?</source>
        <translation>האם לבצע פקודה?</translation>
    </message>
    <message>
        <source>Do you really want to execute the following command?&lt;br&gt;&lt;br&gt;%1&lt;br&gt;</source>
        <translation>האם לבצע את הפקודה הבאה?&lt;br&gt;&lt;br&gt;%1&lt;br&gt;</translation>
    </message>
    <message>
        <source>Remember my choice</source>
        <translation>זכירת הבחירה שלי</translation>
    </message>
    <message>
        <source>Do you really want to move the group &quot;%1&quot; to the recycle bin?</source>
        <translation>האם להעביר את הקבוצה &quot;%1&quot; לסל־המיחזור?</translation>
    </message>
    <message>
        <source>Expired entries</source>
        <translation>רשומות פגות־תוקף</translation>
    </message>
    <message numerus="yes">
        <source>Entries expiring within %1 day(s)</source>
        <translation><numerusform>רשומות שתוקפן יפוג בתוך יום %1</numerusform><numerusform>רשומות שתוקפן יפוג בתוך %1 ימים</numerusform><numerusform>רשומות שתוקפן יפוג בתוך %1 ימים</numerusform></translation>
    </message>
    <message>
        <source>No current database.</source>
        <translation>אין מסד־נתונים נוכחי.</translation>
    </message>
    <message>
        <source>No source database, nothing to do.</source>
        <translation>אין מסד נתוני מקור, אין מה לעשות.</translation>
    </message>
    <message>
        <source>Search Results (%1)</source>
        <translation>תוצאות חיפוש (%1)</translation>
    </message>
    <message>
        <source>No Results</source>
        <translation>אין תוצאות</translation>
    </message>
    <message>
        <source>Enter a unique name or overwrite an existing search from the list:</source>
        <translation>נא להזין שם ייחודי או לכתוב על שם חיפוש מהרשימה:</translation>
    </message>
    <message>
        <source>Save Search</source>
        <translation>שמירת חיפוש</translation>
    </message>
    <message>
        <source>Lock Database?</source>
        <translation>האם לנעול מסד־נתונים?</translation>
    </message>
    <message>
        <source>You are editing an entry. Discard changes and lock anyway?</source>
        <translation>הרשומה בעריכה. האם לנטוש שינויים ולנעול בכל זאת?</translation>
    </message>
    <message>
        <source>&quot;%1&quot; was modified.
Save changes?</source>
        <translation>&quot;%1&quot; הוסגל.
האם לשמור שינויים?</translation>
    </message>
    <message>
        <source>Database was modified.
Save changes?</source>
        <translation>מסד הנתונים הוסגל.
האם לשמור שינויים?</translation>
    </message>
    <message>
        <source>Save changes?</source>
        <translation>האם לשמור שינויים?</translation>
    </message>
    <message>
        <source>File has changed</source>
        <translation>הקובץ השתנה</translation>
    </message>
    <message>
        <source>Disable safe saves?</source>
        <translation>האם להשבית שמירות בטוחות?</translation>
    </message>
    <message>
        <source>KeePassXC has failed to save the database multiple times. This is likely caused by file sync services holding a lock on the save file.
Disable safe saves and try again?</source>
        <translation>KeePassXC כשל בשמירת מסד הנתונים מספר פעמים. סביר להניח שהדבר נגרם על־ידי שירותי סינכרון קבצים הנועלים את קובץ השמירה.
האם להשבית שמירות בטוחות ולנסות שוב?</translation>
    </message>
    <message>
        <source>Writing the database failed: %1</source>
        <translation>כתיבת מסד הנתונים כשלה: %1</translation>
    </message>
    <message>
        <source>Passwords</source>
        <translation>ססמאות</translation>
    </message>
    <message>
        <source>Save database as</source>
        <translation>שמירת מסד־נתונים בשם</translation>
    </message>
    <message>
        <source>KeePass 2 Database</source>
        <translation>מסד נתוני KeePass 2</translation>
    </message>
    <message>
        <source>Empty recycle bin?</source>
        <translation>לרוקן סל־מחזור?</translation>
    </message>
    <message>
        <source>Are you sure you want to permanently delete everything from your recycle bin?</source>
        <translation>האם למחוק הכול מסל־המיחזור לצמיתות?</translation>
    </message>
    <message>
        <source>Could not find database file: %1</source>
        <translation>לא ניתן למצוא קובץ מסד־נתונים: %1</translation>
    </message>
    <message>
        <source>New Database</source>
        <translation>מסד־נתונים חדש</translation>
    </message>
    <message>
        <source>%1 [New Database]</source>
        <comment>Database tab name modifier</comment>
        <translation>%1 [מסד־נתונים חדש]</translation>
    </message>
    <message>
        <source>Remote Sync did not contain any download or upload commands.</source>
        <translation>סנכרון מרוחק לא מכיל הורדה הורדה או העלאה.</translation>
    </message>
    <message>
        <source>Remote sync &apos;%1&apos; completed successfully!</source>
        <translation>סנכרון מרוחק &apos;%1&apos; הושלם בהצלחה!</translation>
    </message>
    <message>
        <source>Downloading...</source>
        <translation>הורדה...</translation>
    </message>
    <message>
        <source>Uploading...</source>
        <translation>מתבצעת העלאה...</translation>
    </message>
    <message>
        <source>Remote sync &apos;%1&apos; failed: %2</source>
        <translation>סנכרון מרוחק &apos;%1&apos; כשל: %2</translation>
    </message>
    <message>
        <source>Syncing...</source>
        <translation>מתבצע סנכרון...</translation>
    </message>
    <message>
        <source>Error while saving database %1: %2</source>
        <translation>שגיאה בעת שמירת מסד נתונים %1: %2</translation>
    </message>
    <message>
        <source>Remove passkey from entry</source>
        <translation>הסרת Passkey מרשומה</translation>
    </message>
    <message>
        <source>Do you want to remove the passkey from this entry?</source>
        <translation>האם להסיר את ה־Passkey מרשומה זו?</translation>
    </message>
    <message>
        <source>The database file &quot;%1&quot; was modified externally</source>
        <translation>קובץ מסד הנתונים &quot;%1&quot; השתנה באופן חיצוני</translation>
    </message>
    <message>
        <source>Do you want to load the changes?</source>
        <translation>האם ברצונך לטעון את השינויים?</translation>
    </message>
    <message>
        <source>Reloading database…</source>
        <translation>טוען מסד־נתונים מחדש…</translation>
    </message>
    <message>
        <source>Reload canceled</source>
        <translation>טעינה מחדש בוטלה</translation>
    </message>
    <message>
        <source>Reload successful</source>
        <translation>טעינה מחדש מוצלחת</translation>
    </message>
    <message>
        <source>Reload pending user action…</source>
        <translation>לטעון מחדש פעולת משתמש ממתינה…</translation>
    </message>
    <message>
        <source>The database file &quot;%1&quot; was modified externally.&lt;br&gt;How would you like to proceed?&lt;br&gt;&lt;br&gt;Merge all changes&lt;br&gt;Ignore the changes on disk until save&lt;br&gt;Discard unsaved changes</source>
        <translation>קובץ מסד הנתונים &quot;%1&quot; השתנה באופן חיצוני.&lt;br&gt;איך היית רוצה להתקדם?&lt;br&gt;&lt;br&gt;מיזוג כל השינויים&lt;br&gt;התעלמות מהשינויים בדיסק עד לשמירה&lt;br&gt;השלכת כל השינויים שלא נשמרו</translation>
    </message>
    <message>
        <source>The database file &quot;%1&quot; was modified externally.&lt;br&gt;How would you like to proceed?&lt;br&gt;&lt;br&gt;Merge all changes then save&lt;br&gt;Overwrite the changes on disk&lt;br&gt;Discard unsaved changes</source>
        <translation>קובץ מסד הנתונים &quot;%1&quot; השתנה באופן חיצוני.&lt;br&gt;איך היית רוצה להתקדם?&lt;br&gt;&lt;br&gt;מיזוג כל השינויים ואז שמירה&lt;br&gt;כתיבה על השינויים בדיסק&lt;br&gt;השלכת כל השינויים שלא נשמרו</translation>
    </message>
    <message>
        <source>Reload database</source>
        <translation>טעינת מסד־נתונים מחדש</translation>
    </message>
    <message>
        <source>Database file overwritten.</source>
        <translation>נכתב על קובץ מסד־נתונים.</translation>
    </message>
    <message>
        <source>Database file on disk cannot be unlocked with current credentials.&lt;br&gt;Enter new credentials and/or present hardware key to continue.</source>
        <translation>לא ניתן לשחרר נעילת קובץ מסד־נתונים בדיסק עם נתוני האמנה הנוכחיים.&lt;br&gt;יש להזין נתוני האמנה חדשים ו/או להציג מפתח חומרה כדי להמשיך.</translation>
    </message>
    <message>
        <source>Failed to save backup database: %1</source>
        <translation>כשל בשמירת גיבוי מסד־נתונים : %1</translation>
    </message>
    <message>
        <source>Confirm Delete Group</source>
        <translation>אישור מחיקת קבוצה</translation>
    </message>
    <message>
        <source>Do you really want to permanently delete the group &quot;%1&quot;?</source>
        <translation>האם למחוק לצמיתות את הקבוצה &quot;%1&quot;?</translation>
    </message>
    <message>
        <source>Confirm Recycle Group</source>
        <translation>אישור מחיקת קבוצה</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>שמירה</translation>
    </message>
    <message>
        <source>Save Database Backup</source>
        <translation>לשמור גיבוי מסד נתונים</translation>
    </message>
    <message>
        <source>Successfully merged the selected database.</source>
        <translation>מסד־נתונים שנבחר מוזגמ בהצלחה.</translation>
    </message>
    <message>
        <source>No changes were made by the merge operation.</source>
        <translation>לא בוצעו שינויים בפעולת המזוג.</translation>
    </message>
    <message>
        <source>Merge canceled, no changes were made.</source>
        <translation>מיזוג בוטל, לא נעשו שינויים.</translation>
    </message>
</context>
<context>
    <name>EditEntryAttachmentsDialog</name>
    <message>
        <source>Edit: %1</source>
        <translation>עריכה: %1</translation>
    </message>
</context>
<context>
    <name>EditEntryWidget</name>
    <message>
        <source>Entry</source>
        <translation>רשומה</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>מתקדם</translation>
    </message>
    <message>
        <source>Icon</source>
        <translation>סמל</translation>
    </message>
    <message>
        <source>Auto-Type</source>
        <translation>הקלדה־אוטומטית</translation>
    </message>
    <message>
        <source>Browser Integration</source>
        <translation>שילוב דפדפן</translation>
    </message>
    <message>
        <source>&lt;empty URL&gt;</source>
        <translation>&lt;מען URL ריק&gt;</translation>
    </message>
    <message>
        <source>Confirm Removal</source>
        <translation>אישור הסרה</translation>
    </message>
    <message>
        <source>Are you sure you want to remove this URL?</source>
        <translation>האם להסיר מען URL זה?</translation>
    </message>
    <message>
        <source>Properties</source>
        <translation>מאפיינים</translation>
    </message>
    <message>
        <source>History</source>
        <translation>היסטוריה</translation>
    </message>
    <message>
        <source>SSH Agent</source>
        <translation>סוכן SSH</translation>
    </message>
    <message>
        <source>n/a</source>
        <translation>ל/ר</translation>
    </message>
    <message>
        <source>Select private key</source>
        <translation>בחירת מפתח פרטי</translation>
    </message>
    <message>
        <source>Entry history</source>
        <translation>הסטורית רשומות</translation>
    </message>
    <message>
        <source>Add entry</source>
        <translation>הוספת רשומה</translation>
    </message>
    <message>
        <source>Edit entry</source>
        <translation>עריכת רשומה</translation>
    </message>
    <message>
        <source>Some Browser Integration settings are overridden by group settings.</source>
        <translation>הגדרות קבוצה יכתבו־על מספר הגדרות כילול דפדפן.</translation>
    </message>
    <message>
        <source>Invalid Entry</source>
        <translation>רשומה לא תקינה</translation>
    </message>
    <message>
        <source>An external merge operation has invalidated this entry.
Unfortunately, any changes made have been lost.</source>
        <translation>פעולת מיזוג חיצונית ביטלה רשומה זו.
למרבה הצער, כל השינויים שבוצעו אבדו.</translation>
    </message>
    <message>
        <source>Auto-Type Validation Error</source>
        <translation>שגיאת אימות הקלדה־אוטומטית</translation>
    </message>
    <message>
        <source>An error occurred while validating the custom Auto-Type sequence:
%1
Would you like to correct it?</source>
        <translation>אירעה שגיאה בעת אימות רצף הקלדה־אוטומטית מותאמת אישית:
%1
האם לתקן זאת?</translation>
    </message>
    <message>
        <source>An error occurred while validating the Auto-Type sequence for &quot;%1&quot;:
%2
Would you like to correct it?</source>
        <translation>אירעה שגיאה בעת אימות רצף הקלדה־אוטומטית ל־&quot;%1&quot;:
%2
האם לתקן זאת?</translation>
    </message>
    <message>
        <source>Entry updated successfully.</source>
        <translation>רשומה עודכנה בהצלחה.</translation>
    </message>
    <message>
        <source>Unsaved Changes</source>
        <translation>שינויים שלא נשמרו</translation>
    </message>
    <message>
        <source>Would you like to save changes to this entry?</source>
        <translation>האם לשמור שינויים לרשומה זו?</translation>
    </message>
    <message>
        <source>New attribute</source>
        <translation>תכונה חדשה</translation>
    </message>
    <message>
        <source>New attribute %1</source>
        <translation>תכונה חדשה %1</translation>
    </message>
    <message>
        <source>Are you sure you want to remove this attribute?</source>
        <translation>האם להסיר תכונה זו?</translation>
    </message>
    <message>
        <source>Reveal</source>
        <translation>חשיפה</translation>
    </message>
    <message>
        <source>[PROTECTED] Press Reveal to view or edit</source>
        <translation>[מוגן] הקשה על חשיפה או עריכה</translation>
    </message>
    <message>
        <source>Hide</source>
        <translation>הסתרה</translation>
    </message>
    <message numerus="yes">
        <source>%n hour(s)</source>
        <translation><numerusform>שעה %n</numerusform><numerusform>%1 שעות</numerusform><numerusform>%1 שעות</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>%n week(s)</source>
        <translation><numerusform>שבוע %n</numerusform><numerusform>%n שבועות</numerusform><numerusform>%n שבועות</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>%n month(s)</source>
        <translation><numerusform>חודש %n</numerusform><numerusform>%n חודשים</numerusform><numerusform>%n חודשים</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>%n year(s)</source>
        <translation><numerusform>שנה %n</numerusform><numerusform>%n שנים</numerusform><numerusform>%n שנים</numerusform></translation>
    </message>
    <message>
        <source>Failed to decrypt SSH key, ensure password is correct.</source>
        <translation>פענוח מפתח SSH כשל, נא לוודא שהססמה תקינה.</translation>
    </message>
</context>
<context>
    <name>EditEntryWidgetAdvanced</name>
    <message>
        <source>Additional attributes</source>
        <translation>תכונות נוספות</translation>
    </message>
    <message>
        <source>Attribute selection</source>
        <translation>בחירת תכונות</translation>
    </message>
    <message>
        <source>Attribute value</source>
        <translation>ערך תכונה</translation>
    </message>
    <message>
        <source>Add a new attribute</source>
        <translation>הוספת תכונה חדשה</translation>
    </message>
    <message>
        <source>Add</source>
        <translation>הוספה</translation>
    </message>
    <message>
        <source>Remove selected attribute</source>
        <translation>הסרת תכונות שנבחרו</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>הסרה</translation>
    </message>
    <message>
        <source>Edit attribute name</source>
        <translation>עריכת שם תכונה</translation>
    </message>
    <message>
        <source>Edit Name</source>
        <translation>עריכת שם</translation>
    </message>
    <message>
        <source>Toggle attribute protection</source>
        <translation>החלפת־מצב הגנה על תכונות</translation>
    </message>
    <message>
        <source>Protect</source>
        <translation>מיזם</translation>
    </message>
    <message>
        <source>Show a protected attribute</source>
        <translation>הצגת תכונה מוגנת</translation>
    </message>
    <message>
        <source>Reveal</source>
        <translation>חשיפה</translation>
    </message>
    <message>
        <source>Attachments</source>
        <translation>צרופות</translation>
    </message>
    <message>
        <source>If checked, the entry will not appear in reports like Health Check and HIBP even if it doesn&apos;t match the quality requirements.</source>
        <translation>אם אפשרות זו מסומנת, הרשומה לא תופיע בדוחות כגון בדיקת תקינות ו־HIBP גם אם היא אינה תואמת לדרישות האיכות.</translation>
    </message>
    <message>
        <source>Exclude from database reports</source>
        <translation>החרגה מדוחות מסד־נתונים</translation>
    </message>
    <message>
        <source>Foreground Color:</source>
        <translation>צבע חזית:</translation>
    </message>
    <message>
        <source>Foreground color selection</source>
        <translation>בחירת צבע חזית</translation>
    </message>
    <message>
        <source>Background Color:</source>
        <translation>צבע רקע:</translation>
    </message>
    <message>
        <source>Background color selection</source>
        <translation>בחירת צבע רקע</translation>
    </message>
</context>
<context>
    <name>EditEntryWidgetAutoType</name>
    <message>
        <source>Enable Auto-Type for this entry</source>
        <translation>אפשור הקלדה־אוטומטית ברשומה זו</translation>
    </message>
    <message>
        <source>Inherit default Auto-Type sequence from the group</source>
        <translation>ירושת רצף ברירת מחדל הקלדה־אוטומטית מהקבוצה</translation>
    </message>
    <message>
        <source>Use custom Auto-Type sequence:</source>
        <translation>שימוש ברצף הקלדה־אוטומטית ברירת מחדל:</translation>
    </message>
    <message>
        <source>Custom Auto-Type sequence</source>
        <translation>רצף הקלדה־אוטומטית מותאם אישית</translation>
    </message>
    <message>
        <source>Open Auto-Type help webpage</source>
        <translation>פתיחת עמוד מרשתת עזרת הקלדה־אוטומטית</translation>
    </message>
    <message>
        <source>Window Associations</source>
        <translation>שיוכי חלונות</translation>
    </message>
    <message>
        <source>Existing window associations</source>
        <translation>שיוכי חלונות קיימים</translation>
    </message>
    <message>
        <source>Add new window association</source>
        <translation>הוספת שיוך חלון חדש</translation>
    </message>
    <message>
        <source>+</source>
        <comment>Add item</comment>
        <translation>+</translation>
    </message>
    <message>
        <source>Remove selected window association</source>
        <translation>הסרת חלון צרופות שנבחר</translation>
    </message>
    <message>
        <source>-</source>
        <comment>Remove item</comment>
        <translation>-</translation>
    </message>
    <message>
        <source>Window title:</source>
        <translation>כותרת חלון:</translation>
    </message>
    <message>
        <source>You can use an asterisk (*) to match everything</source>
        <translation>ניתן להשתמש בכוכבית (*) כדי להתאים לכל דבר</translation>
    </message>
    <message>
        <source>Set the window association title</source>
        <translation>הגדרת כותרת שיוך החלון</translation>
    </message>
    <message>
        <source>You can use an asterisk to match everything</source>
        <translation>ניתן להשתמש בכוכבית כדי להתאים לכל דבר</translation>
    </message>
    <message>
        <source>Use a specific sequence for this association:</source>
        <translation>נא להשתמש ברצף מבויים עבור שיוך זה:</translation>
    </message>
    <message>
        <source>Custom Auto-Type sequence for this window</source>
        <translation>רצף הקלדה־אוטומטית מותאם אישית לחלון זה</translation>
    </message>
</context>
<context>
    <name>EditEntryWidgetBrowser</name>
    <message>
        <source>General</source>
        <translation>כללי</translation>
    </message>
    <message>
        <source>Hide this entry from the browser extension</source>
        <translation>הסתרת רשומה זו מהרחבת הדפדפן</translation>
    </message>
    <message>
        <source>Skip Auto-Submit for this entry</source>
        <translation>דלוג על Auto-Submit ברשומה זו</translation>
    </message>
    <message>
        <source>Use this entry only with HTTP Basic Auth</source>
        <translation>שימוש ברשומה זו רק באמצעות HTTP Basic Auth</translation>
    </message>
    <message>
        <source>Do not use this entry with HTTP Basic Auth</source>
        <translation>לא להשתמש ברשומה זו ב־HTTP Basic Auth</translation>
    </message>
    <message>
        <source>Add</source>
        <translation>הוספה</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>הסרה</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>עריכה</translation>
    </message>
    <message>
        <source>These settings affect the entry&apos;s behaviour with the browser extension.</source>
        <translation>הגדרות אלו משפיעות על התנהגות הרשומה עם הרחבות הדפדפן.</translation>
    </message>
    <message>
        <source>Additional URLs</source>
        <translation>מעני URL נוספים</translation>
    </message>
    <message>
        <source>Only send this entry to the browser for HTTP Auth dialogs. If enabled, normal login forms will not show this entry for selection.</source>
        <translation>לשלוח ערך זה לדפדפן רק עבור תיבות דו־שיח HTTP Auth. אם מופעל, טפסי התחברות רגילים לא יציגו ערך זה לבחירה.</translation>
    </message>
    <message>
        <source>Do not send this entry to the browser for HTTP Auth dialogs. If enabled, HTTP Auth dialogs will not show this entry for selection.</source>
        <translation>לא לשלוח ערך זה לדפדפן עבור תיבות דו־שיח של HTTP Auth. אם מופעל, תיבות דו־שיח HTTP Auth לא יציגו ערך זה לבחירה.</translation>
    </message>
</context>
<context>
    <name>EditEntryWidgetHistory</name>
    <message>
        <source>Entry history selection</source>
        <translation>בחירת הסטורית רשומות</translation>
    </message>
    <message>
        <source>Show entry at selected history state</source>
        <translation>הצגת רשומות במצב היסטוריה שנבחר</translation>
    </message>
    <message>
        <source>Show</source>
        <translation>מצג</translation>
    </message>
    <message>
        <source>Restore entry to selected history state</source>
        <translation>שחזור רשומות למצב היסטוריה שנבחר</translation>
    </message>
    <message>
        <source>Restore</source>
        <translation>שחזור</translation>
    </message>
    <message>
        <source>Delete selected history state</source>
        <translation>מחיקת מצב היסטוריה שנבחר</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>מחיקה</translation>
    </message>
    <message>
        <source>Delete all history</source>
        <translation>מחקת כל ההיסטוריה</translation>
    </message>
    <message>
        <source>Delete all</source>
        <translation>מחיקת הכול</translation>
    </message>
</context>
<context>
    <name>EditEntryWidgetMain</name>
    <message>
        <source>Edit Entry</source>
        <translation>עריכת רשומה</translation>
    </message>
    <message>
        <source>Notes field</source>
        <translation>שדה הערות</translation>
    </message>
    <message>
        <source>Username field</source>
        <translation>השדה &apos;שם משתמש&apos;</translation>
    </message>
    <message>
        <source>Expiration field</source>
        <translation>שדה תפוגה</translation>
    </message>
    <message>
        <source>Expiration Presets</source>
        <translation>תפוגה קבועה מראש</translation>
    </message>
    <message>
        <source>Expiration presets</source>
        <translation>הגדרות תפוגה קבועות מראש</translation>
    </message>
    <message>
        <source>Presets</source>
        <translation>קבועות מראש</translation>
    </message>
    <message>
        <source>Url field</source>
        <translation>שדה מען URL</translation>
    </message>
    <message>
        <source>Download favicon for URL</source>
        <translation>הורדת פביקון למען URL</translation>
    </message>
    <message>
        <source>Title field</source>
        <translation>שדה כותרת</translation>
    </message>
    <message>
        <source>Password field</source>
        <translation>שדה ססמה</translation>
    </message>
    <message>
        <source>Toggle expiration</source>
        <translation>החלפת־מצב תפוגה</translation>
    </message>
    <message>
        <source>Tags list</source>
        <translation>רשימת תגים</translation>
    </message>
    <message>
        <source>&amp;Username:</source>
        <translation>&amp;שם משתמש:</translation>
    </message>
    <message>
        <source>&amp;Title:</source>
        <translation>&amp;תואר:</translation>
    </message>
    <message>
        <source>&amp;Password:</source>
        <translation>&amp;ססמה:</translation>
    </message>
    <message>
        <source>UR&amp;L:</source>
        <translation>UR&amp;L:</translation>
    </message>
    <message>
        <source>&amp;Notes:</source>
        <translation>&amp;הערות:</translation>
    </message>
    <message>
        <source>Toggle notes visibility</source>
        <translation>מחלף נראות הערות</translation>
    </message>
    <message>
        <source>T&amp;ags:</source>
        <translation>ת&amp;גים:</translation>
    </message>
    <message>
        <source>&amp;Expires:</source>
        <translation>&amp;תפוגה:</translation>
    </message>
</context>
<context>
    <name>EditEntryWidgetSSHAgent</name>
    <message>
        <source>Form</source>
        <translation>טופס</translation>
    </message>
    <message>
        <source>Remove key from agent when database is closed/locked</source>
        <translation>הסרת מפתח מהסוכן כשמסד הנתונים סגור/נעול</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>הערה</translation>
    </message>
    <message>
        <source>Add key to agent when database is opened/unlocked</source>
        <translation>הוספת מפתח לסוכן כאשר מסד־נתונים נפתח/שוחרר מנעילה</translation>
    </message>
    <message>
        <source>Decrypt</source>
        <translation>פענוח</translation>
    </message>
    <message>
        <source>Fingerprint</source>
        <translation>טביעות אצבע</translation>
    </message>
    <message>
        <source>Copy to clipboard</source>
        <translation>העתקה ללוח־הגזירים</translation>
    </message>
    <message>
        <source>Public key</source>
        <translation>מפתח ציבורי</translation>
    </message>
    <message>
        <source>Private key</source>
        <translation>מפתח פרטי</translation>
    </message>
    <message>
        <source>Attachment</source>
        <translation>צרופה</translation>
    </message>
    <message>
        <source>External key file</source>
        <translation>קובץ מפתח חיצוני</translation>
    </message>
    <message>
        <source>Add to agent</source>
        <translation>הוספה לסוכן</translation>
    </message>
    <message>
        <source>Remove from agent</source>
        <translation>הסרה מסוכן</translation>
    </message>
    <message>
        <source>External file</source>
        <translation>קובץ חיצוני</translation>
    </message>
    <message>
        <source>Browser for key file</source>
        <translation>דפדוף לקובץ מפתח</translation>
    </message>
    <message>
        <source>Browse…</source>
        <extracomment>Button for opening file dialog</extracomment>
        <translation>עיון...</translation>
    </message>
    <message>
        <source>Generate</source>
        <translation>חילול</translation>
    </message>
    <message>
        <source>Select attachment file</source>
        <translation>בחירת קובץ צרופה</translation>
    </message>
    <message>
        <source>Require user confirmation when this key is used</source>
        <translation>נדרש אישור משתמש בעת שימוש במפתח זה</translation>
    </message>
    <message>
        <source>n/a</source>
        <translation>ל/ר</translation>
    </message>
    <message>
        <source>Remove key from agent after</source>
        <translation>הסרת מפתח מהסוכן לאחר</translation>
    </message>
    <message>
        <source>Remove key from agent after specified seconds</source>
        <translation>הסרה מפתח מהסוכן לאחר מספר השניות שצוינו</translation>
    </message>
    <message>
        <source> seconds</source>
        <translation> שניות</translation>
    </message>
    <message>
        <source>Clear agent</source>
        <translation>ניקוי סוכן</translation>
    </message>
</context>
<context>
    <name>EditGroupWidget</name>
    <message>
        <source>Group</source>
        <translation>קבוצה</translation>
    </message>
    <message>
        <source>Icon</source>
        <translation>סמל</translation>
    </message>
    <message>
        <source>Properties</source>
        <translation>מאפיינים</translation>
    </message>
    <message>
        <source>Add group</source>
        <translation>הוספת קבוצה</translation>
    </message>
    <message>
        <source>Edit group</source>
        <translation>עריכת קבוצה</translation>
    </message>
    <message>
        <source>Group has unsaved changes</source>
        <translation>קיימים שינויי קבוצה שטרם נשמרו</translation>
    </message>
    <message>
        <source>Browser Integration</source>
        <translation>שילוב דפדפן</translation>
    </message>
    <message>
        <source>Enable</source>
        <translation>איפשור</translation>
    </message>
    <message>
        <source>Disable</source>
        <translation>מושבת</translation>
    </message>
    <message>
        <source>Inherit from parent group (%1)</source>
        <translation>ירושה מקבוצת הורה (%1)</translation>
    </message>
</context>
<context>
    <name>EditGroupWidgetBrowser</name>
    <message>
        <source>These settings affect to the group&apos;s behaviour with the browser extension.</source>
        <translation>הגדרות אלה משפיעות על התנהגות הקבוצה בהרחברת הדפדפן.</translation>
    </message>
    <message>
        <source>Hide entries from browser extension:</source>
        <translation>הסתרת רשומות מהרחבת דפדפן:</translation>
    </message>
    <message>
        <source>Hide entries from browser extension toggle for this and sub groups</source>
        <translation>הסתרת רשומות ממחלף הרחבות דפדפן עבור זה ועבור קבוצות משנה</translation>
    </message>
    <message>
        <source>Skip Auto-Submit for entries:</source>
        <translation>דלוג על Auto-Submit לרשומות:</translation>
    </message>
    <message>
        <source>Skip Auto-Submit toggle for this and sub groups</source>
        <translation>דלוג על הקלדה־אוטומטית לזה ולקבוצות משנה</translation>
    </message>
    <message>
        <source>Use entries only with HTTP Basic Auth:</source>
        <translation>שימוש ברשומות רק באמצעות :HTTP Basic Auth</translation>
    </message>
    <message>
        <source>Only HTTP Auth toggle for this and sub groups</source>
        <translation>רק החלפת־מצב HTTP Auth לזה ולקבוצות משנה</translation>
    </message>
    <message>
        <source>Do not use entries with HTTP Basic Auth:</source>
        <translation>לא להשתמש ברשומות עם :HTTP Basic Auth</translation>
    </message>
    <message>
        <source>Do not use HTTP Auth toggle for this and sub groups</source>
        <translation>לא להשתמש ב־HTTP Auth לזה ולקבוצות משנה</translation>
    </message>
    <message>
        <source>Omit WWW subdomain from matching:</source>
        <translation>השמטת תת־תחום WWW מההתאמה:</translation>
    </message>
    <message>
        <source>Omit WWW subdomain from matching toggle for this and sub groups</source>
        <translation>השמטת תת־תחום WWW ממחלף ההתאמה, לקבוצה זו ותתי־קבוצות</translation>
    </message>
    <message>
        <source>Restrict matching to given browser key:</source>
        <translation>הגבלת התאמות למפתחות דפדפן נתונים:</translation>
    </message>
    <message>
        <source>Restrict matching to given browser key toggle for this and sub groups</source>
        <translation>להגביל התאמה כדי לספק מיתוג מפתח דפדפן עבור זה ועבור קבוצות משה.</translation>
    </message>
</context>
<context>
    <name>EditGroupWidgetKeeShare</name>
    <message>
        <source>Sharing mode field</source>
        <translation>שדה מצב שיתוף</translation>
    </message>
    <message>
        <source>Password field</source>
        <translation>שדה ססמה</translation>
    </message>
    <message>
        <source>Type:</source>
        <translation>סוג:</translation>
    </message>
    <message>
        <source>Password:</source>
        <translation>ססמה:</translation>
    </message>
    <message>
        <source>Path:</source>
        <translation>נתיב:</translation>
    </message>
    <message>
        <source>Path to share file field</source>
        <translation>נתיב לשיתוף שדה קובץ</translation>
    </message>
    <message>
        <source>Browse for share file</source>
        <translation>דפדוף לקובץ שיתוף</translation>
    </message>
    <message>
        <source>Browse…</source>
        <translation>עיון...</translation>
    </message>
    <message>
        <source>Clear fields</source>
        <translation>נקוי שדות</translation>
    </message>
    <message>
        <source>Clear</source>
        <translation>נקה</translation>
    </message>
    <message>
        <source>Inactive</source>
        <translation>לא פעיל</translation>
    </message>
    <message>
        <source>Import</source>
        <translation>ייבוא</translation>
    </message>
    <message>
        <source>Export</source>
        <translation>ייצוא</translation>
    </message>
    <message>
        <source>Synchronize</source>
        <translation>סנכרון</translation>
    </message>
    <message>
        <source>Your KeePassXC version does not support sharing this container type.
Supported extensions are: %1.</source>
        <translation>גרסת KeePassXC לא תומכת בשיתוף סוג מיכל זה.
הרחבות נתמכות הן: %1.</translation>
    </message>
    <message>
        <source>%1 is already being exported by this database.</source>
        <translation>מסד־נתונים זה מייצא כבר את %1.</translation>
    </message>
    <message>
        <source>%1 is already being imported by this database.</source>
        <translation>מסד־נתונים זה מייבא כבר את %1.</translation>
    </message>
    <message>
        <source>%1 is being imported and exported by different groups in this database.</source>
        <translation>%1 מיובא ומיוצא על־ידי קבוצות שונות במסד נתונים זה.</translation>
    </message>
    <message>
        <source>KeeShare is currently disabled. You can enable import/export in the application settings.</source>
        <comment>KeeShare is a proper noun</comment>
        <translation>KeeShare מושבת כעת. ניתן לאפשר ייבוא/ייצוא בהגדרות היישום.</translation>
    </message>
    <message>
        <source>Database export is currently disabled by application settings.</source>
        <translation>ייצוא מסד־נתונים מושבת כעת על־ידי הגדרות יישום.</translation>
    </message>
    <message>
        <source>Database import is currently disabled by application settings.</source>
        <translation>ייבוא מסד־נתונים מושבת כעת על־ידי הגדרות יישום.</translation>
    </message>
    <message>
        <source>KeeShare container</source>
        <translation>מיכל KeeShare</translation>
    </message>
    <message>
        <source>KeeShare signed container</source>
        <translation>מיכל KeeShare חתום</translation>
    </message>
    <message>
        <source>Select import source</source>
        <translation>בחירת מקור יבוא</translation>
    </message>
    <message>
        <source>Select export target</source>
        <translation>בחירת יעד יצוא</translation>
    </message>
    <message>
        <source>Select import/export file</source>
        <translation>בחירת קובץ ייבוא/ייצוא</translation>
    </message>
    <message>
        <source>Maintain group structure with shared database</source>
        <translation>שמירה על מבנה מקובץ עם מסד נתונים משותף</translation>
    </message>
    <message>
        <source>Keep Group Structure</source>
        <translation>להשאיר מבנה קבוצה</translation>
    </message>
</context>
<context>
    <name>EditGroupWidgetMain</name>
    <message>
        <source>Edit Group</source>
        <translation>עריכת קבוצה</translation>
    </message>
    <message>
        <source>Toggle expiration</source>
        <translation>החלפת־מצב תפוגה</translation>
    </message>
    <message>
        <source>Expires:</source>
        <translation>תפוגה:</translation>
    </message>
    <message>
        <source>Name field</source>
        <translation>שדה שם</translation>
    </message>
    <message>
        <source>Expiration field</source>
        <translation>שדה תפוגה</translation>
    </message>
    <message>
        <source>Use default Auto-Type sequence of parent group</source>
        <translation>שימוש ברצף הקלדה־אוטומטית ברירת מחדל של קבוצת אב</translation>
    </message>
    <message>
        <source>Auto-Type:</source>
        <translation>הקלדה־אוטומטית:</translation>
    </message>
    <message>
        <source>Search:</source>
        <translation>חיפוש:</translation>
    </message>
    <message>
        <source>Auto-Type toggle for this and sub groups</source>
        <translation>החלפת־מצב הקלדה־אוטומטית לקבוצות משנה אלו</translation>
    </message>
    <message>
        <source>Notes:</source>
        <translation>הערות:</translation>
    </message>
    <message>
        <source>Default auto-type sequence field</source>
        <translation>רצף הקלדה־אוטומטית ברירת מחדל כשל</translation>
    </message>
    <message>
        <source>Notes field</source>
        <translation>שדה הערות</translation>
    </message>
    <message>
        <source>Name:</source>
        <translation>שם:</translation>
    </message>
    <message>
        <source>Set default Auto-Type sequence</source>
        <translation>הגדרת רצף הקלדה־אוטומטית ברירת מחדל</translation>
    </message>
    <message>
        <source>Search toggle for this and sub groups</source>
        <translation>החלפת־מצב חיפוש קבוצות משנה אלה</translation>
    </message>
</context>
<context>
    <name>EditWidgetIcons</name>
    <message>
        <source>Use default icon</source>
        <translation>שימוש בסמל ברירת מחדל</translation>
    </message>
    <message>
        <source>Use custom icon</source>
        <translation>שימוש בסמל מותאם אישית</translation>
    </message>
    <message>
        <source>Choose icon…</source>
        <translation>בחירת סמל...</translation>
    </message>
    <message>
        <source>Set the URL to use to search for a favicon</source>
        <translation>הגדרת מען ה־URL שישמש לחיפוש פביקון</translation>
    </message>
    <message>
        <source>Favicon URL</source>
        <translation>מען URL לפביקון</translation>
    </message>
    <message>
        <source>Download favicon for URL</source>
        <translation>הורדת פביקון למען URL</translation>
    </message>
    <message>
        <source>Download favicon</source>
        <translation>הורדת פביקון</translation>
    </message>
    <message>
        <source>Apply selected icon to subgroups and entries</source>
        <translation>החלת סמל שנבחר לקבוצות־משנה ורשומות</translation>
    </message>
    <message>
        <source>Apply icon to…</source>
        <translation>החלת סמל על...</translation>
    </message>
    <message>
        <source>Apply to this group only</source>
        <translation>החלה על קבוצה זו בלבד</translation>
    </message>
    <message>
        <source>Also apply to child groups</source>
        <translation>חלה גם על קבוצות צאצא</translation>
    </message>
    <message>
        <source>Also apply to child entries</source>
        <translation>חל גם על רשומות צאצא</translation>
    </message>
    <message>
        <source>Also apply to all children</source>
        <translation>חל גם על כל הצאצאים</translation>
    </message>
    <message>
        <source>Unable to fetch favicon.</source>
        <translation>לא ניתן לאחזר פביקון.</translation>
    </message>
    <message>
        <source>Existing icon selected.</source>
        <translation>נבחר סמל קיים.</translation>
    </message>
    <message>
        <source>Images</source>
        <translation>תמונות</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>כל הקבצים</translation>
    </message>
    <message>
        <source>Select Image(s)</source>
        <translation>בחירת תמונה(ות)</translation>
    </message>
    <message numerus="yes">
        <source>Successfully loaded %1 of %n icon(s)</source>
        <translation><numerusform>%1 מתוך %n סמלים נטען בהצלחה</numerusform><numerusform>%1 מתוך %n סמלים נטענו בהצלחה</numerusform><numerusform>%1 מתוך %n סמלים נטענו בהצלחה</numerusform></translation>
    </message>
    <message>
        <source>No icons were loaded</source>
        <translation>לא נטענו סמלים</translation>
    </message>
    <message numerus="yes">
        <source>%n icon(s) already exist in the database</source>
        <translation><numerusform>סמל %n כבר קיים במסד הנתונים</numerusform><numerusform>%n סמלים כבר קיימים במסד הנתונים</numerusform><numerusform>%n סמלים כבר קיימים במסד הנתונים</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>The following icon(s) failed:</source>
        <translation><numerusform>הסמל הבא כשל:</numerusform><numerusform>הסמלים הבאים כשלו:</numerusform><numerusform>הסמלים הבאים כשלו:</numerusform></translation>
    </message>
    <message>
        <source>You can enable the DuckDuckGo website icon service under Application Settings -&gt; Security</source>
        <translation>ניתן לאפשור את שרות סמלי אתר מרשתת DuckDuckGo מתפריט הגדרות יישום -&gt; אבטחה</translation>
    </message>
</context>
<context>
    <name>EditWidgetProperties</name>
    <message>
        <source>Created:</source>
        <translation>נוצר:</translation>
    </message>
    <message>
        <source>Datetime created</source>
        <translation>תאריך ושעה נוצרו</translation>
    </message>
    <message>
        <source>Modified:</source>
        <translation>הוסגל:</translation>
    </message>
    <message>
        <source>Datetime modified</source>
        <translation>תאריך ושעה הוסגלו</translation>
    </message>
    <message>
        <source>Uuid:</source>
        <translation>Uuid:</translation>
    </message>
    <message>
        <source>Unique ID</source>
        <translation>מזהה ייחודי</translation>
    </message>
    <message>
        <source>Plugin Data</source>
        <translation>נתוני מתקע</translation>
    </message>
    <message>
        <source>Plugin data</source>
        <translation>נתוני מתקע</translation>
    </message>
    <message>
        <source>Remove selected plugin data</source>
        <translation>הסרת מידע מתקע שנבחר</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>הסרה</translation>
    </message>
    <message>
        <source>Delete plugin data?</source>
        <translation>האם למחוק נתוני מתקע?</translation>
    </message>
    <message>
        <source>Do you really want to delete the selected plugin data?
This may cause the affected plugins to malfunction.</source>
        <translation>האם למחוק את נתוני המתקע שנבחר?
עלול לגרום לכשל במתקעים מושפעים.</translation>
    </message>
    <message>
        <source>Key</source>
        <translation>ססמה</translation>
    </message>
    <message>
        <source>Value</source>
        <translation>ערך</translation>
    </message>
</context>
<context>
    <name>Entry</name>
    <message>
        <source>%1 - Clone</source>
        <translation>שכפול - %1</translation>
    </message>
    <message>
        <source>Passkey</source>
        <translation>Passkey</translation>
    </message>
    <message>
        <source>Invalid conversion type: %1</source>
        <translation>סוג המרה לא תקין: %1</translation>
    </message>
    <message>
        <source>Invalid conversion syntax: %1</source>
        <translation>תחביר המרה לא תקין: %1</translation>
    </message>
    <message>
        <source>Invalid regular expression syntax %1
%2</source>
        <translation>תחביר ביטוי רגיל לא תקין %1
%2</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>כותרת</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>שם משתמש</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>סיסמה</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>Notes</source>
        <translation>הערות</translation>
    </message>
    <message>
        <source>Custom Attributes</source>
        <translation>מאפיינים מותאמים אישית</translation>
    </message>
    <message>
        <source>Icon</source>
        <translation>סמל</translation>
    </message>
    <message>
        <source>Color</source>
        <translation>צבע</translation>
    </message>
    <message>
        <source>Expiration</source>
        <translation>תפוגה</translation>
    </message>
    <message>
        <source>TOTP</source>
        <translation>TOTP</translation>
    </message>
    <message>
        <source>Custom Data</source>
        <translation>נתונים מותאמים אישית</translation>
    </message>
    <message>
        <source>Attachments</source>
        <translation>צרופות</translation>
    </message>
    <message>
        <source>Auto-Type</source>
        <translation>הקלדה־אוטומטית</translation>
    </message>
    <message>
        <source>Tags</source>
        <translation>תגים</translation>
    </message>
</context>
<context>
    <name>EntryAttachments</name>
    <message>
        <source>Cannot open file &quot;%1&quot;</source>
        <translation>לא ניתן לפתוח קובץ &quot;%1&quot;</translation>
    </message>
</context>
<context>
    <name>EntryAttachmentsModel</name>
    <message>
        <source>Name</source>
        <translation>שם</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>גודל</translation>
    </message>
</context>
<context>
    <name>EntryAttachmentsWidget</name>
    <message>
        <source>Form</source>
        <translation>טופס</translation>
    </message>
    <message>
        <source>Attachments</source>
        <translation>צרופות</translation>
    </message>
    <message>
        <source>Add new attachment</source>
        <translation>הוספת צרופה חדשה</translation>
    </message>
    <message>
        <source>Remove selected attachment</source>
        <translation>הסרת צרופה שנבחרה</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>הסרה</translation>
    </message>
    <message>
        <source>Open selected attachment</source>
        <translation>פתיחת צרופה שנבחרה</translation>
    </message>
    <message>
        <source>Open</source>
        <translation>פתיחה</translation>
    </message>
    <message>
        <source>Save selected attachment to disk</source>
        <translation>שמירת צרופה שנבחרה לכונן הקשיח</translation>
    </message>
    <message>
        <source>Select files</source>
        <translation>בחירת קובצים</translation>
    </message>
    <message>
        <source>Confirm remove</source>
        <translation>אישור הסרה</translation>
    </message>
    <message numerus="yes">
        <source>Are you sure you want to remove %n attachment(s)?</source>
        <translation><numerusform>האם להסיר צרופה %n?</numerusform><numerusform>האם להסיר %n צרופות?</numerusform><numerusform>האם להסיר %n צרופות?</numerusform></translation>
    </message>
    <message>
        <source>Save attachments</source>
        <translation>שמירת צרופות</translation>
    </message>
    <message>
        <source>Unable to create directory:
%1</source>
        <translation>לא ניתן ליצור מחיצה:
%1</translation>
    </message>
    <message>
        <source>Are you sure you want to overwrite the existing file &quot;%1&quot; with the attachment?</source>
        <translation>האם לכתוב־על קובץ קיים &quot;%1&quot; יחד עם הצרופה?</translation>
    </message>
    <message>
        <source>Confirm overwrite</source>
        <translation>אישור כתיבה־על</translation>
    </message>
    <message>
        <source>Unable to save attachments:
%1</source>
        <translation>לא ניתן לשמור צרופות:
 %1</translation>
    </message>
    <message>
        <source>Unable to open attachment:
%1</source>
        <translation>לא ניתן לפתוח צרופה:
 %1</translation>
    </message>
    <message>
        <source>Unable to open attachments:
%1</source>
        <translation>לא ניתן לפתוח צרופה:
 %1</translation>
    </message>
    <message numerus="yes">
        <source>Unable to open file(s):
%1</source>
        <translation><numerusform>לא ניתן לפתוח קובץ:
%1</numerusform><numerusform>לא ניתן לפתוח קובצים:
%1</numerusform><numerusform>לא ניתן לפתוח קובצים:
%1</numerusform></translation>
    </message>
    <message>
        <source>Confirm Overwrite Attachment</source>
        <translation>אישור כתיבה־על צרופה</translation>
    </message>
    <message>
        <source>Confirm Attachment</source>
        <translation>אישור צרופה</translation>
    </message>
    <message>
        <source>%1 is a big file (%2 MB).
Your database may get very large and reduce performance.

Are you sure to add this file?</source>
        <translation>%1 הוא קובץ גדול (%2 מב).
מסד הנתונים עשוי להיות גדול מאוד והביצועים יפגעו.

האם להוסיף קובץ זה?</translation>
    </message>
    <message>
        <source>Attachment modified</source>
        <translation>צרופה הוסגלה</translation>
    </message>
    <message>
        <source>The attachment '%1' was modified.
Do you want to save the changes to your database?</source>
        <translation>צרופה &apos;%1&apos; הוסגלה.
האם לשמור את השינויים למסד הנתונים?</translation>
    </message>
    <message>
        <source>Saving attachment failed</source>
        <translation>שמירת צרופה כשלה</translation>
    </message>
    <message>
        <source>Saving updated attachment failed.
Error: %1</source>
        <translation>שמירת צרופה עדכנית כשלה.
שגיאה: %1</translation>
    </message>
    <message>
        <source>Attachment &quot;%1&quot; already exists. 
Would you like to overwrite the existing attachment?</source>
        <translation>קיימת כבר צרופה &quot;%1&quot;.
האם לכתוב־על הצרופה הקיימת?</translation>
    </message>
    <message>
        <source>Preview</source>
        <translation>תצוגה מקדימה</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>עריכה</translation>
    </message>
    <message>
        <source>New Text Document</source>
        <translation>מסמך מלל חדש</translation>
    </message>
    <message>
        <source>Add file…</source>
        <translation>הוספת קובץ...</translation>
    </message>
    <message>
        <source>Load from Disk…</source>
        <translation>טעינ מכונן...</translation>
    </message>
    <message>
        <source>Save…</source>
        <translation>שמירה...</translation>
    </message>
    <message>
        <source>New Attachment</source>
        <translation>צרופה חדשה</translation>
    </message>
</context>
<context>
    <name>EntryAttributesModel</name>
    <message>
        <source>Name</source>
        <translation>שם</translation>
    </message>
</context>
<context>
    <name>EntryHistoryModel</name>
    <message>
        <source>Current (%1)</source>
        <translation>נוכחי (%1)</translation>
    </message>
    <message>
        <source>Last modified</source>
        <translation>הוסגל לאחרונה</translation>
    </message>
    <message>
        <source>Age</source>
        <translation>גיל</translation>
    </message>
    <message>
        <source>Difference</source>
        <translation>שוני</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>גודל</translation>
    </message>
</context>
<context>
    <name>EntryModel</name>
    <message>
        <source>Ref: </source>
        <comment>Reference abbreviation</comment>
        <translation>הפניה: </translation>
    </message>
    <message>
        <source>Never</source>
        <translation>אף פעם</translation>
    </message>
    <message>
        <source>Group</source>
        <translation>קבוצה</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>כותרת</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>שם משתמש</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>ססמה</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>מען url</translation>
    </message>
    <message>
        <source>Notes</source>
        <translation>הערות</translation>
    </message>
    <message>
        <source>Expires</source>
        <translation>תפוגה</translation>
    </message>
    <message>
        <source>Created</source>
        <translation>נוצר</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>הוסגל</translation>
    </message>
    <message>
        <source>Attachments</source>
        <translation>צרופות</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>גודל</translation>
    </message>
    <message>
        <source>Group name</source>
        <translation>שם קבוצה</translation>
    </message>
    <message>
        <source>Entry title</source>
        <translation>כותרת רשומה</translation>
    </message>
    <message>
        <source>Password Strength</source>
        <translation>חוזק ססמה</translation>
    </message>
    <message>
        <source>Entry notes</source>
        <translation>הערות רשומה</translation>
    </message>
    <message>
        <source>Entry expires at</source>
        <translation>תוקף רשומה פג ב־</translation>
    </message>
    <message>
        <source>Creation date</source>
        <translation>תאריך יצירה</translation>
    </message>
    <message>
        <source>Last modification date</source>
        <translation>תאריך הסגלה אחרון</translation>
    </message>
    <message>
        <source>Attached files</source>
        <translation>קבצים מצורפים</translation>
    </message>
    <message>
        <source>Entry size</source>
        <translation>גודל רשומה</translation>
    </message>
    <message>
        <source>Has attachments</source>
        <translation>קיימות צרופות</translation>
    </message>
    <message>
        <source>Has TOTP</source>
        <translation>קיים TOTP</translation>
    </message>
    <message>
        <source>Background Color</source>
        <translation>צבע רקע</translation>
    </message>
    <message>
        <source>Group Path</source>
        <translation>נתיב קבוצה</translation>
    </message>
</context>
<context>
    <name>EntryPreviewWidget</name>
    <message>
        <source>Display current TOTP value</source>
        <translation>הצגת ערך TOTP נוכחי</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>סגירה</translation>
    </message>
    <message>
        <source>General</source>
        <translation>כללי</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>ססמה</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>מען url</translation>
    </message>
    <message>
        <source>Expiration</source>
        <translation>תפוגה</translation>
    </message>
    <message>
        <source>Tags</source>
        <translation>תגים</translation>
    </message>
    <message>
        <source>Tags list</source>
        <translation>רשימת תגים</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>שם משתמש</translation>
    </message>
    <message>
        <source>Notes</source>
        <translation>הערות</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>מתקדם</translation>
    </message>
    <message>
        <source>Attachments</source>
        <translation>צרופות</translation>
    </message>
    <message>
        <source>Attributes</source>
        <translation>תכונות</translation>
    </message>
    <message>
        <source>Autotype</source>
        <translation>הקלדה־אוטומטית</translation>
    </message>
    <message>
        <source>Default Sequence</source>
        <translation>רצף ברירת מחדל</translation>
    </message>
    <message>
        <source>Window</source>
        <translation>חלון</translation>
    </message>
    <message>
        <source>Sequence</source>
        <translation>רצף סדר פעולות</translation>
    </message>
    <message>
        <source>Searching</source>
        <translation>חיפוש</translation>
    </message>
    <message>
        <source>Share</source>
        <translation>שיתוף</translation>
    </message>
    <message>
        <source>Search</source>
        <translation>חיפוש</translation>
    </message>
    <message>
        <source>Clear</source>
        <translation>נקה</translation>
    </message>
    <message>
        <source>Never</source>
        <translation>אף פעם</translation>
    </message>
    <message>
        <source>Double click to copy value</source>
        <translation>הקשה כפולה להעתקת ערך</translation>
    </message>
    <message>
        <source>Enabled</source>
        <translation>מאופשר</translation>
    </message>
    <message>
        <source>Disabled</source>
        <translation>מושבת</translation>
    </message>
    <message>
        <source>Double click to copy to clipboard</source>
        <translation>הקשה כפולה להעתיק ללוח גזירים</translation>
    </message>
</context>
<context>
    <name>EntryURLModel</name>
    <message>
        <source>Invalid URL</source>
        <translation>מען URL תקין</translation>
    </message>
    <message>
        <source>Duplicate URL</source>
        <translation>שיכפול מען URL</translation>
    </message>
</context>
<context>
    <name>EntryView</name>
    <message>
        <source>Fit to window</source>
        <translation>התאמה לחלון</translation>
    </message>
    <message>
        <source>Fit to contents</source>
        <translation>התאמה לתוכן</translation>
    </message>
    <message>
        <source>Reset to defaults</source>
        <translation>איפוס לברירות המחדל</translation>
    </message>
    <message numerus="yes">
        <source>+ %1 entry(s)...</source>
        <translation><numerusform>רשומה + %1...</numerusform><numerusform>+ %1 רשומות...</numerusform><numerusform>+ %1 רשומות...</numerusform></translation>
    </message>
</context>
<context>
    <name>ExportDialog</name>
    <message>
        <source>Export options</source>
        <translation>אפשרויות יצוא</translation>
    </message>
    <message>
        <source>Sort entries by...</source>
        <translation>מיון רשומות לפי...</translation>
    </message>
    <message>
        <source>You are about to export your database to an unencrypted file.
This will leave your passwords and sensitive information vulnerable!
</source>
        <translation>מסד־הנתונים ייוצא לקובץ לא מוצפן.
הסיסמאות והמידע הרגיש יהיו פגיעים!

</translation>
    </message>
    <message>
        <source>database order</source>
        <translation>סדר מסד־נתונים</translation>
    </message>
    <message>
        <source>name (ascending)</source>
        <translation>שם (סדר עולה)</translation>
    </message>
    <message>
        <source>name (descending)</source>
        <translation>שם (סדר יורד)</translation>
    </message>
    <message>
        <source>Export database to HTML file</source>
        <translation>ייצוא מסד־נתונים לקובץ HTML</translation>
    </message>
    <message>
        <source>HTML file</source>
        <translation>קובץ HTML</translation>
    </message>
    <message>
        <source>invalid sort order</source>
        <translation>סדר מיון לא תקין</translation>
    </message>
</context>
<context>
    <name>FdoSecrets::DBusMgr</name>
    <message>
        <source>Failed to deliver message</source>
        <translation>מסירת הודעה כשלה</translation>
    </message>
    <message>
        <source>Failed to send reply on DBus</source>
        <translation>שליחת תשובה ב־DBus כשלה</translation>
    </message>
    <message>
        <source>Unknown</source>
        <comment>Unknown PID</comment>
        <translation>לא ידוע</translation>
    </message>
    <message>
        <source>Unknown</source>
        <comment>Unknown executable path</comment>
        <translation>לא ידוע</translation>
    </message>
    <message>
        <source>&lt;i&gt;PID: %1, Executable: %2&lt;/i&gt;</source>
        <comment>&lt;i&gt;PID: 1234, Executable: /path/to/exe&lt;/i&gt;</comment>
        <translation>&lt;i&gt;PID: %1, קובץ הפעלה: %2&lt;/i&gt;</translation>
    </message>
    <message>
        <source>Another secret service is running (%1).&lt;br/&gt;Please stop/remove it before re-enabling the Secret Service Integration.</source>
        <translation>שירות חשאי אחר פועל (%1).&lt;br/&gt;נא להפסיק/להסיר אותו לפני איפשור השירות החשאי מחדש.</translation>
    </message>
    <message>
        <source>Failed to register DBus service at %1.&lt;br/&gt;</source>
        <translation>רישום שירות DBus ב־%1 כשל.&lt;br/&gt;</translation>
    </message>
    <message>
        <source>Failed to register service on DBus at path &apos;%1&apos;</source>
        <translation>רישום השירות ב־DBus בנתיב &apos;%1&apos; כשל</translation>
    </message>
    <message>
        <source>Failed to register database on DBus under the name &apos;%1&apos;</source>
        <translation>רישום מסד־נתונים ב־DBus בשם &apos;%1&apos; כשל</translation>
    </message>
    <message>
        <source>Failed to register session on DBus at path &apos;%1&apos;</source>
        <translation>רישום השיח ב־DBus בנתיב &apos;%1&apos; כשל</translation>
    </message>
    <message>
        <source>Failed to register item on DBus at path &apos;%1&apos;</source>
        <translation>רישום פריט ב־DBus בנתיב &apos;%1&apos; כשל</translation>
    </message>
    <message>
        <source>Failed to register prompt object on DBus at path &apos;%1&apos;</source>
        <translation>רישום אובייקט הנחיה ב־DBus בנתיב &apos;%1&apos; כשל</translation>
    </message>
</context>
<context>
    <name>FdoSecrets::Item</name>
    <message>
        <source>Entry &quot;%1&quot; from database &quot;%2&quot; was used by %3</source>
        <translation>%3 עשה שימוש ברשומה &quot;%1&quot; ממסד נתונים &quot;%2&quot;</translation>
    </message>
</context>
<context>
    <name>FdoSecrets::Service</name>
    <message numerus="yes">
        <source>%n Entry(s) was used by %1</source>
        <comment>%1 is the name of an application</comment>
        <translation><numerusform>%1 השתמש ברשומה %n</numerusform><numerusform>%1 השתמש ב־%n רשומות</numerusform><numerusform>%1 השתמש ב־%n רשומות</numerusform></translation>
    </message>
</context>
<context>
    <name>FdoSecrets::SettingsClientModel</name>
    <message>
        <source>Unknown</source>
        <translation>לא ידוע</translation>
    </message>
    <message>
        <source>Non-existing/inaccessible executable path. Please double-check the client is legit.</source>
        <translation>נתיב הפעלה לא קיים/נגיש. נא לבדוק שנית את חוקיות הלקוח.</translation>
    </message>
</context>
<context>
    <name>FdoSecrets::SettingsDatabaseModel</name>
    <message>
        <source>Unlock to show</source>
        <translation>שחרור נעילה להצגה</translation>
    </message>
    <message>
        <source>None</source>
        <translation>ללא</translation>
    </message>
</context>
<context>
    <name>FdoSecrets::UnlockPrompt</name>
    <message>
        <source>%1 (PID: %2)</source>
        <translation>%1 (PID: %2)</translation>
    </message>
</context>
<context>
    <name>FdoSecretsPlugin</name>
    <message>
        <source>&lt;b&gt;Fdo Secret Service:&lt;/b&gt; %1</source>
        <translation>&lt;b&gt;שירות חשאי Fdo:&lt;/b&gt; %1</translation>
    </message>
</context>
<context>
    <name>GlobalShortcutsPortal</name>
    <message>
        <source>KeePassXC - Global Shortcuts</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>The XDG Desktop Portal for global shortcuts is not available on this system.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Global Auto-Type shortcut is already configured. To change it, open your system settings and navigate to the keyboard or application shortcuts section.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Trigger global Auto-Type</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>Group</name>
    <message>
        <source>[empty]</source>
        <comment>group has no children</comment>
        <translation>[ריק]</translation>
    </message>
    <message>
        <source>%1 - Clone</source>
        <translation>שכפול - %1</translation>
    </message>
</context>
<context>
    <name>HibpDownloader</name>
    <message>
        <source>Online password validation failed</source>
        <translation>אימות ססמה מקוון כשל</translation>
    </message>
</context>
<context>
    <name>IconDownloaderDialog</name>
    <message>
        <source>Download Favicons</source>
        <translation>הורדת פביקונס</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>ביטול</translation>
    </message>
    <message>
        <source>Having trouble downloading icons?
You can enable the DuckDuckGo website icon service in the security section of the application settings.</source>
        <translation>בעיה בהורדת סמלים?
ניתן להפעיל את שירות הסמלים של אתר DuckDuckGo במקטע אבטחת הגדרות היישום.</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>סגירה</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>מען url</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>מצב</translation>
    </message>
    <message>
        <source>Please wait, processing entry list…</source>
        <translation>נא להמתין רשימת רשומות מעובדת...</translation>
    </message>
    <message>
        <source>Downloading…</source>
        <translation>הורדה...</translation>
    </message>
    <message>
        <source>Ok</source>
        <translation>בסדר</translation>
    </message>
    <message>
        <source>Already Exists</source>
        <translation>כבר קיים</translation>
    </message>
    <message>
        <source>Download Failed</source>
        <translation>ההורדה כשלה</translation>
    </message>
    <message>
        <source>Downloading favicons (%1/%2)…</source>
        <translation>הורדת פביקונס (%1/%2)...</translation>
    </message>
</context>
<context>
    <name>ImageAttachmentsWidget</name>
    <message>
        <source>Zoom:</source>
        <translation>מיקוד:</translation>
    </message>
    <message>
        <source>Fit</source>
        <translation>התאמה</translation>
    </message>
</context>
<context>
    <name>ImportWizard</name>
    <message>
        <source>Import Wizard</source>
        <translation>אשף ייבוא</translation>
    </message>
</context>
<context>
    <name>ImportWizardPageReview</name>
    <message>
        <source>WizardPage</source>
        <translation>עמוד אשף</translation>
    </message>
    <message>
        <source>Entry count: %1</source>
        <translation>מספר רשומה: %1</translation>
    </message>
    <message>
        <source>Group</source>
        <translation>קבוצה</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>כותרת</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>שם משתמש</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>ססמה</translation>
    </message>
    <message>
        <source>Url</source>
        <translation>מען URL</translation>
    </message>
    <message>
        <source>Could not load key file.</source>
        <translation>לא ניתן לטעון קובץ מפתח.</translation>
    </message>
    <message>
        <source>Could not open remote database. Password or key file may be incorrect.</source>
        <translation>לא ניתן לפתוח מסד־נתונים מרוחק. קובץ מפתח או סיסמה עשויים להיות שגויים.</translation>
    </message>
</context>
<context>
    <name>ImportWizardPageSelect</name>
    <message>
        <source>Form</source>
        <translation>טופס</translation>
    </message>
    <message>
        <source>Import File Selection</source>
        <translation>בחירת קובץ ייבוא</translation>
    </message>
    <message>
        <source>Password:</source>
        <translation>ססמה:</translation>
    </message>
    <message>
        <source>Key File:</source>
        <translation>קובץ ססמה:</translation>
    </message>
    <message>
        <source>Browse…</source>
        <translation>עיון...</translation>
    </message>
    <message>
        <source>Import Into:</source>
        <translation>ייבוא לתוך:</translation>
    </message>
    <message>
        <source>New Database</source>
        <translation>מסד־נתונים חדש</translation>
    </message>
    <message>
        <source>No unlocked databases available</source>
        <translation>אין מסדי נתונים לא נעולים זמינים</translation>
    </message>
    <message>
        <source>Existing Database:</source>
        <translation>מסד נתונים קיים:</translation>
    </message>
    <message>
        <source>Import File:</source>
        <translation>ייבוא קובץ:</translation>
    </message>
    <message>
        <source>Comma Separated Values (.csv)</source>
        <translation>ערכים מופרדים בפסיקים (.csv)</translation>
    </message>
    <message>
        <source>1Password Export (.1pux)</source>
        <translation>ייצוא 1Password (.1pux)</translation>
    </message>
    <message>
        <source>1Password Vault (.opvault)</source>
        <translation>כספת 1Password (.opvault)</translation>
    </message>
    <message>
        <source>Bitwarden (.json)</source>
        <translation>Bitwarden (.json)</translation>
    </message>
    <message>
        <source>KeePass 1 Database (.kdb)</source>
        <translation>מסד נתונים KeePass 1 (.kdb)</translation>
    </message>
    <message>
        <source>Open OPVault</source>
        <translation>פתיחת OPVault</translation>
    </message>
    <message>
        <source>Select import file</source>
        <translation>בחירת קובץ ייבוא</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>כל הקבצים</translation>
    </message>
    <message>
        <source>Key files</source>
        <translation>קבצי מפתח</translation>
    </message>
    <message>
        <source>Select key file</source>
        <translation>בחירת קובץ ססמה</translation>
    </message>
    <message>
        <source>Comma Separated Values</source>
        <translation>ערכים מופרדים בפסיקים</translation>
    </message>
    <message>
        <source>1Password Export</source>
        <translation>ייצוא 1Password</translation>
    </message>
    <message>
        <source>Bitwarden JSON Export</source>
        <translation>ייצוא Bitwarden JSON</translation>
    </message>
    <message>
        <source>1Password Vault</source>
        <translation>כספת 1Password</translation>
    </message>
    <message>
        <source>KeePass1 Database</source>
        <translation>מסד־נתונים KeePass 1</translation>
    </message>
    <message>
        <source>Proton Pass (.json)</source>
        <translation>Proton Pass (.json)</translation>
    </message>
    <message>
        <source>Proton Pass JSON Export</source>
        <translation>ייצוא JSON של Proton Pass</translation>
    </message>
    <message>
        <source>Temporary Database</source>
        <translation>מסד־נתונים זמני</translation>
    </message>
    <message>
        <source>Command:</source>
        <translation>פקודה:</translation>
    </message>
    <message>
        <source>e.g.: &quot;sftp user@hostname&quot; or &quot;scp user@hostname:DatabaseOnRemote.kdbx {TEMP_DATABASE}&quot;</source>
        <translation>לדוגמה: &quot;sftp user@hostname&quot; או  &quot;scp user@hostname:DatabaseOnRemote.kdbx {TEMP_DATABASE}&quot;</translation>
    </message>
    <message>
        <source>Input:</source>
        <translation>קלט:</translation>
    </message>
    <message>
        <source>e.g.:
get DatabaseOnRemote.kdbx {TEMP_DATABASE}
exit
---
{TEMP_DATABASE} is used as placeholder to store the database in a temporary location
The command has to exit. In case of `sftp` as last commend `exit` has to be sent
         </source>
        <translation>לדוגמה:
get DatabaseOnRemote.kdbx {TEMP_DATABASE}
exit
---
{TEMP_DATABASE} משמש כשומר מקום לאחסון מסד הנתונים במיקום זמני.
הפקודה אמורה להסתיים ב&apos;יציאה&apos;. במקרה של `sftp` כפקודה אחרונה, יש לשלוח פקודת `exit`
            </translation>
    </message>
    <message>
        <source>Remote Database (.kdbx)</source>
        <translation>מסד נתונים מרוחק (.kdb)</translation>
    </message>
</context>
<context>
    <name>KMessageWidget</name>
    <message>
        <source>&amp;Close</source>
        <translation>&amp;סגירה</translation>
    </message>
    <message>
        <source>Close message</source>
        <translation>סגירת הערה</translation>
    </message>
</context>
<context>
    <name>Kdbx3Reader</name>
    <message>
        <source>Missing database headers</source>
        <translation>חסרות כותרות מסד־נתונים</translation>
    </message>
    <message>
        <source>Unable to calculate database key</source>
        <translation>לא ניתן לחשב מפתח מסד־נתונים</translation>
    </message>
    <message>
        <source>Unable to issue challenge-response: %1</source>
        <translation>לא ניתן להנפיק אתגר־מענה: %1</translation>
    </message>
    <message>
        <source>Invalid credentials were provided, please try again.
If this reoccurs, then your database file may be corrupt.</source>
        <translation>סופקו אישורים לא תקינים, נא לנסות שוב.
אם פעולה זו חוזרת על עצמה, ייתכן שקובץ מסד הנתונים פגום.</translation>
    </message>
    <message>
        <source>Header doesn&apos;t match hash</source>
        <translation>הכותרת העליונה אינה תואמת לגבובב</translation>
    </message>
    <message>
        <source>Invalid header id size</source>
        <translation>גודל מזהה כותרת לא תקין</translation>
    </message>
    <message>
        <source>Invalid header field length: field %1</source>
        <translation>אורך שדה כותרת לא תקין: שדה %1</translation>
    </message>
    <message>
        <source>Invalid header data length: field %1, %2 expected, %3 found</source>
        <translation>אורך נתוני כותרת לא תקין: שדה %1, ציפיה ל־%2, נמצא %3</translation>
    </message>
</context>
<context>
    <name>Kdbx3Writer</name>
    <message>
        <source>Invalid symmetric cipher IV size.</source>
        <comment>IV = Initialization Vector for symmetric cipher</comment>
        <translation>גודל צופן IV סימטרי לא תקין.</translation>
    </message>
    <message>
        <source>Unable to issue challenge-response: %1</source>
        <translation>לא ניתן להנפיק אתגר־מענה: %1</translation>
    </message>
    <message>
        <source>Unable to calculate database key</source>
        <translation>לא ניתן לחשב מפתח מסד־נתונים</translation>
    </message>
</context>
<context>
    <name>Kdbx4Reader</name>
    <message>
        <source>missing database headers</source>
        <translation>כותרות מסד־נתונים חסרות</translation>
    </message>
    <message>
        <source>Unable to calculate database key: %1</source>
        <translation>לא ניתן לחשב מפתח מסד־נתונים: %1</translation>
    </message>
    <message>
        <source>Invalid header checksum size</source>
        <translation>גודל  סיכום ביקורת כותרת עליונה לא תקין</translation>
    </message>
    <message>
        <source>Header SHA256 mismatch</source>
        <translation>כותרת עליונה SHA256 לא תואמת</translation>
    </message>
    <message>
        <source>Invalid credentials were provided, please try again.
If this reoccurs, then your database file may be corrupt.</source>
        <translation>סופקו אישורים לא תקינים, נא לנסות שוב.
אם פעולה זו חוזרת על עצמה, ייתכן שקובץ מסד הנתונים פגום.</translation>
    </message>
    <message>
        <source>(HMAC mismatch)</source>
        <translation>(אי התאמת HMAC)</translation>
    </message>
    <message>
        <source>Unknown cipher</source>
        <translation>צופן לא ידוע</translation>
    </message>
    <message>
        <source>Invalid header id size</source>
        <translation>גודל מזהה כותרת לא תקין</translation>
    </message>
    <message>
        <source>Invalid header field length: field %1</source>
        <translation>אורך שדה כותרת לא תקין: שדה %1</translation>
    </message>
    <message>
        <source>Invalid header data length: field %1, %2 expected, %3 found</source>
        <translation>אורך נתוני כותרת לא תקין: שדה %1, ציפיה ל־%2, נמצא %3</translation>
    </message>
    <message>
        <source>Failed to open buffer for KDF parameters in header</source>
        <translation>פתיחת החציצה עבור משתני KDF בכותרת, כשלה</translation>
    </message>
    <message>
        <source>Unsupported key derivation function (KDF) or invalid parameters</source>
        <translation>פונקציית נגזרת מפתח (KDF) לא נתמכים או פרמטרים לא תקינים</translation>
    </message>
    <message>
        <source>Legacy header fields found in KDBX4 file.</source>
        <translation>שדות כותרת מדור קודם שנמצאו בקובץ KDBX4.</translation>
    </message>
    <message>
        <source>Invalid inner header id size</source>
        <translation>גודל מזהה כותרת פנימי לא תקין</translation>
    </message>
    <message>
        <source>Invalid inner header field length: field %1</source>
        <translation>אורך שדה כותרת פנימית לא תקין: שדה %1</translation>
    </message>
    <message>
        <source>Invalid inner header data length: field %1, %2 expected, %3 found</source>
        <translation>אורך נתוני כותרת פנימית לא תקין: שדה %1, ציפיה ל־%2, נמצא %3</translation>
    </message>
    <message>
        <source>Invalid inner header binary size</source>
        <translation>גודל בינארי של כותרת פנימית לא תקין</translation>
    </message>
    <message>
        <source>Unsupported KeePass variant map version.</source>
        <extracomment>Translation: variant map = data structure for storing meta data</extracomment>
        <translation>גרסת מפת משתני KeePass לא נתמכת.</translation>
    </message>
    <message>
        <source>Invalid variant map entry name length</source>
        <extracomment>Translation: variant map = data structure for storing meta data</extracomment>
        <translation>אורך שם מפת משתנה רשומה לא תקין</translation>
    </message>
    <message>
        <source>Invalid variant map entry name data</source>
        <extracomment>Translation: variant map = data structure for storing meta data</extracomment>
        <translation>נתוני שם מפת משתנה רשומה לא תקינים</translation>
    </message>
    <message>
        <source>Invalid variant map entry value length</source>
        <extracomment>Translation: variant map = data structure for storing meta data</extracomment>
        <translation>אורך ערך מפת משתנה רשומה לא תקין</translation>
    </message>
    <message>
        <source>Invalid variant map entry value data</source>
        <extracomment>Translation comment: variant map = data structure for storing meta data</extracomment>
        <translation>נתוני ערך מפת משתנה רשומה לא תקינים</translation>
    </message>
    <message>
        <source>Invalid variant map Bool entry value length</source>
        <extracomment>Translation: variant map = data structure for storing meta data</extracomment>
        <translation>אורך ערך מפת משתנה רשומה בוליאנית לא תקין</translation>
    </message>
    <message>
        <source>Invalid variant map Int32 entry value length</source>
        <extracomment>Translation: variant map = data structure for storing meta data</extracomment>
        <translation>אורך ערך מפת משתנה רשומה Int32 לא תקין</translation>
    </message>
    <message>
        <source>Invalid variant map UInt32 entry value length</source>
        <extracomment>Translation: variant map = data structure for storing meta data</extracomment>
        <translation>אורך ערך מפת משתנה רשומה UInt32 לא תקין</translation>
    </message>
    <message>
        <source>Invalid variant map Int64 entry value length</source>
        <extracomment>Translation: variant map = data structure for storing meta data</extracomment>
        <translation>אורך ערך מפת משתנה רשומה Int64 לא תקין</translation>
    </message>
    <message>
        <source>Invalid variant map UInt64 entry value length</source>
        <extracomment>Translation: variant map = data structure for storing meta data</extracomment>
        <translation>אורך ערך מפת משתנה רשומה UInt64 לא תקין</translation>
    </message>
    <message>
        <source>Invalid variant map entry type</source>
        <extracomment>Translation: variant map = data structure for storing meta data</extracomment>
        <translation>סוג מפת משתנה רשומה לא תקינים</translation>
    </message>
    <message>
        <source>Invalid variant map field type size</source>
        <extracomment>Translation: variant map = data structure for storing meta data</extracomment>
        <translation>גודל שדה מפת משתנה לא תקין</translation>
    </message>
</context>
<context>
    <name>Kdbx4Writer</name>
    <message>
        <source>Invalid symmetric cipher algorithm.</source>
        <translation>אלגוריתם צופן סימטרי לא תקין.</translation>
    </message>
    <message>
        <source>Invalid symmetric cipher IV size.</source>
        <comment>IV = Initialization Vector for symmetric cipher</comment>
        <translation>גודל צופן IV סימטרי לא תקין.</translation>
    </message>
    <message>
        <source>Unable to calculate database key: %1</source>
        <translation>לא ניתן לחשב מפתח מסד־נתונים: %1</translation>
    </message>
    <message>
        <source>Failed to serialize KDF parameters variant map</source>
        <extracomment>Translation comment: variant map = data structure for storing meta data</extracomment>
        <translation>סִדְרוּת מפת משתני פרמטר KDF כשלה</translation>
    </message>
</context>
<context>
    <name>KdbxReader</name>
    <message>
        <source>Invalid cipher uuid length: %1 (length=%2)</source>
        <translation>אורך uuid צופן לא תקין: %1 (אורך=%2)</translation>
    </message>
    <message>
        <source>Unable to parse UUID: %1</source>
        <translation>לא ניתן לנתח UUID: %1</translation>
    </message>
    <message>
        <source>Unsupported cipher</source>
        <translation>צופן לא נתמך</translation>
    </message>
    <message>
        <source>Invalid compression flags length</source>
        <translation>אורך דגלי דחיסה לא תקינים</translation>
    </message>
    <message>
        <source>Unsupported compression algorithm</source>
        <translation>אלגוריתם דחיסה לא נתמך</translation>
    </message>
    <message>
        <source>Invalid master seed size</source>
        <translation>גודל זרע ראשי לא תקין</translation>
    </message>
    <message>
        <source>Invalid transform seed size</source>
        <translation>המרת גודל זרע לא תקין</translation>
    </message>
    <message>
        <source>Invalid transform rounds size</source>
        <translation>גודל סבבי המרה לא תקינים</translation>
    </message>
    <message>
        <source>Invalid start bytes size</source>
        <translation>גודל בתים התחלתי לא תקין</translation>
    </message>
    <message>
        <source>Invalid random stream id size</source>
        <translation>גודל מזהה זרם אקראי לא תקין</translation>
    </message>
    <message>
        <source>Invalid inner random stream cipher</source>
        <translation>צופן זרם פנימי אקראי לא תקין</translation>
    </message>
    <message>
        <source>Failed to read database file.</source>
        <translation>קריאת קובץ מסד־נתונים כשלה.</translation>
    </message>
    <message>
        <source>The selected file is an old KeePass 1 database (.kdb).

You can import it by clicking on Database &gt; 'Import KeePass 1 database…'.
This is a one-way migration. You won&apos;t be able to open the imported database with the old KeePassX 0.4 version.</source>
        <translation>הקובץ שנבחר הוא מסד נתונים ישן של KeePass 1 (.kdb).

ניתן לייבא אותו על־ידי לחיצה על מסד נתונים -&gt; &apos;ייבוא KeePass 1 מסד נתונים ...&apos;.
זו הגירה חד־כיוונית. לא תתאפשר פתיחת מסד הנתונים המיובא עם גרסת KeePassX 0.4 הישנה.</translation>
    </message>
    <message>
        <source>Not a KeePass database.</source>
        <translation>לא מסד נתוני KeePass.</translation>
    </message>
    <message>
        <source>Unsupported KeePass 2 database version.</source>
        <translation>גרסת מסד נתוני KeePass 2 לא נתמכת.</translation>
    </message>
</context>
<context>
    <name>KdbxXmlReader</name>
    <message>
        <source>XML parsing failure: %1</source>
        <translation>כשל ניתוח מבנה XML: %1</translation>
    </message>
    <message>
        <source>No root group</source>
        <translation>אין קבוצת שורש</translation>
    </message>
    <message>
        <source>XML error:
%1
Line %2, column %3</source>
        <translation>שגיאת XML:
%1
שורה %2, עמודה %3</translation>
    </message>
    <message>
        <source>Missing icon uuid or data</source>
        <translation>חסרים uuid סמלים או נתונים</translation>
    </message>
    <message>
        <source>Missing custom data key or value</source>
        <translation>חסר מפתח נתונים מותאם אישית או ערך</translation>
    </message>
    <message>
        <source>Multiple group elements</source>
        <translation>רכיבי קבוצה מרובים</translation>
    </message>
    <message>
        <source>Null group uuid</source>
        <translation>uuid קבוצת Null</translation>
    </message>
    <message>
        <source>Invalid group icon number</source>
        <translation>מספר סמל קבוצה לא כותרת פנימית</translation>
    </message>
    <message>
        <source>Invalid EnableAutoType value</source>
        <translation>ערך איפשור הקלדה־אוטומטית לא תקין</translation>
    </message>
    <message>
        <source>Invalid EnableSearching value</source>
        <translation>ערך איפשור חיפוש לא תקין</translation>
    </message>
    <message>
        <source>No group uuid found</source>
        <translation>לא נמצאה uuid קבוצה</translation>
    </message>
    <message>
        <source>Null DeleteObject uuid</source>
        <translation>uuid עצם שנמחק ריק</translation>
    </message>
    <message>
        <source>Missing DeletedObject uuid or time</source>
        <translation>חסרים uuid עצמים שנמחקו או זמן</translation>
    </message>
    <message>
        <source>Null entry uuid</source>
        <translation>רשומת uuid ריקה</translation>
    </message>
    <message>
        <source>Invalid entry icon number</source>
        <translation>מספר סמל רשומה לא תקינה</translation>
    </message>
    <message>
        <source>History element in history entry</source>
        <translation>רכיב היסטורי ברשומה היסטורית</translation>
    </message>
    <message>
        <source>No entry uuid found</source>
        <translation>לא נמצאה uuid רשומת</translation>
    </message>
    <message>
        <source>History element with different uuid</source>
        <translation>רכיב היסטוריה עם uuid שונה</translation>
    </message>
    <message>
        <source>Duplicate custom attribute found</source>
        <translation>נמצאה תכונה מותאמת אישית כפולה</translation>
    </message>
    <message>
        <source>Entry string key or value missing</source>
        <translation>מפתח או ערך מחרוזת רשומה חסרים</translation>
    </message>
    <message>
        <source>Entry binary key or value missing</source>
        <translation>מפתח בינארי או ערך רשומה חסרים</translation>
    </message>
    <message>
        <source>Auto-type association window or sequence missing</source>
        <translation>חסר חלון שיוך או רצף הקלדה־אוטומטית</translation>
    </message>
    <message>
        <source>Invalid bool value</source>
        <translation>ערך בוליאני לא תקין</translation>
    </message>
    <message>
        <source>Invalid date time value</source>
        <translation>ערך תאריך ושעה לא תקין</translation>
    </message>
    <message>
        <source>Invalid color value</source>
        <translation>ערך צבע לא תקין</translation>
    </message>
    <message>
        <source>Invalid color rgb part</source>
        <translation>חלק צבע rbg לא תקין</translation>
    </message>
    <message>
        <source>Invalid number value</source>
        <translation>ערך מספרי לא תקין</translation>
    </message>
    <message>
        <source>Invalid uuid value</source>
        <translation>ערך uuid לא תקין</translation>
    </message>
    <message>
        <source>Unable to decompress binary</source>
        <extracomment>Translator meant is a binary data inside an entry</extracomment>
        <translation>לא ניתן לחלץ דחיסת קבצים בינאריים</translation>
    </message>
</context>
<context>
    <name>KeeAgentSettings</name>
    <message>
        <source>Invalid KeeAgent settings file structure.</source>
        <translation>מבנה קובץ הגדרות KeeAgent לא תקין.</translation>
    </message>
    <message>
        <source>Private key is an attachment but no attachments provided.</source>
        <translation>מפתח פרטי הוא צרופה אך לא סופקו צרופות.</translation>
    </message>
    <message>
        <source>Private key is empty</source>
        <translation>המפתח הפרטי ריק</translation>
    </message>
    <message>
        <source>File too large to be a private key</source>
        <translation>הקובץ גדול מכדי להיות מפתח פרטי</translation>
    </message>
    <message>
        <source>Failed to open private key</source>
        <translation>פתיחת קובץ מפתח כשלה</translation>
    </message>
</context>
<context>
    <name>KeePass1Reader</name>
    <message>
        <source>Unable to read keyfile.</source>
        <translation>לא ניתן לקרוא קובץ מפתח.</translation>
    </message>
    <message>
        <source>Not a KeePass database.</source>
        <translation>לא מסד נתוני KeePass.</translation>
    </message>
    <message>
        <source>Unsupported encryption algorithm.</source>
        <translation>אלגוריתם הצפנה לא נתמך.</translation>
    </message>
    <message>
        <source>Unsupported KeePass database version.</source>
        <translation>גרסת מסד־נתונים KeePass לא נתמכת.</translation>
    </message>
    <message>
        <source>Unable to read encryption IV</source>
        <comment>IV = Initialization Vector for symmetric cipher</comment>
        <translation>לא ניתן לקרוא הצפנה IV</translation>
    </message>
    <message>
        <source>Invalid number of groups</source>
        <translation>מספר קבוצות לא תקין</translation>
    </message>
    <message>
        <source>Invalid number of entries</source>
        <translation>מספר רשומות לא תקין</translation>
    </message>
    <message>
        <source>Invalid content hash size</source>
        <translation>גודל גיבוב תוכן לא תקין</translation>
    </message>
    <message>
        <source>Invalid transform seed size</source>
        <translation>המרת גודל זרע לא תקין</translation>
    </message>
    <message>
        <source>Invalid number of transform rounds</source>
        <translation>מספר סבבי המרה לא תקין</translation>
    </message>
    <message>
        <source>Unable to construct group tree</source>
        <translation>לא ניתן לבנות עץ קבוצה</translation>
    </message>
    <message>
        <source>Root</source>
        <translation>שורש</translation>
    </message>
    <message>
        <source>Unable to calculate database key</source>
        <translation>לא ניתן לחשב מפתח מסד־נתונים</translation>
    </message>
    <message>
        <source>unable to seek to content position</source>
        <translation>לא ניתן לחתור למיקום תוכן</translation>
    </message>
    <message>
        <source>Invalid credentials were provided, please try again.
If this reoccurs, then your database file may be corrupt.</source>
        <translation>סופקו אישורים לא תקינים, נא לנסות שוב.
אם פעולה זו חוזרת על עצמה, ייתכן שקובץ מסד הנתונים פגום.</translation>
    </message>
    <message>
        <source>Key transformation failed</source>
        <translation>המרת מפתח כשלה</translation>
    </message>
    <message>
        <source>Invalid group field type number</source>
        <translation>מספר סוג שדה קבוצה לאתקין</translation>
    </message>
    <message>
        <source>Invalid group field size</source>
        <translation>גודל שדה קבוצה לא תקין</translation>
    </message>
    <message>
        <source>Read group field data doesn&apos;t match size</source>
        <translation>קריאת נתוני שדה קבוצה לא תואם לגודל</translation>
    </message>
    <message>
        <source>Incorrect group id field size</source>
        <translation>גודל שדה מזהה קבוצה שגוי</translation>
    </message>
    <message>
        <source>Incorrect group creation time field size</source>
        <translation>גודל שדה זמן יצירת קבוצה שגוי</translation>
    </message>
    <message>
        <source>Incorrect group modification time field size</source>
        <translation>גודל שדה זמן הסגלת קבוצה שגויה</translation>
    </message>
    <message>
        <source>Incorrect group access time field size</source>
        <translation>גודל שדה זמן גישה לקבוצה  שגוי</translation>
    </message>
    <message>
        <source>Incorrect group expiry time field size</source>
        <translation>גודל שדה זמן תפוגת קבוצה שגוי</translation>
    </message>
    <message>
        <source>Incorrect group icon field size</source>
        <translation>גודל שדה סמל קבוצה שגוי</translation>
    </message>
    <message>
        <source>Incorrect group level field size</source>
        <translation>גודל שדה ברמת הקבוצה שגוי</translation>
    </message>
    <message>
        <source>Invalid group field type</source>
        <translation>סוג שדה קבוצה לא תקין</translation>
    </message>
    <message>
        <source>Missing group id or level</source>
        <translation>מזהה קבוצה או רמה חסרים</translation>
    </message>
    <message>
        <source>Missing entry field type number</source>
        <translation>מספר סוג שדה רשומה חסר</translation>
    </message>
    <message>
        <source>Invalid entry field size</source>
        <translation>גודל שדה רשומה לא תקין</translation>
    </message>
    <message>
        <source>Read entry field data doesn&apos;t match size</source>
        <translation>קריאת נתוני שדה רשומה לא תואם לגודל</translation>
    </message>
    <message>
        <source>Invalid entry UUID field size</source>
        <translation>גודל שדה רשומה UUID לא תקין</translation>
    </message>
    <message>
        <source>Invalid entry group id field size</source>
        <translation>גודל מזהה שדה קבוצת רשומה לא תקין</translation>
    </message>
    <message>
        <source>Invalid entry icon field size</source>
        <translation>גודל שדה סמל רשומה לא תקין</translation>
    </message>
    <message>
        <source>Invalid entry creation time field size</source>
        <translation>גודל שדה זמן יצירת רשומה לא תקין</translation>
    </message>
    <message>
        <source>Invalid entry modification time field size</source>
        <translation>גודל שדה זמן הסגלת רשומה לא תקין</translation>
    </message>
    <message>
        <source>Invalid entry expiry time field size</source>
        <translation>גודל שדה זמן תפוגת רשומה לא תקין</translation>
    </message>
    <message>
        <source>Invalid entry field type</source>
        <translation>סוג שדה רשומה לא תקין</translation>
    </message>
</context>
<context>
    <name>KeeShare</name>
    <message>
        <source>Invalid sharing reference</source>
        <translation>הפניית שיתוף לא תקניה</translation>
    </message>
    <message>
        <source>Inactive share %1</source>
        <translation>מיקום משותף לא פעיל %1</translation>
    </message>
    <message>
        <source>Imported from %1</source>
        <translation>מיובא מ־%1</translation>
    </message>
    <message>
        <source>Exported to %1</source>
        <translation>ייצוא ל־%1</translation>
    </message>
    <message>
        <source>Synchronized with %1</source>
        <translation>סונכרן עם %1</translation>
    </message>
    <message>
        <source>Import is disabled in settings</source>
        <translation>הייבוא מושבת בהגדרות</translation>
    </message>
    <message>
        <source>Export is disabled in settings</source>
        <translation>הייצוא מושבת בהגדרות</translation>
    </message>
    <message>
        <source>Inactive share</source>
        <translation>השבתת שתוף</translation>
    </message>
    <message>
        <source>Imported from</source>
        <translation>יובא מ־</translation>
    </message>
    <message>
        <source>Exported to</source>
        <translation>יוצא ל־</translation>
    </message>
    <message>
        <source>Synchronized with</source>
        <translation>סונכרן עם</translation>
    </message>
</context>
<context>
    <name>KeyComponentWidget</name>
    <message>
        <source>Key Component</source>
        <translation>רכיב מפתח</translation>
    </message>
    <message>
        <source>Key Component Description</source>
        <translation>תיאור רכיב מפתח</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>ביטול</translation>
    </message>
    <message>
        <source>Key Component set, click to change or remove</source>
        <translation>ערכת רכיבי מפתח, הקשה לשנוי או הסרה</translation>
    </message>
</context>
<context>
    <name>KeyFileEditWidget</name>
    <message>
        <source>Generate a new key file</source>
        <translation>חילול קובץ מפתח חדש</translation>
    </message>
    <message>
        <source>Generate</source>
        <translation>חילול</translation>
    </message>
    <message>
        <source>Generate a new key file or choose an existing one to protect your database.</source>
        <translation>חילול קובץ מפתח חדש או בחירת קובץ מפתח קיים להגנה על מסד הנתונים.</translation>
    </message>
    <message>
        <source>Note: Do NOT use a file that may change as that will prevent you from unlocking your database.</source>
        <translation>הערה: נא לא להשתמש בקובץ שעשוי להשתנות כך שימנע את שחרור נעילת מסד הנתונים.</translation>
    </message>
    <message>
        <source>Browse for key file</source>
        <translation>דפדוף לקובץ מפתח</translation>
    </message>
    <message>
        <source>Browse…</source>
        <translation>עיון...</translation>
    </message>
    <message>
        <source>Old key file format</source>
        <translation>תסדיר קובץ מפתח ישן</translation>
    </message>
    <message>
        <source>You selected a key file in an old format which KeePassXC&lt;br&gt;may stop supporting in the future.&lt;br&gt;&lt;br&gt;Please consider generating a new key file instead.</source>
        <translation>נבחר קובץ מפתח בתסדיר ישן ש־KeePassXC&lt;br&gt;עשוי להפסיק לתמוך בעתיד.&lt;br&gt;&lt;br&gt;במקום זאת, נא לשקול ליצור קובץ מפתח חדש.</translation>
    </message>
    <message>
        <source>Error loading the key file '%1'
Message: %2</source>
        <translation>שגיאה בטעינת קובץ המפתח &apos;%1&apos;
הודעה: %2</translation>
    </message>
    <message>
        <source>Key File</source>
        <translation>קובץ מפתח</translation>
    </message>
    <message>
        <source>Add Key File</source>
        <translation>הוספת קובץ מפתח</translation>
    </message>
    <message>
        <source>Change Key File</source>
        <translation>שינוי קובץ מפתח</translation>
    </message>
    <message>
        <source>Remove Key File</source>
        <translation>הסרת קובץ מפתח</translation>
    </message>
    <message>
        <source>Key File set, click to change or remove</source>
        <translation>ערכת קבצי מפתח, הקשה לשנוי או הסרה</translation>
    </message>
    <message>
        <source>&lt;p&gt;You can add a key file containing random bytes for additional security.&lt;/p&gt;&lt;p&gt;You must keep it secret and never lose it or you will be locked out.&lt;/p&gt;</source>
        <translation>&lt;p&gt;ניתן להוסיף קובץ מפתח המכיל בתים אקראיים לאבטחה נוספת.&lt;/p&gt;&lt;p&gt;חובה לשמור אות &apos;סודי&apos; ולעולם לא לאבד אותו או שלא ניתן יהיה להתחבר למערכת שוב!&lt;/p&gt;</translation>
    </message>
    <message>
        <source>Key files</source>
        <translation>קבצי מפתח</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>כל הקבצים</translation>
    </message>
    <message>
        <source>Create Key File…</source>
        <translation>יצירת קובץ מפתח...</translation>
    </message>
    <message>
        <source>Error creating key file</source>
        <translation>שגיאה ביצירת קובץ מפתח</translation>
    </message>
    <message>
        <source>Unable to create key file: %1</source>
        <translation>לא ניתן ליצר קובץ מפתח: %1</translation>
    </message>
    <message>
        <source>Select a key file</source>
        <translation>בחירת קובץ מפתח</translation>
    </message>
    <message>
        <source>Invalid Key File</source>
        <translation>קובץ מפתח לא תקין</translation>
    </message>
    <message>
        <source>You cannot use the current database as its own keyfile. Please choose a different file or generate a new key file.</source>
        <translation>לא ניתן להשתמש במסד הנתונים הנוכחי כקובץ המפתח שלו. נא לבחור קובץ אחר או לחולל קובץ מפתח חדש.</translation>
    </message>
    <message>
        <source>Suspicious Key File</source>
        <translation>קובץ מפתח חשוד</translation>
    </message>
    <message>
        <source>The chosen key file looks like a password database file. A key file must be a static file that never changes or you will lose access to your database forever.
Are you sure you want to continue with this file?</source>
        <translation>קובץ המפתח שנבחר נראה כמו קובץ מסד נתוני ססמאות. קובץ מפתח חייב להיות קובץ נייח שלעולם לא ישתנה או שהגישה למסד הנתונים תאבד  לנצח.
האם להמשיך עם קובץ זה?</translation>
    </message>
</context>
<context>
    <name>MacUtils</name>
    <message>
        <source>Invalid key code</source>
        <translation>קוד מפתח לא תקין</translation>
    </message>
    <message>
        <source>Global shortcut already registered to %1</source>
        <translation>קיצור דרך כללי כבר רשום ב־%1</translation>
    </message>
    <message>
        <source>Could not register global shortcut</source>
        <translation>לא ניתן לרשום קיצור דרך כללי</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>&amp;Database</source>
        <translation>&amp;מסד־נתונים</translation>
    </message>
    <message>
        <source>&amp;Recent Databases</source>
        <translation>מסדי־נתונים &amp;אחרונים</translation>
    </message>
    <message>
        <source>&amp;Export</source>
        <translation>&amp;ייצוא</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>&amp;עזרה</translation>
    </message>
    <message>
        <source>&amp;Entries</source>
        <translation>&amp;רשומות</translation>
    </message>
    <message>
        <source>Copy Att&amp;ribute</source>
        <translation>העתקת &amp;תכונה</translation>
    </message>
    <message>
        <source>TOTP</source>
        <translation>TOTP</translation>
    </message>
    <message>
        <source>Tags</source>
        <translation>תגים</translation>
    </message>
    <message>
        <source>&amp;Groups</source>
        <translation>&amp;קבוצות</translation>
    </message>
    <message>
        <source>&amp;Tools</source>
        <translation>&amp;כלים</translation>
    </message>
    <message>
        <source>View</source>
        <translation>מצג</translation>
    </message>
    <message>
        <source>Theme</source>
        <translation>ערכת נושא</translation>
    </message>
    <message>
        <source>&amp;Quit</source>
        <translation>&amp;יצאה</translation>
    </message>
    <message>
        <source>&amp;About</source>
        <translation>&amp;על אודות</translation>
    </message>
    <message>
        <source>&amp;Check for Updates</source>
        <translation>&amp;בדיקת זמינות עדכונים</translation>
    </message>
    <message>
        <source>&amp;Open Database…</source>
        <translation>&amp;פתיחת מסד־נתונים...</translation>
    </message>
    <message>
        <source>&amp;Save Database</source>
        <translation>&amp;שמירת מסד־נתונים</translation>
    </message>
    <message>
        <source>&amp;Close Database</source>
        <translation>&amp;סגירת מסד־נתונים</translation>
    </message>
    <message>
        <source>&amp;New Database…</source>
        <translation>&amp;מסד־נתונים חדש...</translation>
    </message>
    <message>
        <source>&amp;Merge From Database…</source>
        <translation>&amp;מיזוג ממסד נתונים...</translation>
    </message>
    <message>
        <source>&amp;New Entry…</source>
        <translation>&amp;רשומה חדשה...</translation>
    </message>
    <message>
        <source>&amp;Edit Entry…</source>
        <translation>&amp;עריכת רשומה...</translation>
    </message>
    <message>
        <source>&amp;New Group…</source>
        <translation>&amp;קבוצה חדשה...</translation>
    </message>
    <message>
        <source>&amp;Edit Group…</source>
        <translation>&amp;עריכת קבוצה...</translation>
    </message>
    <message>
        <source>&amp;Delete Group…</source>
        <translation>&amp;מחיקת קבוצה...</translation>
    </message>
    <message>
        <source>Download All &amp;Favicons…</source>
        <translation>הורדת כל ה־&amp;פביקונס...</translation>
    </message>
    <message>
        <source>Sort &amp;A-Z</source>
        <translation>מיין &amp;א-ת</translation>
    </message>
    <message>
        <source>Sort &amp;Z-A</source>
        <translation>מיין &amp;ת-א</translation>
    </message>
    <message>
        <source>Sa&amp;ve Database As…</source>
        <translation>שמי&amp;רת מסד־נתונים בשם...</translation>
    </message>
    <message>
        <source>Database &amp;Security…</source>
        <translation>&amp;אבטחת מסד־נתונים...</translation>
    </message>
    <message>
        <source>Database &amp;Reports…</source>
        <translation>&amp;דוחות מסד־נתונים...</translation>
    </message>
    <message>
        <source>&amp;Database Settings…</source>
        <translation>&amp;הגדרות מסד־נתונים...</translation>
    </message>
    <message>
        <source>&amp;Clone Entry…</source>
        <translation>&amp;שכפול רשומה...</translation>
    </message>
    <message>
        <source>Move u&amp;p</source>
        <translation>העברה &amp;מעלה</translation>
    </message>
    <message>
        <source>Move do&amp;wn</source>
        <translation>העברה &amp;מטה</translation>
    </message>
    <message>
        <source>Copy &amp;Username</source>
        <translation>העתקת &amp;שם משתמש</translation>
    </message>
    <message>
        <source>Copy &amp;Password</source>
        <translation>העתקת &amp;ססמה</translation>
    </message>
    <message>
        <source>&amp;Settings</source>
        <translation>&amp;הגדרות</translation>
    </message>
    <message>
        <source>&amp;Password Generator</source>
        <translation>מחולל &amp;ססמאות</translation>
    </message>
    <message>
        <source>Perform &amp;Auto-Type</source>
        <translation>ביצוע &amp;הקלדה־אוטומטית</translation>
    </message>
    <message>
        <source>Download &amp;Favicon</source>
        <translation>הורדת &amp;פביקון</translation>
    </message>
    <message>
        <source>Open &amp;URL</source>
        <translation>פתיחת &amp;מען URL</translation>
    </message>
    <message>
        <source>&amp;Lock Database</source>
        <translation>&amp;נעילת מסד־נתונים</translation>
    </message>
    <message>
        <source>Lock &amp;All Databases</source>
        <translation>&amp;נעילת כל מסדי־הנתונים</translation>
    </message>
    <message>
        <source>&amp;Title</source>
        <translation>&amp;כותרת</translation>
    </message>
    <message>
        <source>Copy &amp;URL</source>
        <translation>העתקת מען־URL</translation>
    </message>
    <message>
        <source>&amp;Notes</source>
        <translation>&amp;הערות</translation>
    </message>
    <message>
        <source>&amp;CSV File…</source>
        <translation>&amp;קובץ CSV...</translation>
    </message>
    <message>
        <source>&amp;HTML File…</source>
        <translation>ק&amp;ובץ HTML...</translation>
    </message>
    <message>
        <source>KeePass 1 Database…</source>
        <translation>מסד־נתונים KeePass 1...</translation>
    </message>
    <message>
        <source>1Password Vault…</source>
        <translation>כספת 1Password...</translation>
    </message>
    <message>
        <source>CSV File…</source>
        <translation>קובץ CSV...</translation>
    </message>
    <message>
        <source>Show TOTP</source>
        <translation>הצגת TOTP</translation>
    </message>
    <message>
        <source>Show QR Code</source>
        <translation>הצגת קוד QR</translation>
    </message>
    <message>
        <source>Set up TOTP…</source>
        <translation>הגדרת TOTP...</translation>
    </message>
    <message>
        <source>Copy &amp;TOTP</source>
        <translation>העתקת &amp;TOTP</translation>
    </message>
    <message>
        <source>Copy Password and TOTP</source>
        <translation>העתקת ססמה ו־TOTP</translation>
    </message>
    <message>
        <source>E&amp;mpty recycle bin</source>
        <translation>&amp;ריקןן סל־מחזור</translation>
    </message>
    <message>
        <source>&amp;Donate</source>
        <translation>&amp;תרומה</translation>
    </message>
    <message>
        <source>Report a &amp;Bug</source>
        <translation>דיווח על &amp;תקלה</translation>
    </message>
    <message>
        <source>&amp;Getting Started</source>
        <translation>&amp;תחילת עבודה</translation>
    </message>
    <message>
        <source>Open Getting Started Guide</source>
        <translation>פתיחת מדריך &apos;מתחילים&apos;</translation>
    </message>
    <message>
        <source>&amp;Online Help</source>
        <translation>עזרה &amp;מקוונת</translation>
    </message>
    <message>
        <source>&amp;User Guide</source>
        <translation>&amp;מדריך למשתמש</translation>
    </message>
    <message>
        <source>Open User Guide</source>
        <translation>פתיחת מדריך למשתמש</translation>
    </message>
    <message>
        <source>&amp;Keyboard Shortcuts</source>
        <translation>&amp;קיצורי מקשים</translation>
    </message>
    <message>
        <source>Save Database Backup…</source>
        <translation>שמירת גיבוי מסד־נתונים...</translation>
    </message>
    <message>
        <source>Add key to SSH Agent</source>
        <translation>הוספת מפתח לסוכן SSH</translation>
    </message>
    <message>
        <source>Remove key from SSH Agent</source>
        <translation>הסרת מפתח מסוכן SSH</translation>
    </message>
    <message>
        <source>Compact Mode</source>
        <translation>מצב צמום</translation>
    </message>
    <message>
        <source>Automatic</source>
        <translation>אוטומטי</translation>
    </message>
    <message>
        <source>Light</source>
        <translation>בהיר</translation>
    </message>
    <message>
        <source>Dark</source>
        <translation>כהה</translation>
    </message>
    <message>
        <source>Classic (Platform-native)</source>
        <translation>קלאסי (מובנה מסדת)</translation>
    </message>
    <message>
        <source>Show Menubar</source>
        <translation>הצגת סרגל תפריט</translation>
    </message>
    <message>
        <source>Show Toolbar</source>
        <translation>הצגת סרגל־כלים</translation>
    </message>
    <message>
        <source>Show Preview Panel</source>
        <translation>הצגת לוחית &apos;תצוגה מקדימה&apos;</translation>
    </message>
    <message>
        <source>Always on Top</source>
        <translation>תמיד מעל</translation>
    </message>
    <message>
        <source>Hide Usernames</source>
        <translation>הסתרת שמות משתמשים</translation>
    </message>
    <message>
        <source>Hide Passwords</source>
        <translation>הסתרת ססמאות</translation>
    </message>
    <message>
        <source>Clone Group...</source>
        <translation>שכפול קבוצה...</translation>
    </message>
    <message>
        <source>&amp;XML File…</source>
        <translation>&amp;קובץ XML...</translation>
    </message>
    <message>
        <source>Clear history</source>
        <translation>נקוי היסטוריה</translation>
    </message>
    <message>
        <source>Access error for config file %1</source>
        <translation>שגיאת גישה לקובץ התצורה %1</translation>
    </message>
    <message>
        <source>Don&apos;t show again for this version</source>
        <translation>לא להציג שוב לגרסה זו</translation>
    </message>
    <message>
        <source>No Tags</source>
        <translation>ללא תג</translation>
    </message>
    <message numerus="yes">
        <source>Restore Entry(s)</source>
        <translation><numerusform>שחזור רשומה</numerusform><numerusform>שחזור רשומות</numerusform><numerusform>שחזור רשומות</numerusform></translation>
    </message>
    <message>
        <source>Settings</source>
        <translation>הגדרות</translation>
    </message>
    <message>
        <source>Check for updates on startup?</source>
        <translation>האם לבדוק עדכונים בעת האיתחול?</translation>
    </message>
    <message>
        <source>Would you like KeePassXC to check for updates on startup?</source>
        <translation>האם לאפשר ל־KeePassXC לבדוק עדכונים בעת האיתחול?</translation>
    </message>
    <message>
        <source>You can always check for updates manually from the application menu.</source>
        <translation>ניתן תמיד לבדוק אם קיימים עדכונים באופן ידני מתפריט היישום.</translation>
    </message>
    <message>
        <source>Toggle window</source>
        <translation>החלפת־מצב חלון</translation>
    </message>
    <message>
        <source>Quit KeePassXC</source>
        <translation>יצאה מ־KeePassXC</translation>
    </message>
    <message numerus="yes">
        <source>%1 Entry(s)</source>
        <translation><numerusform>רשומה %1</numerusform><numerusform>%1 רשומות</numerusform><numerusform>%1 רשומות</numerusform></translation>
    </message>
    <message>
        <source>Please present or touch your YubiKey to continue…</source>
        <translation>נא להציג או לגעת ב־YubiKey על מנת להמשך...</translation>
    </message>
    <message>
        <source>Restart Application?</source>
        <translation>האם לאתחל את היישום?</translation>
    </message>
    <message>
        <source>You must restart the application to apply this setting. Would you like to restart now?</source>
        <translation>נא לאתחל את היישום להחלת הגדרה זו. האם לאתחל כעת?</translation>
    </message>
    <message>
        <source>Allow Screen Capture</source>
        <translation>אפשור לכידת מסך</translation>
    </message>
    <message>
        <source>1Password 1PUX...</source>
        <translation>1Password 1PUX...</translation>
    </message>
    <message>
        <source>Import a 1Password 1PUX file</source>
        <translation>ייבוא קובץ 1Password 1PUX</translation>
    </message>
    <message>
        <source>Import…</source>
        <translation>ייבוא...</translation>
    </message>
    <message>
        <source>Passkeys…</source>
        <translation>Passkeys…</translation>
    </message>
    <message>
        <source>Import Passkey</source>
        <translation>ייבוא Passkey</translation>
    </message>
    <message>
        <source>Remote S&amp;ync…</source>
        <translation>ס&amp;נכרון מרוחק...</translation>
    </message>
    <message>
        <source>Quit Application</source>
        <translation>לצאת מהיישומון</translation>
    </message>
    <message>
        <source>Open About Dialog</source>
        <translation>פתיחת דו־שיח על אודות</translation>
    </message>
    <message>
        <source>Open Database</source>
        <translation>פתיחת מסד נתונים</translation>
    </message>
    <message>
        <source>Create Database</source>
        <translation>יצירת מסד נתונים</translation>
    </message>
    <message>
        <source>Merge From Database</source>
        <translation>למזג ממסד נתונים</translation>
    </message>
    <message>
        <source>Edit Entry</source>
        <translation>עריכת רשומה</translation>
    </message>
    <message>
        <source>Delete Entry</source>
        <translation>מחיקת רשומה</translation>
    </message>
    <message>
        <source>Create Group</source>
        <translation>יצירת קבוצה</translation>
    </message>
    <message>
        <source>Edit Group</source>
        <translation>עריכת קבוצה</translation>
    </message>
    <message>
        <source>Delete Group</source>
        <translation>מחיקת קבוצה</translation>
    </message>
    <message>
        <source>Download All Favicons</source>
        <translation>הורדת כל הפביקון</translation>
    </message>
    <message>
        <source>Sort Groups A-Z</source>
        <translation>סינון קבוצות א–ת</translation>
    </message>
    <message>
        <source>Sort Groups Z-A</source>
        <translation>סינון קבוצות ת–א</translation>
    </message>
    <message>
        <source>Save Database As</source>
        <translation>שמירת מסד נתונים בשם</translation>
    </message>
    <message>
        <source>Show Database Security</source>
        <translation>הצגת אבטחת מסד נתונים</translation>
    </message>
    <message>
        <source>Show Database Reports</source>
        <translation>הצגת דוחות מסד נתונים</translation>
    </message>
    <message>
        <source>Show Database Settings</source>
        <translation>הצגת הגדרות מסד נתונים</translation>
    </message>
    <message>
        <source>Show Passkeys</source>
        <translation>הצגת Passkeys</translation>
    </message>
    <message>
        <source>Clone Entry</source>
        <translation>שכפול רשומה</translation>
    </message>
    <message>
        <source>Move Entry Up</source>
        <translation>העברת רשומה מעלה</translation>
    </message>
    <message>
        <source>Move Entry Down</source>
        <translation>העברת רשומה מטה</translation>
    </message>
    <message>
        <source>Copy Username</source>
        <translation>העתקת שם משתמש</translation>
    </message>
    <message>
        <source>Copy Password</source>
        <translation>העתקת ססמה</translation>
    </message>
    <message>
        <source>Show Application Settings</source>
        <translation>הצגת הגדרות יישום</translation>
    </message>
    <message>
        <source>Show Password Generator</source>
        <translation>הצגת מחולל ססמאות</translation>
    </message>
    <message>
        <source>Remove Passkey From Entry</source>
        <translation>הסרת Passkey מרשומה</translation>
    </message>
    <message>
        <source>Perform Auto-Type: {USERNAME}</source>
        <translation>ביצוע הקלדה אוטומטית: {USERNAME}</translation>
    </message>
    <message>
        <source>Perform Auto-Type: {USERNAME}{ENTER}</source>
        <translation>ביצוע הקלדה אוטומטית: {USERNAME}{ENTER}</translation>
    </message>
    <message>
        <source>Perform Auto-Type: {PASSWORD}</source>
        <translation>ביצוע הקלדה אוטומטית: {PASSWORD}</translation>
    </message>
    <message>
        <source>Perform Auto-Type: {PASSWORD}{ENTER}</source>
        <translation>ביצוע הקלדה אוטומטית: {PASSWORD}{ENTER}</translation>
    </message>
    <message>
        <source>Perform Auto-Type: {TOTP}</source>
        <translation>ביצוע הקלדה אוטומטית: {TOTP}</translation>
    </message>
    <message>
        <source>Copy Title</source>
        <translation>להעתיק תואר</translation>
    </message>
    <message>
        <source>Copy URL</source>
        <translation>להעתיק מען URL</translation>
    </message>
    <message>
        <source>Copy Notes</source>
        <translation>להעתיק הערות</translation>
    </message>
    <message>
        <source>Export to CSV</source>
        <translation>ייצוא ל־CSV</translation>
    </message>
    <message>
        <source>Export to HTML</source>
        <translation>ייצוא ל־HTML</translation>
    </message>
    <message>
        <source>Import KeePass1 Database</source>
        <translation>ייבוא מסד־נתונים KeePass1</translation>
    </message>
    <message>
        <source>Import 1Password Vault</source>
        <translation>ייבוא כספת 1Password</translation>
    </message>
    <message>
        <source>Import CSV File</source>
        <translation>ייבוא קובץ CSV</translation>
    </message>
    <message>
        <source>Show TOTP QR Code</source>
        <translation>הצגת קוד QR TOTP</translation>
    </message>
    <message>
        <source>Set up TOTP</source>
        <translation>הגדרת TOTP</translation>
    </message>
    <message>
        <source>Empty Recycle Bin</source>
        <translation>לרוקן סל מחזור</translation>
    </message>
    <message>
        <source>Open Donation Website</source>
        <translation>לפתוח אתר מרשתת תרומה</translation>
    </message>
    <message>
        <source>Open Bug Report</source>
        <translation>לפתוח דוח תקלים</translation>
    </message>
    <message>
        <source>Open Online Documentation</source>
        <translation>לפתוח תיעוד מקוון</translation>
    </message>
    <message>
        <source>Open Keyboard Shortcuts Guide</source>
        <translation>לפתוח מדריך קיצורי־דרך מקלדת</translation>
    </message>
    <message>
        <source>Save Database Backup</source>
        <translation>לשמור גיבוי מסד נתונים</translation>
    </message>
    <message>
        <source>SSH Agent: Add Key</source>
        <translation>סוכן SSH: הוספת מפתח</translation>
    </message>
    <message>
        <source>SSH Agent: Remove Key</source>
        <translation>סוכן SSH: הסרת מפתח</translation>
    </message>
    <message>
        <source>Toggle Compact Mode</source>
        <translation>מיתוג מצב צמום</translation>
    </message>
    <message>
        <source>Set Theme: Automatic</source>
        <translation>קביעת ערכת נושא באופן אוטומטי</translation>
    </message>
    <message>
        <source>Set Theme: Light</source>
        <translation>קביעת ערכת נושא: בהירה</translation>
    </message>
    <message>
        <source>Set Theme: Dark</source>
        <translation>קביעת ערכת נושא: כהה</translation>
    </message>
    <message>
        <source>Set Theme: Classic</source>
        <translation>קביעת ערכת נושא: קלאסי</translation>
    </message>
    <message>
        <source>Toggle Show Menubar</source>
        <translation>מיתוג הצגת סרגל תפריט</translation>
    </message>
    <message>
        <source>Toggle Show Toolbar</source>
        <translation>מיתוג הצגת סרגל כלים</translation>
    </message>
    <message>
        <source>Toggle Show Preview Panel</source>
        <translation>מיתוג הצגת לוח תצוגה מקדימה</translation>
    </message>
    <message>
        <source>Toggle Always on Top</source>
        <translation>מיתוג תמיד עליון</translation>
    </message>
    <message>
        <source>Toggle Hide Usernames</source>
        <translation>מיתוג הסתרת שם משתמש</translation>
    </message>
    <message>
        <source>Toggle Hide Passwords</source>
        <translation>מיתוג הסתרת ססמאות</translation>
    </message>
    <message>
        <source>Export to XML</source>
        <translation>ייצוא ל־XML</translation>
    </message>
    <message>
        <source>Toggle Allow Screen Capture</source>
        <translation>מיתוג אפשור לכידת מרקע</translation>
    </message>
    <message>
        <source>Show Group Panel</source>
        <translation>הצגת לוח קבוצה</translation>
    </message>
    <message>
        <source>Toggle Show Group Panel</source>
        <translation>מיתוג הצגת לוח קבוצה</translation>
    </message>
    <message>
        <source>Setup Remote Sync…</source>
        <translation>הגדרת סנכרון מרוחק...</translation>
    </message>
    <message>
        <source>WARNING: You are using a development snapshot build of KeePassXC.
Maintain a backup of your databases in the event of unknown bugs.
This version is not meant for production use.</source>
        <translation>אזהרה: זוהי תמונת גרסת פיתוח של KeePassXC.
נא לשמור גיבוי של מסדי הנתונים למקרה של תקלים לא ידועים.
גרסה זו אינה מיועדת לשימוש בסביבת ייצור.</translation>
    </message>
    <message>
        <source>Clear SSH Agent</source>
        <translation>ניקוי סוכן SSH</translation>
    </message>
    <message>
        <source>Clear all identities in ssh-agent</source>
        <translation>ניקוי כל הזהויות בסוכן SSH</translation>
    </message>
    <message>
        <source>New Entry</source>
        <translation>רשומה חדשה</translation>
    </message>
    <message>
        <source>Password Generator</source>
        <translation>מחולל סיסמאות</translation>
    </message>
    <message>
        <source>Edit Entry…</source>
        <translation>עריכת רשומה...</translation>
    </message>
    <message>
        <source>E&amp;xpire Entry</source>
        <translation>ת&amp;פוגת רשומה…</translation>
    </message>
    <message>
        <source>Expire Entry</source>
        <translation>תפוגת רשומה</translation>
    </message>
    <message>
        <source>&amp;Delete Entry</source>
        <translation>&amp;מחיקת רשומה</translation>
    </message>
    <message numerus="yes">
        <source>Move selected entry(s) to the recycle bin</source>
        <translation><numerusform>להעביר רשומה שנבחרה לסל מחזור</numerusform><numerusform>להעביר רשומות שנבחרו לסל מחזור</numerusform><numerusform>להעביר רשומות שנבחרו לסל מחזור</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>Permanently delete the selected entry(s)</source>
        <translation><numerusform>למחוק לצמיתות רשומה שנבחרה</numerusform><numerusform>למחוק לצמיתות רשומות שנבחרו</numerusform><numerusform>למחוק לצמיתות רשומות שנבחרו</numerusform></translation>
    </message>
</context>
<context>
    <name>ManageDatabase</name>
    <message>
        <source>Database settings</source>
        <translation>הגדרות מסד־נתונים</translation>
    </message>
    <message>
        <source>Edit database settings</source>
        <translation>עריכת הגדרות מסד־נתונים</translation>
    </message>
    <message>
        <source>Unlock database</source>
        <translation>שחרור נעילה של מסד־נתונים</translation>
    </message>
    <message>
        <source>Unlock database to show more information</source>
        <translation>שחרור נעילת מסד־נתונים להצגת מידע נוסף</translation>
    </message>
    <message>
        <source>Lock database</source>
        <translation>נעילת מסד־נתונים</translation>
    </message>
</context>
<context>
    <name>ManageSession</name>
    <message>
        <source>Disconnect</source>
        <translation>התנתקות</translation>
    </message>
    <message>
        <source>Disconnect this application</source>
        <translation>ניתוק יישום זה</translation>
    </message>
    <message>
        <source>Reset</source>
        <translation>איפוס</translation>
    </message>
    <message>
        <source>Reset any remembered decisions for this application</source>
        <translation>איפוס כלל ההגדרות המומלצות ביישומון זה</translation>
    </message>
</context>
<context>
    <name>MergeDialog</name>
    <message>
        <source>Database Merge Confirmation</source>
        <translation>אישור מיזוג מסד־נתונים</translation>
    </message>
    <message>
        <source>Merge</source>
        <translation>מיזוג</translation>
    </message>
    <message>
        <source>Group</source>
        <translation>קבוצה</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>כותרת</translation>
    </message>
    <message>
        <source>UUID</source>
        <translation>UUID</translation>
    </message>
    <message>
        <source>Details</source>
        <translation>פרטים</translation>
    </message>
    <message>
        <source>Change</source>
        <translation>שינוי</translation>
    </message>
</context>
<context>
    <name>Merger</name>
    <message>
        <source>Changed deleted objects</source>
        <translation>אובייקטים שנמחקו ששונו</translation>
    </message>
    <message>
        <source>Removed custom data %1 [%2]</source>
        <translation>הוסרו נתונים מותאמים אישית %1 [%2]</translation>
    </message>
    <message>
        <source>Adding custom data %1 [%2]</source>
        <translation>הוספת נתונים מותאמים אישית %1 [%2]</translation>
    </message>
    <message>
        <source>Added</source>
        <translation>נוספה</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>הוסגל</translation>
    </message>
    <message>
        <source>Moved</source>
        <translation>הועברה</translation>
    </message>
    <message>
        <source>Deleted</source>
        <translation>נמחקה</translation>
    </message>
    <message>
        <source>Previous location: %1</source>
        <translation>מיקום קודם:  %1</translation>
    </message>
    <message>
        <source>Number of entries in group: %1</source>
        <translation>מספר רשומות בקבוצה: %1</translation>
    </message>
    <message>
        <source>Group name</source>
        <translation>שם קבוצה</translation>
    </message>
    <message>
        <source>Notes</source>
        <translation>הערות</translation>
    </message>
    <message>
        <source>Icon (UUID)</source>
        <translation>סמל UUID</translation>
    </message>
    <message>
        <source>Icon (Number)</source>
        <translation>סמל (מספר)</translation>
    </message>
    <message>
        <source>Expiry time</source>
        <translation>זמן תפוגה</translation>
    </message>
    <message>
        <source>Modification time</source>
        <translation>מועד הסגלה</translation>
    </message>
    <message>
        <source>%1 (Add local modifications to new entry)</source>
        <translation>%1 (הוספת הסגלה מקומית לרשומה חדשה)</translation>
    </message>
    <message>
        <source>%1 (Add new modifications to existing entry)</source>
        <translation>%1 (הוספת הסגלה חדשה לרשומה קיימת)</translation>
    </message>
    <message>
        <source>Explicit deletion</source>
        <translation>מחיקה מוחלטת</translation>
    </message>
    <message>
        <source>Implicit deletion (e.g. removal of parent group)</source>
        <translation>מחיקה משתמעת (לדוגמה: הסרת קבוצת־הורה)</translation>
    </message>
    <message>
        <source>Adding new icon %1</source>
        <translation>הוספת סמל חדש: %1</translation>
    </message>
</context>
<context>
    <name>NewDatabaseWizard</name>
    <message>
        <source>Create a new KeePassXC database…</source>
        <translation>יצירת מסד נתוני KeePassXC חדש...</translation>
    </message>
    <message>
        <source>Root</source>
        <comment>Root group</comment>
        <translation>שורש</translation>
    </message>
</context>
<context>
    <name>NewDatabaseWizardPage</name>
    <message>
        <source>WizardPage</source>
        <translation>עמוד אשף</translation>
    </message>
    <message>
        <source>Encryption Settings</source>
        <translation>הצנת ההגדרות</translation>
    </message>
    <message>
        <source>Here you can adjust the database encryption settings. Don&apos;t worry, you can change them later in the database settings.</source>
        <translation>כאן ניתן להתאים את הגדרות הצפנת מסד הנתונים. אל דאגה, אפשר יהיה לשנות אותם מאוחר יותר בהגדרות מסד הנתונים.</translation>
    </message>
</context>
<context>
    <name>NewDatabaseWizardPageDatabaseKey</name>
    <message>
        <source>Database Credentials</source>
        <translation>אישורי מסד־נתונים</translation>
    </message>
    <message>
        <source>A set of credentials known only to you that protects your database.</source>
        <translation>ערכת אישורים הידועה רק לך המגנה על מסד הנתונים.</translation>
    </message>
</context>
<context>
    <name>NewDatabaseWizardPageEncryption</name>
    <message>
        <source>Encryption Settings</source>
        <translation>הצנת ההגדרות</translation>
    </message>
    <message>
        <source>Here you can adjust the database encryption settings. Don&apos;t worry, you can change them later in the database settings.</source>
        <translation>כאן ניתן להתאים את הגדרות הצפנת מסד הנתונים. אל דאגה, אפשר יהיה לשנות אותם מאוחר יותר בהגדרות מסד הנתונים.</translation>
    </message>
</context>
<context>
    <name>NewDatabaseWizardPageMetaData</name>
    <message>
        <source>General Database Information</source>
        <translation>מידע כללי אודות מסד הנתונים</translation>
    </message>
    <message>
        <source>Please fill in the display name and an optional description for your new database:</source>
        <translation>נא להזין את שם המצג ותיאור חלופי למסד הנתונים החדש:</translation>
    </message>
</context>
<context>
    <name>NixUtils</name>
    <message>
        <source>Password Manager</source>
        <translation>מנהל ססמאות</translation>
    </message>
    <message>
        <source>Global shortcut already registered to %1</source>
        <translation>קיצור דרך כללי כבר רשום ב־%1</translation>
    </message>
    <message>
        <source>Could not register global shortcut</source>
        <translation>לא ניתן לרשום קיצור דרך כללי</translation>
    </message>
</context>
<context>
    <name>OpData01</name>
    <message>
        <source>Invalid OpData01, does not contain header</source>
        <translation>OpData01 לא תקין, לא מכיל כותרת עליונה</translation>
    </message>
    <message>
        <source>Unable to read all IV bytes, wanted 16 but got %1</source>
        <translation>לא ניתן לקרוא את כל הביטים של IV, נדרשו 16 אך נתקבלו %1</translation>
    </message>
    <message>
        <source>Unable to init cipher for opdata01: %1</source>
        <translation>לא ניתן ליצור צופן איתחול עבור opdata01: %1</translation>
    </message>
    <message>
        <source>Unable to read all HMAC signature bytes</source>
        <translation>לא ניתן לקרוא את כל הבייטים של החתימת HMAC</translation>
    </message>
    <message>
        <source>Malformed OpData01 due to a failed HMAC</source>
        <translation>OpData01 פגום עקב HMAC שכשל</translation>
    </message>
    <message>
        <source>Unable to process clearText in place</source>
        <translation>לא ניתן לעבד clearText במקום</translation>
    </message>
    <message>
        <source>Expected %1 bytes of clear-text, found %2</source>
        <translation>ציפיה ל־%1 בתים של מלל רגיל, נמצאו %2</translation>
    </message>
</context>
<context>
    <name>OpVaultReader</name>
    <message>
        <source>Directory .opvault must exist</source>
        <translation>מחיצה .opvault חייבת להתקיים</translation>
    </message>
    <message>
        <source>Directory .opvault must be readable</source>
        <translation>מחיצה opvault. חייבת להיות ברת קריאה</translation>
    </message>
    <message>
        <source>Directory .opvault/default must exist</source>
        <translation>מחיצה .opvault/default חייבת להתקיים</translation>
    </message>
    <message>
        <source>Directory .opvault/default must be readable</source>
        <translation>מחיצה .opvault/default חייבת להיות ברת קריאה</translation>
    </message>
    <message>
        <source>Unable to decode masterKey: %1</source>
        <translation>לא ניתן לפענח מפתח ראשי: %1</translation>
    </message>
    <message>
        <source>Unable to derive master key: %1</source>
        <translation>לא ניתן להפיק מפתח ראשי: %1</translation>
    </message>
</context>
<context>
    <name>OpenSSHKey</name>
    <message>
        <source>Invalid key file, expecting an OpenSSH key</source>
        <translation>קובץ מפתח לא תקין, צפייה למפתח OpenSSH</translation>
    </message>
    <message>
        <source>PEM boundary mismatch</source>
        <translation>אי־התאמת גבולות PEM</translation>
    </message>
    <message>
        <source>Base64 decoding failed</source>
        <translation>פענוח Base64 כשל</translation>
    </message>
    <message>
        <source>Key file way too small.</source>
        <translation>קובץ המפתח קטן מדי.</translation>
    </message>
    <message>
        <source>Key file magic header id invalid</source>
        <translation>מזהה כותרת־קסם קובץ־מפתח לא תקין</translation>
    </message>
    <message>
        <source>Found zero keys</source>
        <translation>נמצאו מפתחות אפס</translation>
    </message>
    <message>
        <source>Corrupted key file, reading private key failed</source>
        <translation>קובץ מפתח פגום, קריאת מפתח פרטי כשלה</translation>
    </message>
    <message>
        <source>Unsupported key type: %1</source>
        <translation>סוג מפתח לא נתמך: %1</translation>
    </message>
    <message>
        <source>No private key payload to decrypt</source>
        <translation>אין תכולת מפתח פרטי לפענוח</translation>
    </message>
    <message>
        <source>Unknown cipher: %1</source>
        <translation>צופן לא ידוע: %1</translation>
    </message>
    <message>
        <source>AES-256/GCM is currently not supported</source>
        <translation>AES-256/GCM לא נתמך לעת עתה</translation>
    </message>
    <message>
        <source>Passphrase is required to decrypt this key</source>
        <translation>נדרש ביטוי ססמה כדי לפענח מפתח זה</translation>
    </message>
    <message>
        <source>Key derivation failed: %1</source>
        <translation>נגזרת מפתח כשלה: %1</translation>
    </message>
    <message>
        <source>Cipher IV is too short for MD5 kdf</source>
        <translation>צופן IV קצר מדי עבור MD5 kdf</translation>
    </message>
    <message>
        <source>Unknown KDF: %1</source>
        <translation>KDF לא ידוע: %1</translation>
    </message>
    <message>
        <source>Failed to initialize cipher: %1</source>
        <translation>איתחול צופן כשל: %1</translation>
    </message>
    <message>
        <source>Decryption failed: %1</source>
        <translation>פענוח כשל: %1</translation>
    </message>
    <message>
        <source>Decryption failed, wrong passphrase?</source>
        <translation>פענוח כשל, האם ביטוי ססמה שגוי?</translation>
    </message>
    <message>
        <source>Unexpected EOF while reading key</source>
        <translation>EOF לא צפוי בעת קריאת מפתח</translation>
    </message>
    <message>
        <source>Unsupported key part</source>
        <translation>רכיב מפתח לא נתמך</translation>
    </message>
    <message>
        <source>Unexpected EOF while reading public key</source>
        <translation>EOF לא צפוי בעת קריאת מפתח ציבורי</translation>
    </message>
    <message>
        <source>Unknown key type: %1</source>
        <translation>סוג מפתח לא ידוע: %1</translation>
    </message>
    <message>
        <source>Unexpected EOF while reading private key</source>
        <translation>EOF לא צפוי בעת קריאת מפתח פרטי</translation>
    </message>
    <message>
        <source>Can&apos;t write public key as it is empty</source>
        <translation>לא ניתן לכתוב מפתח פרטי מכיוון שהוא ריק</translation>
    </message>
    <message>
        <source>Unexpected EOF when writing public key</source>
        <translation>EOF לא צפוי בעת כתיבת מפתח ציבורי</translation>
    </message>
    <message>
        <source>Can&apos;t write private key as it is empty</source>
        <translation>לא ניתן לכתוב מפתח פרטי מכיוון שהוא ריק</translation>
    </message>
    <message>
        <source>Unexpected EOF when writing private key</source>
        <translation>EOF לא צפוי בעת כתיבת מפתח פרטי</translation>
    </message>
    <message>
        <source>(encrypted)</source>
        <translation>(מוצפן)</translation>
    </message>
    <message>
        <source>Failed to read key file: %1</source>
        <translation>כשל בקריאת קובץ מפתח: %1</translation>
    </message>
    <message>
        <source>Failed to read public key: %1</source>
        <translation>כשל בקריאת מפתח ציבורי: %1</translation>
    </message>
</context>
<context>
    <name>OpenSSHKeyGenDialog</name>
    <message>
        <source>SSH Key Generator</source>
        <translation>מחולל מפתח SSH</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>סוג</translation>
    </message>
    <message>
        <source>Bits</source>
        <translation>סיביות</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>הערה</translation>
    </message>
</context>
<context>
    <name>PasskeyExportDialog</name>
    <message>
        <source>KeePassXC - Passkey Export</source>
        <translation>ייצוא KeePassXC – Passkey</translation>
    </message>
    <message>
        <source>Filenames will be generated with title and .passkey file extension.</source>
        <translation>שמות קבצים יחוללו עם כותרת וסיומת קובץ Passkey.</translation>
    </message>
    <message>
        <source>Export entries</source>
        <translation>ייצוא רשומות</translation>
    </message>
    <message>
        <source>Export Selected</source>
        <translation>ייצוא בחירה</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>ביטול</translation>
    </message>
    <message>
        <source>Export to folder</source>
        <translation>ייצוא לתיקייה</translation>
    </message>
    <message>
        <source>Export the following passkey entries.</source>
        <translation>ייצוא רשומות ה־Passkey הבאות.</translation>
    </message>
</context>
<context>
    <name>PasskeyExporter</name>
    <message>
        <source>File &quot;%1.passkey&quot; already exists.
Do you want to overwrite it?
</source>
        <translation>קובץ &quot;%1.passkey&quot; כבר קיים
האם לכתוב עליו?</translation>
    </message>
    <message>
        <source>Cannot open file</source>
        <translation>לא ניתן לפתוח קובץ</translation>
    </message>
    <message>
        <source>Cannot open file &quot;%1&quot; for writing.</source>
        <translation>לא ניתן לפתוח קובץ &quot;%1&quot; לכתיבה.</translation>
    </message>
    <message>
        <source>Cannot write to file</source>
        <translation>לא ניתן לכתוב לקובץ</translation>
    </message>
    <message>
        <source>Overwrite Existing File?</source>
        <translation>לכתוב על קובץ קיים?</translation>
    </message>
</context>
<context>
    <name>PasskeyImportDialog</name>
    <message>
        <source>KeePassXC - Passkey Import</source>
        <translation>ייבוא KeePassXC – Passkey</translation>
    </message>
    <message>
        <source>Username: %1</source>
        <translation>שם משתמש: %1</translation>
    </message>
    <message>
        <source>Group</source>
        <translation>קבוצה</translation>
    </message>
    <message>
        <source>Database</source>
        <translation>Database</translation>
    </message>
    <message>
        <source>Import Passkey</source>
        <translation>ייבוא Passkey</translation>
    </message>
    <message>
        <source>Import</source>
        <translation>ייבוא</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>ביטול</translation>
    </message>
    <message>
        <source>Entry</source>
        <translation>רשומה</translation>
    </message>
    <message>
        <source>Create new entry</source>
        <translation>יצירת רשומה חדשה</translation>
    </message>
    <message>
        <source>Relying Party: %1</source>
        <translation>צד סומך: %1</translation>
    </message>
    <message>
        <source>Import the following passkey:</source>
        <translation>ייבוא ה־ הבא:Passkey</translation>
    </message>
    <message>
        <source>Import the following passkey to this entry:</source>
        <translation>לייבא את ה־Passkey הבא לרשומה זו:</translation>
    </message>
    <message>
        <source>Default passkeys group (Imported Passkeys)</source>
        <translation>קבוצה passkeys בררת מחדל (passkeys שיובאו)</translation>
    </message>
</context>
<context>
    <name>PasskeyImporter</name>
    <message>
        <source>Passkey file</source>
        <translation>קובץ Passkey</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>כל הקבצים</translation>
    </message>
    <message>
        <source>Cannot open file</source>
        <translation>לא ניתן לפתוח קובץ</translation>
    </message>
    <message>
        <source>Cannot open file &quot;%1&quot; for reading.</source>
        <translation>לא ניתן לפתוח קובץ &quot;%1&quot; לקריאה.</translation>
    </message>
    <message>
        <source>Cannot import passkey file &quot;%1&quot;. Data is missing.</source>
        <translation>לא ניתן לייבוא קובץ Passkey &quot;%1&quot;. חסרים נתונים.</translation>
    </message>
    <message>
        <source>Cannot import passkey file &quot;%1&quot;.
The following data is missing:
%2</source>
        <translation>לא ניתן לייבא קובץ Passkey &quot;%1&quot;.
הנתון הבא חסר:
%2</translation>
    </message>
    <message>
        <source>Cannot import passkey file &quot;%1&quot;. Private key is missing or malformed.</source>
        <translation>לא ניתן לייבא קובץ Passkey &quot;%1&quot;. מפתח פרטי חסר או לוקה בתצורה.</translation>
    </message>
    <message>
        <source>Open Passkey File</source>
        <translation>לפתוח קובץ Passkey</translation>
    </message>
    <message>
        <source>Passkey Import Failed</source>
        <translation>ייבוא Passkey כשל</translation>
    </message>
</context>
<context>
    <name>PasswordEditWidget</name>
    <message>
        <source>Enter password:</source>
        <translation>הזנת ססמה:</translation>
    </message>
    <message>
        <source>Password field</source>
        <translation>שדה ססמה</translation>
    </message>
    <message>
        <source>Confirm password:</source>
        <translation>אישור ססמה:</translation>
    </message>
    <message>
        <source>Repeat password field</source>
        <translation>חזרה על שדה ססמה</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>ססמה</translation>
    </message>
    <message>
        <source>Add Password</source>
        <translation>הוספת ססמה</translation>
    </message>
    <message>
        <source>Change Password</source>
        <translation>שנוי ססמה</translation>
    </message>
    <message>
        <source>Remove Password</source>
        <translation>הסרת ססמה</translation>
    </message>
    <message>
        <source>Password set, click to change or remove</source>
        <translation>ערכת ססמאות, הקשה לשנוי או להסרה</translation>
    </message>
    <message>
        <source>&lt;p&gt;A password is the primary method for securing your database.&lt;/p&gt;&lt;p&gt;Good passwords are long and unique. KeePassXC can generate one for you.&lt;/p&gt;</source>
        <translation>&lt;p&gt;ססמה היא השיטה העיקרית לאבטחת מסד־נתונים.&lt;/p&gt;&lt;p&gt;ססמאות טובות צריכות שיהיו ארוכות וייחודיות. KeePassXC יכול לחולל אחד כזה בכל עת.&lt;/p&gt;</translation>
    </message>
    <message>
        <source>Passwords do not match.</source>
        <translation>ססמאות לא תואמות.</translation>
    </message>
</context>
<context>
    <name>PasswordGeneratorWidget</name>
    <message>
        <source>Generate Password</source>
        <translation>חילול ססמה</translation>
    </message>
    <message>
        <source>strength</source>
        <comment>Password strength</comment>
        <translation>חוזק</translation>
    </message>
    <message>
        <source>entropy</source>
        <translation>אנטרופיה</translation>
    </message>
    <message>
        <source>Generated password</source>
        <translation>ססמה שחוללה</translation>
    </message>
    <message>
        <source>%p%</source>
        <translation>%p%</translation>
    </message>
    <message>
        <source>Regenerate password</source>
        <translation>חילול ססמה מחדש</translation>
    </message>
    <message>
        <source>Copy password</source>
        <translation>העתקת ססמה</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>ססמה</translation>
    </message>
    <message>
        <source>&amp;Length:</source>
        <translation>&amp;אורך:</translation>
    </message>
    <message>
        <source>Password length</source>
        <translation>אורך ססמה</translation>
    </message>
    <message>
        <source>Switch to advanced mode</source>
        <translation>החלפה למצב מתקדם</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>מתקדם</translation>
    </message>
    <message>
        <source>Character Types</source>
        <translation>סוגי תווים</translation>
    </message>
    <message>
        <source>Special characters</source>
        <translation>תווים מיוחדים</translation>
    </message>
    <message>
        <source>Quotes</source>
        <translation>מרכאות</translation>
    </message>
    <message>
        <source>Punctuation</source>
        <translation>פיסוק</translation>
    </message>
    <message>
        <source>Dashes and Slashes</source>
        <translation>מקפים ולוכסנים</translation>
    </message>
    <message>
        <source>Upper-case letters</source>
        <translation>אותיות רישיות</translation>
    </message>
    <message>
        <source>Numbers</source>
        <translation>מספרים</translation>
    </message>
    <message>
        <source>Lower-case letters</source>
        <translation>אותיות קטנות</translation>
    </message>
    <message>
        <source>Math Symbols</source>
        <translation>סימנים מתמטיים</translation>
    </message>
    <message>
        <source>Extended ASCII</source>
        <translation>ASCII מורחב</translation>
    </message>
    <message>
        <source>Braces</source>
        <translation>סוגרים</translation>
    </message>
    <message>
        <source>Do not include:</source>
        <translation>לא לכלול:</translation>
    </message>
    <message>
        <source>Additional characters to use for the generated password</source>
        <translation>שימוש בערכת תווים נוספת בססמה שחוללה</translation>
    </message>
    <message>
        <source>Additional characters</source>
        <translation>תווים נוספים</translation>
    </message>
    <message>
        <source>Add non-hex letters to &quot;do not include&quot; list</source>
        <translation>הוספת אותיות non-hex לרשימת ה&quot;החרגה&quot;</translation>
    </message>
    <message>
        <source>Hex Passwords</source>
        <translation>ססמאות Hex</translation>
    </message>
    <message>
        <source>Hex</source>
        <translation>הקס</translation>
    </message>
    <message>
        <source>Character set to exclude from generated password</source>
        <translation>ערכת תווים להחרגה מססמה שחוללה</translation>
    </message>
    <message>
        <source>Excluded characters</source>
        <translation>החרגת תווים</translation>
    </message>
    <message>
        <source>Also choose from:</source>
        <translation>נא לבחור גם מבין:</translation>
    </message>
    <message>
        <source>Exclude look-alike characters</source>
        <translation>החרגת תווים דומים</translation>
    </message>
    <message>
        <source>Pick characters from every group</source>
        <translation>בחירת תווים מכל קבוצה</translation>
    </message>
    <message>
        <source>Passphrase</source>
        <translation>ביטוי ססמה</translation>
    </message>
    <message>
        <source>Word Separator:</source>
        <translation>מפריד מילים:</translation>
    </message>
    <message>
        <source>Wordlist:</source>
        <translation>רשימת מילים:</translation>
    </message>
    <message>
        <source>Word Count:</source>
        <translation>ספירת מילים:</translation>
    </message>
    <message>
        <source>Word Case:</source>
        <translation>גודל אות:</translation>
    </message>
    <message>
        <source>Delete selected wordlist</source>
        <translation>מחיקת רשימת־מילים שנבחרה</translation>
    </message>
    <message>
        <source>Add custom wordlist</source>
        <translation>הוספת רשימת־מילים מותאמת אישית</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>סגירה</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
    <message>
        <source>Apply Password</source>
        <translation>החלת ססמה</translation>
    </message>
    <message>
        <source>Regenerate password (%1)</source>
        <translation>חילול ססמה (%1) מחדש</translation>
    </message>
    <message>
        <source>lower case</source>
        <translation>אותיות קטנות</translation>
    </message>
    <message>
        <source>UPPER CASE</source>
        <translation>אותיות רישיות</translation>
    </message>
    <message>
        <source>Title Case</source>
        <translation>אותיות כותרת</translation>
    </message>
    <message>
        <source>(SYSTEM)</source>
        <translation>(מערכת)</translation>
    </message>
    <message>
        <source>Entropy: %1 bit</source>
        <translation>אנטרופיה: %1 סיביות</translation>
    </message>
    <message>
        <source>Password Quality: %1</source>
        <translation>איכות ססמה: %1</translation>
    </message>
    <message>
        <source>Poor</source>
        <comment>Password quality</comment>
        <translation>עלוב</translation>
    </message>
    <message>
        <source>Weak</source>
        <comment>Password quality</comment>
        <translation>חלש</translation>
    </message>
    <message>
        <source>Good</source>
        <comment>Password quality</comment>
        <translation>טוב</translation>
    </message>
    <message>
        <source>Excellent</source>
        <comment>Password quality</comment>
        <translation>מצוין</translation>
    </message>
    <message>
        <source>Failed to delete wordlist</source>
        <translation>מחיקת רשימת־מילים כשלה</translation>
    </message>
    <message>
        <source>Wordlists</source>
        <translation>רשימת מילים</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>כל הקבצים</translation>
    </message>
    <message>
        <source>Select Custom Wordlist</source>
        <translation>בחירת רשימת מילים מותאמת אישית</translation>
    </message>
    <message>
        <source>Overwrite Wordlist?</source>
        <translation>כתיבה־על רשימת מילים?</translation>
    </message>
    <message>
        <source>Wordlist &quot;%1&quot; already exists as a custom wordlist.
Do you want to overwrite it?</source>
        <translation>קימת כבר רשימת מילים &quot;%1&quot; כרשימת מילים מותאמת אישית.
האם לכתוב־על רשימת המילים?</translation>
    </message>
    <message>
        <source>Failed to add wordlist</source>
        <translation>הוספת רשימת־מילים כשלה</translation>
    </message>
    <message>
        <source>Logograms</source>
        <translation>לוגוגרמות</translation>
    </message>
    <message>
        <source>Special Characters</source>
        <translation>תווים מיוחדים</translation>
    </message>
    <message>
        <source>passwordLength</source>
        <translation>אורך ססמה</translation>
    </message>
    <message>
        <source>Characters: %1</source>
        <translation>תווים: %1</translation>
    </message>
    <message>
        <source>MIXED case</source>
        <translation>אותיות רישיות וקטנות מעורבות</translation>
    </message>
    <message>
        <source>Excluded characters: &quot;0&quot;, &quot;1&quot;, &quot;l&quot;, &quot;I&quot;, &quot;O&quot;, &quot;|&quot;, &quot;﹒&quot;, &quot;B&quot;, &quot;8&quot;, &quot;G&quot;, &quot;6&quot;</source>
        <translation>תווים שהוחרגו: &quot;0&quot;, &quot;1&quot;, &quot;l&quot;, &quot;I&quot;, &quot;O&quot;, &quot;|&quot;, &quot;﹒&quot;, &quot;B&quot;, &quot;8&quot;, &quot;G&quot;, &quot;6&quot;</translation>
    </message>
    <message>
        <source>Warning: the chosen wordlist is smaller than the minimum recommended size!</source>
        <translation>אזהרה: רשימת המילים שנבחרה קטנה מהגודל המומלץ המזערי!</translation>
    </message>
    <message>
        <source>Confirm Remove Wordlist</source>
        <translation>אישור הסרת רשימת מילים</translation>
    </message>
    <message>
        <source>Do you really want to remove the wordlist &quot;%1&quot;?</source>
        <translation>האם להסיר רשימת מילים &quot;%1&quot;?</translation>
    </message>
</context>
<context>
    <name>PasswordWidget</name>
    <message>
        <source>Passwords do not match</source>
        <translation>ססמאות לא תואמות</translation>
    </message>
    <message>
        <source>Passwords match so far</source>
        <translation>ססמאות תואמות עד כה</translation>
    </message>
    <message>
        <source>Toggle Password (%1)</source>
        <translation>החלפת־מצב ססמה (%1)</translation>
    </message>
    <message>
        <source>Generate Password (%1)</source>
        <translation>חילול ססמה (%1)</translation>
    </message>
    <message>
        <source>Warning: Caps Lock enabled!</source>
        <translation>אזהרה: אופשרה נעילת רישיות!</translation>
    </message>
    <message>
        <source>Quality: %1</source>
        <translation>איכות: %1</translation>
    </message>
    <message>
        <source>Poor</source>
        <comment>Password quality</comment>
        <translation>עלוב</translation>
    </message>
    <message>
        <source>Weak</source>
        <comment>Password quality</comment>
        <translation>חלש</translation>
    </message>
    <message>
        <source>Good</source>
        <comment>Password quality</comment>
        <translation>טוב</translation>
    </message>
    <message>
        <source>Excellent</source>
        <comment>Password quality</comment>
        <translation>מצוין</translation>
    </message>
    <message>
        <source>Toggle password visibility using Control + H. Open the password generator using Control + G.</source>
        <translation>מיתוג נראות ססמה תוך שימוש ב&apos;קונטרול + H&apos;. פתיחת מחולל ססמאות תוך שימוש ב&apos;קונטרול + G&apos;.</translation>
    </message>
</context>
<context>
    <name>PickcharsDialog</name>
    <message>
        <source>KeePassXC - Pick Characters</source>
        <translation>KeePassXC - בחירת תווים</translation>
    </message>
    <message>
        <source>Select characters to type, navigate with arrow keys, Ctrl + S submits.</source>
        <translation>בחירת תווים להקלדה, נווט באמצעות מקשי החצים, Ctrl + S לשיגור.</translation>
    </message>
    <message>
        <source>Press &amp;Tab between characters</source>
        <translation>הקשה על &amp;Tab בין תווים</translation>
    </message>
</context>
<context>
    <name>PreviewEntryAttachmentsDialog</name>
    <message>
        <source>Form</source>
        <translation>טופס</translation>
    </message>
    <message>
        <source>Preview: %1</source>
        <translation>תצוגה מקדימה: %1</translation>
    </message>
    <message>
        <source>Save…</source>
        <translation>שמירה...</translation>
    </message>
</context>
<context>
    <name>QMessageBox</name>
    <message>
        <source>Overwrite</source>
        <translation>כתיבה־על</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>מחיקה</translation>
    </message>
    <message>
        <source>Move</source>
        <translation>העברה</translation>
    </message>
    <message>
        <source>Empty</source>
        <translation>ריק</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>הסרה</translation>
    </message>
    <message>
        <source>Skip</source>
        <translation>דלוג</translation>
    </message>
    <message>
        <source>Disable</source>
        <translation>מושבת</translation>
    </message>
    <message>
        <source>Merge</source>
        <translation>מיזוג</translation>
    </message>
    <message>
        <source>Continue</source>
        <translation>המשך</translation>
    </message>
    <message>
        <source>Continue with weak password</source>
        <translation>להמשיך עם ססמה חלשה</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Database not opened</source>
        <translation>מסד־נתונים לא נפתח</translation>
    </message>
    <message>
        <source>Database hash not available</source>
        <translation>גיבוב מסד־נתונים לא זמין</translation>
    </message>
    <message>
        <source>Client public key not received</source>
        <translation>לא התקבל מפתח לקוח ציבורי</translation>
    </message>
    <message>
        <source>Cannot decrypt message</source>
        <translation>לא ניתן לפענח הודעה</translation>
    </message>
    <message>
        <source>Action cancelled or denied</source>
        <translation>הפעולה בוטלה או נדחתה</translation>
    </message>
    <message>
        <source>Message encryption failed.</source>
        <translation>הצפנת הודעה כשלה.</translation>
    </message>
    <message>
        <source>KeePassXC association failed, try again</source>
        <translation>שיוך KeePassXC כשל, נא לנסות שוב</translation>
    </message>
    <message>
        <source>Encryption key is not recognized</source>
        <translation>מפתח ההצפנה לא מזוהה</translation>
    </message>
    <message>
        <source>Incorrect action</source>
        <translation>פעולה שגויה</translation>
    </message>
    <message>
        <source>Empty message received</source>
        <translation>התקבלה הודעה ריקה</translation>
    </message>
    <message>
        <source>No URL provided</source>
        <translation>לא סופקמען URL</translation>
    </message>
    <message>
        <source>No logins found</source>
        <translation>לא נמצאו התחברויות</translation>
    </message>
    <message>
        <source>No groups found</source>
        <translation>לא נמצאו קבוצות</translation>
    </message>
    <message>
        <source>Cannot create new group</source>
        <translation>לא ניתן ליצור קבוצה חדשה</translation>
    </message>
    <message>
        <source>No valid UUID provided</source>
        <translation>לא סופק ערך UUID תקין</translation>
    </message>
    <message>
        <source>Username or password cannot contain references</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Unknown error</source>
        <translation>שגיאה לא ידועה</translation>
    </message>
    <message>
        <source>Browser Integration</source>
        <translation>שילוב דפדפן</translation>
    </message>
    <message>
        <source>Browser Plugin Failure</source>
        <translation>כשל במתקע דפדפן</translation>
    </message>
    <message>
        <source>Could not save the native messaging script file for %1.</source>
        <translation>לא ניתן לשמור את קובץ התסריט המקורי של %1.</translation>
    </message>
    <message>
        <source>Username for the entry.</source>
        <translation>שם משתמש הרשומה.</translation>
    </message>
    <message>
        <source>username</source>
        <translation>שם משתמש</translation>
    </message>
    <message>
        <source>URL for the entry.</source>
        <translation>מען URL הרשומה.</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>מען url</translation>
    </message>
    <message>
        <source>Notes for the entry.</source>
        <translation>הערות הרשומה.</translation>
    </message>
    <message>
        <source>Notes</source>
        <translation>הערות</translation>
    </message>
    <message>
        <source>Prompt for the entry&apos;s password.</source>
        <translation>הנחיה לססמת רשומה.</translation>
    </message>
    <message>
        <source>Generate a password for the entry.</source>
        <translation>חילול ססמה עבור הרשומה.</translation>
    </message>
    <message>
        <source>Add a new entry to a database.</source>
        <translation>הוספת רשומה חדשה למסד הנתונים.</translation>
    </message>
    <message>
        <source>Path of the entry to add.</source>
        <translation>הנתיב לרשומה להוספה.</translation>
    </message>
    <message>
        <source>Cannot generate a password and prompt at the same time.</source>
        <translation>לא ניתן לחולל ססמה ולהנחות, בו־זמנית.</translation>
    </message>
    <message>
        <source>Could not create entry with path %1.</source>
        <translation>נא ניתן ליצור רשומה בנתיב %1.</translation>
    </message>
    <message>
        <source>Enter password for new entry: </source>
        <translation>הזנת ססמה לרשומה חדשה: </translation>
    </message>
    <message>
        <source>Writing the database failed %1.</source>
        <translation>כתיבת מסד הנתונים כשלה %1.</translation>
    </message>
    <message>
        <source>Successfully added entry %1.</source>
        <translation>רשומה %1 נוספה בהצלחה.</translation>
    </message>
    <message>
        <source>Adds a new group to a database.</source>
        <translation>הוספת קבוצה חדשה למסד נתונים.</translation>
    </message>
    <message>
        <source>Path of the group to add.</source>
        <translation>הנתיב לקבוצה להוספה.</translation>
    </message>
    <message>
        <source>Group %1 already exists!</source>
        <translation>קבוצה %1 כבר קיימת!</translation>
    </message>
    <message>
        <source>Group %1 not found.</source>
        <translation>הקבוצה %1 לא נמצאה.</translation>
    </message>
    <message>
        <source>Successfully added group %1.</source>
        <translation>קבוצה %1 נוספה בהצלחה.</translation>
    </message>
    <message>
        <source>Check if any passwords have been publicly leaked. FILENAME must be the path of a file listing SHA-1 hashes of leaked passwords in HIBP format, as available from https://haveibeenpwned.com/Passwords.</source>
        <translation>נא לבדוק אם ססמאות כלשהן הודלפו בפומבי. FILENAME חייב להיות הנתיב של קובץ המפרט HASS SHA-1 של ססמאות שדלפו בתסדיר HIBP, כפי שזמין ב־https://haveibeenpwned.com/Passwords.</translation>
    </message>
    <message>
        <source>FILENAME</source>
        <translation>שם קובץ</translation>
    </message>
    <message>
        <source>Path to okon-cli to search a formatted HIBP file</source>
        <translation>נתיב ל־okon-cli לחיפוש בקובץ HIBP מתובנת</translation>
    </message>
    <message>
        <source>okon-cli</source>
        <translation>okon-cli</translation>
    </message>
    <message>
        <source>Analyze passwords for weaknesses and problems.</source>
        <translation>ניתוח ססמאות לחולשות ובעיות.</translation>
    </message>
    <message>
        <source>Cannot find HIBP file: %1</source>
        <translation>קובץ HIBP לא נמצא: %1</translation>
    </message>
    <message>
        <source>Evaluating database entries using okon…</source>
        <translation>הערכת רשומות מסד־נתונים באמצעות okon...</translation>
    </message>
    <message>
        <source>Failed to open HIBP file %1: %2</source>
        <translation>כשל בפתיחת קובץ HIBP %1: %2</translation>
    </message>
    <message>
        <source>Evaluating database entries against HIBP file, this will take a while…</source>
        <translation>הערכת רשומות מסד־נתונים מול קובץ HIBP, פעולה זו תימשך זמן מה...</translation>
    </message>
    <message numerus="yes">
        <source>Password for &apos;%1&apos; has been leaked %2 time(s)!</source>
        <translation><numerusform>הססמה ל־&apos;%1&apos; הודלפה פעם %2!</numerusform><numerusform>הססמה ל־&apos;%1&apos; הודלפה %2 פעמים!</numerusform><numerusform>הססמה ל־&apos;%1&apos; הודלפה %2 פעמים!</numerusform></translation>
    </message>
    <message>
        <source>Password for &apos;%1&apos; has been leaked!</source>
        <translation>הססמה של &apos;%1&apos; דלפה!</translation>
    </message>
    <message>
        <source>Export an attachment of an entry.</source>
        <translation>ייצוא צרופת רשומה.</translation>
    </message>
    <message>
        <source>Path of the entry with the target attachment.</source>
        <translation>הנתיב לרשומה עם צרופת יעד.</translation>
    </message>
    <message>
        <source>Name of the attachment to be exported.</source>
        <translation>שם הצרופה שתיוצא.</translation>
    </message>
    <message>
        <source>Path to which the attachment should be exported.</source>
        <translation>נתיב לצרופה שתיוצא.</translation>
    </message>
    <message>
        <source>Could not find entry with path %1.</source>
        <translation>לא ניתן למצוא רשומה בנתיב %1.</translation>
    </message>
    <message>
        <source>Could not find attachment with name %1.</source>
        <translation>לא ניתן למצוא קובץ צרופה: %1.</translation>
    </message>
    <message>
        <source>No export target given. Please use &apos;--stdout&apos; or specify an &apos;export-file&apos;.</source>
        <translation>לא סופק יעד לייצוא. נא להשתמש ב־&apos;stdout--&apos; או לספק &apos;קובץ ייצוא&apos;.</translation>
    </message>
    <message>
        <source>Could not open output file %1.</source>
        <translation>לא ניתן לפתוח קובץ פלט: %1.</translation>
    </message>
    <message>
        <source>Successfully exported attachment %1 of entry %2 to %3.</source>
        <translation>צרופה %1 מרשומה %2 יוצאה בהצלחה ל%3.</translation>
    </message>
    <message>
        <source>Overwrite existing attachments.</source>
        <translation>כתיבה־על צרופות קיימות.</translation>
    </message>
    <message>
        <source>Imports an attachment to an entry.</source>
        <translation>ייבוא צרופה לרשומה.</translation>
    </message>
    <message>
        <source>Path of the entry.</source>
        <translation>נתיב הרשומה.</translation>
    </message>
    <message>
        <source>Name of the attachment to be added.</source>
        <translation>שם הצרופה שתתווסף.</translation>
    </message>
    <message>
        <source>Path of the attachment to be imported.</source>
        <translation>לנתיב לצרופה שתיובא.</translation>
    </message>
    <message>
        <source>Attachment %1 already exists for entry %2.</source>
        <translation>לרשומה %2 קיימת כבר צרופה %1.</translation>
    </message>
    <message>
        <source>Could not open attachment file %1.</source>
        <translation>לא ניתן לפתוח קובץ צרופה: %1.</translation>
    </message>
    <message>
        <source>Successfully imported attachment %1 as %2 to entry %3.</source>
        <translation>צרופה %1 יובאה בהצלחה כ־%2 לרשומה %3.</translation>
    </message>
    <message>
        <source>Remove an attachment of an entry.</source>
        <translation>הסרת צרופה מרשומה.</translation>
    </message>
    <message>
        <source>Name of the attachment to be removed.</source>
        <translation>שם הצרופה שתוסר.</translation>
    </message>
    <message>
        <source>Successfully removed attachment %1 from entry %2.</source>
        <translation>צרופה %1 הוסרה בהצלחה מרשומה %2.</translation>
    </message>
    <message>
        <source>Copy the given attribute to the clipboard. Defaults to &quot;password&quot; if not specified.</source>
        <comment>Don't translate &quot;password&quot;, it refers to the attribute.</comment>
        <translation>העתקת התכונה הנתונה ללוח־הגזירים. אם לא צוין, ברירת המחדל תהא &quot;ססמה&quot;.</translation>
    </message>
    <message>
        <source>Copy the current TOTP to the clipboard (equivalent to &quot;-a totp&quot;).</source>
        <translation>העתקת תוכן ה־TOTP הנוכחי ללוח־הגזירים (שווה ערך ל־&quot;-a totp&quot;).</translation>
    </message>
    <message>
        <source>Must match only one entry, otherwise a list of possible matches is shown.</source>
        <translation>חייב להתאים לרשומה אחת בלבד, אחרת תוצג רשימת התאמות אפשריות.</translation>
    </message>
    <message>
        <source>Copy an entry&apos;s attribute to the clipboard.</source>
        <translation>העתקת תכונת רשומה ללוח־הגזירים.</translation>
    </message>
    <message>
        <source>Path of the entry to clip.</source>
        <comment>clip = copy to clipboard</comment>
        <translation>הנתיב לרשומה לקְטִימָה.</translation>
    </message>
    <message>
        <source>Timeout before clearing the clipboard (default is %1 seconds, set to 0 for unlimited).</source>
        <translation>פסק־הזמן לפני ניקוי הלוח־הגזירים (ברירת המחדל היא %1 שניות, הגדרה כ־0 עבור &apos;ללא הגבלה&apos;).</translation>
    </message>
    <message>
        <source>Invalid timeout value %1.</source>
        <translation>ערך פסק־זמן לא תקין %1.</translation>
    </message>
    <message>
        <source>Multiple entries matching:</source>
        <translation>התאמת רשומות מרובות:</translation>
    </message>
    <message>
        <source>Using matching entry: %1</source>
        <translation>שימוש ברשומה תואמת: %1</translation>
    </message>
    <message>
        <source>Entry %1 not found.</source>
        <translation>רשומה %1 לא נמצאה.</translation>
    </message>
    <message>
        <source>ERROR: Please specify one of --attribute or --totp, not both.</source>
        <translation>שגיאה: נא לציין אחד מתוך --attribute או --totp, לא את שניהם.</translation>
    </message>
    <message>
        <source>Entry with path %1 has no TOTP set up.</source>
        <translation>לא הוגדר TOTP לרשומה בנתיב %1.</translation>
    </message>
    <message>
        <source>ERROR: attribute %1 is ambiguous, it matches %2.</source>
        <translation>שגיאה: תכונה %1 רב־משמעית, היא תואמת ל־%2.</translation>
    </message>
    <message>
        <source>Attribute &quot;%1&quot; not found.</source>
        <translation>תכונה &quot;%1&quot; לא נמצאה.</translation>
    </message>
    <message>
        <source>Entry&apos;s &quot;%1&quot; attribute copied to the clipboard!</source>
        <translation>העתקת תכונת רשומה &apos;%1&apos; ללוח־הגזירים!</translation>
    </message>
    <message numerus="yes">
        <source>Clearing the clipboard in %1 second(s)...</source>
        <translation><numerusform>ניקוי לוח־גזירים בתוך שניה %1...</numerusform><numerusform>ניקוי לוח־גזירים בתוך %1 שניות...</numerusform><numerusform>ניקוי לוח־גזירים בתוך %1 שניות...</numerusform></translation>
    </message>
    <message>
        <source>Clipboard cleared!</source>
        <translation>לוח־גזירים נוקה!</translation>
    </message>
    <message>
        <source>Close the currently opened database.</source>
        <translation>סגירת מסד הנתונים הנוכחי.</translation>
    </message>
    <message>
        <source>Display this help.</source>
        <translation>הצגת עזרה זו.</translation>
    </message>
    <message>
        <source>Silence password prompt and other secondary outputs.</source>
        <translation>השתקת הנחית ססמה ופלטים משניים אחרים.</translation>
    </message>
    <message>
        <source>Key file of the database.</source>
        <translation>קובץ מפתח מסד־נתונים.</translation>
    </message>
    <message>
        <source>path</source>
        <translation>נתיב</translation>
    </message>
    <message>
        <source>Deactivate password key for the database.</source>
        <translation>השבתת הפעלת מפתח ססמה עבור מסד הנתונים.</translation>
    </message>
    <message>
        <source>Yubikey slot and optional serial used to access the database (e.g., 1:7370001).</source>
        <translation>חריץ Yubikey וסדרה חלופית המשמשת לגישה למסד הנתונים (למשל, 1:7370001).</translation>
    </message>
    <message>
        <source>slot[:serial]</source>
        <translation>חריץ[:טורי]</translation>
    </message>
    <message>
        <source>Missing positional argument(s).</source>
        <translation>חסרים משתנים תלויים.</translation>
    </message>
    <message>
        <source>Too many arguments provided.</source>
        <translation>סופקו משתנים רבים מדי.</translation>
    </message>
    <message>
        <source>Path of the database.</source>
        <translation>הנתיב למסד הנתונים.</translation>
    </message>
    <message>
        <source>Target decryption time in MS for the database.</source>
        <translation>זמן פענוח יעד מסד הנתונים במילי־שניות.</translation>
    </message>
    <message>
        <source>time</source>
        <translation>זמן</translation>
    </message>
    <message>
        <source>Set the key file for the database.</source>
        <translation>הגדרת קובץ המפתח עבור מסד הנתונים.</translation>
    </message>
    <message>
        <source>Set a password for the database.</source>
        <translation>הגדרת ססמה למסד הנתונים.</translation>
    </message>
    <message>
        <source>Create a new database.</source>
        <translation>יצירת מסד־נתונים חדש.</translation>
    </message>
    <message>
        <source>Invalid decryption time %1.</source>
        <translation>זמן פענוח לא תקין %1.</translation>
    </message>
    <message>
        <source>Target decryption time must be between %1 and %2.</source>
        <translation>זמן פענוח היעד חייב להיות בין %1 ל־%2.</translation>
    </message>
    <message>
        <source>Failed to set database password.</source>
        <translation>הגדרת ססמת מסד־נתונים כשלה.</translation>
    </message>
    <message>
        <source>Loading the key file failed</source>
        <translation>טעינת קובץ מפתח כשלה</translation>
    </message>
    <message>
        <source>No key is set. Aborting database creation.</source>
        <translation>לא הוגדר מפתח. נטישת יצירת מסד־נתונים.</translation>
    </message>
    <message>
        <source>Benchmarking key derivation function for %1ms delay.</source>
        <translation>פונקציית גזירת מפתח בחינת ביצועים להשהייה של %1 מילי־שניות.</translation>
    </message>
    <message>
        <source>Setting %1 rounds for key derivation function.</source>
        <translation>הגדרת %1 סבבים פונקציית נגזרת מפתח.</translation>
    </message>
    <message>
        <source>error while setting database key derivation settings.</source>
        <translation>שגיאה בעת הגדרת נגזרת מפתח מסד־נתונים.</translation>
    </message>
    <message>
        <source>File %1 already exists.</source>
        <translation>קובץ %1 כבר קיים.</translation>
    </message>
    <message>
        <source>Failed to save the database: %1.</source>
        <translation>כשל בשמירת מסד־נתונים לקובץ : %1.</translation>
    </message>
    <message>
        <source>Successfully created new database.</source>
        <translation>מסד־נתונים חדש נוצר בהצלחה.</translation>
    </message>
    <message>
        <source>Unset the password for the database.</source>
        <translation>הסרת הגדרת ססמה למסד־הנתונים.</translation>
    </message>
    <message>
        <source>Unset the key file for the database.</source>
        <translation>הסרת הגדרת קובץ המפתח למסד־הנתונים.</translation>
    </message>
    <message>
        <source>Edit a database.</source>
        <translation>עריכת מסד־נתונים.</translation>
    </message>
    <message>
        <source>Cannot use %1 and %2 at the same time.</source>
        <translation>לא ניתן להשתמש ב־%1 וב־%2 בו זמנית.</translation>
    </message>
    <message>
        <source>Could not change the database key.</source>
        <translation>לא ניתן היה לשנות את מפתח מסד־הנתונים.</translation>
    </message>
    <message>
        <source>Database was not modified.</source>
        <translation>מסד־נתונים לא השתנה.</translation>
    </message>
    <message>
        <source>Writing the database failed: %1</source>
        <translation>כתיבת מסד הנתונים כשלה: %1</translation>
    </message>
    <message>
        <source>Successfully edited the database.</source>
        <translation>מסד־נתונים נערך בהצלחה.</translation>
    </message>
    <message>
        <source>Cannot remove password: The database does not have a password.</source>
        <translation>לא מיתן להסיר ססמה: אין למסד־הנתונים ססמה.</translation>
    </message>
    <message>
        <source>Cannot remove file key: The database does not have a file key.</source>
        <translation>לא ניתן להסיר קובץ מפתח: אין למסד־הנתונים קובץ מפתח.</translation>
    </message>
    <message>
        <source>Loading the new key file failed: %1</source>
        <translation>טעינת קובץ מפתח כשלה: %1</translation>
    </message>
    <message>
        <source>Found unexpected Key type %1</source>
        <translation>נמצ סוג מפתח לא צפוי %1</translation>
    </message>
    <message>
        <source>Cannot remove all the keys from a database.</source>
        <translation>לא ניתן להסיר את כל המפתחות ממסד־נתונים.</translation>
    </message>
    <message>
        <source>Show a database&apos;s information.</source>
        <translation>הצגת מידע מסד־נתונים.</translation>
    </message>
    <message>
        <source>UUID: </source>
        <translation>UUID: </translation>
    </message>
    <message>
        <source>Name: </source>
        <translation>שם: </translation>
    </message>
    <message>
        <source>Description: </source>
        <translation>תיאור: </translation>
    </message>
    <message>
        <source>Cipher: </source>
        <translation>צופן: </translation>
    </message>
    <message>
        <source>KDF: </source>
        <translation>KDF: </translation>
    </message>
    <message>
        <source>Recycle bin is enabled.</source>
        <translation>סל־מחזור מאופשר.</translation>
    </message>
    <message>
        <source>Recycle bin is not enabled.</source>
        <translation>סל־מחזור מושבת.</translation>
    </message>
    <message>
        <source>Location</source>
        <translation>מקום</translation>
    </message>
    <message>
        <source>Database created</source>
        <translation>מסד־נתונים נוצר</translation>
    </message>
    <message>
        <source>Last saved</source>
        <translation>שמירה אחרונה</translation>
    </message>
    <message>
        <source>Unsaved changes</source>
        <translation>שינויים שלא נשמרו</translation>
    </message>
    <message>
        <source>yes</source>
        <translation>כן</translation>
    </message>
    <message>
        <source>no</source>
        <translation>לא</translation>
    </message>
    <message>
        <source>Number of groups</source>
        <translation>מספר קבוצות</translation>
    </message>
    <message>
        <source>Number of entries</source>
        <translation>מספר רשומות</translation>
    </message>
    <message>
        <source>Number of expired entries</source>
        <translation>מספר רשומות שתוקפם פג</translation>
    </message>
    <message>
        <source>Unique passwords</source>
        <translation>ססמאות ייחודיות</translation>
    </message>
    <message>
        <source>Non-unique passwords</source>
        <translation>ססמאות לא־ייחודיות</translation>
    </message>
    <message>
        <source>Maximum password reuse</source>
        <translation>שימוש חוזר מרבי בססמה</translation>
    </message>
    <message>
        <source>Number of short passwords</source>
        <translation>מספר ססמאות קצרות</translation>
    </message>
    <message>
        <source>Number of weak passwords</source>
        <translation>מספר ססמאות חלשות</translation>
    </message>
    <message>
        <source>Entries excluded from reports</source>
        <translation>רשומות מוחרגות מדוחות</translation>
    </message>
    <message>
        <source>Average password length</source>
        <translation>אורך ססמה ממוצע</translation>
    </message>
    <message>
        <source>Number of passkeys</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Entries with TOTP setup</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Word count for the diceware passphrase.</source>
        <translation>ספירת מילים עבור ביטוי ססמה הטלת־קוביות.</translation>
    </message>
    <message>
        <source>count</source>
        <comment>CLI parameter</comment>
        <translation>ספירה</translation>
    </message>
    <message>
        <source>Wordlist for the diceware generator.
[Default: EFF English]</source>
        <translation>רשימת מילים עבור מחולל הטלת־קוביות.
[ברירת מחדל: אנגלית EFF]</translation>
    </message>
    <message>
        <source>Generate a new random diceware passphrase.</source>
        <translation>חילול ביטוי ססמת הטלת־קוביות אקראית חדשה.</translation>
    </message>
    <message>
        <source>Invalid word count %1</source>
        <translation>ספירת מילים לא תקינה %1</translation>
    </message>
    <message>
        <source>Title for the entry.</source>
        <translation>כותרת הרשומה.</translation>
    </message>
    <message>
        <source>title</source>
        <translation>כותרת</translation>
    </message>
    <message>
        <source>Edit an entry.</source>
        <translation>עריכת רשומה.</translation>
    </message>
    <message>
        <source>Path of the entry to edit.</source>
        <translation>הנתיב לרשומה לעריכה.</translation>
    </message>
    <message>
        <source>Not changing any field for entry %1.</source>
        <translation>לא השתנו שדות ברשומה %1.</translation>
    </message>
    <message>
        <source>Enter new password for entry: </source>
        <translation>הזנת ססמה חדשה לרשומה: </translation>
    </message>
    <message>
        <source>Successfully edited entry %1.</source>
        <translation>רשומה %1 נערכה בהצלחה.</translation>
    </message>
    <message>
        <source>Perform advanced analysis on the password.</source>
        <translation>ביצוע ניתוח מתקדם לססמה.</translation>
    </message>
    <message>
        <source>Password for which to estimate the entropy.</source>
        <translation>ססמה להערכת האנטרופיה.</translation>
    </message>
    <message>
        <source>Estimate the entropy of a password.</source>
        <translation>הערכת אנטרופית ססמה.</translation>
    </message>
    <message>
        <source>Length %1</source>
        <translation>אורך %1</translation>
    </message>
    <message>
        <source>Entropy %1</source>
        <translation>אנטרופיה %1</translation>
    </message>
    <message>
        <source>Log10 %1</source>
        <translation>Log10 %1</translation>
    </message>
    <message>
        <source>Multi-word extra bits %1</source>
        <translation>סיביות מרובות מילים %1 נוספות</translation>
    </message>
    <message>
        <source>Type: Bruteforce</source>
        <translation>סוג: תְּקִיפָה כּוֹחָנִית</translation>
    </message>
    <message>
        <source>Type: Dictionary</source>
        <translation>סוג: מילון</translation>
    </message>
    <message>
        <source>Type: Dict+Leet</source>
        <translation>סוג: Dict+Leet</translation>
    </message>
    <message>
        <source>Type: User Words</source>
        <translation>סוג: מילות משתמש</translation>
    </message>
    <message>
        <source>Type: User+Leet</source>
        <translation>סוג: משתמש+Leet</translation>
    </message>
    <message>
        <source>Type: Repeated</source>
        <translation>סוג: מחזורי</translation>
    </message>
    <message>
        <source>Type: Sequence</source>
        <translation>סוג: רצף</translation>
    </message>
    <message>
        <source>Type: Spatial</source>
        <translation>סוג: מרחבי</translation>
    </message>
    <message>
        <source>Type: Date</source>
        <translation>סוג: תאריך</translation>
    </message>
    <message>
        <source>Type: Bruteforce(Rep)</source>
        <translation>סוג: תְּקִיפָה כּוֹחָנִית (נציג)</translation>
    </message>
    <message>
        <source>Type: Dictionary(Rep)</source>
        <translation>סוג: מילון(מחזורי)</translation>
    </message>
    <message>
        <source>Type: Dict+Leet(Rep)</source>
        <translation>סוג: תכתיב+לייט(מחזורי)</translation>
    </message>
    <message>
        <source>Type: User Words(Rep)</source>
        <translation>סוג: מילות משתמש(מחזורי)</translation>
    </message>
    <message>
        <source>Type: User+Leet(Rep)</source>
        <translation>סוג: משתמש+לית(מחזורי)</translation>
    </message>
    <message>
        <source>Type: Repeated(Rep)</source>
        <translation>סוג: חוזר(מחזורי)</translation>
    </message>
    <message>
        <source>Type: Sequence(Rep)</source>
        <translation>סוג: רצף(מחזורי)</translation>
    </message>
    <message>
        <source>Type: Spatial(Rep)</source>
        <translation>סוג: מרחבי(מחזורי)</translation>
    </message>
    <message>
        <source>Type: Date(Rep)</source>
        <translation>סוג: תאריך(מחזורי)</translation>
    </message>
    <message>
        <source>Type: Unknown (%1)</source>
        <translation>סוג: לא ידוע (%1)</translation>
    </message>
    <message>
        <source>Entropy %1 (%2)</source>
        <translation>אנטרופיה %1 (%2)</translation>
    </message>
    <message>
        <source>*** Password length (%1) != sum of length of parts (%2) ***</source>
        <translation>אורך ססמה (%1) != סכום אורך החלקים (%2) ***</translation>
    </message>
    <message>
        <source>Exit interactive mode.</source>
        <translation>יציאה ממצב הידודי.</translation>
    </message>
    <message>
        <source>Exports the content of a database to standard output in the specified format.</source>
        <translation>ייצוא תוכן מסד־נתונים לפלט רגיל בתסדיר שצוין.</translation>
    </message>
    <message>
        <source>Unable to export database to XML: %1</source>
        <translation>לא ניתן לייצא מסד־נתונים ל־XML: %1</translation>
    </message>
    <message>
        <source>Unsupported format %1</source>
        <translation>תסדיר %1 לא נתמך</translation>
    </message>
    <message>
        <source>Length of the generated password</source>
        <translation>אורך הססמה שחוללה</translation>
    </message>
    <message>
        <source>length</source>
        <translation>אורך</translation>
    </message>
    <message>
        <source>Use lowercase characters</source>
        <translation>שימוש בתווי אותיות־קטנות</translation>
    </message>
    <message>
        <source>Use uppercase characters</source>
        <translation>שימוש בתווי אותיות רישיות</translation>
    </message>
    <message>
        <source>Use numbers</source>
        <translation>שימוש במספרים</translation>
    </message>
    <message>
        <source>Use special characters</source>
        <translation>שימוש בתווים מיוחדים</translation>
    </message>
    <message>
        <source>Use extended ASCII</source>
        <translation>שימוש ב־ASCII מורחב</translation>
    </message>
    <message>
        <source>Exclude character set</source>
        <translation>החרגת ערכת תווים</translation>
    </message>
    <message>
        <source>chars</source>
        <translation>תווים</translation>
    </message>
    <message>
        <source>Use custom character set</source>
        <translation>שימוש בערכת תווים מותאמת אישית</translation>
    </message>
    <message>
        <source>Exclude similar looking characters</source>
        <translation>החרגת תווים דומים</translation>
    </message>
    <message>
        <source>Include characters from every selected group</source>
        <translation>הכללת תווים מכל קבוצה שנבחרה</translation>
    </message>
    <message>
        <source>Generate a new random password.</source>
        <translation>חילול ססמה אקראית חדשה.</translation>
    </message>
    <message>
        <source>Invalid password length %1</source>
        <translation>אורך ססמה לא תקין %1</translation>
    </message>
    <message>
        <source>Invalid password generator after applying all options</source>
        <translation>מחולל ססמאות לא תקין לאחר החלת כל האפשרויות</translation>
    </message>
    <message>
        <source>Display command help.</source>
        <translation>הצגת עזרת פקודה.</translation>
    </message>
    <message>
        <source>Available commands:</source>
        <translation>פקודות זמינות:</translation>
    </message>
    <message>
        <source>Import the contents of an XML database.</source>
        <translation>ייבוא תוכן מסד נתוני XML.</translation>
    </message>
    <message>
        <source>Path of the XML database export.</source>
        <translation>נתיב ייצוא מסד הנתונים XML.</translation>
    </message>
    <message>
        <source>Path of the new database.</source>
        <translation>הנתיב של מסד הנתונים החדש.</translation>
    </message>
    <message>
        <source>Unable to import XML database: %1</source>
        <translation>לא ניתן לייבא מסד־נתונים ל־XML: %1</translation>
    </message>
    <message>
        <source>Successfully imported database.</source>
        <translation>מסד הנתונים יובא בהצלחה.</translation>
    </message>
    <message>
        <source>Unknown command %1</source>
        <translation>פקודה לא ידועה %1</translation>
    </message>
    <message>
        <source>

Available commands:
</source>
        <translation>

פקודות זמינות:
</translation>
    </message>
    <message>
        <source>Name of the command to execute.</source>
        <translation>שם הפקודה לבצוע.</translation>
    </message>
    <message>
        <source>Displays debugging information.</source>
        <translation>הצגת מידע ניפוי־תקלים.</translation>
    </message>
    <message>
        <source>Invalid command %1.</source>
        <translation>פקודה לא תקינה %1.</translation>
    </message>
    <message>
        <source>Recursively list the elements of the group.</source>
        <translation>פרוט רקורסיבי של רכיבי הקבוצה.</translation>
    </message>
    <message>
        <source>Flattens the output to single lines.</source>
        <translation>שיטוח הפלט לשורות בודדות.</translation>
    </message>
    <message>
        <source>List database entries.</source>
        <translation>הצגת רשומות מסד־נתונים.</translation>
    </message>
    <message>
        <source>Path of the group to list. Default is /</source>
        <translation>נתיב הקבוצה לרשימה. ברירת המחדל היא /</translation>
    </message>
    <message>
        <source>Cannot find group %1.</source>
        <translation>לא ניתן למצוא קבוצה %1.</translation>
    </message>
    <message>
        <source>Use the same credentials for both database files.</source>
        <translation>נא להשתמש באותם אישורים עבור שני קבצי מסדי הנתונים.</translation>
    </message>
    <message>
        <source>Key file of the database to merge from.</source>
        <translation>קובץ מפתח של מסד הנתונים למיזוג.</translation>
    </message>
    <message>
        <source>Deactivate password key for the database to merge from.</source>
        <translation>השבתת מפתח ססמת מסד הנתונים שימוזג.</translation>
    </message>
    <message>
        <source>Only print the changes detected by the merge operation.</source>
        <translation>להדפיס רק את השינויים שזוהו בפעולת המזוג.</translation>
    </message>
    <message>
        <source>Yubikey slot for the second database.</source>
        <translation>חריץ Yubikey למסד הנתונים השני.</translation>
    </message>
    <message>
        <source>slot</source>
        <translation>חריץ</translation>
    </message>
    <message>
        <source>Merge two databases.</source>
        <translation>מזוג שני מסדי־נתונים.</translation>
    </message>
    <message>
        <source>Path of the database to merge from.</source>
        <translation>הנתיב למסד הנתונים שימוזג.</translation>
    </message>
    <message>
        <source>Error reading merge file:
%1</source>
        <translation>שגיאה בקריאת קובץ מיזוג:
%1</translation>
    </message>
    <message>
        <source>Unable to save database to file : %1</source>
        <translation>לא ניתן לשמור מסד־נתונים לקובץ : %1</translation>
    </message>
    <message>
        <source>Successfully merged %1 into %2.</source>
        <translation>%1 מוזג לתוך %2 בהצלחה.</translation>
    </message>
    <message>
        <source>Database was not modified by merge operation.</source>
        <translation>מסד הנתונים לא הוסגל כתוצאה מפעולת המיזוג.</translation>
    </message>
    <message>
        <source>Moves an entry to a new group.</source>
        <translation>העברת רשומה לקבוצה חדשה.</translation>
    </message>
    <message>
        <source>Path of the entry to move.</source>
        <translation>הנתיב לרשומה להעברה.</translation>
    </message>
    <message>
        <source>Path of the destination group.</source>
        <translation>הנתיב של קבוצת היעד.</translation>
    </message>
    <message>
        <source>Could not find group with path %1.</source>
        <translation>לא ניתן למצוא קבוצה בנתיב %1.</translation>
    </message>
    <message>
        <source>Entry is already in group %1.</source>
        <translation>הרשומה נמצאת כבר בקבוצה %1.</translation>
    </message>
    <message>
        <source>Successfully moved entry %1 to group %2.</source>
        <translation>רשומה %1 הועברה בהצלחה לקבוצה %2.</translation>
    </message>
    <message>
        <source>Open a database.</source>
        <translation>פתיחת מסד־נתונים.</translation>
    </message>
    <message>
        <source>Path of the entry to remove.</source>
        <translation>הנתיב לרשומה להסרה.</translation>
    </message>
    <message>
        <source>Unable to save database to file: %1</source>
        <translation>לא ניתן לשמור מסד־נתונים לקובץ : %1</translation>
    </message>
    <message>
        <source>Successfully recycled entry %1.</source>
        <translation>רשומה %1 מוחזרה בהצלחה.</translation>
    </message>
    <message>
        <source>Successfully deleted entry %1.</source>
        <translation>רשומה %1 נמחקה בהצלחה.</translation>
    </message>
    <message>
        <source>Path of the group to remove.</source>
        <translation>הנתיב לקבוצה להסרה.</translation>
    </message>
    <message>
        <source>Cannot remove root group from database.</source>
        <translation>לא ניתן להסיר קבוצת שורש ממסד הנתונים.</translation>
    </message>
    <message>
        <source>Successfully recycled group %1.</source>
        <translation>רשומה %1 מוחזרה בהצלחה.</translation>
    </message>
    <message>
        <source>Successfully deleted group %1.</source>
        <translation>הקבוצה %1 נמחקה בהצלחה.</translation>
    </message>
    <message>
        <source>Find entries quickly.</source>
        <translation>חיפוש ערכים מהיר.</translation>
    </message>
    <message>
        <source>Search term.</source>
        <translation>תנאי חיפוש.</translation>
    </message>
    <message>
        <source>Show the entry&apos;s current TOTP.</source>
        <translation>הצגת TOTP רשומה נוכחי.</translation>
    </message>
    <message>
        <source>Show the protected attributes in clear text.</source>
        <translation>הצגת התכונות המוגנות במלל רגיל.</translation>
    </message>
    <message>
        <source>Show all the attributes of the entry.</source>
        <translation>הצגת כל מאפייני הרשומה.</translation>
    </message>
    <message>
        <source>Show the attachments of the entry.</source>
        <translation>הצגת הצרופה של הרשומה.</translation>
    </message>
    <message>
        <source>Names of the attributes to show. This option can be specified more than once, with each attribute shown one-per-line in the given order. If no attributes are specified, a summary of the default attributes is given.</source>
        <translation>שמות התכונות להצגה. ניתן להגדיר אפשרות זו יותר מפעם אחת, כאשר כל תכונה מוצגת בשורה אחת בסדר הנתון. אם לא צוינו תכונות, תתקבל תמצית של תכונת ברירת המחדל.</translation>
    </message>
    <message>
        <source>attribute</source>
        <translation>תכונה</translation>
    </message>
    <message>
        <source>Show an entry&apos;s information.</source>
        <translation>הצגת מידע רשומה.</translation>
    </message>
    <message>
        <source>Name of the entry to show.</source>
        <translation>מספר רשומות להצגה.</translation>
    </message>
    <message>
        <source>ERROR: unknown attribute %1.</source>
        <translation>שגיאה: תכונה לא ידועה %1.</translation>
    </message>
    <message>
        <source>No attachments present.</source>
        <translation>לא קיימות צרופות.</translation>
    </message>
    <message>
        <source>Attachments:</source>
        <translation>צרופות:</translation>
    </message>
    <message>
        <source>Failed to open database file %1: not found</source>
        <translation>כשל בפתיחת קובץ מסד־נתונים %1: לא נמצא</translation>
    </message>
    <message>
        <source>Failed to open database file %1: not a plain file</source>
        <translation>כשל בפתיחת קובץ מסד־נתונים %1: לא קובץ רגיל</translation>
    </message>
    <message>
        <source>Failed to open database file %1: not readable</source>
        <translation>כשל בפתיחת קובץ מסד־נתונים %1: לא קריא</translation>
    </message>
    <message>
        <source>Enter password to unlock %1: </source>
        <translation>הזנת ססמה לשחרור נעילת %1: </translation>
    </message>
    <message>
        <source>Failed to load key file %1: %2</source>
        <translation>טעינת קובץ מפתח %1 כשלה: %2</translation>
    </message>
    <message>
        <source>WARNING: You are using an old key file format which KeePassXC may
stop supporting in the future.

Please consider generating a new key file.</source>
        <translation>אזהרה: נעשה שימוש בתסדיר קובץ מפתח ישן ש־KeePassXC עשוי
להפסיק לתמוך בעתיד.

נא לשקול ליצור קובץ מפתח חדש.</translation>
    </message>
    <message>
        <source>Invalid YubiKey slot %1</source>
        <translation>חריץ YubiKey לא תקין %1</translation>
    </message>
    <message>
        <source>Invalid YubiKey serial %1</source>
        <translation>YubiKey סידורי %1 לא תקין</translation>
    </message>
    <message>
        <source>Please present or touch your YubiKey to continue.</source>
        <translation>נא להציג או לגעת ב־YubiKey על מנת להמשך...</translation>
    </message>
    <message>
        <source>Enter password to encrypt database (optional): </source>
        <translation>נא להזין ססמה להצפנת מסד־נתונים (חלופי): </translation>
    </message>
    <message>
        <source>Do you want to create a database with an empty password? [y/N]: </source>
        <translation>האם ליצור מסד־נתונים עם ססמה ריקה? [ל/כ]: </translation>
    </message>
    <message>
        <source>Repeat password: </source>
        <translation>חזרה על הססמה: </translation>
    </message>
    <message>
        <source>Error: Passwords do not match.</source>
        <translation>שגיאה: ססמאות לא תואמות.</translation>
    </message>
    <message>
        <source>No program defined for clipboard manipulation</source>
        <translation>לא הוגדרה תכנית לטפלול לוח־הגזירים</translation>
    </message>
    <message>
        <source>All clipping programs failed. Tried %1
</source>
        <translation>כל תוכניות הקְטִימָה כשלו. בוצע ניסיון %1
</translation>
    </message>
    <message>
        <source>Creating KeyFile %1 failed: %2</source>
        <translation>יצירת קובץ מפתח %1 כשלה: %2</translation>
    </message>
    <message>
        <source>Loading KeyFile %1 failed: %2</source>
        <translation>טעינת קובץ מפתח %1 כשלה: %2</translation>
    </message>
    <message>
        <source>HIBP file, line %1: parse error</source>
        <translation>קובץ HIBP, שורה %1: שגיאת ניתוח מבנה</translation>
    </message>
    <message>
        <source>To use okon, you must provide a post-processed file (e.g. file.okon)</source>
        <translation>כדי להשתמש ב־okon, נא לספק קובץ פלט (לדוגמה file.okon)</translation>
    </message>
    <message>
        <source>Could not start okon process: %1</source>
        <translation>לא ניתן להפעיל תהליך אישור: %1</translation>
    </message>
    <message>
        <source>Error: okon process did not finish</source>
        <translation>שגיאה: תהליך okon לא הסתיים</translation>
    </message>
    <message>
        <source>Failed to load okon processed database: %1</source>
        <translation>טעינת מסד הנתונים מעובד okon כשלה: %1</translation>
    </message>
    <message>
        <source>Very weak password</source>
        <translation>ססמה חלשה מאוד</translation>
    </message>
    <message>
        <source>Password entropy is %1 bits</source>
        <translation>אנטרופיית ססמה היא %1 סיביות</translation>
    </message>
    <message>
        <source>Weak password</source>
        <translation>ססמה חלשה</translation>
    </message>
    <message>
        <source>Used in %1/%2</source>
        <translation>נמצא בשימוש ב־%1/%2</translation>
    </message>
    <message numerus="yes">
        <source>Password is used %1 time(s)</source>
        <translation><numerusform>נעשה שימוש בססמה פעם %1</numerusform><numerusform>נעשה שימוש בססמה %1 פעמים</numerusform><numerusform>נעשה שימוש בססמה %1 פעמים</numerusform></translation>
    </message>
    <message>
        <source>Password has expired</source>
        <translation>תוקף הססמה פג</translation>
    </message>
    <message>
        <source>Password expiry was %1</source>
        <translation>תפוגת ססמה היתה %1</translation>
    </message>
    <message>
        <source>Password expires on %1</source>
        <translation>תפוגת ססמה ב־%1</translation>
    </message>
    <message>
        <source>Password is about to expire</source>
        <translation>תוקף הססמה עומד לפוג</translation>
    </message>
    <message numerus="yes">
        <source>Password expires in %1 day(s)</source>
        <translation><numerusform>תוקף הססמה יפוג בתוך יום %1</numerusform><numerusform>תוקף הססמה יפוג בתוך %1 ימים</numerusform><numerusform>תוקף הססמה יפוג בתוך %1 ימים</numerusform></translation>
    </message>
    <message>
        <source>Password will expire soon</source>
        <translation>תוקף ססמה יפוג בקרוב</translation>
    </message>
    <message>
        <source>Version %1</source>
        <translation>גירסה %1</translation>
    </message>
    <message>
        <source>Build Type: %1</source>
        <translation>סוג בניה: %1</translation>
    </message>
    <message>
        <source>Revision: %1</source>
        <translation>מהדורה: %1</translation>
    </message>
    <message>
        <source>Distribution: %1</source>
        <translation>הפצה: %1</translation>
    </message>
    <message>
        <source>Debugging mode is disabled.</source>
        <translation>מצב ניפוי־תקלים מושבת.</translation>
    </message>
    <message>
        <source>Debugging mode is enabled.</source>
        <translation>מצב ניפוי־תקלים מאופשר.</translation>
    </message>
    <message>
        <source>Operating system: %1
CPU architecture: %2
Kernel: %3 %4</source>
        <translation>מערכת הפעלה: %1
ארכיטקטורת CPU: %2
ליבה: %3 %4</translation>
    </message>
    <message>
        <source>Auto-Type</source>
        <translation>הקלדה־אוטומטית</translation>
    </message>
    <message>
        <source>SSH Agent</source>
        <translation>סוכן SSH</translation>
    </message>
    <message>
        <source>KeeShare</source>
        <translation>KeeShare</translation>
    </message>
    <message>
        <source>Quick Unlock</source>
        <translation>שחרור נעילה מהירה</translation>
    </message>
    <message>
        <source>Secret Service Integration</source>
        <translation>שילוב שירות חשאי</translation>
    </message>
    <message>
        <source>Enabled extensions:</source>
        <translation>איפשור הרחבות:</translation>
    </message>
    <message numerus="yes">
        <source>over %1 year(s)</source>
        <translation><numerusform>מעל שנה %1</numerusform><numerusform>מעל %1 שנים</numerusform><numerusform>מעל %1 שנים</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>about %1 month(s)</source>
        <translation><numerusform>בסביבות חודש %1</numerusform><numerusform>בסביבות %1 חודשים</numerusform><numerusform>בסביבות %1 חודשים</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>%1 week(s)</source>
        <translation><numerusform>שבועה %1</numerusform><numerusform>%1 שבועות</numerusform><numerusform>%1 שבועות</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>%1 day(s)</source>
        <translation><numerusform>יום %1</numerusform><numerusform>%1 ימים</numerusform><numerusform>%1 ימים</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>%1 hour(s)</source>
        <translation><numerusform>שעה %1</numerusform><numerusform>%1 שעות</numerusform><numerusform>%1 שעות</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>%1 minute(s)</source>
        <translation><numerusform>דקה %1</numerusform><numerusform>%1 דקות</numerusform><numerusform>%1 דקות</numerusform></translation>
    </message>
    <message>
        <source>Botan library must be at least %1, found %2.%3.%4</source>
        <translation>ספריית Botan חייבת להיות לפחות %1, נמצאה גרסה %2.%3.%4</translation>
    </message>
    <message>
        <source>Cryptographic libraries:</source>
        <translation>ספריות הצפנה:</translation>
    </message>
    <message>
        <source>AES (%1 rounds)</source>
        <translation>AES (%1 סבבים)</translation>
    </message>
    <message>
        <source>Argon2%1 (%2 rounds, %3 KB)</source>
        <translation>Argon2%1 (%2 סבבים, %3 KB)</translation>
    </message>
    <message>
        <source>SymmetricCipher::init: Invalid cipher mode.</source>
        <translation>SymmetricCipher::init: מצב צופן לא תקין.</translation>
    </message>
    <message>
        <source>SymmetricCipher::init: Invalid IV size of %1 for %2.</source>
        <translation>SymmetricCipher::init: גודל IV לא תקין של %1 ל־%2.</translation>
    </message>
    <message>
        <source>Cipher not initialized prior to use.</source>
        <translation>הצופן לא אותחל לפני השימוש.</translation>
    </message>
    <message>
        <source>Cannot process 0 length data.</source>
        <translation>לא ניתן לעבד נתוני אורך 0.</translation>
    </message>
    <message>
        <source>unknown executable (DBus address %1)</source>
        <translation>קובץ הרצה לא ידוע (כתובת DBus %1)</translation>
    </message>
    <message>
        <source>%1 (invalid executable path)</source>
        <translation>%1 (נתיב קובץ הפעלה לא תקין)</translation>
    </message>
    <message>
        <source>NULL device</source>
        <translation>התקן NULL</translation>
    </message>
    <message>
        <source>error reading from device</source>
        <translation>שגיאת קריאה מהתקן</translation>
    </message>
    <message>
        <source>file empty</source>
        <translation>קובץ ריק</translation>
    </message>
    <message>
        <source>AES 256-bit</source>
        <translation>AES- 256 סיביות</translation>
    </message>
    <message>
        <source>Twofish 256-bit</source>
        <translation>256-סיביות Twofish</translation>
    </message>
    <message>
        <source>ChaCha20 256-bit</source>
        <translation>ChaCha20 256-ביט</translation>
    </message>
    <message>
        <source>Argon2d (KDBX 4 – recommended)</source>
        <translation>Argon2d (KDBX 4 – מומלץ)</translation>
    </message>
    <message>
        <source>Argon2id (KDBX 4)</source>
        <translation>Argon2id (KDBX 4)</translation>
    </message>
    <message>
        <source>AES-KDF (KDBX 4)</source>
        <translation>AES-KDF (KDBX 4)</translation>
    </message>
    <message>
        <source>AES-KDF (KDBX 3)</source>
        <translation>AES-KDF (KDBX 3)</translation>
    </message>
    <message>
        <source>Existing single-instance lock file is invalid. Launching new instance.</source>
        <translation>קובץ נעילת אֶדְגָּם־יחיד קיים לא תקין. שיגור אֶדְגָּם חדש.</translation>
    </message>
    <message>
        <source>The lock file could not be created. Single-instance mode disabled.</source>
        <translation>לא ניתן ליצור את קובץ הנעילה. מצב אֶדְגָּם־יחיד לא זמין.</translation>
    </message>
    <message numerus="yes">
        <source>Clearing the clipboard in %1 second(s)…</source>
        <translation><numerusform>ניקוי לוח־גזירים בתוך שניה %1...</numerusform><numerusform>ניקוי לוח־גזירים בתוך %1 שניות...</numerusform><numerusform>ניקוי לוח־גזירים בתוך %1 שניות...</numerusform></translation>
    </message>
    <message>
        <source>Group</source>
        <translation>קבוצה</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>כותרת</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>שם משתמש</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>ססמה</translation>
    </message>
    <message>
        <source>TOTP</source>
        <translation>TOTP</translation>
    </message>
    <message>
        <source>Icon</source>
        <translation>סמל</translation>
    </message>
    <message>
        <source>Last Modified</source>
        <translation>הוסגל לאחרונה</translation>
    </message>
    <message>
        <source>Created</source>
        <translation>נוצר</translation>
    </message>
    <message>
        <source>Benchmark %1 delay</source>
        <translation>השהיית בחינת ביצועים %1</translation>
    </message>
    <message numerus="yes">
        <source>%1 ms</source>
        <comment>milliseconds</comment>
        <translation><numerusform>אלפית שניה %1</numerusform><numerusform>%1 אלפיות שניה</numerusform><numerusform>%1 אלפיות שניה</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>%1 s</source>
        <comment>seconds</comment>
        <translation><numerusform>שניה %1</numerusform><numerusform>%1 שניות</numerusform><numerusform>%1 שניות</numerusform></translation>
    </message>
    <message>
        <source>Do you really want to move entry &quot;%1&quot; to the recycle bin?</source>
        <translation>האם להעביר רשומה &quot;%1&quot; לסל־המחזור?</translation>
    </message>
    <message numerus="yes">
        <source>Do you really want to move %n entry(s) to the recycle bin?</source>
        <translation><numerusform>האם להעביר רשומה %n לסל־המחזור?</numerusform><numerusform>האם להעביר %n רשומות לסל־המחזור?</numerusform><numerusform>האם להעביר %n רשומות לסל־המחזור?</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>Entry &quot;%1&quot; has %2 reference(s). Do you want to overwrite references with values, skip this entry, or delete anyway?</source>
        <translation><numerusform>לרשומה &apos;%1&apos; קיימות %2 הפניות. האם לכתוב־על הפניות עם ערכים, לדלג על רשומה זו, או למחוק אותה בכל זאת?</numerusform><numerusform>לרשומה &apos;%1&apos; קיימות %2 הפניות. האם לכתוב־על הפניות עם ערכים, לדלג על רשומה זו, או למחוק אותה בכל זאת?</numerusform><numerusform>לרשומה &apos;%1&apos; קיימות %2 הפניות. האם לכתוב־על הפניות עם ערכים, לדלג על רשומה זו, או למחוק אותה בכל זאת?</numerusform></translation>
    </message>
    <message>
        <source>User name</source>
        <translation>שם משתמש</translation>
    </message>
    <message>
        <source>Browser Statistics</source>
        <translation>סטטיסטיקת דפדפן</translation>
    </message>
    <message>
        <source>Health Check</source>
        <translation>בדיקת תקינות</translation>
    </message>
    <message>
        <source>HIBP</source>
        <translation>HIBP</translation>
    </message>
    <message>
        <source>Statistics</source>
        <translation>סטטיסטיקה</translation>
    </message>
    <message>
        <source>Unsupported key file version: %1</source>
        <translation>גרסת קובץ מפתח לא נתמכת: %1</translation>
    </message>
    <message>
        <source>Checksum mismatch! Key file may be corrupt.</source>
        <translation>אי התאמת סיכום־בקורת! ייתכן שקובץ המפתח פגום.</translation>
    </message>
    <message>
        <source>Unexpected key file data! Key file may be corrupt.</source>
        <translation>נתוני קובץ מפתח לא צפויים! ייתכן שקובץ המפתח פגום.</translation>
    </message>
    <message>
        <source>KeePassXC - cross-platform password manager</source>
        <translation>KeePassXC - מנהל ססמאות חוצה מסדות</translation>
    </message>
    <message>
        <source>filenames of the password databases to open (*.kdbx)</source>
        <translation>שמות קובץ מסד נתוני ססמאות לפתיחה (*.kdbx)</translation>
    </message>
    <message>
        <source>path to a custom config file</source>
        <translation>נתיב לקובץ תצורה מותאם אישית</translation>
    </message>
    <message>
        <source>path to a custom local config file</source>
        <translation>נתיב לקובץ תצורה מותאם אישית</translation>
    </message>
    <message>
        <source>lock all open databases</source>
        <translation>נעילת כל מסדי הנתונים הפתוחים</translation>
    </message>
    <message>
        <source>key file of the database</source>
        <translation>קובץ המפתח של מסד הנתונים</translation>
    </message>
    <message>
        <source>read password of the database from stdin</source>
        <translation>קריאת ססמה של מסד הנתונים מ־stdin</translation>
    </message>
    <message>
        <source>Database failed to lock.</source>
        <translation>נעילת מסד הנתונים כשלה.</translation>
    </message>
    <message>
        <source>Another instance of KeePassXC is already running.</source>
        <translation>אֶדְגָּם KeePassXC נוסף כבר פועל.</translation>
    </message>
    <message>
        <source>KeePassXC is not running. No open database to lock</source>
        <translation>KeePassXC לא פעיל. אין מסד נתונים פתוח לנעילה.</translation>
    </message>
    <message>
        <source>Fatal error while testing the cryptographic functions.</source>
        <translation>שגיאה מכרעת בעת בדיקת פונקציות ההצפנה.</translation>
    </message>
    <message>
        <source>KeePassXC - Error</source>
        <translation>שגיאת KeePassXC</translation>
    </message>
    <message>
        <source>Database password: </source>
        <translation>ססמת מסד־נתונים: </translation>
    </message>
    <message>
        <source>Invalid Settings</source>
        <comment>TOTP</comment>
        <translation>הגדרות לא תקינות</translation>
    </message>
    <message>
        <source>Invalid Key</source>
        <comment>TOTP</comment>
        <translation>מפתח לא תקין</translation>
    </message>
    <message>
        <source>Failed to create Windows Hello credential.</source>
        <translation>יצירת אישור Windows Hello כשלה.</translation>
    </message>
    <message>
        <source>Failed to sign challenge using Windows Hello.</source>
        <translation>אימות אתגר־מענה באמצעות Windows Hello כשל.</translation>
    </message>
    <message>
        <source>Warning: Failed to block screenshot capture on a top-level window.</source>
        <translation>אזהרה: חסימת צילומי מסך בחלון ברמה העליונה כשלה!</translation>
    </message>
    <message>
        <source>Invalid Cipher</source>
        <translation>צופן לא תקין</translation>
    </message>
    <message>
        <source>Invalid KDF</source>
        <translation>KDF לא תקין</translation>
    </message>
    <message>
        <source>Access to all entries is denied</source>
        <translation>גישה לכול הרשומות נדחתה</translation>
    </message>
    <message>
        <source>allow screenshots and app recording (Windows/macOS)</source>
        <translation>אפשור תצלום מצג והקלטת יישום Iוינדוס/מאק OS)</translation>
    </message>
    <message>
        <source>Set the key file for the database.
This option is deprecated, use --set-key-file instead.</source>
        <translation>קביעת קובץ המפתח למסד הנתונים.
אפשרות זו הוצאה משימוש, במקום זאת יש להשתמש ב: &apos; --set-key-file&apos;.</translation>
    </message>
    <message>
        <source>Databases have been locked.</source>
        <translation>מסד נתונים ננעל.</translation>
    </message>
    <message>
        <source>Attestation not supported</source>
        <translation>אימות לא נתמך</translation>
    </message>
    <message>
        <source>Credential is excluded</source>
        <translation>נתוני אמנה הוחרגו</translation>
    </message>
    <message>
        <source>Passkeys request canceled</source>
        <translation>בקשת Passkeys בוטלה</translation>
    </message>
    <message>
        <source>Invalid user verification</source>
        <translation>אימות משתמש לא תקין</translation>
    </message>
    <message>
        <source>Empty public key</source>
        <translation>מפתח ציבורי ריק</translation>
    </message>
    <message>
        <source>Invalid URL provided</source>
        <translation>סופק מען URL לא תקין</translation>
    </message>
    <message>
        <source>Passkeys</source>
        <translation>Passkeys</translation>
    </message>
    <message>
        <source>AES initialization failed</source>
        <translation>אתחול AES כשל</translation>
    </message>
    <message>
        <source>AES encrypt failed</source>
        <translation>הצפנת AES כשלה</translation>
    </message>
    <message>
        <source>Failed to store in Linux Keyring</source>
        <translation>אחסון ב־Keyring לינוקס כשל</translation>
    </message>
    <message>
        <source>Polkit returned an error: %1</source>
        <translation>Polkit החזיר שגיאה: %1</translation>
    </message>
    <message>
        <source>Could not locate key in keyring</source>
        <translation>לא ניתן לאתר מפתח ב־keyring</translation>
    </message>
    <message>
        <source>Could not read key in keyring</source>
        <translation>לא ניתן לקרוא מפתח ב־keyring</translation>
    </message>
    <message>
        <source>AES decrypt failed</source>
        <translation>פענוח AES כשל</translation>
    </message>
    <message>
        <source>No Polkit authentication agent was available</source>
        <translation>סוכן אימות Polkit לא זמין</translation>
    </message>
    <message>
        <source>Polkit authorization failed</source>
        <translation>הרשאת Polkit כשלה</translation>
    </message>
    <message>
        <source>No Quick Unlock provider is available</source>
        <translation>ספק שרות שחרור נעילה מהיר לא זמין</translation>
    </message>
    <message>
        <source>Failed to init KeePassXC crypto.</source>
        <translation>נכשל באיתחול קריפטו KeePassXC.</translation>
    </message>
    <message>
        <source>Failed to encrypt key data.</source>
        <translation>הצפנת נתוני מפתח כשלה.</translation>
    </message>
    <message>
        <source>Failed to get Windows Hello credential.</source>
        <translation>קבלת אישור Windows Hello כשלה.</translation>
    </message>
    <message>
        <source>Failed to decrypt key data.</source>
        <translation>פענוח נתוני מפתח כשלה.</translation>
    </message>
    <message>
        <source>Origin is empty or not allowed</source>
        <translation>מקור ריק או לא מאופשר</translation>
    </message>
    <message>
        <source>Effective domain is not a valid domain</source>
        <translation>התחום בפועל אינן תחום תקין</translation>
    </message>
    <message>
        <source>Origin and RP ID do not match</source>
        <translation>מקור ומזהה RP לא תואמים</translation>
    </message>
    <message>
        <source>No supported algorithms were provided</source>
        <translation>לא סופק אלגוריתם נתמך</translation>
    </message>
    <message>
        <source>Wait for timer to expire</source>
        <translation>המתנה לתפוגת קוצב זמן</translation>
    </message>
    <message>
        <source>Challenge is shorter than required minimum length</source>
        <translation>אתגר מענה קצר מאורך מזערי נדרש</translation>
    </message>
    <message>
        <source>user.id does not match the required length</source>
        <translation>מזהה משתמש לא תואם לאורך הנדרש</translation>
    </message>
    <message>
        <source>Favorite</source>
        <comment>Tag for favorite entries</comment>
        <translation>מועדף</translation>
    </message>
    <message>
        <source>File does not exist.</source>
        <translation>קובץ לא קיים.</translation>
    </message>
    <message>
        <source>Cannot open file: %1</source>
        <translation>לא ניתן לפתוח קובץ: %1</translation>
    </message>
    <message>
        <source>Cannot parse file: %1 at position %2</source>
        <translation>לא ניתן לפרק קובץ: %1 באיות %2</translation>
    </message>
    <message>
        <source>Failed to decrypt json file: %1</source>
        <translation>פענוח קובץ json כשל: %1</translation>
    </message>
    <message>
        <source>Invalid encKeyValidation field</source>
        <translation>שדה encKeyValidation לא תקין</translation>
    </message>
    <message>
        <source>Invalid cipher list within encKeyValidation field</source>
        <translation>רשימת צופן בתוך שדה צופן encKeyValidation לא תקין</translation>
    </message>
    <message>
        <source>Wrong password</source>
        <translation>ססמה שגויה</translation>
    </message>
    <message>
        <source>Invalid encrypted data field</source>
        <translation>שדה נתונים מוצפן לא תקין</translation>
    </message>
    <message>
        <source>Invalid cipher list within encrypted data field</source>
        <translation>רשימה צופן בתוך שדה נתונים מוצפן לא תקין</translation>
    </message>
    <message>
        <source>Cannot initialize cipher</source>
        <translation>לא ניתן לאתחל צופן</translation>
    </message>
    <message>
        <source>Cannot decrypt data</source>
        <translation>לא ניתן לפענח נתונים</translation>
    </message>
    <message>
        <source>Bitwarden Import</source>
        <translation>ייבוא Bitwarden</translation>
    </message>
    <message>
        <source>Archived</source>
        <comment>Tag for archived entries</comment>
        <translation>הועבר לארכיון</translation>
    </message>
    <message>
        <source>Invalid 1PUX file format: Not a valid ZIP file.</source>
        <translation>תסדיר קובץ 1PUX לא תקין: לא קובץ תקין.</translation>
    </message>
    <message>
        <source>Invalid 1PUX file format: Missing export.data</source>
        <translation>תסדיר קובץ 1PUX לא תקין: נתוני ייצוא חסרים</translation>
    </message>
    <message>
        <source>1Password Import</source>
        <translation>1Password יובא</translation>
    </message>
    <message>
        <source>Enter Shortcut</source>
        <translation>הזנת קיצור־דרך</translation>
    </message>
    <message>
        <source>Action</source>
        <translation>פעולה</translation>
    </message>
    <message>
        <source>Shortcuts</source>
        <translation>קיצורי־דרך</translation>
    </message>
    <message>
        <source>Unknown passkeys error</source>
        <translation>שגיאת passkeys לא ידועה</translation>
    </message>
    <message>
        <source>Invalid KDF iterations, cannot decrypt json file</source>
        <translation>חזרורי KDF לא תקינים, לא ניתן לפענח קובץ json</translation>
    </message>
    <message>
        <source>Unsupported format, ensure your Bitwarden export is password-protected</source>
        <translation>תסדיר לא נתמך, נא לוודא שייצוא Bitwarden מוגן בססמה</translation>
    </message>
    <message>
        <source>Only PBKDF and Argon2 are supported, cannot decrypt json file</source>
        <translation>רק  PBKDF ו־Argon2 נתמכים, לא ניתן לפענח קובץ json</translation>
    </message>
    <message>
        <source>Hardware Keys</source>
        <translation>מפתחות חומרה</translation>
    </message>
    <message>
        <source>Passkey</source>
        <translation>Passkey</translation>
    </message>
    <message>
        <source>Reset Shortcuts</source>
        <translation>שיצוב קיצורי־דרך</translation>
    </message>
    <message>
        <source>Double click an action to change its shortcut</source>
        <translation>הקשה כפולה על פעולה לשינוי קיצור הדרך שלה</translation>
    </message>
    <message>
        <source>Filter...</source>
        <translation>סינון...</translation>
    </message>
    <message>
        <source>Shortcut Conflict</source>
        <translation>התנגשות קיצור־דרך</translation>
    </message>
    <message>
        <source>Shortcut %1 conflicts with &apos;%2&apos;. Overwrite shortcut?</source>
        <translation>קיצור־דרך %1 מתנגש עם %2&apos;. לכתוב על קיצור־הדרך?</translation>
    </message>
    <message>
        <source>Format to use when exporting. Available choices are &apos;xml&apos;, &apos;csv&apos; or &apos;html&apos;. Defaults to &apos;xml&apos;.</source>
        <translation>תסדיר לשימוש בעת ייצוא. אפשרויות זמינות הן &apos;xml&apos;, &apos;csv&apos; או &apos;html&apos;. ברירת המחדל היא &apos;xml&apos;.</translation>
    </message>
    <message>
        <source>malformed string, possible unescaped delimiter</source>
        <translation>מחרוזת פגומה, תוחם שלא נמלט אפשרי</translation>
    </message>
    <message>
        <source>missing closing delimiter</source>
        <translation>חסר תוחם סוגר</translation>
    </message>
    <message>
        <source>%1, row: %2, column: %3</source>
        <translation>%1, שורה: %2, עמודה: %3</translation>
    </message>
    <message>
        <source>Encrypted files are not supported.</source>
        <translation>קבצים מוצפנים אינם נתמכים.</translation>
    </message>
    <message>
        <source>Proton Pass Import</source>
        <translation>ייבוא Proton Pass</translation>
    </message>
    <message>
        <source>Tags</source>
        <translation>תגים</translation>
    </message>
    <message>
        <source>start minimized to the system tray</source>
        <translation>התחלה במצב ממוזער למגש המערכת</translation>
    </message>
    <message>
        <source>Warning: the chosen wordlist is smaller than the minimum recommended size!</source>
        <translation>אזהרה: רשימת המילים שנבחרה קטנה מהגודל המומלץ המזערי!</translation>
    </message>
    <message>
        <source>Invalid Step</source>
        <comment>TOTP</comment>
        <translation>שלב לא תקין</translation>
    </message>
    <message>
        <source>Invalid Digits</source>
        <comment>TOTP</comment>
        <translation>ספרות לא תקינות</translation>
    </message>
    <message numerus="yes">
        <source>%1 character(s)</source>
        <translation><numerusform>תו %1</numerusform><numerusform>%1 תווים</numerusform><numerusform>%1 תווים</numerusform></translation>
    </message>
    <message>
        <source>Do you really want to permanently delete the entry &quot;%1&quot;?</source>
        <translation>האם למחוק לצמיתות את רשומה &quot;%1&quot;?</translation>
    </message>
    <message numerus="yes">
        <source>Do you really want to permanently delete %n entry(s)?</source>
        <translation><numerusform>האם למחוק לצמיתות רשומה %n?</numerusform><numerusform>האם למחוק לצמיתות %n רשומות?</numerusform><numerusform>האם למחוק לצמיתות %n רשומות?</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>Confirm Delete Entry(s)</source>
        <translation><numerusform>אישור מחיקת רשומה</numerusform><numerusform>אישור מחיקת רשומות</numerusform><numerusform>אישור מחיקת רשומות</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>Confirm Recycle Entry(s)</source>
        <translation><numerusform>אישור מחזור רשומה</numerusform><numerusform>אישור מחזור רשומות</numerusform><numerusform>אישור מחזור רשומות</numerusform></translation>
    </message>
    <message>
        <source>Confirm Delete Plugin Data</source>
        <translation>אישור מיקת נתוני מתקע</translation>
    </message>
    <message numerus="yes">
        <source>Delete plugin data from the selected entry(s)?</source>
        <translation><numerusform>האם למחוק נתוני מתקע מהרשומה שנבחרה?</numerusform><numerusform>האם למחוק נתוני מתקע מהרשומות שנבחרו?</numerusform><numerusform>האם למחוק נתוני מתקע מהרשומות שנבחרו?</numerusform></translation>
    </message>
    <message>
        <source>Confirm Replace Entry References</source>
        <translation>אישור החלפת אזכורי רשומות</translation>
    </message>
</context>
<context>
    <name>QtIOCompressor</name>
    <message>
        <source>Internal zlib error when compressing: </source>
        <translation>שגיאת zlib פנימית בעת דחיסה: </translation>
    </message>
    <message>
        <source>Error writing to underlying device: </source>
        <translation>שגיאה בכתיבה להתקן הבסיסי: </translation>
    </message>
    <message>
        <source>Error opening underlying device: </source>
        <translation>שגיאה בפתיחת ההתקן הבסיסי: </translation>
    </message>
    <message>
        <source>Error reading data from underlying device: </source>
        <translation>שגיאה בקריאת נתונים מההתקן הבסיסי: </translation>
    </message>
    <message>
        <source>Internal zlib error when decompressing: </source>
        <translation>שגיאת zlib פנימית בעת חילוץ מדחיסה: </translation>
    </message>
</context>
<context>
    <name>QtIOCompressor::open</name>
    <message>
        <source>The gzip format not supported in this version of zlib.</source>
        <translation>תסדיר gzip אינו נתמך בגרסה זו של zlib.</translation>
    </message>
    <message>
        <source>Internal zlib error: </source>
        <translation>שגיאת zlib פנימית: </translation>
    </message>
</context>
<context>
    <name>RemoteDesktopPortal</name>
    <message>
        <source>Remote desktop session is not active</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Session closed</source>
        <translation>שיח נסגר</translation>
    </message>
    <message>
        <source>User cancelled the interaction</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>User interaction was canceled for unknown reason</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Remote desktop session handle does not match expected path</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>RemoteHandler</name>
    <message>
        <source>Command `%1` did not finish in time. Process was killed.</source>
        <translation>פקודה `%1` לא הסתיימה בזמן. תהליך חוסל.</translation>
    </message>
    <message>
        <source>Failed to upload merged database. Command `%1` did not finish in time. Process was killed.</source>
        <translation>העלאת מסד נתונים שמוזג כשל. פקודה `%1` לא הסתיימה בזמן. תהליך חוסל.</translation>
    </message>
    <message>
        <source>Invalid download parameters provided.</source>
        <translation>סופקו פרמטרי הורדה לא תקינים.</translation>
    </message>
    <message>
        <source>Command `%1` failed to download database.</source>
        <translation>פקודה `%1` כשלה בהורדת מסד נתונים.</translation>
    </message>
    <message>
        <source>Invalid database pointer or upload parameters provided.</source>
        <translation>סופקו מצביעי מסד נתונים או פרמטרי העלאה לא תקינים.</translation>
    </message>
    <message>
        <source>Command `%1` exited with status code: %2</source>
        <translation>פקודה `%1` יצאה עם קוד מצב: %2</translation>
    </message>
    <message>
        <source>Failed to upload merged database. Command `%1` exited with status code: %2</source>
        <translation>העלאת מסד נתונים שמוזג כשלה. פקודה `%1` יצאה עם קוד מצב: %2</translation>
    </message>
</context>
<context>
    <name>ReportsWidgetBrowserStatistics</name>
    <message>
        <source>Double-click entries to edit.</source>
        <translation>לעריכה, נא להקיש הקשה כפולה על הרשומות.</translation>
    </message>
    <message>
        <source>List of entry URLs</source>
        <translation>רשימת כל מעני URL ברשומות</translation>
    </message>
    <message>
        <source>Entry has no URLs set</source>
        <translation>לא הוגדרו מעני URL לרשומה</translation>
    </message>
    <message>
        <source>Allowed URLs</source>
        <translation>מעני URL מורשים</translation>
    </message>
    <message>
        <source>Entry has no Browser Integration settings</source>
        <translation>אין לרשומה הגדרות שילוב דפדפן</translation>
    </message>
    <message>
        <source>Denied URLs</source>
        <translation>מעני URL דחויים</translation>
    </message>
    <message>
        <source> (Excluded)</source>
        <translation> (לא נכלל)</translation>
    </message>
    <message>
        <source>This entry is being excluded from reports</source>
        <translation>הרשומה הוחרגה מדוחות</translation>
    </message>
    <message>
        <source>Please wait, browser statistics is being calculated…</source>
        <translation>נא להמתין, סטטיסטיקת נתוני דפדפן מחושבים עתה...</translation>
    </message>
    <message>
        <source>No entries with a URL, or none has browser extension settings saved.</source>
        <translation>לאף רשומה, עם או ללא מען URL, אין הגדרות הרחבת דפדפן שנשמרו.</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>כותרת</translation>
    </message>
    <message>
        <source>Path</source>
        <translation>נתיב</translation>
    </message>
    <message>
        <source>URLs</source>
        <translation>מעני URL</translation>
    </message>
    <message>
        <source>Edit Entry…</source>
        <translation>עריכת רשומה...</translation>
    </message>
    <message numerus="yes">
        <source>Delete Entry(s)…</source>
        <translation type="unfinished"><numerusform></numerusform><numerusform></numerusform><numerusform>מחיקת רשומות...</numerusform></translation>
    </message>
    <message>
        <source>Exclude from reports</source>
        <translation>החרגה מדוחות</translation>
    </message>
    <message numerus="yes">
        <source>Expire Entry(s)…</source>
        <translation><numerusform>תפוגת רשומה…</numerusform><numerusform>תפוגת רשומות…</numerusform><numerusform>תפוגת רשומות…</numerusform></translation>
    </message>
    <message>
        <source>Only show entries that have a URL</source>
        <translation>להציג רק רשומות שיש להן מען URL</translation>
    </message>
    <message>
        <source>Only show entries that have been explicitly allowed or denied</source>
        <translation>להציג רק רשומות שאפשרו או נדחו במפורש</translation>
    </message>
    <message>
        <source>Show expired entries</source>
        <translation>הצגת רשומות שפגו</translation>
    </message>
    <message>
        <source> (Expired)</source>
        <translation>(פג)</translation>
    </message>
    <message numerus="yes">
        <source>Delete plugin data from Entry(s)…</source>
        <translation><numerusform>מחיקת נתוני מתקע מרשומות?</numerusform><numerusform>מחיקת נתוני מתקע מרשומות?</numerusform><numerusform>מחיקת נתוני מתקע מרשומה?</numerusform></translation>
    </message>
</context>
<context>
    <name>ReportsWidgetHealthcheck</name>
    <message>
        <source>Show expired entries</source>
        <translation>הצגת רשומות שפגו</translation>
    </message>
    <message>
        <source> (Expired)</source>
        <translation>(פג)</translation>
    </message>
    <message>
        <source>Hover over reason to show additional details. Double-click entries to edit.</source>
        <translation>ריחוף מעל &apos;סיבה&apos; להצגת פרטים נוספים. הקשה כפולה על רשומות לעריכה.</translation>
    </message>
    <message>
        <source>Bad — password must be changed</source>
        <translation>חלש — יש לשנות ססמה</translation>
    </message>
    <message>
        <source>Poor — password should be changed</source>
        <translation>חלש — יש לשנות ססמה</translation>
    </message>
    <message>
        <source>Weak — consider changing the password</source>
        <translation>חלש — נא לשקול לשנות הססמה</translation>
    </message>
    <message>
        <source> (Excluded)</source>
        <translation> (מוחרג)</translation>
    </message>
    <message>
        <source>This entry is being excluded from reports</source>
        <translation>הרשומה הוחרגה מדוחות</translation>
    </message>
    <message>
        <source>Please wait, health data is being calculated…</source>
        <translation>נא להמתין, נתוני תקינות מחושבים...</translation>
    </message>
    <message>
        <source>Congratulations, everything is healthy!</source>
        <translation>מזל טוב, הכול תקין!</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>כותרת</translation>
    </message>
    <message>
        <source>Path</source>
        <translation>נתיב</translation>
    </message>
    <message>
        <source>Score</source>
        <translation>ציון</translation>
    </message>
    <message>
        <source>Reason</source>
        <translation>סיבה</translation>
    </message>
    <message>
        <source>Edit Entry…</source>
        <translation>עריכת רשומה...</translation>
    </message>
    <message numerus="yes">
        <source>Delete Entry(s)…</source>
        <translation><numerusform>מחיקת רשומה...</numerusform><numerusform>מחיקת רשומות...</numerusform><numerusform>מחיקת רשומות...</numerusform></translation>
    </message>
    <message>
        <source>Exclude from reports</source>
        <translation>החרגה מדוחות</translation>
    </message>
    <message numerus="yes">
        <source>Expire Entry(s)…</source>
        <translation><numerusform>תפוגת רשומה…</numerusform><numerusform>תפוגת רשומות…</numerusform><numerusform>תפוגת רשומות…</numerusform></translation>
    </message>
    <message>
        <source>Show entries that have been excluded from reports</source>
        <translation>הצגת רשומות שהוחרגו מדוחות</translation>
    </message>
</context>
<context>
    <name>ReportsWidgetHibp</name>
    <message>
        <source>CAUTION: This report requires sending information to the Have I Been Pwned online service (https://haveibeenpwned.com). If you proceed, your database passwords will be cryptographically hashed and the first five characters of those hashes will be sent securely to this service. Your database remains secure and cannot be reconstituted from this information. However, the number of passwords you send and your IP address will be exposed to this service.</source>
        <translation>התראה: דוח זה מחייב שליחת מידע לשירות המקוון של &apos;האם השטלתו עלי&apos; (https://haveibeenpwned.com). אם תמשיכו, ססמאות מסד הנתונים יוצפנו וחמשת התווים הראשונים של הגיבוב יישלחו באופן מאובטח לשירות זה. מסד הנתונים יישאר מאובטח ולא יהיה ניתן לבנות אותו מחדש  מהמידע שיתקבל. עם זאת, מספר הססמאות שיתקבלו וכתובת ה־IP ייחשפו לשירות זה.</translation>
    </message>
    <message>
        <source>Perform Online Analysis</source>
        <translation>ביצוע ניתוח מקוון</translation>
    </message>
    <message>
        <source>Also show entries that have been excluded from reports</source>
        <translation>הצגת רשומות שהוחרגו מדוחות</translation>
    </message>
    <message>
        <source>This build of KeePassXC does not have network functions. Networking is required to check your passwords against Have I Been Pwned databases.</source>
        <translation>לבנייה זו של KeePassXC אין יכולות רשת. חיבור לרשת נדרש כדי לבדוק את הססמאות אל מול מסדי נתוני &apos;I Been Pwned&apos;.</translation>
    </message>
    <message>
        <source>Congratulations, no exposed passwords!</source>
        <translation>ברכות, אין ססמאות חשופות!</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>כותרת</translation>
    </message>
    <message>
        <source>Path</source>
        <translation>נתיב</translation>
    </message>
    <message>
        <source>Password exposed…</source>
        <translation>הססמה נחשפה...</translation>
    </message>
    <message>
        <source> (Excluded)</source>
        <translation> (הוחרג)</translation>
    </message>
    <message>
        <source>This entry is being excluded from reports</source>
        <translation>הרשומה הופעלה מתוך דוחות</translation>
    </message>
    <message>
        <source>once</source>
        <comment>Password exposure amount</comment>
        <translation>פעם אחת</translation>
    </message>
    <message>
        <source>up to 10 times</source>
        <comment>Password exposure amount</comment>
        <translation>עד פי 10</translation>
    </message>
    <message>
        <source>up to 100 times</source>
        <comment>Password exposure amount</comment>
        <translation>עד פי 100</translation>
    </message>
    <message>
        <source>up to 1000 times</source>
        <comment>Password exposure amount</comment>
        <translation>עד 1000 פעמים</translation>
    </message>
    <message>
        <source>up to 10,000 times</source>
        <comment>Password exposure amount</comment>
        <translation>עד 10,000 פעמים</translation>
    </message>
    <message>
        <source>up to 100,000 times</source>
        <comment>Password exposure amount</comment>
        <translation>עד 100,000 פעמים</translation>
    </message>
    <message>
        <source>up to a million times</source>
        <comment>Password exposure amount</comment>
        <translation>עד מיליון פעמים</translation>
    </message>
    <message>
        <source>millions of times</source>
        <comment>Password exposure amount</comment>
        <translation>מיליוני פעמים</translation>
    </message>
    <message>
        <source>Edit Entry…</source>
        <translation>עריכת רשומה...</translation>
    </message>
    <message numerus="yes">
        <source>Delete Entry(s)…</source>
        <translation><numerusform>מחיקת רשומה?</numerusform><numerusform>מחיקת רשומות?</numerusform><numerusform>מחיקת רשומות?</numerusform></translation>
    </message>
    <message>
        <source>Exclude from reports</source>
        <translation>החרגה מדוחות</translation>
    </message>
    <message numerus="yes">
        <source>Expire Entry(s)…</source>
        <translation><numerusform>תפוגת רשומה…</numerusform><numerusform>תפוגת רשומות…</numerusform><numerusform>תפוגת רשומות…</numerusform></translation>
    </message>
</context>
<context>
    <name>ReportsWidgetPasskeys</name>
    <message>
        <source>Export</source>
        <translation>ייצא</translation>
    </message>
    <message>
        <source>Import</source>
        <translation>ייבוא</translation>
    </message>
    <message>
        <source>List of entry URLs</source>
        <translation>רשימת כל מעני URL ברשומות</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>כותרת</translation>
    </message>
    <message>
        <source>Path</source>
        <translation>נתיב</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>שם משתמש</translation>
    </message>
    <message>
        <source>URLs</source>
        <translation>מעני URL</translation>
    </message>
    <message>
        <source>Edit Entry…</source>
        <translation>עריכת רשומה...</translation>
    </message>
    <message numerus="yes">
        <source>Delete Entry(s)…</source>
        <translation><numerusform>מחיקת רשומה?</numerusform><numerusform>מחיקת רשומות?</numerusform><numerusform>מחיקת רשומות?</numerusform></translation>
    </message>
    <message>
        <source>Relying Party</source>
        <translation>צד נסמך</translation>
    </message>
    <message>
        <source>Show expired entries</source>
        <translation>הצגת רשומות שפגו</translation>
    </message>
    <message>
        <source> (Expired)</source>
        <translation>(פג תוקף)</translation>
    </message>
    <message>
        <source>Export Confirmation</source>
        <translation>אישור ייצוא</translation>
    </message>
    <message>
        <source>The passkey file will be vulnerable to theft and unauthorized use, if left unsecured. Are you sure you want to continue?</source>
        <translation>קובץ ה־Passkey יהיה פגיע לגנבה או שימוש לא מאושר.האם להמשיך?</translation>
    </message>
    <message>
        <source>Please wait, list of entries with passkeys is being updated…</source>
        <translation>נא להמתין, מתבצעת העלאת רשימת רשומות עם passkeys 
...</translation>
    </message>
    <message>
        <source>No entries with passkeys.</source>
        <translation>אין רשומות עם passkeys.</translation>
    </message>
</context>
<context>
    <name>ReportsWidgetStatistics</name>
    <message>
        <source>Hover over lines with error icons for further information.</source>
        <translation>רחוף מעל שורות עם סמלי שגיאה לקבלת מידע נוסף.</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>שם</translation>
    </message>
    <message>
        <source>Value</source>
        <translation>ערך</translation>
    </message>
    <message>
        <source>Please wait, database statistics are being calculated…</source>
        <translation>נא להמתין, סטטיסטיקת מסד־נתונים מחושבת...</translation>
    </message>
    <message>
        <source>Database name</source>
        <translation>שם מסד־נתונים</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>תיאור</translation>
    </message>
    <message>
        <source>Location</source>
        <translation>מקום</translation>
    </message>
    <message>
        <source>Database created</source>
        <translation>מסד־נתונים נוצר</translation>
    </message>
    <message>
        <source>Last saved</source>
        <translation>שמירה אחרונה</translation>
    </message>
    <message>
        <source>Unsaved changes</source>
        <translation>שינויים שלא נשמרו</translation>
    </message>
    <message>
        <source>yes</source>
        <translation>כן</translation>
    </message>
    <message>
        <source>no</source>
        <translation>לא</translation>
    </message>
    <message>
        <source>The database was modified, but the changes have not yet been saved to disk.</source>
        <translation>מסד הנתונים הוסגל, אך השינויים עדיין לא נשמרו לכונן הקשיח.</translation>
    </message>
    <message>
        <source>Number of groups</source>
        <translation>מספר קבוצות</translation>
    </message>
    <message>
        <source>Number of entries</source>
        <translation>מספר רשומות</translation>
    </message>
    <message>
        <source>Number of expired entries</source>
        <translation>מספר רשומות שתוקפם פג</translation>
    </message>
    <message>
        <source>The database contains entries that have expired.</source>
        <translation>מסד הנתונים מכיל רשומות שתוקפם פג.</translation>
    </message>
    <message>
        <source>Unique passwords</source>
        <translation>ססמאות ייחודיות</translation>
    </message>
    <message>
        <source>Non-unique passwords</source>
        <translation>ססמאות לא־ייחודיות</translation>
    </message>
    <message>
        <source>More than 10% of passwords are reused. Use unique passwords when possible.</source>
        <translation>נעשה שימוש חוזר ביותר מ־10% מהססמאות. נא להשתמש בססמאות ייחודיות ככל שניתן.</translation>
    </message>
    <message>
        <source>Maximum password reuse</source>
        <translation>שימוש חוזר מרבי בססמה</translation>
    </message>
    <message>
        <source>Some passwords are used more than three times. Use unique passwords when possible.</source>
        <translation>נעשה שימוש בססמאות מסוימות יותר משלוש פעמים. נא להשתמש בססמאות ייחודיות ככל שניתן.</translation>
    </message>
    <message>
        <source>Number of short passwords</source>
        <translation>מספר ססמאות קצרות</translation>
    </message>
    <message>
        <source>Recommended minimum password length is at least 8 characters.</source>
        <translation>אורך הססמה המזערי המומלץ הוא לפחות 8 תווים.</translation>
    </message>
    <message>
        <source>Number of weak passwords</source>
        <translation>מספר ססמאות חלשות</translation>
    </message>
    <message>
        <source>Recommend using long, randomized passwords with a rating of &apos;good&apos; or &apos;excellent&apos;.</source>
        <translation>מומלץ להשתמש בססמאות ארוכות ואקראיות בדירוג &apos;טוב&apos; או &apos;מעולה&apos;.</translation>
    </message>
    <message>
        <source>Entries excluded from reports</source>
        <translation>רשומות מוחרגות מדוחות</translation>
    </message>
    <message>
        <source>Excluding entries from reports, e. g. because they are known to have a poor password, isn&apos;t necessarily a problem but you should keep an eye on them.</source>
        <translation>החרגת רשומות מדוחות, לדוגמה, הידיעה שהססמה חלשה, אינה בהכרח בעיה, אך כדאי לפקוח עליהם עין.</translation>
    </message>
    <message>
        <source>Average password length</source>
        <translation>אורך ססמה ממוצע</translation>
    </message>
    <message>
        <source>Average password length is less than ten characters. Longer passwords provide more security.</source>
        <translation>אורך הססמה הממוצע הוא פחות מעשרה תווים. ססמאות ארוכות יותר מספקות אבטחה טובה יותר.</translation>
    </message>
    <message>
        <source>Number of passkeys</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Entries with TOTP setup</source>
        <translation type="unfinished"/>
    </message>
    <message numerus="yes">
        <source>%1 character(s)</source>
        <translation><numerusform>תו %1</numerusform><numerusform>%1 תוים</numerusform><numerusform>%1 תוים</numerusform></translation>
    </message>
</context>
<context>
    <name>SSHAgent</name>
    <message>
        <source>Agent connection failed.</source>
        <translation>חיבור הסוכן כשל.</translation>
    </message>
    <message>
        <source>Agent protocol error.</source>
        <translation>שגיאת פרוטוקול סוכן.</translation>
    </message>
    <message>
        <source>No agent running, cannot add identity.</source>
        <translation>אין סוכן פעיל, לא ניתן להוסיף זהות.</translation>
    </message>
    <message>
        <source>Key identity ownership conflict. Refusing to add.</source>
        <translation>התנגשות בבעלות על זהות מפתח. ההוספה סורבה.</translation>
    </message>
    <message>
        <source>Agent refused this identity. Possible reasons include:</source>
        <translation>הסוכן סירב לזהות הזאת. סיבות אפשריות כוללות:</translation>
    </message>
    <message>
        <source>The key has already been added.</source>
        <translation>המפתח כבר נוסף.</translation>
    </message>
    <message>
        <source>Restricted lifetime is not supported by the agent (check options).</source>
        <translation>מגבלות אורך־חיים לא נתמכת על־ידי הסוכן (נא לבדוק אפשרויות).</translation>
    </message>
    <message>
        <source>A confirmation request is not supported by the agent (check options).</source>
        <translation>בקשת אישור לא נתמכת על־ידי הסוכן (נא לבדוק אפשרויות).</translation>
    </message>
    <message>
        <source>Security keys are not supported by the agent or the security key provider is unavailable.</source>
        <translation>מפתחות האבטחה אינם נתמכים על ידי הסוכן או שספק שרות מפתחות האבטחה אינו זמין.</translation>
    </message>
    <message>
        <source>No agent running, cannot remove identity.</source>
        <translation>אין סוכן פעיל, לא ניתן להוסיף זהות.</translation>
    </message>
    <message>
        <source>No agent running, cannot list identities.</source>
        <translation>אין סוכן פעיל, לא ניתן להוסיף זהויות.</translation>
    </message>
    <message>
        <source>Failed to remove all SSH identities from agent.</source>
        <translation>הסרת כל זהויות ה ־SSH מהסוכן כשלה.</translation>
    </message>
    <message>
        <source>All SSH identities removed from agent.</source>
        <translation>כל זהויות ה ־SSH הוסרו מהסוכן.</translation>
    </message>
</context>
<context>
    <name>SearchHelpWidget</name>
    <message>
        <source>Search Help</source>
        <translation>עזרה בחיפוש</translation>
    </message>
    <message>
        <source>Search terms are as follows: [modifiers][field:][&quot;]term[&quot;]</source>
        <translation>מונחי חיפוש כדלקמן: [מהדד][שדה:][&quot;]מונח[&quot;]</translation>
    </message>
    <message>
        <source>Every search term must match (ie, logical AND)</source>
        <translation>כל מונח חיפוש חייב להתאים (כלומר, AND לוגי)</translation>
    </message>
    <message>
        <source>Modifiers</source>
        <translation>מהדדים</translation>
    </message>
    <message>
        <source>exclude term from results</source>
        <translation>החרגת מונח מהתוצאות</translation>
    </message>
    <message>
        <source>match term exactly</source>
        <translation>התאמת מונח במדויק</translation>
    </message>
    <message>
        <source>use regex in term</source>
        <translation>שימוש בביטי־רגיל במונח</translation>
    </message>
    <message>
        <source>Fields</source>
        <translation>שדות</translation>
    </message>
    <message>
        <source>Term Wildcards</source>
        <translation>תו־כל מונחים</translation>
    </message>
    <message>
        <source>match anything</source>
        <translation>התאמת הכול</translation>
    </message>
    <message>
        <source>match one</source>
        <translation>התאמה לאחד</translation>
    </message>
    <message>
        <source>logical OR</source>
        <translation>OR לוגי</translation>
    </message>
    <message>
        <source>Examples</source>
        <translation>דוגמאות</translation>
    </message>
</context>
<context>
    <name>SearchWidget</name>
    <message>
        <source>Search</source>
        <translation>חיפוש</translation>
    </message>
    <message>
        <source>Search Help</source>
        <translation>עזרה בחיפוש</translation>
    </message>
    <message>
        <source>Save Search</source>
        <translation>שמירת חיפוש</translation>
    </message>
    <message>
        <source>Search (%1)…</source>
        <comment>Search placeholder text, %1 is the keyboard shortcut</comment>
        <translation>חיפוש (%1)...</translation>
    </message>
    <message>
        <source>Case sensitive</source>
        <translation>תלוי רישיות</translation>
    </message>
    <message>
        <source>Limit search to selected group</source>
        <translation>הגבלת חיפוש לקבוצה שנבחרה</translation>
    </message>
    <message>
        <source>Press Enter to search</source>
        <translation>לחיצה על &apos;אנטר&apos; כדי להמשיך</translation>
    </message>
</context>
<context>
    <name>SettingsClientModel</name>
    <message>
        <source>Application</source>
        <translation>יישום</translation>
    </message>
    <message>
        <source>PID</source>
        <translation>קוד זיהוי אישי</translation>
    </message>
    <message>
        <source>DBus Address</source>
        <translation> מען DBus</translation>
    </message>
    <message>
        <source>Manage</source>
        <translation>ניהול</translation>
    </message>
</context>
<context>
    <name>SettingsDatabaseModel</name>
    <message>
        <source>File Name</source>
        <translation>שם קובץ</translation>
    </message>
    <message>
        <source>Group</source>
        <translation>קבוצה</translation>
    </message>
    <message>
        <source>Manage</source>
        <translation>ניהול</translation>
    </message>
</context>
<context>
    <name>SettingsWidgetFdoSecrets</name>
    <message>
        <source>Options</source>
        <translation>אפשרויות</translation>
    </message>
    <message>
        <source>Enable KeepassXC Freedesktop.org Secret Service integration</source>
        <translation>איפשור שילוב שירות חשאי Freedesktop.org KeepassXC</translation>
    </message>
    <message>
        <source>General</source>
        <translation>כללי</translation>
    </message>
    <message>
        <source>Show notification when passwords are retrieved by clients</source>
        <translation>הצג הודעה כאשר ססמאות מאוחזרות על־ידי לקוחות</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;If enabled, any attempt to read a password must be confirmed. Otherwise, clients can read passwords without confirmation when the database is unlocked.&lt;/p&gt;&lt;p&gt;This option only covers the access to the password of an entry. Clients can always enumerate the items of exposed databases and query their attributes.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;אם אופשר, כל ניסיון לקרוא ססמה תחויב באישור. אחרת, לקוחות יוכלו לקרוא ססמאות ללא אישור כאשר מסד הנתונים לא נעול.&lt;/p&gt;&lt;p&gt;אפשרות זו מכסה רק את הגישה לססמה של רשומה. לקוחות יכולו תמיד לספרר את פריטי מסדי־נתונים החשופים ולתשאל את התכונות שלהם.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Confirm when passwords are retrieved by clients</source>
        <translation>אישור כשלקוחות מאחזרים ססמאות</translation>
    </message>
    <message>
        <source>Confirm when clients request entry deletion</source>
        <translation>אשור כאשר לקוחות מבקשים מחיקת רשומה</translation>
    </message>
    <message>
        <source>Prompt to unlock database before searching</source>
        <translation>הנחיה לשחרור נעילת מסד־נתונים לפני חיפוש</translation>
    </message>
    <message>
        <source>Exposed database groups:</source>
        <translation>קבוצות מסדי־נתונים חשופות:</translation>
    </message>
    <message>
        <source>Authorization</source>
        <translation>הרשאות</translation>
    </message>
    <message>
        <source>These applications are currently connected:</source>
        <translation>יישומים אלה מחוברים כעת:</translation>
    </message>
    <message>
        <source>&lt;b&gt;Warning:&lt;/b&gt; </source>
        <translation>&lt;b&gt;אזהרה:&lt;/b&gt; </translation>
    </message>
    <message>
        <source>Save current changes to activate the plugin and enable editing of this section.</source>
        <translation>שמירת השינויים הנוכחיים כדי להפעיל את המתקע ולאפשר עריכת מקטע זה.</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;This setting does not override disabling recycle bin prompts &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;הגדרה זו does not לא עוקפת השבתת השבתת הנחיות סל מחזור &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;This improves compatibility with certain applications which search for password without unlocking the database first.&lt;/p&gt;&lt;p&gt;But enabling this may also crash the client if the database can not be unlocked within a certain timeout. (Usually 25s, but may be a different value set in applications.) &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;משפר תאימות עם יישומים מסוימים שמחפשים ססמה מבלי לשחרר את נעילת מסד הנתונים תחילה.&lt;/p&gt;&lt;p&gt;אבל הפעלת אפשרות זו עשויה גם לגרום ללקוח לקרוס אם נעילת מסד הנתונים ישתחרר בתוך פרק זמן מסוים. (בדרך כלל 25 שניות, אך עשוי להיות ערך שונה שהוגדר ביישומים.) &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
</context>
<context>
    <name>SettingsWidgetKeeShare</name>
    <message>
        <source>Active</source>
        <translation>פעיל</translation>
    </message>
    <message>
        <source>Allow KeeShare imports</source>
        <translation>איפשור ייבוא KeeShare</translation>
    </message>
    <message>
        <source>Allow import</source>
        <translation>איפשור ייבוא</translation>
    </message>
    <message>
        <source>Allow KeeShare exports</source>
        <translation>איפשור ייצוא KeeShare</translation>
    </message>
    <message>
        <source>Allow export</source>
        <translation>איפשור ייצוא</translation>
    </message>
    <message>
        <source>Only show warnings and errors</source>
        <translation>הצגת אזהרות ושגיאות בלבד</translation>
    </message>
    <message>
        <source>Own certificate</source>
        <translation>אישור עצמי</translation>
    </message>
    <message>
        <source>Signer:</source>
        <translation>חותם:</translation>
    </message>
    <message>
        <source>Generate new certificate</source>
        <translation>חילול אישור חדש</translation>
    </message>
    <message>
        <source>Generate</source>
        <translation>חילול</translation>
    </message>
    <message>
        <source>Fingerprint:</source>
        <translation>טביעות אצבע:</translation>
    </message>
    <message>
        <source>Signer name field</source>
        <translation>שדה שם חותם</translation>
    </message>
    <message>
        <source>Fingerprint</source>
        <translation>טביעות אצבע</translation>
    </message>
</context>
<context>
    <name>ShareExport</name>
    <message>
        <source>Could not write export container.</source>
        <translation>לא ניתן לכתוב מיכל ייצוא.</translation>
    </message>
</context>
<context>
    <name>ShareImport</name>
    <message>
        <source>Successful import</source>
        <translation>ייבוא צלח</translation>
    </message>
</context>
<context>
    <name>ShareObserver</name>
    <message>
        <source>Import from %1 failed (%2)</source>
        <translation>ייבוא מ־%1 כשל (%2)</translation>
    </message>
    <message>
        <source>Import from %1 successful (%2)</source>
        <translation>הייבוא מ־%1 צלח (%2)</translation>
    </message>
    <message>
        <source>Imported from %1</source>
        <translation>מיובא מ־%1</translation>
    </message>
    <message>
        <source>Multiple import source path to %1 in %2</source>
        <translation>נתיבי מקור ייבוא מרובים ל־%1 ב־%2</translation>
    </message>
    <message>
        <source>Conflicting export target path %1 in %2</source>
        <translation>התנגשות בנתיב יעד ייצוא %1 ב־ %2</translation>
    </message>
    <message>
        <source>Export to %1 failed (%2)</source>
        <translation>ייצוא ל־%1 כשל (%2)</translation>
    </message>
    <message>
        <source>Export to %1 successful (%2)</source>
        <translation>הייצוא ל־%1 צלח (%2)</translation>
    </message>
    <message>
        <source>Export to %1</source>
        <translation>ייצוא ל־%1</translation>
    </message>
</context>
<context>
    <name>TagModel</name>
    <message>
        <source>Clear Search</source>
        <translation>ניקוי חיפוש</translation>
    </message>
    <message>
        <source>All Entries</source>
        <translation>כל הרשומות</translation>
    </message>
    <message>
        <source>Expired</source>
        <translation>תפוגה</translation>
    </message>
    <message>
        <source>Weak Passwords</source>
        <translation>ססמאות חלשות</translation>
    </message>
    <message>
        <source>TOTP Entries</source>
        <translation>רשומות TOTP</translation>
    </message>
</context>
<context>
    <name>TagView</name>
    <message>
        <source>Remove Search</source>
        <translation>הסרת חיפוש</translation>
    </message>
    <message>
        <source>Remove Tag</source>
        <translation>הסרת תג</translation>
    </message>
    <message>
        <source>Confirm Remove Tag</source>
        <translation>אישור הסרת תג</translation>
    </message>
    <message>
        <source>Remove tag &quot;%1&quot; from all entries in this database?</source>
        <translation>להסיר תג &apos;%1&apos; מכול הרשומות במסד־נתונים זה? </translation>
    </message>
</context>
<context>
    <name>TextAttachmentsEditWidget</name>
    <message>
        <source>Preview</source>
        <translation>תצוגה מקדימה</translation>
    </message>
</context>
<context>
    <name>TextAttachmentsPreviewWidget</name>
    <message>
        <source>Form</source>
        <translation>טופס</translation>
    </message>
    <message>
        <source>Type:</source>
        <translation>סוג:</translation>
    </message>
</context>
<context>
    <name>TotpDialog</name>
    <message>
        <source>Timed Password</source>
        <translation>ססמה מתוזמנת</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>עותק</translation>
    </message>
    <message numerus="yes">
        <source>Expires in &lt;b&gt;%n&lt;/b&gt; second(s)</source>
        <translation><numerusform>תפוגה &lt;b&gt;בתוך שניה %n&lt;/b&gt;</numerusform><numerusform>תפוגה &lt;b&gt;בתוך %n&lt;/b&gt; שניות</numerusform><numerusform>תפוגה &lt;b&gt;בתוך %n&lt;/b&gt; שניות</numerusform></translation>
    </message>
</context>
<context>
    <name>TotpExportSettingsDialog</name>
    <message>
        <source>Copy</source>
        <translation>עותק</translation>
    </message>
    <message>
        <source>NOTE: These TOTP settings are custom and may not work with other authenticators.</source>
        <comment>TOTP QR code dialog warning</comment>
        <translation>הערה: הגדרות TOTP אלה מותאמות אישית וייתכן שלא יפעלו עם מאמתים אחרים.</translation>
    </message>
    <message>
        <source>There was an error creating the QR code.</source>
        <translation>אירעה שגיאה בעת יצירת קוד ה־QR.</translation>
    </message>
    <message>
        <source>Closing in %1 seconds.</source>
        <translation>סגירה בעוד %1 שניות.</translation>
    </message>
</context>
<context>
    <name>TotpSetupDialog</name>
    <message>
        <source>Setup TOTP</source>
        <translation>הגדרת TOTP</translation>
    </message>
    <message>
        <source>Secret Key:</source>
        <translation>מפתח סודי:</translation>
    </message>
    <message>
        <source>Secret key must be in Base32 format</source>
        <translation>מפתח סודי חייב להיות בתסדיר Base32</translation>
    </message>
    <message>
        <source>Secret key field</source>
        <translation>שדה מפתח סודי</translation>
    </message>
    <message>
        <source>Default settings (RFC 6238)</source>
        <translation>הגדרות ברירת מחדל (RFC 6238)</translation>
    </message>
    <message>
        <source>Steam® settings</source>
        <translation>הגדרות Steam®</translation>
    </message>
    <message>
        <source>Custom settings:</source>
        <translation>הגדרות מותאמות אישית:</translation>
    </message>
    <message>
        <source>Custom Settings</source>
        <translation>הגדרות מותאמות אישית</translation>
    </message>
    <message>
        <source>Algorithm:</source>
        <translation>אלגוריתם:</translation>
    </message>
    <message>
        <source>Time step:</source>
        <translation>שלב זמן:</translation>
    </message>
    <message>
        <source>Time step field</source>
        <translation>שדה חותמת זמן</translation>
    </message>
    <message>
        <source> sec</source>
        <comment>Seconds</comment>
        <translation> שניה</translation>
    </message>
    <message>
        <source>Code size:</source>
        <translation>גודל קוד:</translation>
    </message>
    <message>
        <source> digits</source>
        <translation> ספרות</translation>
    </message>
    <message>
        <source>Invalid TOTP Secret</source>
        <translation>סוד TOTP לא תקין</translation>
    </message>
    <message>
        <source>You have entered an invalid secret key. The key must be in Base32 format.
Example: JBSWY3DPEHPK3PXP</source>
        <translation>הוזן מפתח סודי לא תקין. המפתח חייב להיות בתסדיר Base32.
דוגמה: JBSWY3DPEHPK3PXP</translation>
    </message>
    <message>
        <source>Confirm Remove TOTP Settings</source>
        <translation>אישור הסרת הגדרות TOTP</translation>
    </message>
    <message>
        <source>Are you sure you want to delete TOTP settings for this entry?</source>
        <translation>האם למחוק הגדרות TOTP לרשומות זו?</translation>
    </message>
    <message>
        <source>Error: secret key is invalid</source>
        <translation>שגיאה: מפתח סודי לא תקין</translation>
    </message>
</context>
<context>
    <name>URLEdit</name>
    <message>
        <source>Invalid URL</source>
        <translation>מען URL תקין</translation>
    </message>
</context>
<context>
    <name>UpdateCheckDialog</name>
    <message>
        <source>Checking for updates</source>
        <translation>בדיקת זמינות עדכונים</translation>
    </message>
    <message>
        <source>Checking for updates…</source>
        <translation>בודקת זמינות עדכונים...</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>סגירה</translation>
    </message>
    <message>
        <source>Software Update</source>
        <translation>עדכון תוכנה</translation>
    </message>
    <message>
        <source>An error occurred when trying to retrieve update information, please try again later.</source>
        <translation>אירעה שגיאה בעת ניסיון לאחזר מידע עדכון, נא לנסות שוב מאוחר יותר.</translation>
    </message>
    <message>
        <source>&lt;strong&gt;A new version is available.&lt;/strong&gt;&lt;br/&gt;KeePassXC %1 can be &lt;a href=&quot;https://keepassxc.org/download/&quot;&gt;downloaded here&lt;/a&gt;.</source>
        <translation>&lt;strong&gt;גרסה חדשה זמינה.&lt;/strong&gt;&lt;br/&gt;ניתן &lt;a href=&quot;https://keepassxc.org/download/&quot;&gt;להוריד כאן את&lt;/a&gt;KeePassXC %1 .</translation>
    </message>
    <message>
        <source>You have the latest version of KeePassXC</source>
        <translation>זוהי הגרסה העדכנית ביותר של KeePassXC</translation>
    </message>
</context>
<context>
    <name>WelcomeWidget</name>
    <message>
        <source>Start storing your passwords securely in a KeePassXC database</source>
        <translation>ניתן להתחיל ולאחסן את הססמאות בצורה מאובטחת במסד נתוני KeePassXC</translation>
    </message>
    <message>
        <source>Recent databases</source>
        <translation>מסדי־נתונים אחרונים</translation>
    </message>
    <message>
        <source>Open a recent database</source>
        <translation>פתיחת מסד־נתונים קודם</translation>
    </message>
    <message>
        <source>Welcome to KeePassXC %1</source>
        <translation>ברוכים הבאים ל-KeePassXC %1</translation>
    </message>
    <message>
        <source>Create Database</source>
        <translation>יצירת מסד נתונים</translation>
    </message>
    <message>
        <source>Open Database</source>
        <translation>פתיחת מסד נתונים</translation>
    </message>
    <message>
        <source>Import File</source>
        <translation>ייבוא קובץ</translation>
    </message>
</context>
<context>
    <name>WinUtils</name>
    <message>
        <source>Invalid key code</source>
        <translation>קוד מפתח לא תקין</translation>
    </message>
    <message>
        <source>Global shortcut already registered to %1</source>
        <translation>קיצור דרך כללי כבר רשום ב־%1</translation>
    </message>
    <message>
        <source>Could not register global shortcut</source>
        <translation>לא ניתן לרשום קיצור דרך כללי</translation>
    </message>
</context>
<context>
    <name>YubiKey</name>
    <message>
        <source>Could not find hardware key with serial number %1. Please connect it to continue.</source>
        <translation>לא ניתן למצוא מפתח חומרה עם מספר סידורי %1. נא לחברו כדי להמשיך.</translation>
    </message>
</context>
<context>
    <name>YubiKeyEditWidget</name>
    <message>
        <source>Hardware key slot selection</source>
        <translation>בחירת עמדה למפתח חומרה</translation>
    </message>
    <message>
        <source>Could not find any hardware keys!</source>
        <translation>לא ניתן למצוא מפתחות חומרה!</translation>
    </message>
    <message>
        <source>Selected hardware key slot does not support challenge-response!</source>
        <translation>חריץ מפתח החומרה שנבחר לא תומך באתגר־מענה!</translation>
    </message>
    <message>
        <source>Challenge-Response</source>
        <translation>אתגר־מענה</translation>
    </message>
    <message>
        <source>Add Challenge-Response</source>
        <translation>הוספת אתגר־מענה</translation>
    </message>
    <message>
        <source>Change Challenge-Response</source>
        <translation>שינוי אתגר־מענה</translation>
    </message>
    <message>
        <source>Remove Challenge-Response</source>
        <translation>הסרת אתגר־מענה</translation>
    </message>
    <message>
        <source>Challenge-Response set, click to change or remove</source>
        <translation>ערכת אתגר־מענה, הקשה לשנוי או הסרה</translation>
    </message>
    <message>
        <source>Detecting hardware keys…</source>
        <translation>זוהה מפתח חומרה...</translation>
    </message>
    <message>
        <source>No hardware keys detected</source>
        <translation>לא זוהה מפתח חומרה</translation>
    </message>
    <message>
        <source>Refresh hardware keys</source>
        <translation>רענון מפתחות חומרה</translation>
    </message>
    <message>
        <source>&lt;p&gt;If you own a &lt;a href=&quot;https://www.yubico.com/&quot;&gt;YubiKey&lt;/a&gt; or &lt;a href=&quot;https://onlykey.io&quot;&gt;OnlyKey&lt;/a&gt;, you can use it for additional security.&lt;/p&gt;&lt;p&gt;The key requires one of its slots to be programmed with &lt;a href=&quot;https://keepassxc.org/docs/#faq-yubikey-howto&quot;&gt;Challenge-Response&lt;/a&gt;.&lt;/p&gt;</source>
        <translation>&lt;p&gt;אם קיים &lt;a href=&quot;https://www.yubico.com/&quot;&gt;YubiKey&lt;/a&gt; או &lt;a href=&quot;https://onlykey.io&quot;&gt;OnlyKey&lt;/a&gt;, ניתן להשתמש בו לאבטחה נוספת.&lt;/p&gt;&lt;p&gt;המפתח דורש שאחד החריצים שלו יהיה מתוכנת עם &lt;a href=&quot;https://keepassxc.org/docs/#faq-yubikey-howto&quot;&gt;אתגר־מענה&lt;/a&gt;.&lt;/p&gt;</translation>
    </message>
    <message>
        <source>Hardware keys found, but no slots are configured</source>
        <translation>נמצאו מפתחות חומרה, אבל לא הוגדרו חריצים</translation>
    </message>
</context>
<context>
    <name>YubiKeyInterfacePCSC</name>
    <message>
        <source>Hardware key is locked or timed out. Unlock or re-present it to continue.</source>
        <translation>מפתח חומרה נעול או שפסק־הזמן חלף. נא לשחרר נעילה או להציגו שוב על מנת להמשיך.</translation>
    </message>
    <message>
        <source>Hardware key was not found or is not configured.</source>
        <translation>מפתח חומרה לא נמצא או שאינו מתוצר.</translation>
    </message>
    <message>
        <source>(NFC) %1 [%2] - Slot %3, %4</source>
        <comment>YubiKey display fields</comment>
        <translation>(NFC) %1 [%2] - חריץ %3, %4</translation>
    </message>
    <message>
        <source>Press</source>
        <comment>USB Challenge-Response Key interaction request</comment>
        <translation>לחיצה</translation>
    </message>
    <message>
        <source>Passive</source>
        <comment>USB Challenge-Response Key no interaction required</comment>
        <translation>סביל</translation>
    </message>
    <message>
        <source>The YubiKey PC/SC interface has not been initialized.</source>
        <translation>מנשק YubiKey PC/SC לא איתחל.</translation>
    </message>
    <message>
        <source>Failed to complete a challenge-response, the PC/SC error code was: %1</source>
        <translation>השלמת אתגר־מענה כשלה,קוד שגיאת PC/SC הייתה: %1</translation>
    </message>
</context>
<context>
    <name>YubiKeyInterfaceUSB</name>
    <message>
        <source>Press</source>
        <comment>USB Challenge-Response Key interaction request</comment>
        <translation>לחיצה</translation>
    </message>
    <message>
        <source>Passive</source>
        <comment>USB Challenge-Response Key no interaction required</comment>
        <translation>סביל</translation>
    </message>
    <message>
        <source>The YubiKey USB interface has not been initialized.</source>
        <translation>מנשק USB YubiKey לא אותחל.</translation>
    </message>
    <message>
        <source>Could not find hardware key with serial number %1. Please plug it in to continue.</source>
        <translation>לא ניתן למצוא מפתח חומרה עם המספר הסידורי %1. נא לחבר אותו כדי להמשיך.</translation>
    </message>
    <message>
        <source>Hardware key timed out waiting for user interaction.</source>
        <translation>פסק־זמן מפתח חומרה בהמתנה להידוד המשתמש.</translation>
    </message>
    <message>
        <source>A USB error occurred when accessing the hardware key: %1</source>
        <translation>אירעה שגיאת USB בעת גישה למפתח החומרה: %1</translation>
    </message>
    <message>
        <source>Failed to complete a challenge-response, the specific error was: %1</source>
        <translation>השלמת אתגר־מענה כשלה, השגיאה המסוימת היתה: %1</translation>
    </message>
    <message>
        <source>%1 [%2] - Slot %3</source>
        <comment>YubiKey NEO display fields</comment>
        <translation>%1 [%2] - חריץ %3</translation>
    </message>
    <message>
        <source>%1 [%2] - Slot %3, %4</source>
        <comment>YubiKey display fields</comment>
        <translation>%1 [%2] - חריץ %3, %4</translation>
    </message>
    <message>
        <source>Unknown</source>
        <comment>Unknown hardware key name</comment>
        <translation>לא ידוע</translation>
    </message>
</context>
</TS>
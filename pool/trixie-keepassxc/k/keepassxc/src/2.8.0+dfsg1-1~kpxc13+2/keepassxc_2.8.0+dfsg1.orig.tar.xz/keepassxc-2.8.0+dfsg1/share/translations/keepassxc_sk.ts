<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="sk">
<context>
    <name>AboutDialog</name>
    <message>
        <source>About KeePassXC</source>
        <translation>O KeepassXC</translation>
    </message>
    <message>
        <source>About</source>
        <translation>O aplikácii</translation>
    </message>
    <message>
        <source>Report bugs at: &lt;a href=&quot;https://github.com/keepassxreboot/keepassxc/issues&quot; style=&quot;text-decoration: underline;&quot;&gt;https://github.com&lt;/a&gt;</source>
        <translation>Chyby hláste na: &lt;a href=&quot;https://github.com/keepassxreboot/keepassxc/issues&quot; style=&quot;text-decoration: underline;&quot;&gt;https://github.com&lt;/a&gt;</translation>
    </message>
    <message>
        <source>KeePassXC is distributed under the terms of the GNU General Public License (GPL) version 2 or (at your option) version 3.</source>
        <translation>KeePassXC je distribuovaný za podmienok GNU General Public License (GPL) verzie 2 alebo (podľa Vášho výberu) verzie 3.</translation>
    </message>
    <message>
        <source>Project Maintainers:</source>
        <translation>Správcovia projektu:</translation>
    </message>
    <message>
        <source>Special thanks from the KeePassXC team go to debfx for creating the original KeePassX.</source>
        <translation>Špeciálne poďakovanie od tímu KeePassXC patrí debfx za vytvorenie pôvodného KeePassX.</translation>
    </message>
    <message>
        <source>Contributors</source>
        <translation>K vývoju prispeli</translation>
    </message>
    <message>
        <source>&lt;a href=&quot;https://github.com/keepassxreboot/keepassxc/graphs/contributors&quot;&gt;See Contributions on GitHub&lt;/a&gt;</source>
        <translation>&lt;a href=&quot;https://github.com/keepassxreboot/keepassxc/graphs/contributors&quot;&gt;Viď prispievateľov na GitHub&lt;/a&gt;</translation>
    </message>
    <message>
        <source>Debug Info</source>
        <translation>Ladiace informácie</translation>
    </message>
    <message>
        <source>Include the following information whenever you report a bug:</source>
        <translation>Do každého hlásenia chyby zahrňte nasledujúce informácie:</translation>
    </message>
    <message>
        <source>Copy to clipboard</source>
        <translation>Kopírovať do schránky</translation>
    </message>
</context>
<context>
    <name>AccessControlDialog</name>
    <message>
        <source>KeePassXC -  Access Request</source>
        <translation>KeePassXC – Žiadosť o prístup</translation>
    </message>
    <message>
        <source>Non-existing/inaccessible executable path. Please double-check the client is legit.</source>
        <translation>Cesta k súboru neexistuje alebo nieje dostupná. Prosím, uistite sa či je klient pravý.</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;%1 &lt;/span&gt;is requesting access to the following entries:&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;%1 &lt;/span&gt;žiada o prístup k týmto položkám:&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Názov</translation>
    </message>
    <message>
        <source>PID</source>
        <translation>PID</translation>
    </message>
    <message>
        <source>Executable</source>
        <translation>Spustiteľný súbor</translation>
    </message>
    <message>
        <source>Command Line</source>
        <translation>Príkazový riadok</translation>
    </message>
    <message>
        <source>Details</source>
        <translation>Podrobnosti</translation>
    </message>
    <message>
        <source>Your decision will be remembered for the duration while both the requesting client AND KeePassXC are running.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Remember</source>
        <translation>Zapamätať</translation>
    </message>
    <message>
        <source>Allow Selected</source>
        <translation>Povoliť vybraným</translation>
    </message>
    <message>
        <source>Deny All &amp;&amp; Future</source>
        <translation>Odmietnuť všetko &amp;&amp; Budúce</translation>
    </message>
    <message>
        <source>Allow All &amp;&amp; &amp;Future</source>
        <translation>Povoliť všetko &amp;&amp; Budúce</translation>
    </message>
</context>
<context>
    <name>AccessControlDialog::DenyButton</name>
    <message>
        <source>Deny for this program</source>
        <translation>Zakázať pre tento program</translation>
    </message>
</context>
<context>
    <name>AgentSettingsWidget</name>
    <message>
        <source>Enable SSH Agent integration</source>
        <translation>Zapnúť integráciu Agenta SSH</translation>
    </message>
    <message>
        <source>Use Pageant</source>
        <translation>Použiť Pageant</translation>
    </message>
    <message>
        <source>Use OpenSSH</source>
        <translation>Použiť OpenSSH</translation>
    </message>
    <message>
        <source>Use both agents</source>
        <translation>Použiť oboch agentov</translation>
    </message>
    <message>
        <source>SSH_AUTH_SOCK override</source>
        <translation>Prepísanie SSH_AUTH_SOCK</translation>
    </message>
    <message>
        <source>SSH_AUTH_SOCK value</source>
        <translation>Hodnota SSH_AUTH_SOCK</translation>
    </message>
    <message>
        <source>(empty)</source>
        <translation>(prázdne)</translation>
    </message>
    <message>
        <source>SSH_SK_PROVIDER value</source>
        <translation>Hodnota SSH_SK_PROVIDER</translation>
    </message>
    <message>
        <source>SSH_SK_PROVIDER override</source>
        <translation>Prepísanie SSH_SK_PROVIDER</translation>
    </message>
    <message>
        <source>No SSH Agent socket available. Either make sure SSH_AUTH_SOCK environment variable exists or set an override.</source>
        <translation>Nie je dostupný socket Agenta SSH. Buď zaistite existenciu premennej prostredia SSH_AUTH_SOCK alebo nastavte prepísanie.</translation>
    </message>
    <message>
        <source>SSH Agent connection is working!</source>
        <translation>Spojenie Agenta SSH funkčné!</translation>
    </message>
</context>
<context>
    <name>AppKit</name>
    <message>
        <source>Window</source>
        <translation>Okno</translation>
    </message>
    <message>
        <source>Minimize</source>
        <translation>Minimalizovať</translation>
    </message>
    <message>
        <source>Zoom</source>
        <translation>Priblíženie</translation>
    </message>
    <message>
        <source>Bring All to Front</source>
        <translation>Preniesť všetko do popredia</translation>
    </message>
</context>
<context>
    <name>ApplicationSettingsWidget</name>
    <message>
        <source>Application Settings</source>
        <translation>Nastavenia aplikácie</translation>
    </message>
    <message>
        <source>General</source>
        <translation>Všeobecné</translation>
    </message>
    <message>
        <source>Security</source>
        <translation>Bezpečnosť</translation>
    </message>
    <message>
        <source>This setting cannot be enabled when minimize on unlock is enabled.</source>
        <translation>Toto nastavenie nemožno zapnúť, keď je zapnuté minimalizovať pri odomknutí.</translation>
    </message>
    <message>
        <source>Access error for config file %1</source>
        <translation>Chyba prístupu ku konfiguračnému súboru %1</translation>
    </message>
    <message>
        <source>Icon only</source>
        <translation>Len ikona</translation>
    </message>
    <message>
        <source>Text only</source>
        <translation>Len text</translation>
    </message>
    <message>
        <source>Text beside icon</source>
        <translation>Text vedľa ikony</translation>
    </message>
    <message>
        <source>Text under icon</source>
        <translation>Text pod ikonou</translation>
    </message>
    <message>
        <source>Follow style</source>
        <translation>Štýl nasledovania</translation>
    </message>
    <message>
        <source>Monochrome</source>
        <translation>Monochromatické</translation>
    </message>
    <message>
        <source>Monochrome (light)</source>
        <translation>Monochromatický (svetlé)</translation>
    </message>
    <message>
        <source>Monochrome (dark)</source>
        <translation>Monochromatický (tmavé)</translation>
    </message>
    <message>
        <source>Colorful</source>
        <translation>Farebné</translation>
    </message>
    <message>
        <source>You must restart the application to set the new language. Would you like to restart now?</source>
        <translation>Musíte reštartovať aplikáciu, aby sa tieto zmeny prejavili. Chcete ju reštartovať teraz?</translation>
    </message>
    <message>
        <source>Select backup storage directory</source>
        <translation>Vyberte priečinok pre uloženie zálohy</translation>
    </message>
    <message>
        <source>Confirm Reset</source>
        <translation>Potvrdiť Reset</translation>
    </message>
    <message>
        <source>Are you sure you want to reset all settings to default?</source>
        <translation>Ste si istý, že chcete resetovať všetky nastavenia na pôvodné?</translation>
    </message>
    <message>
        <source>Import KeePassXC Settings</source>
        <translation>Importovať nastavenia KeepassXC</translation>
    </message>
    <message>
        <source>Failed to import settings from %1, not a valid settings file.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Export KeePassXC Settings</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Small</source>
        <translation>Malé</translation>
    </message>
    <message>
        <source>Normal</source>
        <translation>Normálne</translation>
    </message>
    <message>
        <source>Medium</source>
        <translation>Stredné</translation>
    </message>
    <message>
        <source>Large</source>
        <translation>Veľké</translation>
    </message>
    <message>
        <source>Custom</source>
        <translation>Vlastné</translation>
    </message>
    <message>
        <source>None</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Restart KeePassXC to apply the Auto-Type desktop portals preference.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>This setting is managed by your organization.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>ApplicationSettingsWidgetGeneral</name>
    <message>
        <source>Basic Settings</source>
        <translation>Základné nastavenia</translation>
    </message>
    <message>
        <source>Startup</source>
        <translation>Štart</translation>
    </message>
    <message>
        <source>Start only a single instance of KeePassXC</source>
        <translation>Spustiť len jednu inštanciu KeePassXC</translation>
    </message>
    <message>
        <source>Automatically launch KeePassXC at system startup</source>
        <translation>Automaticky spustiť KeePassXC pri štarte systému</translation>
    </message>
    <message>
        <source>Minimize window at application startup</source>
        <translation>Minimalizovať okno pri spustení aplikácie</translation>
    </message>
    <message>
        <source>Minimize window after unlocking database</source>
        <translation>Minimalizovať okno po odomknutí databázy</translation>
    </message>
    <message>
        <source>Remember previously used databases</source>
        <translation>Zapamätať si predtým používané databázy</translation>
    </message>
    <message>
        <source> recent files</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Load previously open databases on startup</source>
        <translation>Načítanie predtým otvorených databáz pri spustení</translation>
    </message>
    <message>
        <source>Remember database key files and security dongles</source>
        <translation>Zapamätať databázové kľúčové súbory a zabezpečovacie HW kľúče</translation>
    </message>
    <message>
        <source>Check for updates at application startup once per week</source>
        <translation>Pri štarte skontrolovať aktualizácie raz týždenne</translation>
    </message>
    <message>
        <source>Include beta releases when checking for updates</source>
        <translation>Pri kontrole aktualizácii zahrnúť pred-vydania</translation>
    </message>
    <message>
        <source>File Management</source>
        <translation>Správa súborov</translation>
    </message>
    <message>
        <source>Automatically save after every change</source>
        <translation>Automaticky uložiť po každej zmene</translation>
    </message>
    <message>
        <source>Automatically save when locking database</source>
        <translation>Pri zamknutí databázy automaticky uložiť</translation>
    </message>
    <message>
        <source>Automatically save non-data changes when locking database</source>
        <translation>Pri zamknutí databázy automaticky uložiť nedátové zmeny</translation>
    </message>
    <message>
        <source>Automatically reload the database when modified externally</source>
        <translation>Automaticky načítať databázu, ak je upravená externe</translation>
    </message>
    <message>
        <source>Backup database file before saving</source>
        <translation>Zálohovať databázu pri každom uložení</translation>
    </message>
    <message>
        <source>{DB_FILENAME}.old.kdbx</source>
        <translation>{MENO_SÚBORU_DB}.old.kdbx</translation>
    </message>
    <message>
        <source>Use alternative saving method (may solve problems with Dropbox, Google Drive, GVFS, etc.)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Temporary file moved into place</source>
        <translation>Dočasný súbor presunutý na miesto</translation>
    </message>
    <message>
        <source>Directly write to database file (dangerous)</source>
        <translation>Priamo zapisovať do databázy (nebezpečné)</translation>
    </message>
    <message>
        <source>Entry Management</source>
        <translation>Správa položky</translation>
    </message>
    <message>
        <source>Use group icon on entry creation</source>
        <translation>Použiť  ikonu skupiny pri vytváraní položky</translation>
    </message>
    <message>
        <source>Minimize when opening a URL</source>
        <translation>Minimalizovať pri otvorení URL</translation>
    </message>
    <message>
        <source>Hide window when copying to clipboard</source>
        <translation>Skryť okno pri kopírovaní do schránky</translation>
    </message>
    <message>
        <source>Minimize</source>
        <translation>Minimalizovať</translation>
    </message>
    <message>
        <source>Drop to background</source>
        <translation>Poslať do pozadia</translation>
    </message>
    <message>
        <source>Favicon download timeout:</source>
        <translation>Časový limit stiahnutia ikony:</translation>
    </message>
    <message>
        <source>Website icon download timeout in seconds</source>
        <translation>Časový limit stiahnutia ikony v sekundách</translation>
    </message>
    <message>
        <source> sec</source>
        <comment>Seconds</comment>
        <translation>s</translation>
    </message>
    <message>
        <source>User Interface</source>
        <translation>Používateľské rozhranie</translation>
    </message>
    <message>
        <source>Toolbar button style</source>
        <translation>Štýl tlačidiel panela nástrojov</translation>
    </message>
    <message>
        <source>Movable toolbar</source>
        <translation>Presúvateľný panel nástrojov</translation>
    </message>
    <message>
        <source>Language selection</source>
        <translation>Výber jazyka</translation>
    </message>
    <message>
        <source>Language:</source>
        <translation>Jazyk:</translation>
    </message>
    <message>
        <source>(restart program to activate)</source>
        <translation>(reštartovať program kvôli aktivácii)</translation>
    </message>
    <message>
        <source>Toolbar button style:</source>
        <translation>Štýl tlačidiel panela nástrojov:</translation>
    </message>
    <message>
        <source>Show passwords in color</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Use monospaced font for notes</source>
        <translation>Na poznámky použiť písmo Monospace</translation>
    </message>
    <message>
        <source>Minimize instead of app exit</source>
        <translation>Minimalizovať namiesto ukončenia</translation>
    </message>
    <message>
        <source>Show a system tray icon</source>
        <translation>Zobraziť ikonu v oznamovacej oblasti</translation>
    </message>
    <message>
        <source>Tray icon type</source>
        <translation>Typ ikona oznamovacej oblasti</translation>
    </message>
    <message>
        <source>Tray icon type:</source>
        <translation>Ikona oznamovacej oblasti:</translation>
    </message>
    <message>
        <source>Hide window to system tray when minimized</source>
        <translation>Skryť okno do oznamovacej oblasti pri minimalizácii</translation>
    </message>
    <message>
        <source>Reset settings to default…</source>
        <translation>Obnoviť predvolené nastavenia</translation>
    </message>
    <message>
        <source>Auto-Type</source>
        <translation>Automatické vypĺňanie</translation>
    </message>
    <message>
        <source>Use entry title to match windows for global Auto-Type</source>
        <translation>Použiť názov položky na zhodu okna pre globálne Automatické vypĺňanie</translation>
    </message>
    <message>
        <source>Use entry URL to match windows for global Auto-Type</source>
        <translation>Použiť URL položky na zhodu okna pre globálne Automatické vypĺňanie</translation>
    </message>
    <message>
        <source>Always ask before performing Auto-Type</source>
        <translation>Vždy sa spýtať pred vykonaním Automatického vypĺňania</translation>
    </message>
    <message>
        <source>Hide expired entries from Auto-Type</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Re-lock previously locked database after performing Auto-Type</source>
        <translation>Znova zamknúť predtým zamknutú databázu po vykonaní Automatického vypĺňania</translation>
    </message>
    <message>
        <source>Auto-Type start delay:</source>
        <translation>Oneskorenia spustenia Automatického vypĺňania:</translation>
    </message>
    <message>
        <source>Global Auto-Type shortcut:</source>
        <translation>Globálna klávesová skratka Automatického vypĺňania:</translation>
    </message>
    <message>
        <source>Auto-type start delay milliseconds</source>
        <translation>Oneskorenia spustenia Automatického vypĺňania v milisekundách</translation>
    </message>
    <message>
        <source> ms</source>
        <comment>Milliseconds</comment>
        <translation> ms</translation>
    </message>
    <message>
        <source>Auto-Type typing delay:</source>
        <translation>Oneskorenie Automatického vypĺňania:</translation>
    </message>
    <message>
        <source>Global auto-type shortcut</source>
        <translation>Globálna klávesová skratka Automatického vypĺňania</translation>
    </message>
    <message>
        <source>Auto-type character typing delay milliseconds</source>
        <translation>Oneskorenie Automatického vypĺňania znakov v milisekundách</translation>
    </message>
    <message>
        <source>Remember last typed entry for:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>On database unlock, show entries that will expire within</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>On database unlock, show entries that will expire within </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source> days</source>
        <comment>number of days warning for password expiration</comment>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Destination format:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;{DB_FILENAME}&lt;/span&gt; is replaced with the filename of the saved database without extension&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;{TIME:&amp;lt;format&amp;gt;}&lt;/span&gt; is replaced with the specified time format (default: dd_MM_yyyy_hh-mm-ss)&lt;/p&gt;&lt;p&gt;See the User Guide for more details&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Choose folder...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Show confirmation before moving entries to recycle bin</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Copy data on double clicking field in entry view</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Show toolbar</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Show the menu bar by pressing the Alt key</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Show menubar</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Import settings…</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Export settings…</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Font size:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Font size selection</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Skip confirmation for main window Auto-Type actions</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Double-click action for URL:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Double-click action for URL field</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Edit entry</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Open entry URL in browser</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Copy entry URL to clipboard</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Auto-generate password for new entries</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Keep remote desktop connection open after performing Auto-Type</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Remote desktop mode:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Never remember session</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Remember session until exit</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Remember session until revoked by desktop</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>None</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Configure...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Use remote desktop for clipboard access</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Experimental: Prefer desktop portals (Wayland implementation)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Show autocomplete suggestions for username and additional attributes</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>ApplicationSettingsWidgetSecurity</name>
    <message>
        <source>Timeouts</source>
        <translation>Časové limity</translation>
    </message>
    <message>
        <source>Database lock timeout seconds</source>
        <translation>Časový limit zamknutia databázy v sekundách</translation>
    </message>
    <message>
        <source> sec</source>
        <comment>Seconds</comment>
        <translation>s</translation>
    </message>
    <message>
        <source>Clear clipboard after</source>
        <translation>Vymazať schránku po</translation>
    </message>
    <message>
        <source>Clear search query after</source>
        <translation>Vymazať dopyt po</translation>
    </message>
    <message>
        <source> min</source>
        <comment>Minutes</comment>
        <translation> min</translation>
    </message>
    <message>
        <source>Clipboard clear seconds</source>
        <translation>Sekundy do vymazania schárnky</translation>
    </message>
    <message>
        <source>Lock databases after inactivity of</source>
        <translation>Zamknúť databázu po neaktivite</translation>
    </message>
    <message>
        <source>Convenience</source>
        <translation>Pohodlie</translation>
    </message>
    <message>
        <source>Enable database quick unlock (Touch ID / Windows Hello)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Lock databases when session is locked or lid is closed</source>
        <translation>Zamknúť databázu pri zamknutí relácie alebo zatvorení krytu</translation>
    </message>
    <message>
        <source>Lock databases after minimizing the window</source>
        <translation>Zamknúť databázu pri minimalizovaní okna</translation>
    </message>
    <message>
        <source>Hide passwords when editing them</source>
        <translation>Skryť heslo pri jeho úprave</translation>
    </message>
    <message>
        <source>Use placeholder for empty password fields</source>
        <translation>Použiť zástupnú hodnotu na prázdne polia hesiel</translation>
    </message>
    <message>
        <source>Hide passwords in the entry preview panel</source>
        <translation>Skryť heslá v paneli ukážky položky </translation>
    </message>
    <message>
        <source>Privacy</source>
        <translation>Súkromie</translation>
    </message>
    <message>
        <source>Use DuckDuckGo service to download website icons</source>
        <translation>Používať služby DuckDuckGo na stiahnutie ikon webových stránok</translation>
    </message>
    <message>
        <source>Hide TOTP in the entry preview panel</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Lock databases when switching user</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Lock Options</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Hide notes in the entry preview panel</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>AttachmentWidget</name>
    <message>
        <source>Attachment Viewer</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Unknown attachment type</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>AutoType</name>
    <message>
        <source>The requested Auto-Type sequence cannot be used due to an error:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Auto-Type Error</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Permission Required</source>
        <translation>Požadované práva</translation>
    </message>
    <message>
        <source>KeePassXC requires the Accessibility permission in order to perform entry level Auto-Type. If you already granted permission, you may have to restart KeePassXC.</source>
        <translation>KeePassXC vyžaduje povolenie Prístupnosť aby mohol realizovať Automatické dopĺňanie na úrovni položky. Ak ste povolenie už pridelili, môže byť potrebné reštartovať.</translation>
    </message>
    <message>
        <source>KeePassXC requires the Accessibility and Screen Recorder permission in order to perform global Auto-Type. Screen Recording is necessary to use the window title to find entries. If you already granted permission, you may have to restart KeePassXC.</source>
        <translation>KeePassXC vyžaduje povolenie Prístupnosť a Záznam obrazovky aby mohol realizovať globálne Automatické dopĺňanie. Záznam obrazovky je potrebný na získanie názvu okna na vyhľadávanie položiek. Ak ste povolenie už pridelili, môže byť potrebné reštartovať.</translation>
    </message>
    <message>
        <source>Invalid entry provided</source>
        <translation>Zadaná neplatná položka</translation>
    </message>
    <message>
        <source>Bracket imbalance detected, found extra { or }</source>
        <translation>Zistené nerovnomerné zátvorky, nájdené naviac { alebo }</translation>
    </message>
    <message>
        <source>Too many repetitions detected, max is %1: %2</source>
        <translation>Zistených príliš veľa opakovaní, maximum je %1: %2</translation>
    </message>
    <message>
        <source>Very slow key press detected, max is %1: %2</source>
        <translation>Zistené veľmi pomalé stláčanie klávesov, maximum je %1: %2</translation>
    </message>
    <message>
        <source>Very long delay detected, max is %1: %2</source>
        <translation>Zistené príliš dlhé čakanie, maximum je %1: %2</translation>
    </message>
    <message>
        <source>Entry does not have attribute for PICKCHARS: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Invalid placeholder: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Entry has invalid TOTP settings</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>AutoTypeAssociationsModel</name>
    <message>
        <source>Window</source>
        <translation>Okno</translation>
    </message>
    <message>
        <source>Sequence</source>
        <translation>Postupnosť</translation>
    </message>
    <message>
        <source>(empty)</source>
        <translation>(prázdne)</translation>
    </message>
    <message>
        <source>Default sequence</source>
        <translation>Predvolená postupnosť</translation>
    </message>
</context>
<context>
    <name>AutoTypeMatchModel</name>
    <message>
        <source>Group</source>
        <translation>Skupina</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>Nadpis</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>Používateľské meno</translation>
    </message>
    <message>
        <source>Sequence</source>
        <translation>Postupnosť</translation>
    </message>
</context>
<context>
    <name>AutoTypePlatformWayland</name>
    <message>
        <source>No symbol found for key: &apos;%1&apos;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>No symbol found for character: &apos;%1&apos;</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>AutoTypePlatformX11</name>
    <message>
        <source>Sequence aborted: Caps Lock is on</source>
        <translation>Postupnosť zrušená: je zapnutý Caps Lock</translation>
    </message>
    <message>
        <source>Sequence aborted: Modifier keys held by user</source>
        <translation>Postupnosť zrušená, modifikátor držaný používateľom</translation>
    </message>
    <message>
        <source>Unable to get valid keycode for key: </source>
        <translation>Nemožno získať platný klávesový kód klávesy: </translation>
    </message>
    <message>
        <source>Trying to send invalid keyboard symbol.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>AutoTypeSelectDialog</name>
    <message>
        <source>Auto-Type - KeePassXC</source>
        <translation>Automatické vypĺňanie – KeePassXC</translation>
    </message>
    <message>
        <source>Double click a row to perform Auto-Type or find an entry using the search:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Search all open databases</source>
        <translation>Hľadať vo všetkých otvorených databázach</translation>
    </message>
    <message>
        <source>Search…</source>
        <translation>Hľadanie…</translation>
    </message>
    <message>
        <source>Type Sequence</source>
        <translation>Napíšte postupnosť</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Zrušiť</translation>
    </message>
    <message>
        <source>Type {USERNAME}</source>
        <translation>Zadajte {POUŽÍVATEĽ}</translation>
    </message>
    <message>
        <source>Type {PASSWORD}</source>
        <translation>Zadajte {HESLO}</translation>
    </message>
    <message>
        <source>Type {TOTP}</source>
        <translation>Zadajte {TOTP}</translation>
    </message>
    <message>
        <source>Copy Username</source>
        <translation>Kopírovať použ. meno</translation>
    </message>
    <message>
        <source>Copy Password</source>
        <translation>Kopírovať heslo</translation>
    </message>
    <message>
        <source>Copy TOTP</source>
        <translation>Kopírovať TOTP</translation>
    </message>
    <message>
        <source>Use Virtual Keyboard</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Type {URL}</source>
        <translation>Zadajte {URL}</translation>
    </message>
    <message>
        <source>Copy URL</source>
        <translation>Kopírovať URL adresu</translation>
    </message>
    <message>
        <source>&lt;p&gt;The following shortcuts are available:&lt;br/&gt;
Ctrl+F - Focus search&lt;br/&gt;
Ctrl+1 - Type username&lt;br/&gt;
Ctrl+2 - Type password&lt;br/&gt;
Ctrl+3 - Type TOTP&lt;br/&gt;
Ctrl+4 - Type URL&lt;br/&gt;
Ctrl+5 - Use Virtual Keyboard (Windows Only)&lt;br/&gt;
Ctrl+Shift+1 - Copy username&lt;br/&gt;
Ctrl+Shift+2 - Copy password&lt;br/&gt;
Ctrl+Shift+3 - Copy TOTP&lt;br/&gt;
Ctrl+Shift+4 - Copy URL&lt;br/&gt;
&lt;/p&gt;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>You can use advanced search queries to find any entry in your open databases.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>BinaryStream</name>
    <message>
        <source>Failed to read string data: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>String length exceeds 10 MiB limit (requested %1)</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>BrowserAccessControlDialog</name>
    <message>
        <source>KeePassXC - Browser Access Request</source>
        <translation>Žiadosť o prístup KeePassXC-Prehliadač</translation>
    </message>
    <message>
        <source>%1 is requesting access to the following entries:</source>
        <translation>%1 žiada prístup k nasledujúcim položkám:</translation>
    </message>
    <message>
        <source>Remember access to checked entries</source>
        <translation>Zapamätať si prístup k označeným položkám</translation>
    </message>
    <message>
        <source>Remember</source>
        <translation>Zapamätať</translation>
    </message>
    <message>
        <source>Allow access to entries</source>
        <translation>Povoliť prístup k položkám</translation>
    </message>
    <message>
        <source>Allow Selected</source>
        <translation>Povoliť vybraným</translation>
    </message>
    <message>
        <source>Deny All</source>
        <translation>Zakázať všetkým</translation>
    </message>
    <message>
        <source>Disable for this site</source>
        <translation>Zakázať tejto stránke</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>BrowserEntrySaveDialog</name>
    <message>
        <source>Ok</source>
        <translation>Ok</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Zrušiť</translation>
    </message>
    <message>
        <source>You have multiple databases open.
Please select the correct database for saving credentials.</source>
        <translation>Máte otvorených viac databáz.
Prosím, vyberte správnu databázu na uloženie prihlasovacích údajov.</translation>
    </message>
    <message>
        <source>KeePassXC - Select Database</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>BrowserPasskeysConfirmationDialog</name>
    <message>
        <source>Cancel</source>
        <translation>Zrušiť</translation>
    </message>
    <message>
        <source>Update</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Authenticate</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Register new</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Register</source>
        <translation type="unfinished"/>
    </message>
    <message numerus="yes">
        <source>Timeout in &lt;b&gt;%n&lt;/b&gt; seconds...</source>
        <translation type="unfinished"><numerusform></numerusform><numerusform></numerusform><numerusform></numerusform><numerusform></numerusform></translation>
    </message>
    <message>
        <source>Relying Party: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Username: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>KeePassXC - Passkey credentials</source>
        <translation>KeePassXC - Prístupové kľúče</translation>
    </message>
    <message>
        <source>Add to existing entry</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Existing passkey found.
Do you want to register a new passkey for:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Select the existing passkey and press Update to replace it.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Authenticate passkey credentials for:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Do you want to register a passkey for:</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>BrowserService</name>
    <message>
        <source>A request for creating a new group &quot;%1&quot; has been received.
Do you want to create this group?
</source>
        <translation>Bola prijatá požiadavka n novú skupinu „%1”.
Chcete vytvoriť túto skupinu?
</translation>
    </message>
    <message>
        <source>You have received an association request for the following database:
%1

Give the connection a unique name or ID, for example:
chrome-laptop.</source>
        <translation>Obdržali ste požiadavku na priradenie nasledujúcej databázy.
%1

Zadajte mu jedinečný názov alebo identifikátor, napríklad:
chrome-laptop.</translation>
    </message>
    <message>
        <source>Save and allow access</source>
        <translation>Uložiť a povoliť prístup</translation>
    </message>
    <message>
        <source>A shared encryption key with the name &quot;%1&quot; already exists.
Do you want to overwrite it?</source>
        <translation>Zdieľaný šifrovací kľúč s menom „%1” už existuje.
Chcete ho prepísať?</translation>
    </message>
    <message>
        <source>Do you want to update the information in %1 - %2?</source>
        <translation>Chcete upraviť informácie v %1 – %2?</translation>
    </message>
    <message>
        <source>A request for deleting entry &quot;%1&quot; has been received.
Do you want to delete the entry?
</source>
        <translation>Bola prijatá požiadavka na odstránenie položky „%1”.
Chcete odstrániť položku?
</translation>
    </message>
    <message>
        <source>%1 (Passkey)</source>
        <translation>%1 (Prístupový kľúč)</translation>
    </message>
    <message>
        <source>KeePassXC - Create a new group</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Disable</source>
        <translation>Vypnúť</translation>
    </message>
    <message>
        <source>KeePassXC - Overwrite existing key?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>KeePassXC - Update Entry</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>KeePassXC - Delete entry</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>KeePassXC - New key association request</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Passkey</source>
        <translation>Prístupový kľúč</translation>
    </message>
    <message>
        <source>KeePassXC - Passkey credentials</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Register a new passkey to this entry:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>KeePassXC - Update passkey</source>
        <translation>KeePassXC - Aktualizovať prístupový kľúč</translation>
    </message>
    <message>
        <source>Entry already has a passkey.
Do you want to overwrite the passkey in %1 - %2?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Register</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>BrowserSettingsWidget</name>
    <message>
        <source>Dialog</source>
        <translation>Dialóg</translation>
    </message>
    <message>
        <source>This is required for accessing your databases with KeePassXC-Browser</source>
        <translation>Toto je potrebné na prístup k vašim databázam cez KeePassXC-Browser</translation>
    </message>
    <message>
        <source>Enable browser integration</source>
        <translation>Povoliť integráciu prehľadávača</translation>
    </message>
    <message>
        <source>General</source>
        <translation>Všeobecné</translation>
    </message>
    <message>
        <source>Enable integration for these browsers:</source>
        <translation>Zapnúť integráciu v týchto prehliadačoch:</translation>
    </message>
    <message>
        <source>Vivaldi</source>
        <translation>Vivaldi</translation>
    </message>
    <message>
        <source>&amp;Edge</source>
        <translation>&amp;Edge</translation>
    </message>
    <message>
        <source>Firefox</source>
        <translation>Firefox</translation>
    </message>
    <message>
        <source>Tor Browser</source>
        <translation>Tor Browser</translation>
    </message>
    <message>
        <source>Brave</source>
        <translation>Brave</translation>
    </message>
    <message>
        <source>Google Chrome</source>
        <translation>Google Chrome</translation>
    </message>
    <message>
        <source>Chromium</source>
        <translation>Chromium</translation>
    </message>
    <message>
        <source>Show a notification when credentials are requested</source>
        <extracomment>Credentials mean login data requested via browser extension</extracomment>
        <translation>Zobraziť upozornenie, keď sú požadované prihlasovacie údaje</translation>
    </message>
    <message>
        <source>Request to unlock the database if it is locked</source>
        <translation>Požiadať o odomknutie databázy, ak je zamknutá</translation>
    </message>
    <message>
        <source>Only entries with the same scheme (http://, https://, …) are returned.</source>
        <translation>Vrátené sú len položky s rovnakou schémou (http://, https://, …).</translation>
    </message>
    <message>
        <source>Match URL scheme (e.g., https://example.com)</source>
        <translation>Zhoda schémy URL (napr., https://example.com)</translation>
    </message>
    <message>
        <source>Only returns the best matches for a specific URL instead of all entries for the whole domain.</source>
        <translation>Vrátiť len najlepšie zhody danej URL, namiesto všetkých položiek celej domény.</translation>
    </message>
    <message>
        <source>Return only best-matching credentials</source>
        <translation>Vrátiť len prihlasovacie údaje s najlepšou zhodou</translation>
    </message>
    <message>
        <source>Returns expired credentials. String [expired] is added to the title.</source>
        <translation>Vrátiť prshlasovacie údaje po vypršaní platnosti. Do názvu je pridaný reťazec [expired].</translation>
    </message>
    <message>
        <source>Allow returning expired credentials</source>
        <translation>Povoliť vrátenie prihlasovacích údajov po dobe platnosti</translation>
    </message>
    <message>
        <source>All databases connected to the extension will return matching credentials.</source>
        <translation>Všetky databázy pripojené k rozšíreniu budú vracať zodpovedajúce prihlasovacie údaje.</translation>
    </message>
    <message>
        <source>Search in all opened databases for matching credentials</source>
        <extracomment>Credentials mean login data requested via browser extension</extracomment>
        <translation>Hľadať vyhovujúce prihlasovacie údaje vo všetkých databázach</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>Pokročilé</translation>
    </message>
    <message>
        <source>Never ask before accessing credentials</source>
        <extracomment>Credentials mean login data requested via browser extension</extracomment>
        <translation>Nikdy sa nepýtať pred prístupom k prihlasovacím údajom</translation>
    </message>
    <message>
        <source>Never ask before updating credentials</source>
        <extracomment>Credentials mean login data requested via browser extension</extracomment>
        <translation>Nikdy sa nepýtať pred úpravou prihlasovacích údajov</translation>
    </message>
    <message>
        <source>Do not ask permission for HTTP Basic Auth</source>
        <extracomment>An extra HTTP Basic Auth setting</extracomment>
        <translation>Nepýtať povolenie na HTTP Basic Auth</translation>
    </message>
    <message>
        <source>Automatically creating or updating string fields is not supported.</source>
        <translation>Automatické vytváranie alebo úprava textových polí nie je podporovaná.</translation>
    </message>
    <message>
        <source>Return advanced string fields which start with &quot;KPH: &quot;</source>
        <translation>Vrátiť reťazce pokročilých polí, ktoré začínajú na „KPH: ”</translation>
    </message>
    <message>
        <source>Don&apos;t display the popup suggesting migration of legacy KeePassHTTP settings.</source>
        <translation>Nezobrazovať okno s návrhom na migráciu starých nastavení KeePassHTTP.</translation>
    </message>
    <message>
        <source>Do not prompt for KeePassHTTP settings migration.</source>
        <translation>Nepýtať sa na migráciu nastavení KeePassHTTP.</translation>
    </message>
    <message>
        <source>Updates KeePassXC or keepassxc-proxy binary path automatically to native messaging scripts on startup.</source>
        <translation>Pri štarte automaticky aktualizovať cestu spustiteľného súboru s KeePassXC alebo keepassxc-proxy na skripty posielania správ medzi prehliadačom a KeePassXC (native messaging).</translation>
    </message>
    <message>
        <source>Update native messaging manifest files at startup</source>
        <translation>Pri štarte automaticky aktualizovať súbory manifestu</translation>
    </message>
    <message>
        <source>Use a custom proxy location if you installed a proxy manually.</source>
        <translation>Použiť vlastné umiestnenie proxy, ak ste nainštalovali proxy manuálne.</translation>
    </message>
    <message>
        <source>Use a custom proxy location:</source>
        <comment>Meant is the proxy for KeePassXC-Browser</comment>
        <translation>Použiť vlastné umiestnenie proxy:</translation>
    </message>
    <message>
        <source>Custom proxy location field</source>
        <translation>Pole vlastné umiestnenia proxy</translation>
    </message>
    <message>
        <source>Browser for custom proxy file</source>
        <translation>Prehliadač súboru vlastného proxy</translation>
    </message>
    <message>
        <source>Browse…</source>
        <extracomment>Button for opening file dialog</extracomment>
        <translation>Prechádzať…</translation>
    </message>
    <message>
        <source>Use a custom browser configuration location:</source>
        <translation>Použiť vlastné umiestnenie nastavenia prehliadača:</translation>
    </message>
    <message>
        <source>Browser type:</source>
        <translation>Typ prehliadača:</translation>
    </message>
    <message>
        <source>Toolbar button style</source>
        <translation>Štýl tlačidiel panela nástrojov</translation>
    </message>
    <message>
        <source>Config Location:</source>
        <translation>Umiestnenie nastavenia:</translation>
    </message>
    <message>
        <source>Custom browser location field</source>
        <translation>Pole vlastného umiestnenia prehlaidača</translation>
    </message>
    <message>
        <source>Browse for custom browser path</source>
        <translation>Nájsť cestu vlastného prehlaidača</translation>
    </message>
    <message>
        <source>Custom extension ID:</source>
        <translation>Vlastné ID rozšírenia:</translation>
    </message>
    <message>
        <source>Custom extension ID</source>
        <translation>Vlastné ID rozšírenia</translation>
    </message>
    <message>
        <source>Executable Files</source>
        <translation>Spustiteľné súbory</translation>
    </message>
    <message>
        <source>All Files</source>
        <translation>Všetky súbory</translation>
    </message>
    <message>
        <source>Select custom proxy location</source>
        <translation>Zvoliť vlastné umiestnenie proxy</translation>
    </message>
    <message>
        <source>Select native messaging host folder location</source>
        <translation>Vyberte umiestnenie zložky hostiteľa správe medzi prehliadačom a KeePassXC</translation>
    </message>
    <message>
        <source>Allow keepassxc-proxy to list all entries with their title, URL and UUID in connected databases.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Allow limited access to all entries in connected databases (ignores site access restrictions)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>&lt;b&gt;Warning:&lt;/b&gt; Only adjust these settings if necessary.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>The custom proxy location does not exist.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>&lt;b&gt;Error:&lt;/b&gt; The custom proxy location does not exist. Correct this in the advanced settings tab.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>&lt;b&gt;Error:&lt;/b&gt; The installed proxy executable is missing from the expected location: %1&lt;br/&gt;Please set a custom proxy location in the advanced settings or reinstall the application.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Allows using insecure http://localhost with passkeys for testing purposes.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Allow using localhost with passkeys</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>KeePassXC-Browser is needed for the browser integration to work. &lt;br /&gt;Download it for %1 and %2 and %3.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Browsers installed using Snap or Flatpak are not supported with exception to Firefox installed using Snap.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>CloneDialog</name>
    <message>
        <source>Clone Entry Options</source>
        <translation>Klonovať voľby položky</translation>
    </message>
    <message>
        <source>Append &apos; - Clone&apos; to title</source>
        <translation>Pripojiť do názvu „- Klon”</translation>
    </message>
    <message>
        <source>Replace username and password with references</source>
        <translation>Nahradiť použ. meno a heslo odkazmi</translation>
    </message>
    <message>
        <source>Copy history</source>
        <translation>Kopírovať históriu</translation>
    </message>
</context>
<context>
    <name>CsvImportWidget</name>
    <message>
        <source>size, rows, columns</source>
        <translation>veľkosť, riadky, stĺpce</translation>
    </message>
    <message>
        <source>Column Association</source>
        <translation>Asociaácia stĺpca</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Heslo</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>Použ. meno:</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>Nadpis</translation>
    </message>
    <message>
        <source>Group</source>
        <translation>Skupina</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>Notes</source>
        <translation>Poznámky</translation>
    </message>
    <message>
        <source>TOTP</source>
        <translation>TOTP</translation>
    </message>
    <message>
        <source>Created</source>
        <translation>Vytvorené</translation>
    </message>
    <message>
        <source>Last Modified</source>
        <translation>Posledná úprava</translation>
    </message>
    <message>
        <source>Icon</source>
        <translation>Ikona</translation>
    </message>
    <message>
        <source>Encoding</source>
        <translation>Kódovanie</translation>
    </message>
    <message>
        <source>Codec</source>
        <translation>Kodek</translation>
    </message>
    <message>
        <source>Text is qualified by</source>
        <translation>Text je vymedzený pomocou </translation>
    </message>
    <message>
        <source>Text qualification</source>
        <translation>Kvalifikácia textu</translation>
    </message>
    <message>
        <source>Fields are separated by</source>
        <translation>Polia sú oddelené pomocou</translation>
    </message>
    <message>
        <source>Field separation</source>
        <translation>Oddeľovanie polí</translation>
    </message>
    <message>
        <source>Comments start with</source>
        <translation>Komentáre začínajú</translation>
    </message>
    <message>
        <source>Header lines skipped</source>
        <translation>Preskočené riadky hlavičky</translation>
    </message>
    <message>
        <source>Number of header lines to discard</source>
        <translation>Počet riadkov hlavičky na zahodenie</translation>
    </message>
    <message>
        <source>First line has field names</source>
        <translation>Prvý riadok sú názvy polí</translation>
    </message>
    <message>
        <source>Consider &apos;\&apos; an escape character</source>
        <translation>Považovať „\” za znak „escape”</translation>
    </message>
    <message>
        <source>Preview</source>
        <translation>Ukážka</translation>
    </message>
    <message>
        <source>CSV import preview</source>
        <translation>Ukážka importu CSV</translation>
    </message>
    <message>
        <source>Not Present</source>
        <translation>Chýba</translation>
    </message>
    <message>
        <source>Column %1</source>
        <translation>Stĺpec %1</translation>
    </message>
    <message numerus="yes">
        <source>[%n more message(s) skipped]</source>
        <translation><numerusform>[%n ďalšia správa preskočená]</numerusform><numerusform>[%n ďalšie správy preskočené</numerusform><numerusform>[%n ďalších správ preskočených]</numerusform><numerusform>[%n ďalších správ preskočených]</numerusform></translation>
    </message>
    <message>
        <source>Failed to parse CSV file: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Imported from CSV file: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>No Title Selected</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>No title column was selected, entries will be hard to tell apart.
Are you sure you want to import?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Tags</source>
        <translation>Štítky</translation>
    </message>
</context>
<context>
    <name>CsvParserModel</name>
    <message numerus="yes">
        <source>%n row(s)</source>
        <comment>CSV row count</comment>
        <translation><numerusform>%n riadok</numerusform><numerusform>%n riadky</numerusform><numerusform>%n riadkov</numerusform><numerusform>%n riadkov</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>%n column(s)</source>
        <comment>CSV column count</comment>
        <translation><numerusform>%n stĺpec</numerusform><numerusform>%n stĺpce</numerusform><numerusform>%n stĺpcov</numerusform><numerusform>%n stĺpcov</numerusform></translation>
    </message>
</context>
<context>
    <name>Database</name>
    <message>
        <source>Passwords</source>
        <comment>Root group name</comment>
        <translation>Heslá</translation>
    </message>
    <message>
        <source>File %1 does not exist.</source>
        <translation>Súbor %1 neexistuje.</translation>
    </message>
    <message>
        <source>Unable to open file %1.</source>
        <translation>Nemožno otvoriť súbor %1.</translation>
    </message>
    <message>
        <source>Error while reading the database: %1</source>
        <translation>Chyba čítania databázy: %1</translation>
    </message>
    <message>
        <source>Could not save, database does not point to a valid file.</source>
        <translation>Nepodarilo sa uložiť, databáza neukazuje na platný súbor.</translation>
    </message>
    <message>
        <source>Database save is already in progress.</source>
        <translation>Ukladanie databázy už prebieha.</translation>
    </message>
    <message>
        <source>Could not save, database has not been initialized!</source>
        <translation>Nemožno uložiť, databáza nebola inicializovaná!</translation>
    </message>
    <message>
        <source>Database file has unmerged changes.</source>
        <translation>Súbor databázy má neuložené zmeny.</translation>
    </message>
    <message>
        <source>%1
Backup database located at %2</source>
        <translation>%1
Zálohovať databázu nachádzajúcu sa na %2</translation>
    </message>
    <message>
        <source>Key not transformed. This is a bug, please report it to the developers.</source>
        <translation>Kľúč nebol transformovaný. Je to chyba, prosím, nahláste ju vývojárom!</translation>
    </message>
    <message>
        <source>Recycle Bin</source>
        <translation>Kôš</translation>
    </message>
    <message>
        <source>Database file read error.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>No file path was provided.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>DatabaseOpenDialog</name>
    <message>
        <source>Unlock Database - KeePassXC</source>
        <translation>Odomknúť databázu – KeePassXC</translation>
    </message>
</context>
<context>
    <name>DatabaseOpenWidget</name>
    <message>
        <source>Unlock KeePassXC Database</source>
        <translation>Odomknúť databázu KeePassXC</translation>
    </message>
    <message>
        <source>Enter Password:</source>
        <translation>Zadajte heslo:</translation>
    </message>
    <message>
        <source>Password field</source>
        <translation>Pole pre heslo</translation>
    </message>
    <message>
        <source>Hardware key slot selection</source>
        <translation>Výber slotu hardvérového kľúča</translation>
    </message>
    <message>
        <source>Key file to unlock the database</source>
        <translation>Súbor kľúča na odomknutie databázy</translation>
    </message>
    <message>
        <source>Browse for key file</source>
        <translation>Vyhľadať súbor kľúča</translation>
    </message>
    <message>
        <source>Browse…</source>
        <translation>Prechádzať…</translation>
    </message>
    <message>
        <source>Unlock Database</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Zrušiť</translation>
    </message>
    <message>
        <source>Unlock</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Please present or touch your YubiKey to continue…</source>
        <translation>Prosím, pripojte alebo stlačte tlačidlo svojho YubiKey na pokračovanie*…</translation>
    </message>
    <message>
        <source>Database Version Mismatch</source>
        <translation>Verzia Databázy sa Nezhoduje</translation>
    </message>
    <message>
        <source>The database you are trying to open was most likely
created by a newer version of KeePassXC.

You can try to open it anyway, but it may be incomplete
and saving any changes may incur data loss.

We recommend you update your KeePassXC installation.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Open database anyway</source>
        <translation>Aj tak otvoriť databázu</translation>
    </message>
    <message>
        <source>Database unlock canceled.</source>
        <translation>Odomknutie Databázy prerušené.</translation>
    </message>
    <message>
        <source>Unlock failed and no password given</source>
        <translation>Odomkntie zlyhalo a nebolo zadané žiadne heslo</translation>
    </message>
    <message>
        <source>Unlocking the database failed and you did not enter a password.
Do you want to retry with an &quot;empty&quot; password instead?

To prevent this error from appearing, you must go to &quot;Database Settings / Security&quot; and reset your password.</source>
        <translation>Odomknutie databázy zlyhalo a nezadali ste heslo.
Chcete sa pokúsiť znova s prázdnym heslom?

Ak chcete zabrániť zobrazovaniu tejto chyby, musíte ísť do &quot;Nastavenia databázy/Zabezpečenia&quot; a obnoviť heslo.</translation>
    </message>
    <message>
        <source>Retry with empty password</source>
        <translation>Skúsiť znova s prázdnym heslom</translation>
    </message>
    <message>
        <source>Failed to open key file: %1</source>
        <translation>Nepodarilo sa otvoriť kľúčový súbor: %1</translation>
    </message>
    <message>
        <source>Old key file format</source>
        <translation>Starý formát kľúča</translation>
    </message>
    <message>
        <source>You are using an old key file format which KeePassXC may&lt;br&gt;stop supporting in the future.&lt;br&gt;&lt;br&gt;Please consider generating a new key file by going to:&lt;br&gt;&lt;strong&gt;Database &amp;gt; Database Security &amp;gt; Change Key File.&lt;/strong&gt;&lt;br&gt;</source>
        <translation>Používate starý formát kľúča, ktorý KeePassXC môže&lt;br&gt;v budúcnosti prestať podporovať.&lt;br&gt;&lt;br&gt;Prosím, zvážte generovanie nového súboru kľúča v &lt;br&gt;&lt;strong&gt;Databáza &amp;gt; Bezpečnosť databázy &amp;gt; Zmeniť súbor kľúča.&lt;/strong&gt;&lt;br&gt;</translation>
    </message>
    <message>
        <source>Don&apos;t show this warning again</source>
        <translation>Nezobrazovať znova toto upozornenie</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>Všetky súbory</translation>
    </message>
    <message>
        <source>Key files</source>
        <translation>Súbory kľúčov</translation>
    </message>
    <message>
        <source>Select key file</source>
        <translation>Zvoľte súbor kľúča</translation>
    </message>
    <message>
        <source>Cannot use database file as key file</source>
        <translation>Súbor databázy nemožno použiť ako súbor kľúča</translation>
    </message>
    <message>
        <source>authenticate to access the database</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Failed to authenticate with Quick Unlock: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Select Key File:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>&lt;p&gt;In addition to a password, you can use a secret file to enhance the security of your database. This file can be generated in your database&apos;s security settings.&lt;/p&gt;&lt;p&gt;This is &lt;strong&gt;not&lt;/strong&gt; your *.kdbx database file!&lt;/p&gt;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Use hardware key [Serial: %1]</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Use hardware key</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Your database file is NOT a key file!
If you don&apos;t have a key file or don&apos;t know what that is, you don&apos;t have to select one.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>KeePassXC database file selected</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>The file you selected looks like a database file.
A database file is NOT a key file!

Are you sure you want to continue with this file?.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>No hardware keys found.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Refresh Hardware Keys</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Click to add a key file.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Hardware keys found, but no slots are configured.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Press ESC again to close this database</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>I have a key file</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>DatabaseSettingWidgetMetaData</name>
    <message>
        <source>Passwords</source>
        <translation>Heslá</translation>
    </message>
</context>
<context>
    <name>DatabaseSettingsDialog</name>
    <message>
        <source>General</source>
        <translation>Všeobecné</translation>
    </message>
    <message>
        <source>Security</source>
        <translation>Bezpečnosť</translation>
    </message>
    <message>
        <source>Database Credentials</source>
        <translation>Prihlasovacie údaje databázy</translation>
    </message>
    <message>
        <source>Encryption Settings</source>
        <translation>Nastavenia šifrovania</translation>
    </message>
    <message>
        <source>Browser Integration</source>
        <translation>Integrácia prehliadača</translation>
    </message>
    <message>
        <source>Maintenance</source>
        <translation>Údržba</translation>
    </message>
    <message>
        <source>KeeShare</source>
        <translation>KeeShare</translation>
    </message>
    <message>
        <source>Secret Service Integration</source>
        <translation>Integrácia Tajnej služby</translation>
    </message>
    <message>
        <source>Remote Sync</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Database Settings: %1</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>DatabaseSettingsWidgetBrowser</name>
    <message>
        <source>KeePassXC-Browser settings</source>
        <translation>Nastavenia KeePassXC-Browser</translation>
    </message>
    <message>
        <source>Disconnect all browsers</source>
        <translation>Odpojiť všetky prehliadače</translation>
    </message>
    <message>
        <source>Forget all site-specific settings on entries</source>
        <translation>Zabudnúť všetky nastavenia položiek špecifické pre stránky</translation>
    </message>
    <message>
        <source>Refresh database root group ID</source>
        <translation>Obnoviť ID koreňovej skupiny databázy</translation>
    </message>
    <message>
        <source>Stored keys</source>
        <translation>Uložené kľúče</translation>
    </message>
    <message>
        <source>Stored browser keys</source>
        <translation>Kľúče prehliadača uložené</translation>
    </message>
    <message>
        <source>Remove selected key</source>
        <translation>Odstrániť vybraný kľúč</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Odstrániť</translation>
    </message>
    <message>
        <source>Delete the selected key?</source>
        <translation>Odstrániť zvolený kľúč?</translation>
    </message>
    <message>
        <source>Do you really want to delete the selected key?
This may prevent connection to the browser plugin.</source>
        <translation>Naozaj chcete odstrániť zvolený kľúč?
Môže to brániť pripojeniu zásuvného modulu prehliadača.</translation>
    </message>
    <message>
        <source>Key</source>
        <translation>Kľúč</translation>
    </message>
    <message>
        <source>Value</source>
        <translation>Hodnota</translation>
    </message>
    <message>
        <source>Created</source>
        <translation>Vytvorené</translation>
    </message>
    <message>
        <source>Enable Browser Integration to access these settings.</source>
        <translation>Zapnúť Integráciu prehliadača na prístup k týmto nastaveniam.</translation>
    </message>
    <message>
        <source>Do you really want to disconnect all browsers?
This may prevent connection to the browser plugin.</source>
        <translation>Naozaj chcete odpojiť všetky prehliadače?
Môže to brániť pripojeniu zásuvného modulu prehliadača.</translation>
    </message>
    <message>
        <source>No shared encryption keys found in KeePassXC settings.</source>
        <translation>V nastavení KeePassXC neboli nájdené zdieľané šifrovacie kľúče.</translation>
    </message>
    <message numerus="yes">
        <source>Successfully removed %n encryption key(s) from KeePassXC settings.</source>
        <translation><numerusform>Úspešne odstránený %n šifrovací kľúč z nastavení KeePassXC.</numerusform><numerusform>Úspešne odstránené %n šifrovacie kľúče z nastavení KeePassXC.</numerusform><numerusform>Úspešne odstránených %n šifrovacích kľúčov z nastavení KeePassXC.</numerusform><numerusform>Úspešne odstránených %n šifrovacích kľúčov z nastavení KeePassXC.</numerusform></translation>
    </message>
    <message>
        <source>Do you really want forget all site-specific settings on every entry?
Permissions to access entries will be revoked.</source>
        <translation>Naozaj chcete zabudnúť všetky nastavenia stránok v každej položke?
Povolenia na prístup k položkám budú odvolané.</translation>
    </message>
    <message>
        <source>Removing stored permissions…</source>
        <translation>Odstraňovanie uložených povolení…</translation>
    </message>
    <message>
        <source>Abort</source>
        <translation>Zrušiť</translation>
    </message>
    <message numerus="yes">
        <source>Successfully removed permissions from %n entry(s).</source>
        <translation><numerusform>Úspešne odstránené povolenia z %n položky.</numerusform><numerusform>Úspešne odstránené povolenia z %n položiek.</numerusform><numerusform>Úspešne odstránené povolenia z %n položiek.</numerusform><numerusform>Úspešne odstránené povolenia z %n položky.</numerusform></translation>
    </message>
    <message>
        <source>The active database does not contain an entry with permissions.</source>
        <translation>Aktívna databáza neobsahuje položku s povoleniami.</translation>
    </message>
    <message>
        <source>Refresh database ID</source>
        <translation>Obnoviť ID databázy</translation>
    </message>
    <message>
        <source>Do you really want refresh the database ID?
This is only necessary if your database is a copy of another and the browser extension cannot connect.</source>
        <translation>Naozaj chcete obnoviť ID databázy?
Toto je potrebné len ak je vaša databáza kópiou inej a doplnok prehliadača sa nemôže pripojiť.</translation>
    </message>
    <message>
        <source>Convert legacy KeePassHTTP attributes to KeePassXC-Browser compatible custom data</source>
        <translation>Konvertovať KeePassHTTP atribúty do formátu kompatibilného s KeePassXC-Browser</translation>
    </message>
    <message>
        <source>No keys found</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Removed keys from database</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Removed permissions</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>No entry with permissions found!</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>DatabaseSettingsWidgetDatabaseKey</name>
    <message>
        <source>Add additional protection…</source>
        <translation>Pridať dodatočné zabezpečenie…</translation>
    </message>
    <message>
        <source>No password set</source>
        <translation>Nie je nastavené heslo</translation>
    </message>
    <message>
        <source>WARNING! You have not set a password. Using a database without a password is strongly discouraged!

Are you sure you want to continue without a password?</source>
        <translation>UPOZORNENIE! Nenastavili iste heslo. Použitie databázy bez hesla dôrazne neodporúčame!

Naozaj chcete pokračovať bez hesla?</translation>
    </message>
    <message>
        <source>Continue without password</source>
        <translation>Pokračovať bez hesla</translation>
    </message>
    <message>
        <source>No encryption key added</source>
        <translation>Nie je pridaný šifrovací kľúč</translation>
    </message>
    <message>
        <source>You must add at least one encryption key to secure your database!</source>
        <translation>Na zabezpečenie svojej databázy musíte pridať aspoň jeden šifrovací kľúč!</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation>Neznáma chyba</translation>
    </message>
    <message>
        <source>Failed to change database credentials</source>
        <translation>Zlyhala zmena prihlasovacích údajov databázy</translation>
    </message>
    <message>
        <source>Weak password</source>
        <translation>Slabé heslo</translation>
    </message>
    <message>
        <source>This is a weak password! For better protection of your secrets, you should choose a stronger password.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>The provided password does not meet the minimum quality requirement.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>DatabaseSettingsWidgetEncryption</name>
    <message>
        <source>Decryption Time:</source>
        <translation>Čas dešifrovania:</translation>
    </message>
    <message>
        <source>Decryption time in seconds</source>
        <translation>Čas dešifrovania v sekundách</translation>
    </message>
    <message>
        <source>Higher values offer more protection, but opening the database will take longer.</source>
        <translation>Vyššie hodnoty poskytujú viac ochrany, ale otvorenie databázy bude trvať dlhšie.</translation>
    </message>
    <message>
        <source>Database format:</source>
        <translation>Formát databázy:</translation>
    </message>
    <message>
        <source>Database format</source>
        <translation>Formát databázy</translation>
    </message>
    <message>
        <source>Format cannot be changed: Your database uses KDBX 4 features</source>
        <translation>Format nemôže byť zmenený: Vaša databáta používa vlastnosti KDBX 4</translation>
    </message>
    <message>
        <source>Unless you need to open your database with other programs, always use the latest format.</source>
        <translation>Pokiaľ nepotrebujete otvoriť databázu iným programom, vždy používajte najnovší formát.</translation>
    </message>
    <message>
        <source>Encryption Algorithm:</source>
        <translation>Šifrovací algoritmus:</translation>
    </message>
    <message>
        <source>Encryption algorithm</source>
        <translation>Šifrovací algoritmus</translation>
    </message>
    <message>
        <source>AES:  256 Bit   (default)</source>
        <translation>AES:  256 bit (predvolené)</translation>
    </message>
    <message>
        <source>Twofish:  256 Bit</source>
        <translation>Twofish:  256 bitov</translation>
    </message>
    <message>
        <source>Key Derivation Function:</source>
        <translation>Funkcia odvodenia kľúča (KDF):</translation>
    </message>
    <message>
        <source>Key derivation function</source>
        <translation>Funkcia odvodenia kľúča</translation>
    </message>
    <message>
        <source>Transform rounds:</source>
        <translation>Počet transformácií:</translation>
    </message>
    <message>
        <source>Transform rounds</source>
        <translation>Počet transformácií</translation>
    </message>
    <message>
        <source>Memory Usage:</source>
        <translation>Využitie pamäte:</translation>
    </message>
    <message>
        <source>Memory usage</source>
        <translation>Využitie pamäte</translation>
    </message>
    <message>
        <source>Parallelism:</source>
        <translation>Paralelizmus:</translation>
    </message>
    <message>
        <source>Parallelism</source>
        <translation>Paralelizácia</translation>
    </message>
    <message>
        <source>KDBX 4 (recommended)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>KDBX 3</source>
        <translation>KDBX 3</translation>
    </message>
    <message>
        <source>Number of rounds too high</source>
        <comment>Key transformation rounds</comment>
        <translation>Počet prechodov príliš vysoký</translation>
    </message>
    <message>
        <source>You are using a very high number of key transform rounds with Argon2.

If you keep this number, your database may take hours, days, or even longer to open.</source>
        <translation>Zadali ste príliš vysoký počet prechodov transformácie kľúča pre Argon2.

Ak ponecháte toto číslo, môže otvorenie databázy trvať hodiny alebo i dni (dokonca i dlhšie)!</translation>
    </message>
    <message>
        <source>Understood, keep number</source>
        <translation>Rozumiem, nechať hodnotu</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Zrušiť</translation>
    </message>
    <message>
        <source>Number of rounds too low</source>
        <comment>Key transformation rounds</comment>
        <translation>Počet prechodov príliš nízky</translation>
    </message>
    <message>
        <source>You are using a very low number of key transform rounds with AES-KDF.

If you keep this number, your database will not be protected from brute force attacks.</source>
        <translation>Zadali ste príliš nízky počet prechodov transformácie kľúča pre AES-KDF.

Ak ponecháte toto číslo, môže byť prelomenie ochrany databázy príliš jednoduché!</translation>
    </message>
    <message>
        <source>KDF unchanged</source>
        <translation>KDF nezmenené</translation>
    </message>
    <message>
        <source>Failed to transform key with new KDF parameters; KDF unchanged.</source>
        <translation>Zlyhala transformácia kľúča s novými parametrami KDF; KDF nezmenené.</translation>
    </message>
    <message numerus="yes">
        <source> MiB</source>
        <comment>Abbreviation for Mebibytes (KDF settings)</comment>
        <translation><numerusform> MiB</numerusform><numerusform> MiB</numerusform><numerusform> MiB</numerusform><numerusform> MiB</numerusform></translation>
    </message>
    <message numerus="yes">
        <source> thread(s)</source>
        <comment>Threads for parallel execution (KDF settings)</comment>
        <translation><numerusform>vlákno</numerusform><numerusform>vlákna</numerusform><numerusform>vlákien</numerusform><numerusform> vlákien</numerusform></translation>
    </message>
    <message>
        <source>Encryption Settings:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Basic</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Advanced</source>
        <translation>Pokročilé</translation>
    </message>
</context>
<context>
    <name>DatabaseSettingsWidgetFdoSecrets</name>
    <message>
        <source>Exposed Entries</source>
        <translation>Exponované položky</translation>
    </message>
    <message>
        <source>Don&apos;t expose this database</source>
        <translation>Nezverejňovať túto databázu</translation>
    </message>
    <message>
        <source>Expose entries under this group:</source>
        <translation>Zverejňovať položky tejto skupiny:</translation>
    </message>
    <message>
        <source>Enable Secret Service to access these settings.</source>
        <translation>Zapnúť Tajnú službu na prístup k týmto nastaveniam.</translation>
    </message>
</context>
<context>
    <name>DatabaseSettingsWidgetGeneral</name>
    <message>
        <source>Database Metadata</source>
        <translation>Meta dáta databázy</translation>
    </message>
    <message>
        <source>Database name:</source>
        <translation>Meno databázy:</translation>
    </message>
    <message>
        <source>Database name field</source>
        <translation>Pole názvu databázy</translation>
    </message>
    <message>
        <source>Database description:</source>
        <translation>Popis databázy:</translation>
    </message>
    <message>
        <source>Database description field</source>
        <translation>Pole popisu databázy</translation>
    </message>
    <message>
        <source>Default username:</source>
        <translation>Predvolené použ. meno:</translation>
    </message>
    <message>
        <source>Default username field</source>
        <translation>Pole predvoleného používateľa</translation>
    </message>
    <message>
        <source>History Settings</source>
        <translation>Nastavenia histórie</translation>
    </message>
    <message>
        <source>Maximum number of history items per entry</source>
        <translation>Maximálny počet  histórie na položku</translation>
    </message>
    <message>
        <source>Maximum size of history per entry</source>
        <translation>Maximálna veľkosť  histórie na položku</translation>
    </message>
    <message>
        <source> MiB</source>
        <translation>MiB</translation>
    </message>
    <message>
        <source>Use recycle bin</source>
        <translation>Použiť kôš</translation>
    </message>
    <message>
        <source>Additional Database Settings</source>
        <translation>Dodatočné nastavenia databázy</translation>
    </message>
    <message>
        <source>Enable compression (recommended)</source>
        <translation>Zapnúť komprimáciu (odporúčané)</translation>
    </message>
    <message>
        <source>Delete Recycle Bin</source>
        <translation>Odstrániť Kôš</translation>
    </message>
    <message>
        <source>Do you want to delete the current recycle bin and all its contents?
This action is not reversible.</source>
        <translation>Chcete odstrániť aktuálny Kôš a všetok jeho obsah?
Táto akcia nie je reverzibilná.</translation>
    </message>
    <message>
        <source> (old)</source>
        <translation> (staré)</translation>
    </message>
    <message>
        <source>When saving this setting or editing an entry
the oldest history items of an entry will be
removed such that only the specified amount
of entries remain at most.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Limit the amount of history items per entry to:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>When saving this setting or editing an entry
the oldest history items of an entry will be
removed such that the remaining history items
add up to the specified amount at most.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Limit the total size of history items per entry to:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Move entries to a recycle bin group
instead of deleting them from the database.
Entries deleted from the recycle bin are
removed from the database.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Autosave delay since last change</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Autosave delay</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Autosave delay since last change in minutes</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source> min</source>
        <translation> min</translation>
    </message>
    <message>
        <source>Autosave delay since last change checkbox</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Public Database Metadata</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Warning: the following settings are not encrypted.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Display name:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Database public display name</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Display color:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Database public display color chooser</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Clear</source>
        <translation>Vymazať</translation>
    </message>
    <message>
        <source>Display icon:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Select Database Icon</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Publicly visible display name used on the unlock dialog</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Publicly visible color used on the unlock dialog</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>DatabaseSettingsWidgetKeeShare</name>
    <message>
        <source>Sharing</source>
        <translation>Zdieľanie</translation>
    </message>
    <message>
        <source>Breadcrumb</source>
        <translation>Breadcrumb</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Typ</translation>
    </message>
    <message>
        <source>Path</source>
        <translation>Cesta</translation>
    </message>
    <message>
        <source>Last Signer</source>
        <translation>Naposledy podpísal</translation>
    </message>
    <message>
        <source>Certificates</source>
        <translation>Certifikáty</translation>
    </message>
    <message>
        <source> &gt; </source>
        <comment>Breadcrumb separator</comment>
        <translation> &gt; </translation>
    </message>
</context>
<context>
    <name>DatabaseSettingsWidgetMaintenance</name>
    <message>
        <source>Manage Custom Icons</source>
        <translation>Spravovať vlastné ikony</translation>
    </message>
    <message>
        <source>Delete selected icon(s)</source>
        <translation>Odstrániť zvolenú ikonu(y)</translation>
    </message>
    <message>
        <source>Delete all custom icons not in use by any entry or group</source>
        <translation>Odstrániť všetky vlastné ikony, ktoré nie sú použité žiadnou položkou alebo skupinou</translation>
    </message>
    <message>
        <source>Purge unused icons</source>
        <translation>Zahodiť nepoužité ikony</translation>
    </message>
    <message>
        <source>Confirm Deletion</source>
        <translation>Potvrďte odstránenie</translation>
    </message>
    <message>
        <source>At least one of the selected icons is currently in use by at least one entry or group. The icons of all affected entries and groups will be replaced by the default icon. Are you sure you want to delete icons that are currently in use?</source>
        <translation>Aspoň jedna zo zvolených ikon je používaná aspoň jednou položkou alebo skupinou. Ikony všetkých dotknutých položiek a skupín budú nahradené predvolenou ikonou. Naozaj chcete odstrániť používané ikony?</translation>
    </message>
    <message>
        <source>Custom Icons Are In Use</source>
        <translation>Vlastné ikony sú používané</translation>
    </message>
    <message>
        <source>All custom icons are in use by at least one entry or group.</source>
        <translation>Všetky vlastné ikony sú použité aspoň jednou položkou alebo skupinou.</translation>
    </message>
    <message>
        <source>Purged Unused Icons</source>
        <translation>Nepoužité ikony zahodené</translation>
    </message>
    <message numerus="yes">
        <source>Purged %n icon(s) from the database.</source>
        <translation><numerusform>Z databázy zahodená jedna ikona.</numerusform><numerusform>Z databázy zahodené %n ikony.</numerusform><numerusform>Z databázy zahodených %n ikon.</numerusform><numerusform>Z databázy zahodených %n ikony.</numerusform></translation>
    </message>
</context>
<context>
    <name>DatabaseSettingsWidgetMetaDataSimple</name>
    <message>
        <source>Database Name:</source>
        <translation>Meno databázy:</translation>
    </message>
    <message>
        <source>Database name field</source>
        <translation>Pole názvu databázy</translation>
    </message>
    <message>
        <source>Description:</source>
        <translation>Popis:</translation>
    </message>
    <message>
        <source>Database description field</source>
        <translation>Pole popisu databázy</translation>
    </message>
</context>
<context>
    <name>DatabaseSettingsWidgetRemote</name>
    <message>
        <source>Sync Commands</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Remove</source>
        <translation>Odstrániť</translation>
    </message>
    <message>
        <source>Command Settings</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Name</source>
        <translation>Názov</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>Uložiť</translation>
    </message>
    <message>
        <source>Download</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Command:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Download command field</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>e.g.: &quot;sftp user@hostname&quot; or &quot;scp user@hostname:DatabaseOnRemote.kdbx {TEMP_DATABASE}&quot;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Input:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Download input field</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Upload</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Upload command field</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>e.g.: &quot;sftp user@hostname&quot; or &quot;scp {TEMP_DATABASE} user@hostname:DatabaseOnRemote.kdbx&quot;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Upload input field</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Name cannot be empty.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Test</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Download command cannot be empty.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Download failed with error: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Download finished, but file %1 could not be found.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Download successful.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Save Remote Settings</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>You have unsaved changes. Do you want to save them?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>e.g.:
get DatabaseOnRemote.kdbx {TEMP_DATABASE}
exit
---
{TEMP_DATABASE} is used as placeholder to store the database in a temporary location
The command has to exit. In case of `sftp` as last command `exit` has to be sent
            </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>e.g.:
put {TEMP_DATABASE} DatabaseOnRemote.kdbx
exit
---
{TEMP_DATABASE} is used as placeholder to store the database in a temporary location
The command has to exit. In case of `sftp` as last command `exit` has to be sent
            </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Timeout:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source> seconds</source>
        <translation>sekundy</translation>
    </message>
</context>
<context>
    <name>DatabaseTabWidget</name>
    <message>
        <source>Database creation error</source>
        <translation>Chyba vytvorenia databázy</translation>
    </message>
    <message>
        <source>The created database has no key or KDF, refusing to save it.
This is definitely a bug, please report it to the developers.</source>
        <translation>Vytvorená databáza nemá kľúča alebo KDF, jej uloženie je odmietnuté.
Toto je určite chyba, prosím nahláste ju vývojárom.</translation>
    </message>
    <message>
        <source>KeePass 2 Database</source>
        <translation>Databáza KeePass 2</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>Všetky súbory</translation>
    </message>
    <message>
        <source>Open database</source>
        <translation>Otvoriť databázu</translation>
    </message>
    <message>
        <source>Failed to open %1. It either does not exist or is not accessible.</source>
        <translation>Zlyhalo otvorenie %1. Buď neexistuje alebo je neprístupný.</translation>
    </message>
    <message>
        <source>CSV file</source>
        <translation>Súbor CSV</translation>
    </message>
    <message>
        <source>Merge database</source>
        <translation>Zlúčiť databázu</translation>
    </message>
    <message>
        <source>Export database to CSV file</source>
        <translation>Exportovať databázu do súboru CSV</translation>
    </message>
    <message>
        <source>Writing the CSV file failed.</source>
        <translation>Zápis do súboru CSV zlyhal.</translation>
    </message>
    <message>
        <source>Writing the HTML file failed.</source>
        <translation>Zápis do súboru HTML zlyhal.</translation>
    </message>
    <message>
        <source>Export database to XML file</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>XML file</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Writing the XML file failed</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Export Confirmation</source>
        <translation>Potvrdenie exportu</translation>
    </message>
    <message>
        <source>You are about to export your database to an unencrypted file. This will leave your passwords and sensitive information vulnerable! Are you sure you want to continue?</source>
        <translation>Chystáte sa exportovať svoju databázu do nešifrovaného súboru. Takto necháte svoje heslá a citlivé informácie nechránené! Naozaj chcete pokračovať?</translation>
    </message>
    <message>
        <source>%1 [Locked]</source>
        <comment>Database tab name modifier</comment>
        <translation>%1 [Zamknutá]</translation>
    </message>
    <message>
        <source>%1 [Temporary]</source>
        <comment>Database tab name modifier</comment>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>DatabaseWidget</name>
    <message>
        <source>Searches and Tags</source>
        <translation>Vyhľadávania a štítky</translation>
    </message>
    <message>
        <source>Searching…</source>
        <translation>Hľadanie…</translation>
    </message>
    <message>
        <source>Shared group…</source>
        <translation>Zdieľaná skupina…</translation>
    </message>
    <message>
        <source>Confirm Auto-Type</source>
        <translation>Potvrdiť Automatické vypĺňanie</translation>
    </message>
    <message>
        <source>Perform Auto-Type into the previously active window?</source>
        <translation>Automaticky vyplniť do posledného aktivného okna?</translation>
    </message>
    <message>
        <source>Execute command?</source>
        <translation>Vykonať príkaz?</translation>
    </message>
    <message>
        <source>Do you really want to execute the following command?&lt;br&gt;&lt;br&gt;%1&lt;br&gt;</source>
        <translation>Naozaj chcete spustiť nasledujúci príkaz?&lt;br&gt;&lt;br&gt;%1&lt;br&gt;</translation>
    </message>
    <message>
        <source>Remember my choice</source>
        <translation>Zapamätať si moju voľbu</translation>
    </message>
    <message>
        <source>Do you really want to move the group &quot;%1&quot; to the recycle bin?</source>
        <translation>Naozaj chcete presunúť skupinu „%1” do koša?</translation>
    </message>
    <message>
        <source>Expired entries</source>
        <translation type="unfinished"/>
    </message>
    <message numerus="yes">
        <source>Entries expiring within %1 day(s)</source>
        <translation type="unfinished"><numerusform></numerusform><numerusform></numerusform><numerusform></numerusform><numerusform></numerusform></translation>
    </message>
    <message>
        <source>No current database.</source>
        <translation>Žiadna otvorená databáza.</translation>
    </message>
    <message>
        <source>No source database, nothing to do.</source>
        <translation>Žiadna zdrojová databáza, niet čo robiť.</translation>
    </message>
    <message>
        <source>Search Results (%1)</source>
        <translation>Výsledky hľadania (%1)</translation>
    </message>
    <message>
        <source>No Results</source>
        <translation>Žiadne výsledky</translation>
    </message>
    <message>
        <source>Enter a unique name or overwrite an existing search from the list:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Save Search</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Lock Database?</source>
        <translation>Zamknúť databázu?</translation>
    </message>
    <message>
        <source>You are editing an entry. Discard changes and lock anyway?</source>
        <translation>Upravujete položku. Zahodiť zmeny a zamknúť napriek tomu?</translation>
    </message>
    <message>
        <source>&quot;%1&quot; was modified.
Save changes?</source>
        <translation>„%1” bol zmenený.
Uložiť zmeny?</translation>
    </message>
    <message>
        <source>Database was modified.
Save changes?</source>
        <translation>Databáza bola zmenená.
Uložiť zmeny?</translation>
    </message>
    <message>
        <source>Save changes?</source>
        <translation>Uložiť zmeny?</translation>
    </message>
    <message>
        <source>File has changed</source>
        <translation>Súbor bol zmenený</translation>
    </message>
    <message>
        <source>Disable safe saves?</source>
        <translation>Vypnúť bezpečné ukladanie?</translation>
    </message>
    <message>
        <source>KeePassXC has failed to save the database multiple times. This is likely caused by file sync services holding a lock on the save file.
Disable safe saves and try again?</source>
        <translation>KeePassXC pri ukladaní databázy viac krát zlyhal. Pravdepodobne to je spôsobené službou synchronizácie súborov, ktorá drží zámok na ukladanom súbore.
Vypnúť bezpečné ukladanie a skúsiť znova?</translation>
    </message>
    <message>
        <source>Writing the database failed: %1</source>
        <translation>Zápis do databázy zlyhal: %1</translation>
    </message>
    <message>
        <source>Passwords</source>
        <translation>Heslá</translation>
    </message>
    <message>
        <source>Save database as</source>
        <translation>Uložiť databázu ako</translation>
    </message>
    <message>
        <source>KeePass 2 Database</source>
        <translation>Databáza KeePass 2</translation>
    </message>
    <message>
        <source>Empty recycle bin?</source>
        <translation>Vyprázdniť kôš?</translation>
    </message>
    <message>
        <source>Are you sure you want to permanently delete everything from your recycle bin?</source>
        <translation>Naozaj chcete na trvalo odstrániť všetko zo svojho koša?</translation>
    </message>
    <message>
        <source>Could not find database file: %1</source>
        <translation>Nemožno nájsť súbor databázy: %1</translation>
    </message>
    <message>
        <source>New Database</source>
        <translation>Nová databáza</translation>
    </message>
    <message>
        <source>%1 [New Database]</source>
        <comment>Database tab name modifier</comment>
        <translation>%1 [Nová databáza]</translation>
    </message>
    <message>
        <source>Remote Sync did not contain any download or upload commands.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Remote sync &apos;%1&apos; completed successfully!</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Downloading...</source>
        <translation>Sťahovanie…</translation>
    </message>
    <message>
        <source>Uploading...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Remote sync &apos;%1&apos; failed: %2</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Syncing...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Error while saving database %1: %2</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Remove passkey from entry</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Do you want to remove the passkey from this entry?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>The database file &quot;%1&quot; was modified externally</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Do you want to load the changes?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Reloading database…</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Reload canceled</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Reload successful</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Reload pending user action…</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>The database file &quot;%1&quot; was modified externally.&lt;br&gt;How would you like to proceed?&lt;br&gt;&lt;br&gt;Merge all changes&lt;br&gt;Ignore the changes on disk until save&lt;br&gt;Discard unsaved changes</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>The database file &quot;%1&quot; was modified externally.&lt;br&gt;How would you like to proceed?&lt;br&gt;&lt;br&gt;Merge all changes then save&lt;br&gt;Overwrite the changes on disk&lt;br&gt;Discard unsaved changes</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Reload database</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Database file overwritten.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Database file on disk cannot be unlocked with current credentials.&lt;br&gt;Enter new credentials and/or present hardware key to continue.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Failed to save backup database: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Confirm Delete Group</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Do you really want to permanently delete the group &quot;%1&quot;?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Confirm Recycle Group</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Save</source>
        <translation>Uložiť</translation>
    </message>
    <message>
        <source>Save Database Backup</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Successfully merged the selected database.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>No changes were made by the merge operation.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Merge canceled, no changes were made.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>EditEntryAttachmentsDialog</name>
    <message>
        <source>Edit: %1</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>EditEntryWidget</name>
    <message>
        <source>Entry</source>
        <translation>Položka</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>Pokročilé</translation>
    </message>
    <message>
        <source>Icon</source>
        <translation>Ikona</translation>
    </message>
    <message>
        <source>Auto-Type</source>
        <translation>Automatické vypĺňanie</translation>
    </message>
    <message>
        <source>Browser Integration</source>
        <translation>Integrácia prehliadača</translation>
    </message>
    <message>
        <source>&lt;empty URL&gt;</source>
        <translation>&lt;prázdna URL&gt;</translation>
    </message>
    <message>
        <source>Confirm Removal</source>
        <translation>Potvrdiť odstránenie</translation>
    </message>
    <message>
        <source>Are you sure you want to remove this URL?</source>
        <translation>Naozaj chcete odstrániť túto URL?</translation>
    </message>
    <message>
        <source>Properties</source>
        <translation>Vlastnosti</translation>
    </message>
    <message>
        <source>History</source>
        <translation>História</translation>
    </message>
    <message>
        <source>SSH Agent</source>
        <translation>Agent SSH</translation>
    </message>
    <message>
        <source>n/a</source>
        <translation>neznáme</translation>
    </message>
    <message>
        <source>Select private key</source>
        <translation>Zvoľte súkromný kľúč</translation>
    </message>
    <message>
        <source>Entry history</source>
        <translation>História položky</translation>
    </message>
    <message>
        <source>Add entry</source>
        <translation>Pridať položku</translation>
    </message>
    <message>
        <source>Edit entry</source>
        <translation>Upraviť položku</translation>
    </message>
    <message>
        <source>Some Browser Integration settings are overridden by group settings.</source>
        <translation>Niektoré nastavenia Integrácie prehliadača sú prepísané nastavení skupiny.</translation>
    </message>
    <message>
        <source>Invalid Entry</source>
        <translation>Neplatná položka</translation>
    </message>
    <message>
        <source>An external merge operation has invalidated this entry.
Unfortunately, any changes made have been lost.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Auto-Type Validation Error</source>
        <translation>Chyba Oprávnenia Automatického Vypĺňania</translation>
    </message>
    <message>
        <source>An error occurred while validating the custom Auto-Type sequence:
%1
Would you like to correct it?</source>
        <translation>Pri overovaní vlastnej sekvencie Automatického Vypĺňania nastala chyba.
%1
Chceli by ste chybu napraviť?</translation>
    </message>
    <message>
        <source>An error occurred while validating the Auto-Type sequence for &quot;%1&quot;:
%2
Would you like to correct it?</source>
        <translation>Nastala chyba pri overovaní postupnosti Automatického vypĺňania pre „%1”:
%2
Chcete to opraviť?</translation>
    </message>
    <message>
        <source>Entry updated successfully.</source>
        <translation>Položka úspešne zmenená.</translation>
    </message>
    <message>
        <source>Unsaved Changes</source>
        <translation>Neuložené zmeny</translation>
    </message>
    <message>
        <source>Would you like to save changes to this entry?</source>
        <translation>Chcete uložiť zmeny tejto položky?</translation>
    </message>
    <message>
        <source>New attribute</source>
        <translation>Nový atribút</translation>
    </message>
    <message>
        <source>New attribute %1</source>
        <translation>Nový atribút %1</translation>
    </message>
    <message>
        <source>Are you sure you want to remove this attribute?</source>
        <translation>Naozaj chcete odstrániť tento atribút?</translation>
    </message>
    <message>
        <source>Reveal</source>
        <translation>Odkryť</translation>
    </message>
    <message>
        <source>[PROTECTED] Press Reveal to view or edit</source>
        <translation>[CHRÁNENÉ] Stlačte odkryť na zobrazenie alebo úpravu</translation>
    </message>
    <message>
        <source>Hide</source>
        <translation>Skryť</translation>
    </message>
    <message numerus="yes">
        <source>%n hour(s)</source>
        <translation type="unfinished"><numerusform></numerusform><numerusform></numerusform><numerusform></numerusform><numerusform></numerusform></translation>
    </message>
    <message numerus="yes">
        <source>%n week(s)</source>
        <translation><numerusform>%n týždeň</numerusform><numerusform>%n týždne</numerusform><numerusform>%n týždňov</numerusform><numerusform>%n týždňov</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>%n month(s)</source>
        <translation><numerusform>%n mesiacoch</numerusform><numerusform>%n mesiacoch</numerusform><numerusform>%n mesiacoch</numerusform><numerusform>%n mesiacoch</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>%n year(s)</source>
        <translation><numerusform>%n rok</numerusform><numerusform>%n roky</numerusform><numerusform>%n rokov</numerusform><numerusform>%n rokov</numerusform></translation>
    </message>
    <message>
        <source>Failed to decrypt SSH key, ensure password is correct.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>EditEntryWidgetAdvanced</name>
    <message>
        <source>Additional attributes</source>
        <translation>Ďalšie atribúty</translation>
    </message>
    <message>
        <source>Attribute selection</source>
        <translation>Výber atribútu</translation>
    </message>
    <message>
        <source>Attribute value</source>
        <translation>Hodnota atribútu</translation>
    </message>
    <message>
        <source>Add a new attribute</source>
        <translation>Pridať nový atribút</translation>
    </message>
    <message>
        <source>Add</source>
        <translation>Pridať</translation>
    </message>
    <message>
        <source>Remove selected attribute</source>
        <translation>Odstrániť vybraný atribút</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Odstrániť</translation>
    </message>
    <message>
        <source>Edit attribute name</source>
        <translation>Upraviť meno atribúta</translation>
    </message>
    <message>
        <source>Edit Name</source>
        <translation>Upraviť názov</translation>
    </message>
    <message>
        <source>Toggle attribute protection</source>
        <translation>Prepnúť ochranu atribúta</translation>
    </message>
    <message>
        <source>Protect</source>
        <translation>Chrániť</translation>
    </message>
    <message>
        <source>Show a protected attribute</source>
        <translation>Zobraziť chránený atribút</translation>
    </message>
    <message>
        <source>Reveal</source>
        <translation>Odkryť</translation>
    </message>
    <message>
        <source>Attachments</source>
        <translation>Prílohy</translation>
    </message>
    <message>
        <source>If checked, the entry will not appear in reports like Health Check and HIBP even if it doesn&apos;t match the quality requirements.</source>
        <translation>Ak je zvolené, položka sa neobjaví v hláseniach ako Kontrola zdravia a HIBP, i keď nespĺňa požiadavky kvality.</translation>
    </message>
    <message>
        <source>Exclude from database reports</source>
        <translation>Vylúčiť z hlásení databázy</translation>
    </message>
    <message>
        <source>Foreground Color:</source>
        <translation>Farba popredia:</translation>
    </message>
    <message>
        <source>Foreground color selection</source>
        <translation>Výber farby popredia</translation>
    </message>
    <message>
        <source>Background Color:</source>
        <translation>Farba pozadia:</translation>
    </message>
    <message>
        <source>Background color selection</source>
        <translation>Výber farby pozadia</translation>
    </message>
</context>
<context>
    <name>EditEntryWidgetAutoType</name>
    <message>
        <source>Enable Auto-Type for this entry</source>
        <translation>Zapnúť Automatické vypĺňanie pre túto položku</translation>
    </message>
    <message>
        <source>Inherit default Auto-Type sequence from the group</source>
        <translation>Zdediť predvolenú postupnosť Automatického vypĺňania zo skupiny</translation>
    </message>
    <message>
        <source>Use custom Auto-Type sequence:</source>
        <translation>Použiť vlastnú postupnosť Automatického vypĺňania:</translation>
    </message>
    <message>
        <source>Custom Auto-Type sequence</source>
        <translation>Vlastná postupnosť Automatického vypĺňania</translation>
    </message>
    <message>
        <source>Open Auto-Type help webpage</source>
        <translation>Otvorí webovú stránku Automatického vypĺňania</translation>
    </message>
    <message>
        <source>Window Associations</source>
        <translation>Priradenie okna</translation>
    </message>
    <message>
        <source>Existing window associations</source>
        <translation>Existujúce priradenia okna</translation>
    </message>
    <message>
        <source>Add new window association</source>
        <translation>Pridať nové priradenia okna</translation>
    </message>
    <message>
        <source>+</source>
        <comment>Add item</comment>
        <translation>+</translation>
    </message>
    <message>
        <source>Remove selected window association</source>
        <translation>Odstrániť vybrané priradenia okna</translation>
    </message>
    <message>
        <source>-</source>
        <comment>Remove item</comment>
        <translation>-</translation>
    </message>
    <message>
        <source>Window title:</source>
        <translation>Názov okna:</translation>
    </message>
    <message>
        <source>You can use an asterisk (*) to match everything</source>
        <translation>Môžete použiť hviezdičku (*) na zhodu so všetkým</translation>
    </message>
    <message>
        <source>Set the window association title</source>
        <translation>Nastaviť názov priradenia okna</translation>
    </message>
    <message>
        <source>You can use an asterisk to match everything</source>
        <translation>Môžete použiť hviezdičku na zhodu so všetkým</translation>
    </message>
    <message>
        <source>Use a specific sequence for this association:</source>
        <translation>Pre toto priradenie použiť špecifickú postupnosť:</translation>
    </message>
    <message>
        <source>Custom Auto-Type sequence for this window</source>
        <translation>Vlastná postupnosť Automatického vypĺňania tohoto okna</translation>
    </message>
</context>
<context>
    <name>EditEntryWidgetBrowser</name>
    <message>
        <source>General</source>
        <translation>Všeobecné</translation>
    </message>
    <message>
        <source>Hide this entry from the browser extension</source>
        <translation>Skryť túto položku v rozšírení prehliadača</translation>
    </message>
    <message>
        <source>Skip Auto-Submit for this entry</source>
        <translation>Zapnúť Automatické vypĺňanie pre túto položku</translation>
    </message>
    <message>
        <source>Use this entry only with HTTP Basic Auth</source>
        <translation>Použiť položku len pre HTTP Basic Auth</translation>
    </message>
    <message>
        <source>Do not use this entry with HTTP Basic Auth</source>
        <translation>Nepoužiť túto položku pre HTTP Basic Auth</translation>
    </message>
    <message>
        <source>Add</source>
        <translation>Pridať</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Odstrániť</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Upraviť</translation>
    </message>
    <message>
        <source>These settings affect the entry&apos;s behaviour with the browser extension.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Additional URLs</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Only send this entry to the browser for HTTP Auth dialogs. If enabled, normal login forms will not show this entry for selection.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Do not send this entry to the browser for HTTP Auth dialogs. If enabled, HTTP Auth dialogs will not show this entry for selection.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>EditEntryWidgetHistory</name>
    <message>
        <source>Entry history selection</source>
        <translation>Výber histórie položky</translation>
    </message>
    <message>
        <source>Show entry at selected history state</source>
        <translation>Zobraziť stav položky v okamžiku zvolenej histórie</translation>
    </message>
    <message>
        <source>Show</source>
        <translation>Zobraziť</translation>
    </message>
    <message>
        <source>Restore entry to selected history state</source>
        <translation>Obnoviť stav položky do okamžiku zvolenej histórie</translation>
    </message>
    <message>
        <source>Restore</source>
        <translation>Vrátiť</translation>
    </message>
    <message>
        <source>Delete selected history state</source>
        <translation>Vymazať zvolený stav histórie</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Odstrániť</translation>
    </message>
    <message>
        <source>Delete all history</source>
        <translation>Vymazať celú históriu</translation>
    </message>
    <message>
        <source>Delete all</source>
        <translation>Odstrániť všetko</translation>
    </message>
</context>
<context>
    <name>EditEntryWidgetMain</name>
    <message>
        <source>Edit Entry</source>
        <translation>Upraviť položku</translation>
    </message>
    <message>
        <source>Notes field</source>
        <translation>Pole poznámok</translation>
    </message>
    <message>
        <source>Username field</source>
        <translation>Pole použ. mena</translation>
    </message>
    <message>
        <source>Expiration field</source>
        <translation>Pole doby platnosti</translation>
    </message>
    <message>
        <source>Expiration Presets</source>
        <translation>Prednastavenia platnosti</translation>
    </message>
    <message>
        <source>Expiration presets</source>
        <translation>Prednastavenia platnosti</translation>
    </message>
    <message>
        <source>Presets</source>
        <translation>Predvoľby</translation>
    </message>
    <message>
        <source>Url field</source>
        <translation>Pole URL</translation>
    </message>
    <message>
        <source>Download favicon for URL</source>
        <translation>Stiahnuť ikonu URL</translation>
    </message>
    <message>
        <source>Title field</source>
        <translation>Pole nadpisu</translation>
    </message>
    <message>
        <source>Password field</source>
        <translation>Pole pre heslo</translation>
    </message>
    <message>
        <source>Toggle expiration</source>
        <translation>Prepnúť dobu platnosti</translation>
    </message>
    <message>
        <source>Tags list</source>
        <translation>Zoznam štítkov</translation>
    </message>
    <message>
        <source>&amp;Username:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>&amp;Title:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>&amp;Password:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>UR&amp;L:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>&amp;Notes:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Toggle notes visibility</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>T&amp;ags:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>&amp;Expires:</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>EditEntryWidgetSSHAgent</name>
    <message>
        <source>Form</source>
        <translation>Formulár</translation>
    </message>
    <message>
        <source>Remove key from agent when database is closed/locked</source>
        <translation>Odstrániť kľúč z agenta po zatvorení/zamknutí databázy</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>Komentár</translation>
    </message>
    <message>
        <source>Add key to agent when database is opened/unlocked</source>
        <translation>Pridať kľúč do agenta keď je databáza otvorená/odomknutá</translation>
    </message>
    <message>
        <source>Decrypt</source>
        <translation>Dešifrovať</translation>
    </message>
    <message>
        <source>Fingerprint</source>
        <translation>Odtlačok</translation>
    </message>
    <message>
        <source>Copy to clipboard</source>
        <translation>Kopírovať do schránky</translation>
    </message>
    <message>
        <source>Public key</source>
        <translation>Verejný kľúč</translation>
    </message>
    <message>
        <source>Private key</source>
        <translation>Súkromný kľúč</translation>
    </message>
    <message>
        <source>Attachment</source>
        <translation>Príloha</translation>
    </message>
    <message>
        <source>External key file</source>
        <translation>Súbor externého kľúča</translation>
    </message>
    <message>
        <source>Add to agent</source>
        <translation>Pridať do agenta</translation>
    </message>
    <message>
        <source>Remove from agent</source>
        <translation>Odstrániť z agenta</translation>
    </message>
    <message>
        <source>External file</source>
        <translation>Externý súbor</translation>
    </message>
    <message>
        <source>Browser for key file</source>
        <translation>Vybrať súbor kľúča</translation>
    </message>
    <message>
        <source>Browse…</source>
        <extracomment>Button for opening file dialog</extracomment>
        <translation>Prechádzať…</translation>
    </message>
    <message>
        <source>Generate</source>
        <translation>Generovať</translation>
    </message>
    <message>
        <source>Select attachment file</source>
        <translation>Zvoľte súbor prílohy</translation>
    </message>
    <message>
        <source>Require user confirmation when this key is used</source>
        <translation>Vyžadovať potvrdenie používateľa, keď je tento kľúč použitý</translation>
    </message>
    <message>
        <source>n/a</source>
        <translation>neznáme</translation>
    </message>
    <message>
        <source>Remove key from agent after</source>
        <translation>Odstrániť kľúč z agenta po</translation>
    </message>
    <message>
        <source>Remove key from agent after specified seconds</source>
        <translation>Odstrániť kľúč z agenta po zadanom počte sekúnd</translation>
    </message>
    <message>
        <source> seconds</source>
        <translation>sekundy</translation>
    </message>
    <message>
        <source>Clear agent</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>EditGroupWidget</name>
    <message>
        <source>Group</source>
        <translation>Skupina</translation>
    </message>
    <message>
        <source>Icon</source>
        <translation>Ikona</translation>
    </message>
    <message>
        <source>Properties</source>
        <translation>Vlastnosti</translation>
    </message>
    <message>
        <source>Add group</source>
        <translation>Pridať skupinu</translation>
    </message>
    <message>
        <source>Edit group</source>
        <translation>Upraviť skupinu</translation>
    </message>
    <message>
        <source>Group has unsaved changes</source>
        <translation>Skupina má neuložené zmeny</translation>
    </message>
    <message>
        <source>Browser Integration</source>
        <translation>Integrácia prehliadača</translation>
    </message>
    <message>
        <source>Enable</source>
        <translation>Zapnúť</translation>
    </message>
    <message>
        <source>Disable</source>
        <translation>Vypnúť</translation>
    </message>
    <message>
        <source>Inherit from parent group (%1)</source>
        <translation>Zdediť z nadradenej skupiny (%1)</translation>
    </message>
</context>
<context>
    <name>EditGroupWidgetBrowser</name>
    <message>
        <source>These settings affect to the group&apos;s behaviour with the browser extension.</source>
        <translation>Tieto nastavenia ovplyvňujú správanie skupiny s doplnkom prehliadača.</translation>
    </message>
    <message>
        <source>Hide entries from browser extension:</source>
        <translation>Skryť túto položku v rozšírení prehliadača:</translation>
    </message>
    <message>
        <source>Hide entries from browser extension toggle for this and sub groups</source>
        <translation>Schovať záznamy pred rozšírenim v prehliadači pre túto skupinu a podskupiny</translation>
    </message>
    <message>
        <source>Skip Auto-Submit for entries:</source>
        <translation>Vypnúť Automatické Vypĺňanie pre tieto položky:</translation>
    </message>
    <message>
        <source>Skip Auto-Submit toggle for this and sub groups</source>
        <translation>Vypnúť Automatické vypĺňanie pre túto skupinu a podskupiny</translation>
    </message>
    <message>
        <source>Use entries only with HTTP Basic Auth:</source>
        <translation>Použiť položky len pre HTTP Basic Auth:</translation>
    </message>
    <message>
        <source>Only HTTP Auth toggle for this and sub groups</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Do not use entries with HTTP Basic Auth:</source>
        <translation>Nepoužívať položky s HTTP Basic Auth:</translation>
    </message>
    <message>
        <source>Do not use HTTP Auth toggle for this and sub groups</source>
        <translation>Nepoužívať HTTP Auth pre túto a podriadené skupiny</translation>
    </message>
    <message>
        <source>Omit WWW subdomain from matching:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Omit WWW subdomain from matching toggle for this and sub groups</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Restrict matching to given browser key:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Restrict matching to given browser key toggle for this and sub groups</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>EditGroupWidgetKeeShare</name>
    <message>
        <source>Sharing mode field</source>
        <translation>Pole režimu zdieľania</translation>
    </message>
    <message>
        <source>Password field</source>
        <translation>Pole pre heslo</translation>
    </message>
    <message>
        <source>Type:</source>
        <translation>Typ:</translation>
    </message>
    <message>
        <source>Password:</source>
        <translation>Heslo:</translation>
    </message>
    <message>
        <source>Path:</source>
        <translation>Cesta:</translation>
    </message>
    <message>
        <source>Path to share file field</source>
        <translation>Pole cesty zdieľania súboru</translation>
    </message>
    <message>
        <source>Browse for share file</source>
        <translation>Vybrať zdieľaný súbor</translation>
    </message>
    <message>
        <source>Browse…</source>
        <translation>Prechádzať…</translation>
    </message>
    <message>
        <source>Clear fields</source>
        <translation>Vymazať polia</translation>
    </message>
    <message>
        <source>Clear</source>
        <translation>Vymazať</translation>
    </message>
    <message>
        <source>Inactive</source>
        <translation>Neaktívne</translation>
    </message>
    <message>
        <source>Import</source>
        <translation>Importovať</translation>
    </message>
    <message>
        <source>Export</source>
        <translation>Export</translation>
    </message>
    <message>
        <source>Synchronize</source>
        <translation>Synchronizovať</translation>
    </message>
    <message>
        <source>Your KeePassXC version does not support sharing this container type.
Supported extensions are: %1.</source>
        <translation>Táto verzia KeePassXC nepodporuje zdieľanie tohoto typu kontajnera.
Podporované rozšírenia sú: %1.</translation>
    </message>
    <message>
        <source>%1 is already being exported by this database.</source>
        <translation>%1 už bolo exportované touto databázou.</translation>
    </message>
    <message>
        <source>%1 is already being imported by this database.</source>
        <translation>%1 už bolo importované touto databázou.</translation>
    </message>
    <message>
        <source>%1 is being imported and exported by different groups in this database.</source>
        <translation>%1 má byť importované a exportované rôznymi skupinami tejto databázy.</translation>
    </message>
    <message>
        <source>KeeShare is currently disabled. You can enable import/export in the application settings.</source>
        <comment>KeeShare is a proper noun</comment>
        <translation>KeeShare je momentálne vypnuté. Import/export môžete zapnúť v nastaveniach aplikácie.</translation>
    </message>
    <message>
        <source>Database export is currently disabled by application settings.</source>
        <translation>Export databázy je momentálne vypnutý v nastaveniach aplikácie.</translation>
    </message>
    <message>
        <source>Database import is currently disabled by application settings.</source>
        <translation>Import databázy je momentálne vypnutý v nastaveniach aplikácie.</translation>
    </message>
    <message>
        <source>KeeShare container</source>
        <translation>Kontajner KeeShare</translation>
    </message>
    <message>
        <source>KeeShare signed container</source>
        <translation>Podpísaný kontajner KeeShare</translation>
    </message>
    <message>
        <source>Select import source</source>
        <translation>Vyberte zdroj importu</translation>
    </message>
    <message>
        <source>Select export target</source>
        <translation>Vyberte cieľ exportu</translation>
    </message>
    <message>
        <source>Select import/export file</source>
        <translation>Vyberte súbor importu/exportu</translation>
    </message>
    <message>
        <source>Maintain group structure with shared database</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Keep Group Structure</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>EditGroupWidgetMain</name>
    <message>
        <source>Edit Group</source>
        <translation>Upraviť skupinu</translation>
    </message>
    <message>
        <source>Toggle expiration</source>
        <translation>Prepnúť dobu platnosti</translation>
    </message>
    <message>
        <source>Expires:</source>
        <translation>Platí do:</translation>
    </message>
    <message>
        <source>Name field</source>
        <translation>Pole mena</translation>
    </message>
    <message>
        <source>Expiration field</source>
        <translation>Pole doby platnosti</translation>
    </message>
    <message>
        <source>Use default Auto-Type sequence of parent group</source>
        <translation>Použiť predvolenú postupnosť Automatického vypĺňania rodičovskej skupiny</translation>
    </message>
    <message>
        <source>Auto-Type:</source>
        <translation>Automatické vypĺňanie:</translation>
    </message>
    <message>
        <source>Search:</source>
        <translation>Hľadať:</translation>
    </message>
    <message>
        <source>Auto-Type toggle for this and sub groups</source>
        <translation>Prepnúť Automatické dopĺňanie tejto a vnorených skupín</translation>
    </message>
    <message>
        <source>Notes:</source>
        <translation>Poznámky:</translation>
    </message>
    <message>
        <source>Default auto-type sequence field</source>
        <translation>Pole postupnosti Automatického vypĺňania</translation>
    </message>
    <message>
        <source>Notes field</source>
        <translation>Pole poznámok</translation>
    </message>
    <message>
        <source>Name:</source>
        <translation>Názov:</translation>
    </message>
    <message>
        <source>Set default Auto-Type sequence</source>
        <translation>Nastaviť predvolenú postupnosť Automatického vypĺňania</translation>
    </message>
    <message>
        <source>Search toggle for this and sub groups</source>
        <translation>Prepnúť hľadanie tejto a podriadených skupín</translation>
    </message>
</context>
<context>
    <name>EditWidgetIcons</name>
    <message>
        <source>Use default icon</source>
        <translation>Použiť predvolenú ikonu</translation>
    </message>
    <message>
        <source>Use custom icon</source>
        <translation>Použiť vlastnú ikonu</translation>
    </message>
    <message>
        <source>Choose icon…</source>
        <translation>Vybrať ikonu...</translation>
    </message>
    <message>
        <source>Set the URL to use to search for a favicon</source>
        <translation>URL adresa použitá pre vyhľadávanie Favikonu</translation>
    </message>
    <message>
        <source>Favicon URL</source>
        <translation>URL Adresa Favikonu</translation>
    </message>
    <message>
        <source>Download favicon for URL</source>
        <translation>Stiahnuť ikonu URL</translation>
    </message>
    <message>
        <source>Download favicon</source>
        <translation>Stiahnuť ikonu stránky</translation>
    </message>
    <message>
        <source>Apply selected icon to subgroups and entries</source>
        <translation>Použiť zvolenú ikonu na podskupiny a položky</translation>
    </message>
    <message>
        <source>Apply icon to…</source>
        <translation>Použiť ikonu na…</translation>
    </message>
    <message>
        <source>Apply to this group only</source>
        <translation>Použiť len na túto skupinu</translation>
    </message>
    <message>
        <source>Also apply to child groups</source>
        <translation>Použiť aj na podriadené skupiny</translation>
    </message>
    <message>
        <source>Also apply to child entries</source>
        <translation>Použiť aj na podriadené položky</translation>
    </message>
    <message>
        <source>Also apply to all children</source>
        <translation>Použiť na všetkých potomkov</translation>
    </message>
    <message>
        <source>Unable to fetch favicon.</source>
        <translation>Nemožno stiahnuť ikonu stránky</translation>
    </message>
    <message>
        <source>Existing icon selected.</source>
        <translation>Zvolená existujúca ikona.</translation>
    </message>
    <message>
        <source>Images</source>
        <translation>Obrázky</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>Všetky súbory</translation>
    </message>
    <message>
        <source>Select Image(s)</source>
        <translation>vyberte obrázok(y)</translation>
    </message>
    <message numerus="yes">
        <source>Successfully loaded %1 of %n icon(s)</source>
        <translation><numerusform>Úspešne načítané %1 z %n ikony</numerusform><numerusform>Úspešne načítané %1 z %n ikon</numerusform><numerusform>Úspešne načítané %1 z %n ikon</numerusform><numerusform>Úspešne načítané %1 z %n ikony</numerusform></translation>
    </message>
    <message>
        <source>No icons were loaded</source>
        <translation>Neboli načítané ikony</translation>
    </message>
    <message numerus="yes">
        <source>%n icon(s) already exist in the database</source>
        <translation><numerusform>%n ikony už v databáze existuje</numerusform><numerusform>%n ikony už v databáze existujú</numerusform><numerusform>%n ikon už v databáze existuje</numerusform><numerusform>%n ikony už v databáze existuje</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>The following icon(s) failed:</source>
        <translation><numerusform>Nasledujúca ikona zlyhala:</numerusform><numerusform>Nasledujúce ikony zlyhali:</numerusform><numerusform>Nasledujúce ikony zlyhali:</numerusform><numerusform>Nasledujúce ikony zlyhali:</numerusform></translation>
    </message>
    <message>
        <source>You can enable the DuckDuckGo website icon service under Application Settings -&gt; Security</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>EditWidgetProperties</name>
    <message>
        <source>Created:</source>
        <translation>Vytvorené:</translation>
    </message>
    <message>
        <source>Datetime created</source>
        <translation>Dátum a čas vytvorenia</translation>
    </message>
    <message>
        <source>Modified:</source>
        <translation>Zmenené:</translation>
    </message>
    <message>
        <source>Datetime modified</source>
        <translation>Dátum a čas úpravy</translation>
    </message>
    <message>
        <source>Uuid:</source>
        <translation>UUID:</translation>
    </message>
    <message>
        <source>Unique ID</source>
        <translation>Jedinečné ID</translation>
    </message>
    <message>
        <source>Plugin Data</source>
        <translation>Dáta zásuvného modulu</translation>
    </message>
    <message>
        <source>Plugin data</source>
        <translation>Dáta zásuvného modulu</translation>
    </message>
    <message>
        <source>Remove selected plugin data</source>
        <translation>Odstrániť dáta zásuvného modulu</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Odstrániť</translation>
    </message>
    <message>
        <source>Delete plugin data?</source>
        <translation>Odstrániť dáta zásuvného modulu?</translation>
    </message>
    <message>
        <source>Do you really want to delete the selected plugin data?
This may cause the affected plugins to malfunction.</source>
        <translation>Naozaj chcete odstrániť dáta zvoleného zásuvného modulu?
Môže to spôsobiť nefunkčnosť dotknutých zásuvných modulov.</translation>
    </message>
    <message>
        <source>Key</source>
        <translation>Kľúč</translation>
    </message>
    <message>
        <source>Value</source>
        <translation>Hodnota</translation>
    </message>
</context>
<context>
    <name>Entry</name>
    <message>
        <source>%1 - Clone</source>
        <translation>%1 – Klon</translation>
    </message>
    <message>
        <source>Passkey</source>
        <translation>Prístupový kľúč</translation>
    </message>
    <message>
        <source>Invalid conversion type: %1</source>
        <translation>Neplatný typ konverzie: %1</translation>
    </message>
    <message>
        <source>Invalid conversion syntax: %1</source>
        <translation>Neplatná syntax konverzie: %1</translation>
    </message>
    <message>
        <source>Invalid regular expression syntax %1
%2</source>
        <translation>Neplatná syntax regulárneho výrazu %1
%2</translation>
    </message>
    <message>
        <source>Title</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Username</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Password</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>URL</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Notes</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Custom Attributes</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Icon</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Color</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Expiration</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>TOTP</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Custom Data</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Attachments</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Auto-Type</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Tags</source>
        <translation>Štítky</translation>
    </message>
</context>
<context>
    <name>EntryAttachments</name>
    <message>
        <source>Cannot open file &quot;%1&quot;</source>
        <translation>Nemožno otvoriť súbor „%1”.</translation>
    </message>
</context>
<context>
    <name>EntryAttachmentsModel</name>
    <message>
        <source>Name</source>
        <translation>Názov</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Veľkosť</translation>
    </message>
</context>
<context>
    <name>EntryAttachmentsWidget</name>
    <message>
        <source>Form</source>
        <translation>Formulár</translation>
    </message>
    <message>
        <source>Attachments</source>
        <translation>Prílohy</translation>
    </message>
    <message>
        <source>Add new attachment</source>
        <translation>Pridať novú prílohu</translation>
    </message>
    <message>
        <source>Remove selected attachment</source>
        <translation>Odstrániť zvolenú prílohu</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Odstrániť</translation>
    </message>
    <message>
        <source>Open selected attachment</source>
        <translation>Otvoriť zvolenú prílohu</translation>
    </message>
    <message>
        <source>Open</source>
        <translation>Otvoriť</translation>
    </message>
    <message>
        <source>Save selected attachment to disk</source>
        <translation>Uložiť zvolenú prílohu na disk</translation>
    </message>
    <message>
        <source>Select files</source>
        <translation>Zvoľte súbory</translation>
    </message>
    <message>
        <source>Confirm remove</source>
        <translation>Potvrdiť odstránenie</translation>
    </message>
    <message numerus="yes">
        <source>Are you sure you want to remove %n attachment(s)?</source>
        <translation><numerusform>Naozaj chcete odstrániť %n prílohu?</numerusform><numerusform>Naozaj chcete odstrániť %n prílohy?</numerusform><numerusform>Naozaj chcete odstrániť %n príloh?</numerusform><numerusform>Naozaj chcete odstrániť %n príloh?</numerusform></translation>
    </message>
    <message>
        <source>Save attachments</source>
        <translation>Uložiť prílohy</translation>
    </message>
    <message>
        <source>Unable to create directory:
%1</source>
        <translation>Nemožno vytvoriť zložku:
%1</translation>
    </message>
    <message>
        <source>Are you sure you want to overwrite the existing file &quot;%1&quot; with the attachment?</source>
        <translation>Naozaj chcete prepísať existujúci súbor „%1” prílohou?</translation>
    </message>
    <message>
        <source>Confirm overwrite</source>
        <translation>Potvrďte prepísanie</translation>
    </message>
    <message>
        <source>Unable to save attachments:
%1</source>
        <translation>Nemožno uložiť prílohy:
%1</translation>
    </message>
    <message>
        <source>Unable to open attachment:
%1</source>
        <translation>Nemožno otvoriť prílohu:
%1</translation>
    </message>
    <message>
        <source>Unable to open attachments:
%1</source>
        <translation>Nemožno otvoriť prílohy:
%1</translation>
    </message>
    <message numerus="yes">
        <source>Unable to open file(s):
%1</source>
        <translation><numerusform>Nemožno otvoriť súbor:
%1</numerusform><numerusform>Nemožno otvoriť súbory:
%1</numerusform><numerusform>Nemožno otvoriť súbory:
%1</numerusform><numerusform>Nemožno otvoriť súbory:
%1</numerusform></translation>
    </message>
    <message>
        <source>Confirm Overwrite Attachment</source>
        <translation>Potvrďte Prepísanie Prílohy</translation>
    </message>
    <message>
        <source>Confirm Attachment</source>
        <translation>Potvrdiť prílohu</translation>
    </message>
    <message>
        <source>%1 is a big file (%2 MB).
Your database may get very large and reduce performance.

Are you sure to add this file?</source>
        <translation>%1 je veľký súbor (%2 MB).
Vaša databáza môže veľmi narásť a znížiť výkon.

Naozaj chcete pridať tento súbor?</translation>
    </message>
    <message>
        <source>Attachment modified</source>
        <translation>Príloha zmenená</translation>
    </message>
    <message>
        <source>The attachment '%1' was modified.
Do you want to save the changes to your database?</source>
        <translation>Príloha „%1” bola zmenená.
Chcete uložiť zmeny vo svojej databáze?</translation>
    </message>
    <message>
        <source>Saving attachment failed</source>
        <translation>Uloženie prílohy zlyhalo</translation>
    </message>
    <message>
        <source>Saving updated attachment failed.
Error: %1</source>
        <translation>Uloženie aktualizovanej prílohy zlyhalo.
Chyba: %1</translation>
    </message>
    <message>
        <source>Attachment &quot;%1&quot; already exists. 
Would you like to overwrite the existing attachment?</source>
        <translation>Príloha &quot;%1&quot; už existuje.
Prepísať existujúcu prílohu?</translation>
    </message>
    <message>
        <source>Preview</source>
        <translation>Ukážka</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Upraviť</translation>
    </message>
    <message>
        <source>New Text Document</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Add file…</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Load from Disk…</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Save…</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>New Attachment</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>EntryAttributesModel</name>
    <message>
        <source>Name</source>
        <translation>Názov</translation>
    </message>
</context>
<context>
    <name>EntryHistoryModel</name>
    <message>
        <source>Current (%1)</source>
        <translation>Súčasný (%1)</translation>
    </message>
    <message>
        <source>Last modified</source>
        <translation>Posledná úprava</translation>
    </message>
    <message>
        <source>Age</source>
        <translation>Vek</translation>
    </message>
    <message>
        <source>Difference</source>
        <translation>Rozdiel</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Veľkosť</translation>
    </message>
</context>
<context>
    <name>EntryModel</name>
    <message>
        <source>Ref: </source>
        <comment>Reference abbreviation</comment>
        <translation>Ref: </translation>
    </message>
    <message>
        <source>Never</source>
        <translation>Nikdy</translation>
    </message>
    <message>
        <source>Group</source>
        <translation>Skupina</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>Nadpis</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>Používateľské meno</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Heslo</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>Notes</source>
        <translation>Poznámky</translation>
    </message>
    <message>
        <source>Expires</source>
        <translation>Platí do</translation>
    </message>
    <message>
        <source>Created</source>
        <translation>Vytvorené</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Upravené</translation>
    </message>
    <message>
        <source>Attachments</source>
        <translation>Prílohy</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Veľkosť</translation>
    </message>
    <message>
        <source>Group name</source>
        <translation>Názov skupiny</translation>
    </message>
    <message>
        <source>Entry title</source>
        <translation>Názov položky</translation>
    </message>
    <message>
        <source>Password Strength</source>
        <translation>Sila hesla</translation>
    </message>
    <message>
        <source>Entry notes</source>
        <translation>Poznámky položky</translation>
    </message>
    <message>
        <source>Entry expires at</source>
        <translation>Položka platí do</translation>
    </message>
    <message>
        <source>Creation date</source>
        <translation>Dátum vytvorenia</translation>
    </message>
    <message>
        <source>Last modification date</source>
        <translation>Dátum poslednej úpravy</translation>
    </message>
    <message>
        <source>Attached files</source>
        <translation>Pripojené súbory</translation>
    </message>
    <message>
        <source>Entry size</source>
        <translation>Veľkosť položky</translation>
    </message>
    <message>
        <source>Has attachments</source>
        <translation>Má prílohy</translation>
    </message>
    <message>
        <source>Has TOTP</source>
        <translation>Má TOTP</translation>
    </message>
    <message>
        <source>Background Color</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Group Path</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>EntryPreviewWidget</name>
    <message>
        <source>Display current TOTP value</source>
        <translation>Zobraziť aktuálnu hodnotu TOTP</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Zatvoriť</translation>
    </message>
    <message>
        <source>General</source>
        <translation>Všeobecné</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Heslo</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>Expiration</source>
        <translation>Platí do</translation>
    </message>
    <message>
        <source>Tags</source>
        <translation>Štítky</translation>
    </message>
    <message>
        <source>Tags list</source>
        <translation>Zoznam štítkov</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>Použ. meno:</translation>
    </message>
    <message>
        <source>Notes</source>
        <translation>Poznámky</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>Pokročilé</translation>
    </message>
    <message>
        <source>Attachments</source>
        <translation>Prílohy</translation>
    </message>
    <message>
        <source>Attributes</source>
        <translation>Atribúty</translation>
    </message>
    <message>
        <source>Autotype</source>
        <translation>Automatické vypĺňanie</translation>
    </message>
    <message>
        <source>Default Sequence</source>
        <translation>Predvolená postupnosť</translation>
    </message>
    <message>
        <source>Window</source>
        <translation>Okno</translation>
    </message>
    <message>
        <source>Sequence</source>
        <translation>Postupnosť</translation>
    </message>
    <message>
        <source>Searching</source>
        <translation>Hľadanie</translation>
    </message>
    <message>
        <source>Share</source>
        <translation>Zdieľať</translation>
    </message>
    <message>
        <source>Search</source>
        <translation>Hľadať</translation>
    </message>
    <message>
        <source>Clear</source>
        <translation>Vymazať</translation>
    </message>
    <message>
        <source>Never</source>
        <translation>Nikdy</translation>
    </message>
    <message>
        <source>Double click to copy value</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Enabled</source>
        <translation>Zapnuté</translation>
    </message>
    <message>
        <source>Disabled</source>
        <translation>Vypnuté</translation>
    </message>
    <message>
        <source>Double click to copy to clipboard</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>EntryURLModel</name>
    <message>
        <source>Invalid URL</source>
        <translation>Neplatná URL</translation>
    </message>
    <message>
        <source>Duplicate URL</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>EntryView</name>
    <message>
        <source>Fit to window</source>
        <translation>Prispôsobiť oknu</translation>
    </message>
    <message>
        <source>Fit to contents</source>
        <translation>Prispôsobiť obsahu</translation>
    </message>
    <message>
        <source>Reset to defaults</source>
        <translation>Obnoviť predvolené</translation>
    </message>
    <message numerus="yes">
        <source>+ %1 entry(s)...</source>
        <translation type="unfinished"><numerusform></numerusform><numerusform></numerusform><numerusform></numerusform><numerusform></numerusform></translation>
    </message>
</context>
<context>
    <name>ExportDialog</name>
    <message>
        <source>Export options</source>
        <translation>Možnosti Exportovania</translation>
    </message>
    <message>
        <source>Sort entries by...</source>
        <translation>Zoradiť záznamy podľa...</translation>
    </message>
    <message>
        <source>You are about to export your database to an unencrypted file.
This will leave your passwords and sensitive information vulnerable!
</source>
        <translation>Chystáte sa exportovať svoju databázu do nešifrovaného súboru.
 Takto necháte svoje heslá a citlivé informácie nechránené!
</translation>
    </message>
    <message>
        <source>database order</source>
        <translation>poradie databázy</translation>
    </message>
    <message>
        <source>name (ascending)</source>
        <translation>mena (vzostupne)</translation>
    </message>
    <message>
        <source>name (descending)</source>
        <translation>mena (zostupne)</translation>
    </message>
    <message>
        <source>Export database to HTML file</source>
        <translation>Exportovať databázu do súboru HTML</translation>
    </message>
    <message>
        <source>HTML file</source>
        <translation>Súbor HTML</translation>
    </message>
    <message>
        <source>invalid sort order</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>FdoSecrets::DBusMgr</name>
    <message>
        <source>Failed to deliver message</source>
        <translation>Doručenie správy zlyhalo</translation>
    </message>
    <message>
        <source>Failed to send reply on DBus</source>
        <translation>Zlyhalo poslanie odpovede DBus</translation>
    </message>
    <message>
        <source>Unknown</source>
        <comment>Unknown PID</comment>
        <translation>Neznámy</translation>
    </message>
    <message>
        <source>Unknown</source>
        <comment>Unknown executable path</comment>
        <translation>Neznámy</translation>
    </message>
    <message>
        <source>&lt;i&gt;PID: %1, Executable: %2&lt;/i&gt;</source>
        <comment>&lt;i&gt;PID: 1234, Executable: /path/to/exe&lt;/i&gt;</comment>
        <translation>&lt;i&gt;PID: %1, príkaz: %2&lt;/i&gt;</translation>
    </message>
    <message>
        <source>Another secret service is running (%1).&lt;br/&gt;Please stop/remove it before re-enabling the Secret Service Integration.</source>
        <translation>Je spustená iná tajná služba (%1).&lt;br/&gt;Prosím, zastavte/odstráňte ju pred zapnutím Integrácie Tajnej služby.</translation>
    </message>
    <message>
        <source>Failed to register DBus service at %1.&lt;br/&gt;</source>
        <translation>Zlyhala registrácia služby DBus na %1.</translation>
    </message>
    <message>
        <source>Failed to register service on DBus at path &apos;%1&apos;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Failed to register database on DBus under the name &apos;%1&apos;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Failed to register session on DBus at path &apos;%1&apos;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Failed to register item on DBus at path &apos;%1&apos;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Failed to register prompt object on DBus at path &apos;%1&apos;</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>FdoSecrets::Item</name>
    <message>
        <source>Entry &quot;%1&quot; from database &quot;%2&quot; was used by %3</source>
        <translation>Položka „%1” z databázy „%2” bola použitá %3</translation>
    </message>
</context>
<context>
    <name>FdoSecrets::Service</name>
    <message numerus="yes">
        <source>%n Entry(s) was used by %1</source>
        <comment>%1 is the name of an application</comment>
        <translation><numerusform>%n položka použitá v %1</numerusform><numerusform>%n položky použité v %1</numerusform><numerusform>%n položiek použitých v %1</numerusform><numerusform>%n položky použité v %1</numerusform></translation>
    </message>
</context>
<context>
    <name>FdoSecrets::SettingsClientModel</name>
    <message>
        <source>Unknown</source>
        <translation>Neznámy</translation>
    </message>
    <message>
        <source>Non-existing/inaccessible executable path. Please double-check the client is legit.</source>
        <translation>Cesta k súboru neexistuje alebo nieje dostupná. Prosím, uistite sa či je klient pravý.</translation>
    </message>
</context>
<context>
    <name>FdoSecrets::SettingsDatabaseModel</name>
    <message>
        <source>Unlock to show</source>
        <translation>Odomknúť na zobrazenie</translation>
    </message>
    <message>
        <source>None</source>
        <translation>Žiadny</translation>
    </message>
</context>
<context>
    <name>FdoSecrets::UnlockPrompt</name>
    <message>
        <source>%1 (PID: %2)</source>
        <translation>%1 (PID: %2)</translation>
    </message>
</context>
<context>
    <name>FdoSecretsPlugin</name>
    <message>
        <source>&lt;b&gt;Fdo Secret Service:&lt;/b&gt; %1</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>GlobalShortcutsPortal</name>
    <message>
        <source>KeePassXC - Global Shortcuts</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>The XDG Desktop Portal for global shortcuts is not available on this system.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Global Auto-Type shortcut is already configured. To change it, open your system settings and navigate to the keyboard or application shortcuts section.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Trigger global Auto-Type</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>Group</name>
    <message>
        <source>[empty]</source>
        <comment>group has no children</comment>
        <translation>[prázdne]</translation>
    </message>
    <message>
        <source>%1 - Clone</source>
        <translation>%1 – Klon</translation>
    </message>
</context>
<context>
    <name>HibpDownloader</name>
    <message>
        <source>Online password validation failed</source>
        <translation>Online overenie hesla zlyahlo</translation>
    </message>
</context>
<context>
    <name>IconDownloaderDialog</name>
    <message>
        <source>Download Favicons</source>
        <translation>Stiahnuť ikony</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Zrušiť</translation>
    </message>
    <message>
        <source>Having trouble downloading icons?
You can enable the DuckDuckGo website icon service in the security section of the application settings.</source>
        <translation>Máte problémy so sťahovaním ikon?
V bezpečnostnej sekcii nastavení aplikácie môžete zapnúť webovú službu ikon.</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Zatvoriť</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Status</translation>
    </message>
    <message>
        <source>Please wait, processing entry list…</source>
        <translation>Prosím, počkajte, spracovanie zoznamu položiek…</translation>
    </message>
    <message>
        <source>Downloading…</source>
        <translation>Sťahovanie…</translation>
    </message>
    <message>
        <source>Ok</source>
        <translation>Ok</translation>
    </message>
    <message>
        <source>Already Exists</source>
        <translation>Už existuje</translation>
    </message>
    <message>
        <source>Download Failed</source>
        <translation>Sťahovanie zlyhalo</translation>
    </message>
    <message>
        <source>Downloading favicons (%1/%2)…</source>
        <translation>Sťahovanie ikon (%1/%2)…</translation>
    </message>
</context>
<context>
    <name>ImageAttachmentsWidget</name>
    <message>
        <source>Zoom:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Fit</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>ImportWizard</name>
    <message>
        <source>Import Wizard</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>ImportWizardPageReview</name>
    <message>
        <source>WizardPage</source>
        <translation>Stránka sprievodcu</translation>
    </message>
    <message>
        <source>Entry count: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Group</source>
        <translation>Skupina</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>Nadpis</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>Používateľské meno</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Heslo</translation>
    </message>
    <message>
        <source>Url</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Could not load key file.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Could not open remote database. Password or key file may be incorrect.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>ImportWizardPageSelect</name>
    <message>
        <source>Form</source>
        <translation>Formulár</translation>
    </message>
    <message>
        <source>Import File Selection</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Password:</source>
        <translation>Heslo:</translation>
    </message>
    <message>
        <source>Key File:</source>
        <translation>Súbor kľúča:</translation>
    </message>
    <message>
        <source>Browse…</source>
        <translation>Prechádzať…</translation>
    </message>
    <message>
        <source>Import Into:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>New Database</source>
        <translation>Nová databáza</translation>
    </message>
    <message>
        <source>No unlocked databases available</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Existing Database:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Import File:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Comma Separated Values (.csv)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>1Password Export (.1pux)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>1Password Vault (.opvault)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Bitwarden (.json)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>KeePass 1 Database (.kdb)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Open OPVault</source>
        <translation>Otvoriť OPVault</translation>
    </message>
    <message>
        <source>Select import file</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>All files</source>
        <translation>Všetky súbory</translation>
    </message>
    <message>
        <source>Key files</source>
        <translation>Súbory kľúčov</translation>
    </message>
    <message>
        <source>Select key file</source>
        <translation>Zvoľte súbor kľúča</translation>
    </message>
    <message>
        <source>Comma Separated Values</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>1Password Export</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Bitwarden JSON Export</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>1Password Vault</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>KeePass1 Database</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Proton Pass (.json)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Proton Pass JSON Export</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Temporary Database</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Command:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>e.g.: &quot;sftp user@hostname&quot; or &quot;scp user@hostname:DatabaseOnRemote.kdbx {TEMP_DATABASE}&quot;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Input:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>e.g.:
get DatabaseOnRemote.kdbx {TEMP_DATABASE}
exit
---
{TEMP_DATABASE} is used as placeholder to store the database in a temporary location
The command has to exit. In case of `sftp` as last commend `exit` has to be sent
         </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Remote Database (.kdbx)</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>KMessageWidget</name>
    <message>
        <source>&amp;Close</source>
        <translation>&amp;Zatvoriť</translation>
    </message>
    <message>
        <source>Close message</source>
        <translation>Zatvoriť správu</translation>
    </message>
</context>
<context>
    <name>Kdbx3Reader</name>
    <message>
        <source>Missing database headers</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Unable to calculate database key</source>
        <translation>Nemožno vypočítať kľúč databázy</translation>
    </message>
    <message>
        <source>Unable to issue challenge-response: %1</source>
        <translation>Nemožno vyvolať výzvu – odpoveď: %1</translation>
    </message>
    <message>
        <source>Invalid credentials were provided, please try again.
If this reoccurs, then your database file may be corrupt.</source>
        <translation>Boli zadané neplatné prihlasovacie údaje, prosím skúste znova.
Ak sa to opakuje, potom môže byť súbor databázy poškodený.</translation>
    </message>
    <message>
        <source>Header doesn&apos;t match hash</source>
        <translation>Hlavička nezodpovedá odtlačku</translation>
    </message>
    <message>
        <source>Invalid header id size</source>
        <translation>Neplatná veľkosť ID hlavičky</translation>
    </message>
    <message>
        <source>Invalid header field length: field %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Invalid header data length: field %1, %2 expected, %3 found</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>Kdbx3Writer</name>
    <message>
        <source>Invalid symmetric cipher IV size.</source>
        <comment>IV = Initialization Vector for symmetric cipher</comment>
        <translation>Neplatná veľkosť IV symetrickej šifry.</translation>
    </message>
    <message>
        <source>Unable to issue challenge-response: %1</source>
        <translation>Nemožno vyvolať výzvu – odpoveď: %1</translation>
    </message>
    <message>
        <source>Unable to calculate database key</source>
        <translation>Nemožno vypočítať kľúč databázy</translation>
    </message>
</context>
<context>
    <name>Kdbx4Reader</name>
    <message>
        <source>missing database headers</source>
        <translation>chýbajúce hlavičky databázy</translation>
    </message>
    <message>
        <source>Unable to calculate database key: %1</source>
        <translation>Nemožno vypočítať kľúč databázy: %1</translation>
    </message>
    <message>
        <source>Invalid header checksum size</source>
        <translation>Neplatná veľkosť kontrolného súčtu hlavičky</translation>
    </message>
    <message>
        <source>Header SHA256 mismatch</source>
        <translation>Nezhoda hlavičky SHA256</translation>
    </message>
    <message>
        <source>Invalid credentials were provided, please try again.
If this reoccurs, then your database file may be corrupt.</source>
        <translation>Boli zadané neplatné prihlasovacie údaje, prosím skúste znova.
Ak sa to opakuje, potom môže byť súbor databázy poškodený.</translation>
    </message>
    <message>
        <source>(HMAC mismatch)</source>
        <translation>(nezhoda HMAC)</translation>
    </message>
    <message>
        <source>Unknown cipher</source>
        <translation>Neznáma šifra</translation>
    </message>
    <message>
        <source>Invalid header id size</source>
        <translation>Neplatná veľkosť ID hlavičky</translation>
    </message>
    <message>
        <source>Invalid header field length: field %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Invalid header data length: field %1, %2 expected, %3 found</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Failed to open buffer for KDF parameters in header</source>
        <translation>Zlyhalo otvorenie bufera parametrov KDF v hlavičke</translation>
    </message>
    <message>
        <source>Unsupported key derivation function (KDF) or invalid parameters</source>
        <translation>Nepodporovaná funkcia odvodenia kľúča (KDF) alebo neplatné parametre</translation>
    </message>
    <message>
        <source>Legacy header fields found in KDBX4 file.</source>
        <translation>V súbore KDBX4 nájdené staré polia hlavičiek.</translation>
    </message>
    <message>
        <source>Invalid inner header id size</source>
        <translation>Neplatná veľkosť ID vnútornej hlavičky</translation>
    </message>
    <message>
        <source>Invalid inner header field length: field %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Invalid inner header data length: field %1, %2 expected, %3 found</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Invalid inner header binary size</source>
        <translation>Neplatná binárna veľkosť vnútornej hlavičky</translation>
    </message>
    <message>
        <source>Unsupported KeePass variant map version.</source>
        <extracomment>Translation: variant map = data structure for storing meta data</extracomment>
        <translation>Nepodporovaná verzia meta-dát KeePass.</translation>
    </message>
    <message>
        <source>Invalid variant map entry name length</source>
        <extracomment>Translation: variant map = data structure for storing meta data</extracomment>
        <translation>Neplatná dĺžka názvu položky mapy varianty</translation>
    </message>
    <message>
        <source>Invalid variant map entry name data</source>
        <extracomment>Translation: variant map = data structure for storing meta data</extracomment>
        <translation>Neplatné dáta názvu položky mapy varianty</translation>
    </message>
    <message>
        <source>Invalid variant map entry value length</source>
        <extracomment>Translation: variant map = data structure for storing meta data</extracomment>
        <translation>Neplatná dĺžka hodnoty položky mapy varianty
        </translation>
    </message>
    <message>
        <source>Invalid variant map entry value data</source>
        <extracomment>Translation comment: variant map = data structure for storing meta data</extracomment>
        <translation>Neplatné dáta hodnoty položky mapy varianty</translation>
    </message>
    <message>
        <source>Invalid variant map Bool entry value length</source>
        <extracomment>Translation: variant map = data structure for storing meta data</extracomment>
        <translation>Neplatná dĺžka hodnoty logickej položky meta-dát</translation>
    </message>
    <message>
        <source>Invalid variant map Int32 entry value length</source>
        <extracomment>Translation: variant map = data structure for storing meta data</extracomment>
        <translation>Neplatná dĺžka 32 bitovej celočíselnej hodnoty položky meta-dát</translation>
    </message>
    <message>
        <source>Invalid variant map UInt32 entry value length</source>
        <extracomment>Translation: variant map = data structure for storing meta data</extracomment>
        <translation>Neplatná dĺžka 32 bitovej kladnej celočíselné hodnoty meta-dát</translation>
    </message>
    <message>
        <source>Invalid variant map Int64 entry value length</source>
        <extracomment>Translation: variant map = data structure for storing meta data</extracomment>
        <translation>Neplatná dĺžka 64 bitovej celočíselnej hodnoty meta-dát</translation>
    </message>
    <message>
        <source>Invalid variant map UInt64 entry value length</source>
        <extracomment>Translation: variant map = data structure for storing meta data</extracomment>
        <translation>Neplatná dĺžka 64 bitovej kladnej celočíselné hodnoty meta-dát</translation>
    </message>
    <message>
        <source>Invalid variant map entry type</source>
        <extracomment>Translation: variant map = data structure for storing meta data</extracomment>
        <translation>Neplatný typ položky meta-dát</translation>
    </message>
    <message>
        <source>Invalid variant map field type size</source>
        <extracomment>Translation: variant map = data structure for storing meta data</extracomment>
        <translation>Neplatná veľkosť typu poľa meta-dát</translation>
    </message>
</context>
<context>
    <name>Kdbx4Writer</name>
    <message>
        <source>Invalid symmetric cipher algorithm.</source>
        <translation>Neplatný algoritmus symetrickej šifry.</translation>
    </message>
    <message>
        <source>Invalid symmetric cipher IV size.</source>
        <comment>IV = Initialization Vector for symmetric cipher</comment>
        <translation>Neplatná veľkosť IV symetrickej šifry.</translation>
    </message>
    <message>
        <source>Unable to calculate database key: %1</source>
        <translation>Nemožno vypočítať kľúč databázy: %1</translation>
    </message>
    <message>
        <source>Failed to serialize KDF parameters variant map</source>
        <extracomment>Translation comment: variant map = data structure for storing meta data</extracomment>
        <translation>Zlyhala serializácia parametrov KDF meta-dát</translation>
    </message>
</context>
<context>
    <name>KdbxReader</name>
    <message>
        <source>Invalid cipher uuid length: %1 (length=%2)</source>
        <translation>Neplatná dĺžka UUID šifry: %1 (length=%2)</translation>
    </message>
    <message>
        <source>Unable to parse UUID: %1</source>
        <translation>Nemožno spracovať UUID: %1</translation>
    </message>
    <message>
        <source>Unsupported cipher</source>
        <translation>Nepodporovaná šifra</translation>
    </message>
    <message>
        <source>Invalid compression flags length</source>
        <translation>Nepodporovaný komprimačný algoritmus</translation>
    </message>
    <message>
        <source>Unsupported compression algorithm</source>
        <translation>Nepodporovaný komprimačný algoritmus</translation>
    </message>
    <message>
        <source>Invalid master seed size</source>
        <translation>Neplatná veľkosť hlavnej náhodnosti (seed)</translation>
    </message>
    <message>
        <source>Invalid transform seed size</source>
        <translation>Neplatná transformácia hlavnej náhodnosti (seed)</translation>
    </message>
    <message>
        <source>Invalid transform rounds size</source>
        <translation>Neplatná veľkosť transformačných prechodov</translation>
    </message>
    <message>
        <source>Invalid start bytes size</source>
        <translation>Neplatná počiatočná veľkosť bajtov</translation>
    </message>
    <message>
        <source>Invalid random stream id size</source>
        <translation>Neplatná veľkosť ID náhodného prúdu</translation>
    </message>
    <message>
        <source>Invalid inner random stream cipher</source>
        <translation>Neplatná vnútorná náhodnosť prúdovej šifry</translation>
    </message>
    <message>
        <source>Failed to read database file.</source>
        <translation>Zlyhalo čítanie súboru databázy.</translation>
    </message>
    <message>
        <source>The selected file is an old KeePass 1 database (.kdb).

You can import it by clicking on Database &gt; 'Import KeePass 1 database…'.
This is a one-way migration. You won&apos;t be able to open the imported database with the old KeePassX 0.4 version.</source>
        <translation>Zvolený súbor je stará databáza KeePass 1 (.kdb).

Môžete ju importovať kliknutím na Databáza &gt; „Importovať databázu KeePass 1…”.
Je to jednosmerná migrácia. Importovanú databázu už nebude možné otvoriť pomocou starej verzie KeePassX 0.4.</translation>
    </message>
    <message>
        <source>Not a KeePass database.</source>
        <translation>Nie je databáza KeePass</translation>
    </message>
    <message>
        <source>Unsupported KeePass 2 database version.</source>
        <translation>Nepodporovaná verzia databázy KeePass 2.</translation>
    </message>
</context>
<context>
    <name>KdbxXmlReader</name>
    <message>
        <source>XML parsing failure: %1</source>
        <translation>Chyba spracovania XML: %1</translation>
    </message>
    <message>
        <source>No root group</source>
        <translation>Žiadna koreňová skupina</translation>
    </message>
    <message>
        <source>XML error:
%1
Line %2, column %3</source>
        <translation>Chyba XML:
%1
Riadok %2, stĺpec %3</translation>
    </message>
    <message>
        <source>Missing icon uuid or data</source>
        <translation>Chýbajúce UUID ikony alebo dáta</translation>
    </message>
    <message>
        <source>Missing custom data key or value</source>
        <translation>Chýbajúci kľúč alebo hodnota vlastných dát</translation>
    </message>
    <message>
        <source>Multiple group elements</source>
        <translation>Viaceré položky skupiny</translation>
    </message>
    <message>
        <source>Null group uuid</source>
        <translation>Nulový UUID skupiny</translation>
    </message>
    <message>
        <source>Invalid group icon number</source>
        <translation>Neplatný počet ikon skupiny</translation>
    </message>
    <message>
        <source>Invalid EnableAutoType value</source>
        <translation>Neplatná hodnota EnableAutoType</translation>
    </message>
    <message>
        <source>Invalid EnableSearching value</source>
        <translation>Neplatná hodnota EnableSearching</translation>
    </message>
    <message>
        <source>No group uuid found</source>
        <translation>Nenájdené UUID skupiny</translation>
    </message>
    <message>
        <source>Null DeleteObject uuid</source>
        <translation>Nulový UUID DeleteObject</translation>
    </message>
    <message>
        <source>Missing DeletedObject uuid or time</source>
        <translation>Chýbajúci UUID alebo čas DeletedObject</translation>
    </message>
    <message>
        <source>Null entry uuid</source>
        <translation>Nulový UUID položky</translation>
    </message>
    <message>
        <source>Invalid entry icon number</source>
        <translation>Neplatný počet ikon položky</translation>
    </message>
    <message>
        <source>History element in history entry</source>
        <translation>Prvok histórie v položke histórie</translation>
    </message>
    <message>
        <source>No entry uuid found</source>
        <translation>Nenájdené UUID položky</translation>
    </message>
    <message>
        <source>History element with different uuid</source>
        <translation>Prvok histórie s iným UUID</translation>
    </message>
    <message>
        <source>Duplicate custom attribute found</source>
        <translation>Nájdený duplicitný vlastný atribút</translation>
    </message>
    <message>
        <source>Entry string key or value missing</source>
        <translation>Chýba kľúč alebo hodnota reťazca položky</translation>
    </message>
    <message>
        <source>Entry binary key or value missing</source>
        <translation>Chýba binárny kľúč alebo hodnota položky</translation>
    </message>
    <message>
        <source>Auto-type association window or sequence missing</source>
        <translation>Chýba priradenie okna alebo postupnosť Automatického vypĺňania</translation>
    </message>
    <message>
        <source>Invalid bool value</source>
        <translation>Neplatná logická hodnota</translation>
    </message>
    <message>
        <source>Invalid date time value</source>
        <translation>Neplatná hodnota dátumu/času</translation>
    </message>
    <message>
        <source>Invalid color value</source>
        <translation>Neplatná hodnota farby</translation>
    </message>
    <message>
        <source>Invalid color rgb part</source>
        <translation>neplatná časť RGB farby</translation>
    </message>
    <message>
        <source>Invalid number value</source>
        <translation>Neplatná číselná hodnota</translation>
    </message>
    <message>
        <source>Invalid uuid value</source>
        <translation>Neplatná hodnota UUID</translation>
    </message>
    <message>
        <source>Unable to decompress binary</source>
        <extracomment>Translator meant is a binary data inside an entry</extracomment>
        <translation>Nemožno dekomprimovať binárku</translation>
    </message>
</context>
<context>
    <name>KeeAgentSettings</name>
    <message>
        <source>Invalid KeeAgent settings file structure.</source>
        <translation>Neplatná štruktúra súboru nastavení KeeAgent.</translation>
    </message>
    <message>
        <source>Private key is an attachment but no attachments provided.</source>
        <translation>Súkromný kľúč je prílohou, ale nie sú žiadne prílohy.</translation>
    </message>
    <message>
        <source>Private key is empty</source>
        <translation>Súkromný kľúč je prázdny</translation>
    </message>
    <message>
        <source>File too large to be a private key</source>
        <translation>Súbor je na súkromný kľúč príliš veľký</translation>
    </message>
    <message>
        <source>Failed to open private key</source>
        <translation>Zlyhalo otvorenie súkromného kľúča</translation>
    </message>
</context>
<context>
    <name>KeePass1Reader</name>
    <message>
        <source>Unable to read keyfile.</source>
        <translation>Nemožno čítať súbor kľúča.</translation>
    </message>
    <message>
        <source>Not a KeePass database.</source>
        <translation>Nie je databáza KeePass</translation>
    </message>
    <message>
        <source>Unsupported encryption algorithm.</source>
        <translation>Nepodporovaný šifrovací algoritmus.</translation>
    </message>
    <message>
        <source>Unsupported KeePass database version.</source>
        <translation>Nepodporovaná verzia databázy KeePass.</translation>
    </message>
    <message>
        <source>Unable to read encryption IV</source>
        <comment>IV = Initialization Vector for symmetric cipher</comment>
        <translation>Nemožno čítať šifrovací IV</translation>
    </message>
    <message>
        <source>Invalid number of groups</source>
        <translation>Neplatný počet skupín</translation>
    </message>
    <message>
        <source>Invalid number of entries</source>
        <translation>Neplatný počet položiek</translation>
    </message>
    <message>
        <source>Invalid content hash size</source>
        <translation>Neplatná veľkosť odtlačku obsahu</translation>
    </message>
    <message>
        <source>Invalid transform seed size</source>
        <translation>Neplatná transformácia hlavnej náhodnosti (seed)</translation>
    </message>
    <message>
        <source>Invalid number of transform rounds</source>
        <translation>Neplatný počet transformačných prechodov</translation>
    </message>
    <message>
        <source>Unable to construct group tree</source>
        <translation>Nemožno zostaviť strom skupiny</translation>
    </message>
    <message>
        <source>Root</source>
        <translation>Koreň</translation>
    </message>
    <message>
        <source>Unable to calculate database key</source>
        <translation>Nemožno vypočítať kľúč databázy</translation>
    </message>
    <message>
        <source>unable to seek to content position</source>
        <translation>nemožno sa posunúť na pozíciu obsahu</translation>
    </message>
    <message>
        <source>Invalid credentials were provided, please try again.
If this reoccurs, then your database file may be corrupt.</source>
        <translation>Boli zadané neplatné prihlasovacie údaje, prosím skúste znova.
Ak sa to opakuje, potom môže byť súbor databázy poškodený.</translation>
    </message>
    <message>
        <source>Key transformation failed</source>
        <translation>Transformácia kľúča zlyhala</translation>
    </message>
    <message>
        <source>Invalid group field type number</source>
        <translation>Neplatné číslo typu poľa skupiny</translation>
    </message>
    <message>
        <source>Invalid group field size</source>
        <translation>Neplatná veľkosť poľa skupiny</translation>
    </message>
    <message>
        <source>Read group field data doesn&apos;t match size</source>
        <translation>Prečítané dáta poľa skupiny nezodpovedajú veľkosťou</translation>
    </message>
    <message>
        <source>Incorrect group id field size</source>
        <translation>Nesprávna veľkosť ID poľa skupiny</translation>
    </message>
    <message>
        <source>Incorrect group creation time field size</source>
        <translation>Nesprávna veľkosť poľa času vytvorenia skupiny</translation>
    </message>
    <message>
        <source>Incorrect group modification time field size</source>
        <translation>Nesprávna veľkosť poľa času úpravy skupiny</translation>
    </message>
    <message>
        <source>Incorrect group access time field size</source>
        <translation>Nesprávna veľkosť poľa času prístupu skupiny</translation>
    </message>
    <message>
        <source>Incorrect group expiry time field size</source>
        <translation>nesprávna veľkosť poľa vypršania platnosti skupiny</translation>
    </message>
    <message>
        <source>Incorrect group icon field size</source>
        <translation>Nesprávna veľkosť poľa ikony skupiny</translation>
    </message>
    <message>
        <source>Incorrect group level field size</source>
        <translation>Nesprávna veľkosť poľa úrovne skupiny</translation>
    </message>
    <message>
        <source>Invalid group field type</source>
        <translation>Neplatný typ poľa skupiny</translation>
    </message>
    <message>
        <source>Missing group id or level</source>
        <translation>Chýbajúce ID alebo úrovne skupiny</translation>
    </message>
    <message>
        <source>Missing entry field type number</source>
        <translation>Chýbajúce číslo typu poľa položky</translation>
    </message>
    <message>
        <source>Invalid entry field size</source>
        <translation>Neplatná veľkosť poľa položky</translation>
    </message>
    <message>
        <source>Read entry field data doesn&apos;t match size</source>
        <translation>Prečítané dáta poľa položky majú neplatnú veľkosť</translation>
    </message>
    <message>
        <source>Invalid entry UUID field size</source>
        <translation>Neplatná veľkosť UUID poľa položky</translation>
    </message>
    <message>
        <source>Invalid entry group id field size</source>
        <translation>Neplatná veľkosť ID poľa položky skupiny</translation>
    </message>
    <message>
        <source>Invalid entry icon field size</source>
        <translation>Neplatná veľkosť poľa ikony položky</translation>
    </message>
    <message>
        <source>Invalid entry creation time field size</source>
        <translation>Neplatná veľkosť poľa vytvorenia položky</translation>
    </message>
    <message>
        <source>Invalid entry modification time field size</source>
        <translation>Neplatná veľkosť poľa poslednej úpravy</translation>
    </message>
    <message>
        <source>Invalid entry expiry time field size</source>
        <translation>Neplatná veľkosť poľa vypršania platnosti</translation>
    </message>
    <message>
        <source>Invalid entry field type</source>
        <translation>Neplatný typ poľa položky</translation>
    </message>
</context>
<context>
    <name>KeeShare</name>
    <message>
        <source>Invalid sharing reference</source>
        <translation>Neplatný odkaz zdieľania</translation>
    </message>
    <message>
        <source>Inactive share %1</source>
        <translation>Neaktívne zdieľanie %1</translation>
    </message>
    <message>
        <source>Imported from %1</source>
        <translation>Importované z %1</translation>
    </message>
    <message>
        <source>Exported to %1</source>
        <translation>Exportované do %1</translation>
    </message>
    <message>
        <source>Synchronized with %1</source>
        <translation>Synchronizované s %1</translation>
    </message>
    <message>
        <source>Import is disabled in settings</source>
        <translation>Import je vypnutý v nastaveniach</translation>
    </message>
    <message>
        <source>Export is disabled in settings</source>
        <translation>Export je vypnutý v nastaveniach</translation>
    </message>
    <message>
        <source>Inactive share</source>
        <translation>Neaktívne zdieľanie</translation>
    </message>
    <message>
        <source>Imported from</source>
        <translation>Importované z</translation>
    </message>
    <message>
        <source>Exported to</source>
        <translation>Exportované do</translation>
    </message>
    <message>
        <source>Synchronized with</source>
        <translation>Synchronizované s</translation>
    </message>
</context>
<context>
    <name>KeyComponentWidget</name>
    <message>
        <source>Key Component</source>
        <translation>Kľúč komponentu</translation>
    </message>
    <message>
        <source>Key Component Description</source>
        <translation>Popis kľúča komponentu</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Zrušiť</translation>
    </message>
    <message>
        <source>Key Component set, click to change or remove</source>
        <translation>Nastavenie kľúča komponentu, kliknite na zmenu alebo odstránenie</translation>
    </message>
</context>
<context>
    <name>KeyFileEditWidget</name>
    <message>
        <source>Generate a new key file</source>
        <translation>Generovať nový súbor kľúča</translation>
    </message>
    <message>
        <source>Generate</source>
        <translation>Generovať</translation>
    </message>
    <message>
        <source>Generate a new key file or choose an existing one to protect your database.</source>
        <translation>Generovať nový súbor kľúča alebo zvoliť existujúci na ochranu svojej databázy.</translation>
    </message>
    <message>
        <source>Note: Do NOT use a file that may change as that will prevent you from unlocking your database.</source>
        <translation>Poznámka: Nepoužívajte súbor, ktorý sa môže zmeniť, pretože to zabráni odomknutiu databázy!</translation>
    </message>
    <message>
        <source>Browse for key file</source>
        <translation>Vyhľadať súbor kľúča</translation>
    </message>
    <message>
        <source>Browse…</source>
        <translation>Prechádzať…</translation>
    </message>
    <message>
        <source>Old key file format</source>
        <translation>Starý formát kľúča</translation>
    </message>
    <message>
        <source>You selected a key file in an old format which KeePassXC&lt;br&gt;may stop supporting in the future.&lt;br&gt;&lt;br&gt;Please consider generating a new key file instead.</source>
        <translation>Zvolili ste starý formát kľúča, ktorý KeePassXC&lt;br&gt;môže v budúcnosti prestať podporovať.&lt;br&gt;&lt;br&gt;Prosím, zvážte generovať nový súbor kľúča.</translation>
    </message>
    <message>
        <source>Error loading the key file '%1'
Message: %2</source>
        <translation>Chyba načítania súboru kľúča „%1”
Správa: %2</translation>
    </message>
    <message>
        <source>Key File</source>
        <translation>Súbor kľúča</translation>
    </message>
    <message>
        <source>Add Key File</source>
        <translation>Pridať súbor kľúča</translation>
    </message>
    <message>
        <source>Change Key File</source>
        <translation>Zmeniť súbor kľúča</translation>
    </message>
    <message>
        <source>Remove Key File</source>
        <translation>Odstrániť súbor kľúča</translation>
    </message>
    <message>
        <source>Key File set, click to change or remove</source>
        <translation>Súbor kľúča nastavený, kliknite na zmenu alebo odstránenie</translation>
    </message>
    <message>
        <source>&lt;p&gt;You can add a key file containing random bytes for additional security.&lt;/p&gt;&lt;p&gt;You must keep it secret and never lose it or you will be locked out.&lt;/p&gt;</source>
        <translation>&lt;p&gt;Môžete pridať súbor kľúča s náhodnými bajtmi, na dodatočnú bezpečnosť .&lt;/p&gt;&lt;p&gt;Musíte ho držať v tajnosti a nikdy nestratiť, inak prídete o prístup!&lt;/p&gt;</translation>
    </message>
    <message>
        <source>Key files</source>
        <translation>Súbory kľúčov</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>Všetky súbory</translation>
    </message>
    <message>
        <source>Create Key File…</source>
        <translation>Vytvoriť súbor kľúča...</translation>
    </message>
    <message>
        <source>Error creating key file</source>
        <translation>Chyba vytvárania súboru kľúča</translation>
    </message>
    <message>
        <source>Unable to create key file: %1</source>
        <translation>Nemožno vytvoriť súbor kľúča: %1</translation>
    </message>
    <message>
        <source>Select a key file</source>
        <translation>Zvoľte súbor kľúča</translation>
    </message>
    <message>
        <source>Invalid Key File</source>
        <translation>Neplatný súbor kľúča</translation>
    </message>
    <message>
        <source>You cannot use the current database as its own keyfile. Please choose a different file or generate a new key file.</source>
        <translation>Nemôžete použiť svoju databázu ako súbor kľúča. Prosím, zvoľte iný súbor alebo vygenerujte nový súbor kľúča.</translation>
    </message>
    <message>
        <source>Suspicious Key File</source>
        <translation>Podozrivý súbor kľúča</translation>
    </message>
    <message>
        <source>The chosen key file looks like a password database file. A key file must be a static file that never changes or you will lose access to your database forever.
Are you sure you want to continue with this file?</source>
        <translation>Zvolený súbor kľúča vyzerá ako súbor hesla databázy. Súbor kľúča musí byť statický súbor, ktorý sa nikdy nezmení, inak navždy stratíte prístup k svojej databáze.
Naozaj chcete pokračovať s týmto súborom?</translation>
    </message>
</context>
<context>
    <name>MacUtils</name>
    <message>
        <source>Invalid key code</source>
        <translation>Neplatný súbor kľúča</translation>
    </message>
    <message>
        <source>Global shortcut already registered to %1</source>
        <translation>Globálna klávesová skratka už je registrovaná na %1</translation>
    </message>
    <message>
        <source>Could not register global shortcut</source>
        <translation>Nemožno registrovať globálnu klávesovú skratku</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>&amp;Database</source>
        <translation>&amp;Databáza</translation>
    </message>
    <message>
        <source>&amp;Recent Databases</source>
        <translation>&amp;Nedávne databázy</translation>
    </message>
    <message>
        <source>&amp;Export</source>
        <translation>&amp;Exportovať</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>&amp;Pomocník</translation>
    </message>
    <message>
        <source>&amp;Entries</source>
        <translation>&amp;Položky</translation>
    </message>
    <message>
        <source>Copy Att&amp;ribute</source>
        <translation>Kopírovať at&amp;ribút</translation>
    </message>
    <message>
        <source>TOTP</source>
        <translation>TOTP</translation>
    </message>
    <message>
        <source>Tags</source>
        <translation>Štítky</translation>
    </message>
    <message>
        <source>&amp;Groups</source>
        <translation>&amp;Skupiny</translation>
    </message>
    <message>
        <source>&amp;Tools</source>
        <translation>&amp;Nástroje</translation>
    </message>
    <message>
        <source>View</source>
        <translation>Zobraziť</translation>
    </message>
    <message>
        <source>Theme</source>
        <translation>Téma</translation>
    </message>
    <message>
        <source>&amp;Quit</source>
        <translation>&amp;Koniec</translation>
    </message>
    <message>
        <source>&amp;About</source>
        <translation>&amp;O programe</translation>
    </message>
    <message>
        <source>&amp;Check for Updates</source>
        <translation>&amp;Skontrolovať aktualizácie</translation>
    </message>
    <message>
        <source>&amp;Open Database…</source>
        <translation>&amp;Otvoriť databázu…</translation>
    </message>
    <message>
        <source>&amp;Save Database</source>
        <translation>&amp;Uložiť databázu</translation>
    </message>
    <message>
        <source>&amp;Close Database</source>
        <translation>&amp;Zatvoriť databázu</translation>
    </message>
    <message>
        <source>&amp;New Database…</source>
        <translation>&amp;Nová databáza…</translation>
    </message>
    <message>
        <source>&amp;Merge From Database…</source>
        <translation>&amp;Zlúčiť z databázou…</translation>
    </message>
    <message>
        <source>&amp;New Entry…</source>
        <translation>&amp;Nová položka…</translation>
    </message>
    <message>
        <source>&amp;Edit Entry…</source>
        <translation>&amp;Upraviť položku…</translation>
    </message>
    <message>
        <source>&amp;New Group…</source>
        <translation>&amp;Nová skupina…</translation>
    </message>
    <message>
        <source>&amp;Edit Group…</source>
        <translation>&amp;Upraviť skupinu…</translation>
    </message>
    <message>
        <source>&amp;Delete Group…</source>
        <translation>O&amp;dstrániť skupinu…</translation>
    </message>
    <message>
        <source>Download All &amp;Favicons…</source>
        <translation>Stiahnuť &amp;všetky ikony…</translation>
    </message>
    <message>
        <source>Sort &amp;A-Z</source>
        <translation>Zoradiť &amp;A-Z</translation>
    </message>
    <message>
        <source>Sort &amp;Z-A</source>
        <translation>Zoradiť &amp;Z-A</translation>
    </message>
    <message>
        <source>Sa&amp;ve Database As…</source>
        <translation>Uložiť data&amp;bázu ako…</translation>
    </message>
    <message>
        <source>Database &amp;Security…</source>
        <translation>&amp;Bezpečnosť databázy…</translation>
    </message>
    <message>
        <source>Database &amp;Reports…</source>
        <translation>&amp;Hlásenia databázy…</translation>
    </message>
    <message>
        <source>&amp;Database Settings…</source>
        <translation>Nastavenia &amp;databázy…</translation>
    </message>
    <message>
        <source>&amp;Clone Entry…</source>
        <translation>&amp;Klonovať položku…</translation>
    </message>
    <message>
        <source>Move u&amp;p</source>
        <translation>&amp;Posunúť vyššie</translation>
    </message>
    <message>
        <source>Move do&amp;wn</source>
        <translation>&amp;Posunúť nižšie</translation>
    </message>
    <message>
        <source>Copy &amp;Username</source>
        <translation>Kopírovať po&amp;už. meno</translation>
    </message>
    <message>
        <source>Copy &amp;Password</source>
        <translation>Kopírovať &amp;heslo</translation>
    </message>
    <message>
        <source>&amp;Settings</source>
        <translation>Na&amp;stavenia</translation>
    </message>
    <message>
        <source>&amp;Password Generator</source>
        <translation>&amp;Generátor hesla</translation>
    </message>
    <message>
        <source>Perform &amp;Auto-Type</source>
        <translation>Vykonať &amp;Automatické vypĺňanie</translation>
    </message>
    <message>
        <source>Download &amp;Favicon</source>
        <translation>Stiahnuť i&amp;konu</translation>
    </message>
    <message>
        <source>Open &amp;URL</source>
        <translation>Otvoriť &amp;URL</translation>
    </message>
    <message>
        <source>&amp;Lock Database</source>
        <translation>&amp;Zamknúť Databázu</translation>
    </message>
    <message>
        <source>Lock &amp;All Databases</source>
        <translation>Zamknúť &amp;Všetky Databázy</translation>
    </message>
    <message>
        <source>&amp;Title</source>
        <translation>&amp;Názov</translation>
    </message>
    <message>
        <source>Copy &amp;URL</source>
        <translation>Kopírovať &amp;URL adresu</translation>
    </message>
    <message>
        <source>&amp;Notes</source>
        <translation>&amp;Poznámky</translation>
    </message>
    <message>
        <source>&amp;CSV File…</source>
        <translation>Súbor &amp;CSV…</translation>
    </message>
    <message>
        <source>&amp;HTML File…</source>
        <translation>Súbor &amp;HTML…</translation>
    </message>
    <message>
        <source>KeePass 1 Database…</source>
        <translation>Databáza KeePass 1</translation>
    </message>
    <message>
        <source>1Password Vault…</source>
        <translation>Úložisko 1Password...</translation>
    </message>
    <message>
        <source>CSV File…</source>
        <translation>Súbor CSV…</translation>
    </message>
    <message>
        <source>Show TOTP</source>
        <translation>Zobraziť TOTP</translation>
    </message>
    <message>
        <source>Show QR Code</source>
        <translation>Zobraziť QR kód</translation>
    </message>
    <message>
        <source>Set up TOTP…</source>
        <translation>Nastaviť TOTP…</translation>
    </message>
    <message>
        <source>Copy &amp;TOTP</source>
        <translation>Kopírovať &amp;TOTP</translation>
    </message>
    <message>
        <source>Copy Password and TOTP</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>E&amp;mpty recycle bin</source>
        <translation>V&amp;yprázdniť kôš</translation>
    </message>
    <message>
        <source>&amp;Donate</source>
        <translation>&amp;Podporiť</translation>
    </message>
    <message>
        <source>Report a &amp;Bug</source>
        <translation>Nahlásiť &amp;chybu</translation>
    </message>
    <message>
        <source>&amp;Getting Started</source>
        <translation>&amp;Začíname</translation>
    </message>
    <message>
        <source>Open Getting Started Guide</source>
        <translation>Otvorí príručku Začíname</translation>
    </message>
    <message>
        <source>&amp;Online Help</source>
        <translation>Pomocník &amp;online</translation>
    </message>
    <message>
        <source>&amp;User Guide</source>
        <translation>&amp;Používateľská príručka</translation>
    </message>
    <message>
        <source>Open User Guide</source>
        <translation>Otvorí používateľskú príručku</translation>
    </message>
    <message>
        <source>&amp;Keyboard Shortcuts</source>
        <translation>&amp;Klávesové skratky</translation>
    </message>
    <message>
        <source>Save Database Backup…</source>
        <translation>Uložiť zálohu databázy…</translation>
    </message>
    <message>
        <source>Add key to SSH Agent</source>
        <translation>Pridať kľúč do Agenta SSH</translation>
    </message>
    <message>
        <source>Remove key from SSH Agent</source>
        <translation>Odstrániť kľúč z Agenta SSH</translation>
    </message>
    <message>
        <source>Compact Mode</source>
        <translation>Kompaktný režim</translation>
    </message>
    <message>
        <source>Automatic</source>
        <translation>Automaticky</translation>
    </message>
    <message>
        <source>Light</source>
        <translation>Svetlá</translation>
    </message>
    <message>
        <source>Dark</source>
        <translation>Tmavá</translation>
    </message>
    <message>
        <source>Classic (Platform-native)</source>
        <translation>Klasický (podľa platformy)</translation>
    </message>
    <message>
        <source>Show Menubar</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Show Toolbar</source>
        <translation>Zobraziť panel nástrojov</translation>
    </message>
    <message>
        <source>Show Preview Panel</source>
        <translation>Zobraziť panel ukážky</translation>
    </message>
    <message>
        <source>Always on Top</source>
        <translation>Vždy navrchu</translation>
    </message>
    <message>
        <source>Hide Usernames</source>
        <translation>Skryť použ. mená</translation>
    </message>
    <message>
        <source>Hide Passwords</source>
        <translation>Skryť heslá</translation>
    </message>
    <message>
        <source>Clone Group...</source>
        <translation>Klonovať skupinu…</translation>
    </message>
    <message>
        <source>&amp;XML File…</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Clear history</source>
        <translation>Vymazať históriu</translation>
    </message>
    <message>
        <source>Access error for config file %1</source>
        <translation>Chyba prístupu ku konfiguračnému súboru %1</translation>
    </message>
    <message>
        <source>Don&apos;t show again for this version</source>
        <translation>Nezobrazovať znova v tejto verzii</translation>
    </message>
    <message>
        <source>No Tags</source>
        <translation>Žiadne štítky</translation>
    </message>
    <message numerus="yes">
        <source>Restore Entry(s)</source>
        <translation type="unfinished"><numerusform></numerusform><numerusform></numerusform><numerusform></numerusform><numerusform></numerusform></translation>
    </message>
    <message>
        <source>Settings</source>
        <translation>Nastavenia</translation>
    </message>
    <message>
        <source>Check for updates on startup?</source>
        <translation>Skontrolovať aktualizácie pri štarte?</translation>
    </message>
    <message>
        <source>Would you like KeePassXC to check for updates on startup?</source>
        <translation>Chcete aby KeePassXC skontroloval aktualizácie pri štarte?</translation>
    </message>
    <message>
        <source>You can always check for updates manually from the application menu.</source>
        <translation>Vždy môžete skontrolovať aktualizácie manuálne z menu aplikácie.</translation>
    </message>
    <message>
        <source>Toggle window</source>
        <translation>Prepnúť okno</translation>
    </message>
    <message>
        <source>Quit KeePassXC</source>
        <translation>Skončiť KeePassXC</translation>
    </message>
    <message numerus="yes">
        <source>%1 Entry(s)</source>
        <translation type="unfinished"><numerusform></numerusform><numerusform></numerusform><numerusform></numerusform><numerusform></numerusform></translation>
    </message>
    <message>
        <source>Please present or touch your YubiKey to continue…</source>
        <translation>Prosím, pripojte alebo stlačte tlačidlo svojho YubiKey na pokračovanie*…</translation>
    </message>
    <message>
        <source>Restart Application?</source>
        <translation>Reštartovať aplikáciu?</translation>
    </message>
    <message>
        <source>You must restart the application to apply this setting. Would you like to restart now?</source>
        <translation>Musíte reštartovať aplikáciu, aby sa tieto zmeny prejavili. Chcete ju reštartovať teraz?</translation>
    </message>
    <message>
        <source>Allow Screen Capture</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>1Password 1PUX...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Import a 1Password 1PUX file</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Import…</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Passkeys…</source>
        <translation>Prístupové kľúče…</translation>
    </message>
    <message>
        <source>Import Passkey</source>
        <translation>Importovať prístupový kľúč</translation>
    </message>
    <message>
        <source>Remote S&amp;ync…</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Quit Application</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Open About Dialog</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Open Database</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Create Database</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Merge From Database</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Edit Entry</source>
        <translation>Upraviť položku</translation>
    </message>
    <message>
        <source>Delete Entry</source>
        <translation>Vymazať záznam</translation>
    </message>
    <message>
        <source>Create Group</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Edit Group</source>
        <translation>Upraviť skupinu</translation>
    </message>
    <message>
        <source>Delete Group</source>
        <translation>Vymazať skupinu</translation>
    </message>
    <message>
        <source>Download All Favicons</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Sort Groups A-Z</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Sort Groups Z-A</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Save Database As</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Show Database Security</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Show Database Reports</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Show Database Settings</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Show Passkeys</source>
        <translation>Zobraziť prístupový kľúč</translation>
    </message>
    <message>
        <source>Clone Entry</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Move Entry Up</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Move Entry Down</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Copy Username</source>
        <translation>Kopírovať použ. meno</translation>
    </message>
    <message>
        <source>Copy Password</source>
        <translation>Kopírovať heslo</translation>
    </message>
    <message>
        <source>Show Application Settings</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Show Password Generator</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Remove Passkey From Entry</source>
        <translation>Odstrániť prístupový kľúč zo záznamu</translation>
    </message>
    <message>
        <source>Perform Auto-Type: {USERNAME}</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Perform Auto-Type: {USERNAME}{ENTER}</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Perform Auto-Type: {PASSWORD}</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Perform Auto-Type: {PASSWORD}{ENTER}</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Perform Auto-Type: {TOTP}</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Copy Title</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Copy URL</source>
        <translation>Kopírovať URL adresu</translation>
    </message>
    <message>
        <source>Copy Notes</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Export to CSV</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Export to HTML</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Import KeePass1 Database</source>
        <translation>Importovať databázu KeePass 1</translation>
    </message>
    <message>
        <source>Import 1Password Vault</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Import CSV File</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Show TOTP QR Code</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Set up TOTP</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Empty Recycle Bin</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Open Donation Website</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Open Bug Report</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Open Online Documentation</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Open Keyboard Shortcuts Guide</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Save Database Backup</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>SSH Agent: Add Key</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>SSH Agent: Remove Key</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Toggle Compact Mode</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Set Theme: Automatic</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Set Theme: Light</source>
        <translation>Nastavená téma: Svetlá</translation>
    </message>
    <message>
        <source>Set Theme: Dark</source>
        <translation>Nastavená téma: Tmavá</translation>
    </message>
    <message>
        <source>Set Theme: Classic</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Toggle Show Menubar</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Toggle Show Toolbar</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Toggle Show Preview Panel</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Toggle Always on Top</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Toggle Hide Usernames</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Toggle Hide Passwords</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Export to XML</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Toggle Allow Screen Capture</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Show Group Panel</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Toggle Show Group Panel</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Setup Remote Sync…</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>WARNING: You are using a development snapshot build of KeePassXC.
Maintain a backup of your databases in the event of unknown bugs.
This version is not meant for production use.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Clear SSH Agent</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Clear all identities in ssh-agent</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>New Entry</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Password Generator</source>
        <translation>Generátor hesla</translation>
    </message>
    <message>
        <source>Edit Entry…</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>E&amp;xpire Entry</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Expire Entry</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>&amp;Delete Entry</source>
        <translation>&amp;Vymazať záznam</translation>
    </message>
    <message numerus="yes">
        <source>Move selected entry(s) to the recycle bin</source>
        <translation type="unfinished"><numerusform></numerusform><numerusform></numerusform><numerusform></numerusform><numerusform></numerusform></translation>
    </message>
    <message numerus="yes">
        <source>Permanently delete the selected entry(s)</source>
        <translation type="unfinished"><numerusform></numerusform><numerusform></numerusform><numerusform></numerusform><numerusform></numerusform></translation>
    </message>
</context>
<context>
    <name>ManageDatabase</name>
    <message>
        <source>Database settings</source>
        <translation>Nastavenia databázy</translation>
    </message>
    <message>
        <source>Edit database settings</source>
        <translation>Upraviť nastavenia databázy</translation>
    </message>
    <message>
        <source>Unlock database</source>
        <translation>Odomknúť databázu</translation>
    </message>
    <message>
        <source>Unlock database to show more information</source>
        <translation>Odomknúť databázu na zobrazenie ďalších informácií</translation>
    </message>
    <message>
        <source>Lock database</source>
        <translation>Zamknúť databázu</translation>
    </message>
</context>
<context>
    <name>ManageSession</name>
    <message>
        <source>Disconnect</source>
        <translation>Odpojiť</translation>
    </message>
    <message>
        <source>Disconnect this application</source>
        <translation>Odpojiť túto palikáciu</translation>
    </message>
    <message>
        <source>Reset</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Reset any remembered decisions for this application</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>MergeDialog</name>
    <message>
        <source>Database Merge Confirmation</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Merge</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Group</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Title</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>UUID</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Details</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Change</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>Merger</name>
    <message>
        <source>Changed deleted objects</source>
        <translation>Odstránené objekty boli zmenené </translation>
    </message>
    <message>
        <source>Removed custom data %1 [%2]</source>
        <translation>Odstránené vlastné dáta %1 [%2]</translation>
    </message>
    <message>
        <source>Adding custom data %1 [%2]</source>
        <translation>Pridanie vlastných dát %1 [%2]</translation>
    </message>
    <message>
        <source>Added</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Modified</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Moved</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Deleted</source>
        <translation>Vymazané</translation>
    </message>
    <message>
        <source>Previous location: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Number of entries in group: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Group name</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Notes</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Icon (UUID)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Icon (Number)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Expiry time</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Modification time</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>%1 (Add local modifications to new entry)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>%1 (Add new modifications to existing entry)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Explicit deletion</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Implicit deletion (e.g. removal of parent group)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Adding new icon %1</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>NewDatabaseWizard</name>
    <message>
        <source>Create a new KeePassXC database…</source>
        <translation>Vytvoriť novú databázu KeePassXC...</translation>
    </message>
    <message>
        <source>Root</source>
        <comment>Root group</comment>
        <translation>Koreň</translation>
    </message>
</context>
<context>
    <name>NewDatabaseWizardPage</name>
    <message>
        <source>WizardPage</source>
        <translation>Stránka sprievodcu</translation>
    </message>
    <message>
        <source>Encryption Settings</source>
        <translation>Nastavenia šifrovania</translation>
    </message>
    <message>
        <source>Here you can adjust the database encryption settings. Don&apos;t worry, you can change them later in the database settings.</source>
        <translation>Tu môžete prispôsobiť nastavenia šifrovania databázy. Nebojte sa, neskôr ich môžete zmeniť v nastavení databázy.</translation>
    </message>
</context>
<context>
    <name>NewDatabaseWizardPageDatabaseKey</name>
    <message>
        <source>Database Credentials</source>
        <translation>Prihlasovacie údaje databázy</translation>
    </message>
    <message>
        <source>A set of credentials known only to you that protects your database.</source>
        <translation>Sada prihlasovacích údajov, známe len Vám, chráni vašu databázu.</translation>
    </message>
</context>
<context>
    <name>NewDatabaseWizardPageEncryption</name>
    <message>
        <source>Encryption Settings</source>
        <translation>Nastavenia šifrovania</translation>
    </message>
    <message>
        <source>Here you can adjust the database encryption settings. Don&apos;t worry, you can change them later in the database settings.</source>
        <translation>Tu môžete prispôsobiť nastavenia šifrovania databázy. Nebojte sa, neskôr ich môžete zmeniť v nastavení databázy.</translation>
    </message>
</context>
<context>
    <name>NewDatabaseWizardPageMetaData</name>
    <message>
        <source>General Database Information</source>
        <translation>Všeobecné informácie databázy</translation>
    </message>
    <message>
        <source>Please fill in the display name and an optional description for your new database:</source>
        <translation>Prosím, vyplňte meno a prípadne aj popis svojej novej databázy:</translation>
    </message>
</context>
<context>
    <name>NixUtils</name>
    <message>
        <source>Password Manager</source>
        <translation>Správca hesiel</translation>
    </message>
    <message>
        <source>Global shortcut already registered to %1</source>
        <translation>Globálna klávesová skratka už je registrovaná na %1</translation>
    </message>
    <message>
        <source>Could not register global shortcut</source>
        <translation>Nemožno registrovať globálnu klávesovú skratku</translation>
    </message>
</context>
<context>
    <name>OpData01</name>
    <message>
        <source>Invalid OpData01, does not contain header</source>
        <translation>Neplatné OpData01, neobsahuje hlavičku</translation>
    </message>
    <message>
        <source>Unable to read all IV bytes, wanted 16 but got %1</source>
        <translation>Nemožno čítať všetky bajty IV, potrebných 16, ale získaných %1</translation>
    </message>
    <message>
        <source>Unable to init cipher for opdata01: %1</source>
        <translation>Nemožno inicializovať šifru pre opdata01: %1</translation>
    </message>
    <message>
        <source>Unable to read all HMAC signature bytes</source>
        <translation>Nemožno čítať všetky bajty podpisu HMAC</translation>
    </message>
    <message>
        <source>Malformed OpData01 due to a failed HMAC</source>
        <translation>Zlý formát OpData01 kvôli zlyhanému HMAC</translation>
    </message>
    <message>
        <source>Unable to process clearText in place</source>
        <translation>Nepodarilo sa sprocesovať clearText</translation>
    </message>
    <message>
        <source>Expected %1 bytes of clear-text, found %2</source>
        <translation>Očakávaných %1 B prostého textu, nájdených %2</translation>
    </message>
</context>
<context>
    <name>OpVaultReader</name>
    <message>
        <source>Directory .opvault must exist</source>
        <translation>Adresár .opvault musí existovať</translation>
    </message>
    <message>
        <source>Directory .opvault must be readable</source>
        <translation>Adresár .opvault musí byť čitateľný</translation>
    </message>
    <message>
        <source>Directory .opvault/default must exist</source>
        <translation>Adresár .opvault/default musí existovať</translation>
    </message>
    <message>
        <source>Directory .opvault/default must be readable</source>
        <translation>Adresár .opvault/default musí byť čitateľný</translation>
    </message>
    <message>
        <source>Unable to decode masterKey: %1</source>
        <translation>Nemožno dekódovať hlavný kľúč: %1</translation>
    </message>
    <message>
        <source>Unable to derive master key: %1</source>
        <translation>Nemožno odvodiť hlavný kľúč: %1</translation>
    </message>
</context>
<context>
    <name>OpenSSHKey</name>
    <message>
        <source>Invalid key file, expecting an OpenSSH key</source>
        <translation>Neplatný súbor kľúča, očakávaný je kľúč OpenSSH</translation>
    </message>
    <message>
        <source>PEM boundary mismatch</source>
        <translation>Nezhoda ohraničenia PEM</translation>
    </message>
    <message>
        <source>Base64 decoding failed</source>
        <translation>Dekódovanie Base64 zlyhalo</translation>
    </message>
    <message>
        <source>Key file way too small.</source>
        <translation>Súbor kľúča je príliš krátky.</translation>
    </message>
    <message>
        <source>Key file magic header id invalid</source>
        <translation>Neplatný ID magickej hlavičky súboru kľúča</translation>
    </message>
    <message>
        <source>Found zero keys</source>
        <translation>Nenájdené žiadne kľúče</translation>
    </message>
    <message>
        <source>Corrupted key file, reading private key failed</source>
        <translation>Poškodený súbor kľúča, čítanie súkromného kľúč azlyhalo</translation>
    </message>
    <message>
        <source>Unsupported key type: %1</source>
        <translation>Nepodporovaný typ kľúča: %1</translation>
    </message>
    <message>
        <source>No private key payload to decrypt</source>
        <translation>Žiadny obsah súkromného kľúča na dešifrovanie</translation>
    </message>
    <message>
        <source>Unknown cipher: %1</source>
        <translation>Neznáma šifra: %1</translation>
    </message>
    <message>
        <source>AES-256/GCM is currently not supported</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Passphrase is required to decrypt this key</source>
        <translation>Na dešifrovanie tohoto kľúča je potrebná tajná veta</translation>
    </message>
    <message>
        <source>Key derivation failed: %1</source>
        <translation>Odvodenie kľúča zlyhalo: %1</translation>
    </message>
    <message>
        <source>Cipher IV is too short for MD5 kdf</source>
        <translation>IV šifry je príliš krátky na MD5 KDF</translation>
    </message>
    <message>
        <source>Unknown KDF: %1</source>
        <translation>Neznáma KDF: %1</translation>
    </message>
    <message>
        <source>Failed to initialize cipher: %1</source>
        <translation>Inicializácia šifry zlyhala: %1</translation>
    </message>
    <message>
        <source>Decryption failed: %1</source>
        <translation>Dešifrovanie zlyhalo: %1</translation>
    </message>
    <message>
        <source>Decryption failed, wrong passphrase?</source>
        <translation>Dešifrovanie zlyhalo, zlá tajná veta?</translation>
    </message>
    <message>
        <source>Unexpected EOF while reading key</source>
        <translation>Neočakávaný koniec súboru pri čítaní kľúča</translation>
    </message>
    <message>
        <source>Unsupported key part</source>
        <translation>Nepodporovaná časť kľúča</translation>
    </message>
    <message>
        <source>Unexpected EOF while reading public key</source>
        <translation>Neočakávaný koniec súboru pri čítaní verejného kľúča</translation>
    </message>
    <message>
        <source>Unknown key type: %1</source>
        <translation>Neznámy typ kľúča: %1</translation>
    </message>
    <message>
        <source>Unexpected EOF while reading private key</source>
        <translation>Neočakávaný koniec súboru pri čítaní súkromného kľúča</translation>
    </message>
    <message>
        <source>Can&apos;t write public key as it is empty</source>
        <translation>Nemožno zapísať verejný kľúč, pretože je prázdny</translation>
    </message>
    <message>
        <source>Unexpected EOF when writing public key</source>
        <translation>Neočakávaný koniec súboru pri zápise verejného kľúča</translation>
    </message>
    <message>
        <source>Can&apos;t write private key as it is empty</source>
        <translation>Nemožno zapísať súkromný kľúč, pretože je prázdny</translation>
    </message>
    <message>
        <source>Unexpected EOF when writing private key</source>
        <translation>Neočakávaný koniec súboru pri zápise súkromného kľúča</translation>
    </message>
    <message>
        <source>(encrypted)</source>
        <translation>(šifrované)</translation>
    </message>
    <message>
        <source>Failed to read key file: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Failed to read public key: %1</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>OpenSSHKeyGenDialog</name>
    <message>
        <source>SSH Key Generator</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Type</source>
        <translation>Typ</translation>
    </message>
    <message>
        <source>Bits</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Comment</source>
        <translation>Komentár</translation>
    </message>
</context>
<context>
    <name>PasskeyExportDialog</name>
    <message>
        <source>KeePassXC - Passkey Export</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Filenames will be generated with title and .passkey file extension.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Export entries</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Export Selected</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Zrušiť</translation>
    </message>
    <message>
        <source>Export to folder</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Export the following passkey entries.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>PasskeyExporter</name>
    <message>
        <source>File &quot;%1.passkey&quot; already exists.
Do you want to overwrite it?
</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Cannot open file</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Cannot open file &quot;%1&quot; for writing.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Cannot write to file</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Overwrite Existing File?</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>PasskeyImportDialog</name>
    <message>
        <source>KeePassXC - Passkey Import</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Username: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Group</source>
        <translation>Skupina</translation>
    </message>
    <message>
        <source>Database</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Import Passkey</source>
        <translation>Importovať prístupový kľúč</translation>
    </message>
    <message>
        <source>Import</source>
        <translation>Importovať</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Zrušiť</translation>
    </message>
    <message>
        <source>Entry</source>
        <translation>Položka</translation>
    </message>
    <message>
        <source>Create new entry</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Relying Party: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Import the following passkey:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Import the following passkey to this entry:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Default passkeys group (Imported Passkeys)</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>PasskeyImporter</name>
    <message>
        <source>Passkey file</source>
        <translation>Súbor s prístupovým kľúčom</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>Všetky súbory</translation>
    </message>
    <message>
        <source>Cannot open file</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Cannot open file &quot;%1&quot; for reading.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Cannot import passkey file &quot;%1&quot;. Data is missing.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Cannot import passkey file &quot;%1&quot;.
The following data is missing:
%2</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Cannot import passkey file &quot;%1&quot;. Private key is missing or malformed.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Open Passkey File</source>
        <translation>Otvoriť súbor s prístupovým kľúčom</translation>
    </message>
    <message>
        <source>Passkey Import Failed</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>PasswordEditWidget</name>
    <message>
        <source>Enter password:</source>
        <translation>Zadajte heslo:</translation>
    </message>
    <message>
        <source>Password field</source>
        <translation>Pole pre heslo</translation>
    </message>
    <message>
        <source>Confirm password:</source>
        <translation>Potvrďte heslo:</translation>
    </message>
    <message>
        <source>Repeat password field</source>
        <translation>Pole opakovaného hesla</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Heslo</translation>
    </message>
    <message>
        <source>Add Password</source>
        <translation>Pridať heslo</translation>
    </message>
    <message>
        <source>Change Password</source>
        <translation>Zmeniť heslo</translation>
    </message>
    <message>
        <source>Remove Password</source>
        <translation>Odstrániť heslo</translation>
    </message>
    <message>
        <source>Password set, click to change or remove</source>
        <translation>Heslo nastavené, kliknite na zmenu alebo odstránenie</translation>
    </message>
    <message>
        <source>&lt;p&gt;A password is the primary method for securing your database.&lt;/p&gt;&lt;p&gt;Good passwords are long and unique. KeePassXC can generate one for you.&lt;/p&gt;</source>
        <translation>&lt;p&gt;Heslo je primárna metóda na zabezpečenie svojej databázy.&lt;/p&gt;&lt;p&gt;Dobré heslá sú dlhé a jedinečné. KeePassXC Vám môže nejaké vygenerovať.&lt;/p&gt;</translation>
    </message>
    <message>
        <source>Passwords do not match.</source>
        <translation>Heslá sa nezhodujú.</translation>
    </message>
</context>
<context>
    <name>PasswordGeneratorWidget</name>
    <message>
        <source>Generate Password</source>
        <translation>Generovať heslo</translation>
    </message>
    <message>
        <source>strength</source>
        <comment>Password strength</comment>
        <translation>sila</translation>
    </message>
    <message>
        <source>entropy</source>
        <translation>náhodnosť</translation>
    </message>
    <message>
        <source>Generated password</source>
        <translation>Generované heslo</translation>
    </message>
    <message>
        <source>%p%</source>
        <translation>%p%</translation>
    </message>
    <message>
        <source>Regenerate password</source>
        <translation>Obnoviť heslo</translation>
    </message>
    <message>
        <source>Copy password</source>
        <translation>Kopírovať heslo</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Heslo</translation>
    </message>
    <message>
        <source>&amp;Length:</source>
        <translation>&amp;Dĺžka:</translation>
    </message>
    <message>
        <source>Password length</source>
        <translation>Dĺžka hesla</translation>
    </message>
    <message>
        <source>Switch to advanced mode</source>
        <translation>Prepnúť na pokročilý režim</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>Pokročilé</translation>
    </message>
    <message>
        <source>Character Types</source>
        <translation>Typy znakov</translation>
    </message>
    <message>
        <source>Special characters</source>
        <translation>Špeciálne znaky</translation>
    </message>
    <message>
        <source>Quotes</source>
        <translation>Úvodzovky</translation>
    </message>
    <message>
        <source>Punctuation</source>
        <translation>Interpunkcia</translation>
    </message>
    <message>
        <source>Dashes and Slashes</source>
        <translation>Pomlčky a lomky</translation>
    </message>
    <message>
        <source>Upper-case letters</source>
        <translation>Veľké písmená</translation>
    </message>
    <message>
        <source>Numbers</source>
        <translation>Číslice</translation>
    </message>
    <message>
        <source>Lower-case letters</source>
        <translation>Malé písmená</translation>
    </message>
    <message>
        <source>Math Symbols</source>
        <translation>Matematické symboly</translation>
    </message>
    <message>
        <source>Extended ASCII</source>
        <translation>Rozšírené ASCII</translation>
    </message>
    <message>
        <source>Braces</source>
        <translation>Zátvorky</translation>
    </message>
    <message>
        <source>Do not include:</source>
        <translation>Nezahŕňať:</translation>
    </message>
    <message>
        <source>Additional characters to use for the generated password</source>
        <translation>Dodatočné znaky použité pri generovaní hesla</translation>
    </message>
    <message>
        <source>Additional characters</source>
        <translation>Dodatočné znaky</translation>
    </message>
    <message>
        <source>Add non-hex letters to &quot;do not include&quot; list</source>
        <translation>Pridajte nie-šestnástkové písmená do zoznamu „vynechať”</translation>
    </message>
    <message>
        <source>Hex Passwords</source>
        <translation>Hexadecimálne heslá</translation>
    </message>
    <message>
        <source>Hex</source>
        <translation>Šestnástkové</translation>
    </message>
    <message>
        <source>Character set to exclude from generated password</source>
        <translation>Sady znakov, ktoré majú byť vynechané pri generovaní hesla</translation>
    </message>
    <message>
        <source>Excluded characters</source>
        <translation>Rozšírené znaky</translation>
    </message>
    <message>
        <source>Also choose from:</source>
        <translation>Tiež vybrať z:</translation>
    </message>
    <message>
        <source>Exclude look-alike characters</source>
        <translation>Vynechať podobne vyzerajúce znaky</translation>
    </message>
    <message>
        <source>Pick characters from every group</source>
        <translation>Zvoliť znak z každej skupiny</translation>
    </message>
    <message>
        <source>Passphrase</source>
        <translation>Tajná veta</translation>
    </message>
    <message>
        <source>Word Separator:</source>
        <translation>Oddeľovač slov:</translation>
    </message>
    <message>
        <source>Wordlist:</source>
        <translation>Zoznam slov:</translation>
    </message>
    <message>
        <source>Word Count:</source>
        <translation>Počet slov:</translation>
    </message>
    <message>
        <source>Word Case:</source>
        <translation>Slová veľkými:</translation>
    </message>
    <message>
        <source>Delete selected wordlist</source>
        <translation>Vymazať vybraný zoznam slov</translation>
    </message>
    <message>
        <source>Add custom wordlist</source>
        <translation>Pridať vlastný zoznam slov</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Zatvoriť</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
    <message>
        <source>Apply Password</source>
        <translation>Použiť heslo</translation>
    </message>
    <message>
        <source>Regenerate password (%1)</source>
        <translation>Obnoviť heslo (%1)</translation>
    </message>
    <message>
        <source>lower case</source>
        <translation>malé písmená</translation>
    </message>
    <message>
        <source>UPPER CASE</source>
        <translation>VEĽKÉ PÍSMENÁ</translation>
    </message>
    <message>
        <source>Title Case</source>
        <translation>Titulková Veľkosť</translation>
    </message>
    <message>
        <source>(SYSTEM)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Entropy: %1 bit</source>
        <translation>Náhodnosť: %1 b</translation>
    </message>
    <message>
        <source>Password Quality: %1</source>
        <translation>Kvalita hesla: %1</translation>
    </message>
    <message>
        <source>Poor</source>
        <comment>Password quality</comment>
        <translation>Slabé</translation>
    </message>
    <message>
        <source>Weak</source>
        <comment>Password quality</comment>
        <translation>Slabé</translation>
    </message>
    <message>
        <source>Good</source>
        <comment>Password quality</comment>
        <translation>Dobré</translation>
    </message>
    <message>
        <source>Excellent</source>
        <comment>Password quality</comment>
        <translation>Výbroné</translation>
    </message>
    <message>
        <source>Failed to delete wordlist</source>
        <translation>Zmazanie zoznamu slov sa nezdarilo</translation>
    </message>
    <message>
        <source>Wordlists</source>
        <translation>Zoznamy slov</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>Všetky súbory</translation>
    </message>
    <message>
        <source>Select Custom Wordlist</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Overwrite Wordlist?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Wordlist &quot;%1&quot; already exists as a custom wordlist.
Do you want to overwrite it?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Failed to add wordlist</source>
        <translation>Pridatie zoznamu slov sa nezdarilo</translation>
    </message>
    <message>
        <source>Logograms</source>
        <translation>Zástupné znaky</translation>
    </message>
    <message>
        <source>Special Characters</source>
        <translation>Špeciálne znaky</translation>
    </message>
    <message>
        <source>passwordLength</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Characters: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>MIXED case</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Excluded characters: &quot;0&quot;, &quot;1&quot;, &quot;l&quot;, &quot;I&quot;, &quot;O&quot;, &quot;|&quot;, &quot;﹒&quot;, &quot;B&quot;, &quot;8&quot;, &quot;G&quot;, &quot;6&quot;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Warning: the chosen wordlist is smaller than the minimum recommended size!</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Confirm Remove Wordlist</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Do you really want to remove the wordlist &quot;%1&quot;?</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>PasswordWidget</name>
    <message>
        <source>Passwords do not match</source>
        <translation>Heslá sa nezhodujú.</translation>
    </message>
    <message>
        <source>Passwords match so far</source>
        <translation>Heslá sa zhodujú až potiaľ</translation>
    </message>
    <message>
        <source>Toggle Password (%1)</source>
        <translation>Prepnúť heslo (%1)</translation>
    </message>
    <message>
        <source>Generate Password (%1)</source>
        <translation>Generovať heslo (%1)</translation>
    </message>
    <message>
        <source>Warning: Caps Lock enabled!</source>
        <translation>Upozornenie: Caps Lock zapnutý!</translation>
    </message>
    <message>
        <source>Quality: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Poor</source>
        <comment>Password quality</comment>
        <translation>Slabé</translation>
    </message>
    <message>
        <source>Weak</source>
        <comment>Password quality</comment>
        <translation>Slabé</translation>
    </message>
    <message>
        <source>Good</source>
        <comment>Password quality</comment>
        <translation>Dobré</translation>
    </message>
    <message>
        <source>Excellent</source>
        <comment>Password quality</comment>
        <translation>Výbroné</translation>
    </message>
    <message>
        <source>Toggle password visibility using Control + H. Open the password generator using Control + G.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>PickcharsDialog</name>
    <message>
        <source>KeePassXC - Pick Characters</source>
        <translation>KeePassXC - Zvoľte znaky</translation>
    </message>
    <message>
        <source>Select characters to type, navigate with arrow keys, Ctrl + S submits.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Press &amp;Tab between characters</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>PreviewEntryAttachmentsDialog</name>
    <message>
        <source>Form</source>
        <translation>Formulár</translation>
    </message>
    <message>
        <source>Preview: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Save…</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>QMessageBox</name>
    <message>
        <source>Overwrite</source>
        <translation>Prepísať</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Odstrániť</translation>
    </message>
    <message>
        <source>Move</source>
        <translation>Presunúť</translation>
    </message>
    <message>
        <source>Empty</source>
        <translation>Vyprádzniť</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Odstrániť</translation>
    </message>
    <message>
        <source>Skip</source>
        <translation>Preskočiť</translation>
    </message>
    <message>
        <source>Disable</source>
        <translation>Vypnúť</translation>
    </message>
    <message>
        <source>Merge</source>
        <translation>Zlúčiť</translation>
    </message>
    <message>
        <source>Continue</source>
        <translation>Pokračovať</translation>
    </message>
    <message>
        <source>Continue with weak password</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Database not opened</source>
        <translation>Databáza nie je otvorená</translation>
    </message>
    <message>
        <source>Database hash not available</source>
        <translation>Odtlačok databázy nie je dostupný</translation>
    </message>
    <message>
        <source>Client public key not received</source>
        <translation>Nebol prijatý verejný kľúč klienta</translation>
    </message>
    <message>
        <source>Cannot decrypt message</source>
        <translation>Nemožno dešifrovať správu</translation>
    </message>
    <message>
        <source>Action cancelled or denied</source>
        <translation>Akcia zrušená alebo odmietnutá</translation>
    </message>
    <message>
        <source>Message encryption failed.</source>
        <translation>Šifrovanie správy zlyhalo.</translation>
    </message>
    <message>
        <source>KeePassXC association failed, try again</source>
        <translation>Spojenie s KeePassXC zlyhalo, skúste znova</translation>
    </message>
    <message>
        <source>Encryption key is not recognized</source>
        <translation>Šifrovací kľúč nerozpoznaný</translation>
    </message>
    <message>
        <source>Incorrect action</source>
        <translation>Nesprávna akcia</translation>
    </message>
    <message>
        <source>Empty message received</source>
        <translation>Prijatá prázdna správa</translation>
    </message>
    <message>
        <source>No URL provided</source>
        <translation>Nebolo poskytnuté URL</translation>
    </message>
    <message>
        <source>No logins found</source>
        <translation>Nebolo nájdené prihlásenie</translation>
    </message>
    <message>
        <source>No groups found</source>
        <translation>Skupiny nenájdené</translation>
    </message>
    <message>
        <source>Cannot create new group</source>
        <translation>Nemožno vytvoriť novú skupinu</translation>
    </message>
    <message>
        <source>No valid UUID provided</source>
        <translation>Nebol zadaný platný UUID</translation>
    </message>
    <message>
        <source>Username or password cannot contain references</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Unknown error</source>
        <translation>Neznáma chyba</translation>
    </message>
    <message>
        <source>Browser Integration</source>
        <translation>Integrácia prehliadača</translation>
    </message>
    <message>
        <source>Browser Plugin Failure</source>
        <translation>Chyba doplnku prehlaidača</translation>
    </message>
    <message>
        <source>Could not save the native messaging script file for %1.</source>
        <translation>Nemožno uložiť súbor skriptu správ medzi prehliadačom a KeePassXC (native messaging) pre %1.</translation>
    </message>
    <message>
        <source>Username for the entry.</source>
        <translation>Použ. meno položky.</translation>
    </message>
    <message>
        <source>username</source>
        <translation>použmeno</translation>
    </message>
    <message>
        <source>URL for the entry.</source>
        <translation>URL položky.</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>Notes for the entry.</source>
        <translation>Poznámky položky.</translation>
    </message>
    <message>
        <source>Notes</source>
        <translation>Poznámky</translation>
    </message>
    <message>
        <source>Prompt for the entry&apos;s password.</source>
        <translation>Vyžiadať heslo položky.</translation>
    </message>
    <message>
        <source>Generate a password for the entry.</source>
        <translation>Generovať heslo tejto položky.</translation>
    </message>
    <message>
        <source>Add a new entry to a database.</source>
        <translation>Pridá do databázy novú položku</translation>
    </message>
    <message>
        <source>Path of the entry to add.</source>
        <translation>Cesta pridávanej položky</translation>
    </message>
    <message>
        <source>Cannot generate a password and prompt at the same time.</source>
        <translation>Nemožno naraz generovať aj zadať heslo!</translation>
    </message>
    <message>
        <source>Could not create entry with path %1.</source>
        <translation>Nemožno vytvoriť položku s cestou %1.</translation>
    </message>
    <message>
        <source>Enter password for new entry: </source>
        <translation>Zadajte heslo novej položky:</translation>
    </message>
    <message>
        <source>Writing the database failed %1.</source>
        <translation>Zápis do databázy zlyhal %1.</translation>
    </message>
    <message>
        <source>Successfully added entry %1.</source>
        <translation>Úspešne pridaná položka %1.</translation>
    </message>
    <message>
        <source>Adds a new group to a database.</source>
        <translation>Pridá do databázy novú skupinu</translation>
    </message>
    <message>
        <source>Path of the group to add.</source>
        <translation>Cesta pridávanej skupiny.</translation>
    </message>
    <message>
        <source>Group %1 already exists!</source>
        <translation>Skupina %1 už existuje!</translation>
    </message>
    <message>
        <source>Group %1 not found.</source>
        <translation>Skupina %1 nenájdená.</translation>
    </message>
    <message>
        <source>Successfully added group %1.</source>
        <translation>Úspešne pridaná skupina %1.</translation>
    </message>
    <message>
        <source>Check if any passwords have been publicly leaked. FILENAME must be the path of a file listing SHA-1 hashes of leaked passwords in HIBP format, as available from https://haveibeenpwned.com/Passwords.</source>
        <translation>Skontrolovať, či nejaké heslo neuniklo na verejnosť. MENOSÚBORU musí byť cesta k súboru so zoznamom odtlačkov SHA-1 uniknutých hesiel vo formáte HIBP, ako je dostupný z https://haveibeenpwned.com/Passwords.</translation>
    </message>
    <message>
        <source>FILENAME</source>
        <translation>MENOSÚBORU</translation>
    </message>
    <message>
        <source>Path to okon-cli to search a formatted HIBP file</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>okon-cli</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Analyze passwords for weaknesses and problems.</source>
        <translation>Analyzovať slabé a problémové heslá.</translation>
    </message>
    <message>
        <source>Cannot find HIBP file: %1</source>
        <translation>Nemožno nájsť súbor HIBP: %1</translation>
    </message>
    <message>
        <source>Evaluating database entries using okon…</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Failed to open HIBP file %1: %2</source>
        <translation>Zlyhalo otvorenie súboru HIBP %1: %2</translation>
    </message>
    <message>
        <source>Evaluating database entries against HIBP file, this will take a while…</source>
        <translation type="unfinished"/>
    </message>
    <message numerus="yes">
        <source>Password for &apos;%1&apos; has been leaked %2 time(s)!</source>
        <translation><numerusform>Heslo k „%1” uniknuté %2 krát!</numerusform><numerusform>Heslo k „%1” uniknuté %2 krát!</numerusform><numerusform>Heslo k „%1” uniknuté %2 krát!</numerusform><numerusform>Heslo k „%1” uniknuté %2 krát!</numerusform></translation>
    </message>
    <message>
        <source>Password for &apos;%1&apos; has been leaked!</source>
        <translation>Heslo k „%1” uniknuté %2 krát!</translation>
    </message>
    <message>
        <source>Export an attachment of an entry.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Path of the entry with the target attachment.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Name of the attachment to be exported.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Path to which the attachment should be exported.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Could not find entry with path %1.</source>
        <translation>Nepodarilo sa nájsť položku s cestou %1.</translation>
    </message>
    <message>
        <source>Could not find attachment with name %1.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>No export target given. Please use &apos;--stdout&apos; or specify an &apos;export-file&apos;.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Could not open output file %1.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Successfully exported attachment %1 of entry %2 to %3.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Overwrite existing attachments.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Imports an attachment to an entry.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Path of the entry.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Name of the attachment to be added.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Path of the attachment to be imported.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Attachment %1 already exists for entry %2.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Could not open attachment file %1.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Successfully imported attachment %1 as %2 to entry %3.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Remove an attachment of an entry.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Name of the attachment to be removed.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Successfully removed attachment %1 from entry %2.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Copy the given attribute to the clipboard. Defaults to &quot;password&quot; if not specified.</source>
        <comment>Don't translate &quot;password&quot;, it refers to the attribute.</comment>
        <translation>Prekopírovať zadaný atribút do schránky. Ak nie je zadané, predvolene bude „password”.</translation>
    </message>
    <message>
        <source>Copy the current TOTP to the clipboard (equivalent to &quot;-a totp&quot;).</source>
        <translation>Kopírovať aktuálny TOTP do schránky (ekvivalent „-a totp”).</translation>
    </message>
    <message>
        <source>Must match only one entry, otherwise a list of possible matches is shown.</source>
        <translation>Musí zodpovedať len jednej položke, inak bude zobrazený zoznam zodpovedajúcich položiek.</translation>
    </message>
    <message>
        <source>Copy an entry&apos;s attribute to the clipboard.</source>
        <translation>Skopírovať atribút položky do schránky.</translation>
    </message>
    <message>
        <source>Path of the entry to clip.</source>
        <comment>clip = copy to clipboard</comment>
        <translation>Cesta položky na vystrihnutie.</translation>
    </message>
    <message>
        <source>Timeout before clearing the clipboard (default is %1 seconds, set to 0 for unlimited).</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Invalid timeout value %1.</source>
        <translation>Neplatná hodnota časového limitu %1.</translation>
    </message>
    <message>
        <source>Multiple entries matching:</source>
        <translation>Zodpovedajú viaceré položky:</translation>
    </message>
    <message>
        <source>Using matching entry: %1</source>
        <translation>Použitie zodpovedajúcej položky: %1</translation>
    </message>
    <message>
        <source>Entry %1 not found.</source>
        <translation>Položka %1 nenájdená.</translation>
    </message>
    <message>
        <source>ERROR: Please specify one of --attribute or --totp, not both.</source>
        <translation>CHYBA: Prosím, zadajte len jedno z --attribute alebo --totp, nie oba.</translation>
    </message>
    <message>
        <source>Entry with path %1 has no TOTP set up.</source>
        <translation>Položka s cestou %1 nemá nastavený TOTP.</translation>
    </message>
    <message>
        <source>ERROR: attribute %1 is ambiguous, it matches %2.</source>
        <translation>CHYBA: atribút  %1 je nejednoznačný, vyhovuje %2.</translation>
    </message>
    <message>
        <source>Attribute &quot;%1&quot; not found.</source>
        <translation>Atribút „%1” nenájdený.</translation>
    </message>
    <message>
        <source>Entry&apos;s &quot;%1&quot; attribute copied to the clipboard!</source>
        <translation>Atribút „%1” položky skopírovaný do schránky!</translation>
    </message>
    <message numerus="yes">
        <source>Clearing the clipboard in %1 second(s)...</source>
        <translation><numerusform>Vymazaním schránky v %1 sekundu...</numerusform><numerusform>Vymazaním schránky v %1 sekundu...</numerusform><numerusform>Vymazaním schránky v %1 sekundu...</numerusform><numerusform>Clipboard bude vymazaný za %1 sek.</numerusform></translation>
    </message>
    <message>
        <source>Clipboard cleared!</source>
        <translation>Schránka vymazaná!</translation>
    </message>
    <message>
        <source>Close the currently opened database.</source>
        <translation>Zatvoriť aktuálne otvorenú databázu.</translation>
    </message>
    <message>
        <source>Display this help.</source>
        <translation>Zobrazí tohoto pomocníka.</translation>
    </message>
    <message>
        <source>Silence password prompt and other secondary outputs.</source>
        <translation>Potlačiť prompt hesla a ďalšie sekundárne výstupy</translation>
    </message>
    <message>
        <source>Key file of the database.</source>
        <translation>Súbor kľúča databázy.</translation>
    </message>
    <message>
        <source>path</source>
        <translation>cesta</translation>
    </message>
    <message>
        <source>Deactivate password key for the database.</source>
        <translation>Deaktivovať heslo kľúča databázy.</translation>
    </message>
    <message>
        <source>Yubikey slot and optional serial used to access the database (e.g., 1:7370001).</source>
        <translation>Slot Yubikey a voliteľné sériové číslo na prístup k databáze (napr. 1:7370001).</translation>
    </message>
    <message>
        <source>slot[:serial]</source>
        <translation>slot[:ser.číslo]</translation>
    </message>
    <message>
        <source>Missing positional argument(s).</source>
        <translation>Chýbajú pozičné argumenty.</translation>
    </message>
    <message>
        <source>Too many arguments provided.</source>
        <translation>Príliš veľa argumentov.</translation>
    </message>
    <message>
        <source>Path of the database.</source>
        <translation>Cesta k databáze.</translation>
    </message>
    <message>
        <source>Target decryption time in MS for the database.</source>
        <translation>Cieľový čas dešifrovania databázy v ms.</translation>
    </message>
    <message>
        <source>time</source>
        <translation>čas</translation>
    </message>
    <message>
        <source>Set the key file for the database.</source>
        <translation>Nastaviť súbor kľúča databázy.</translation>
    </message>
    <message>
        <source>Set a password for the database.</source>
        <translation>Nastaviť heslo databázy.</translation>
    </message>
    <message>
        <source>Create a new database.</source>
        <translation>Vytvoriť novú databázu.</translation>
    </message>
    <message>
        <source>Invalid decryption time %1.</source>
        <translation>Neplatný čas dešifrovania %1.</translation>
    </message>
    <message>
        <source>Target decryption time must be between %1 and %2.</source>
        <translation>Cieľový čas dešifrovania databázy má byť medzi %1 a %2.</translation>
    </message>
    <message>
        <source>Failed to set database password.</source>
        <translation>Zlyhalo nastavenie hesla databázy.</translation>
    </message>
    <message>
        <source>Loading the key file failed</source>
        <translation>Načítanie nového kľúča zlyhalo</translation>
    </message>
    <message>
        <source>No key is set. Aborting database creation.</source>
        <translation>Nie je nastavený kľúč. Vytvorenie novej databázy zrušené.</translation>
    </message>
    <message>
        <source>Benchmarking key derivation function for %1ms delay.</source>
        <translation>meranie výkonu funkcie odvodenia kľúča pre %1ms trvanie.</translation>
    </message>
    <message>
        <source>Setting %1 rounds for key derivation function.</source>
        <translation>Nastavenie %1 opakovaní pre funkciu odvodenia kľúča.</translation>
    </message>
    <message>
        <source>error while setting database key derivation settings.</source>
        <translation>chyba nastavovania kľúča databázy pri nastavení odvodenia kľúča.</translation>
    </message>
    <message>
        <source>File %1 already exists.</source>
        <translation>Súbor %1 už existuje.</translation>
    </message>
    <message>
        <source>Failed to save the database: %1.</source>
        <translation>Zlyhalo uloženie databázy: %1.</translation>
    </message>
    <message>
        <source>Successfully created new database.</source>
        <translation>Úspešne vytvorená nová databáza.</translation>
    </message>
    <message>
        <source>Unset the password for the database.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Unset the key file for the database.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Edit a database.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Cannot use %1 and %2 at the same time.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Could not change the database key.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Database was not modified.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Writing the database failed: %1</source>
        <translation>Zápis do databázy zlyhal: %1</translation>
    </message>
    <message>
        <source>Successfully edited the database.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Cannot remove password: The database does not have a password.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Cannot remove file key: The database does not have a file key.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Loading the new key file failed: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Found unexpected Key type %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Cannot remove all the keys from a database.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Show a database&apos;s information.</source>
        <translation>Zobraziť informácie databázy.</translation>
    </message>
    <message>
        <source>UUID: </source>
        <translation>UUID: </translation>
    </message>
    <message>
        <source>Name: </source>
        <translation>Názov:</translation>
    </message>
    <message>
        <source>Description: </source>
        <translation>Popis:</translation>
    </message>
    <message>
        <source>Cipher: </source>
        <translation>Šifra:</translation>
    </message>
    <message>
        <source>KDF: </source>
        <translation>KDF: </translation>
    </message>
    <message>
        <source>Recycle bin is enabled.</source>
        <translation>Odpadkový kôš je zapnutý.</translation>
    </message>
    <message>
        <source>Recycle bin is not enabled.</source>
        <translation>Odpadkový kôš nie je zapnutý.</translation>
    </message>
    <message>
        <source>Location</source>
        <translation>Umiestnenie</translation>
    </message>
    <message>
        <source>Database created</source>
        <translation>Databáza vytvorená</translation>
    </message>
    <message>
        <source>Last saved</source>
        <translation>Naposledy uložené</translation>
    </message>
    <message>
        <source>Unsaved changes</source>
        <translation>Neuložené zmeny</translation>
    </message>
    <message>
        <source>yes</source>
        <translation>áno</translation>
    </message>
    <message>
        <source>no</source>
        <translation>nie</translation>
    </message>
    <message>
        <source>Number of groups</source>
        <translation>Počet skupín</translation>
    </message>
    <message>
        <source>Number of entries</source>
        <translation>Počet položiek</translation>
    </message>
    <message>
        <source>Number of expired entries</source>
        <translation>Počet položiek po dobe platnosti</translation>
    </message>
    <message>
        <source>Unique passwords</source>
        <translation>Jedinečné heslá</translation>
    </message>
    <message>
        <source>Non-unique passwords</source>
        <translation>Nie jedinečné heslá</translation>
    </message>
    <message>
        <source>Maximum password reuse</source>
        <translation>Maximálny počet opakovane použitých hesiel</translation>
    </message>
    <message>
        <source>Number of short passwords</source>
        <translation>Počet krátkych hesiel</translation>
    </message>
    <message>
        <source>Number of weak passwords</source>
        <translation>Počet slabých hesiel</translation>
    </message>
    <message>
        <source>Entries excluded from reports</source>
        <translation>Položky vylúčené z hlásení</translation>
    </message>
    <message>
        <source>Average password length</source>
        <translation>Priemerná dĺžka hesla</translation>
    </message>
    <message>
        <source>Number of passkeys</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Entries with TOTP setup</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Word count for the diceware passphrase.</source>
        <translation>Počet slov pre diceware tajnú vetu.</translation>
    </message>
    <message>
        <source>count</source>
        <comment>CLI parameter</comment>
        <translation>počet</translation>
    </message>
    <message>
        <source>Wordlist for the diceware generator.
[Default: EFF English]</source>
        <translation>Zoznam slov pre generátor diceware.
[Predvolené: EFF angličtina]</translation>
    </message>
    <message>
        <source>Generate a new random diceware passphrase.</source>
        <translation>Generovať novú náhodnú diceware tajnú vetu.</translation>
    </message>
    <message>
        <source>Invalid word count %1</source>
        <translation>Neplatný počet slov %1</translation>
    </message>
    <message>
        <source>Title for the entry.</source>
        <translation>Názov položky.</translation>
    </message>
    <message>
        <source>title</source>
        <translation>názov</translation>
    </message>
    <message>
        <source>Edit an entry.</source>
        <translation>Upraviť položku.</translation>
    </message>
    <message>
        <source>Path of the entry to edit.</source>
        <translation>Cesta položky na úpravu.</translation>
    </message>
    <message>
        <source>Not changing any field for entry %1.</source>
        <translation>Nemení sa žiadne pole položky %1.</translation>
    </message>
    <message>
        <source>Enter new password for entry: </source>
        <translation>Zadajte nové heslo položky:</translation>
    </message>
    <message>
        <source>Successfully edited entry %1.</source>
        <translation>Úspešne upravená položka %1.</translation>
    </message>
    <message>
        <source>Perform advanced analysis on the password.</source>
        <translation>Vykonať pokročilú analýzu hesla.</translation>
    </message>
    <message>
        <source>Password for which to estimate the entropy.</source>
        <translation>Heslo, ktorému zistiť očakávanú náhodnosť.</translation>
    </message>
    <message>
        <source>Estimate the entropy of a password.</source>
        <translation>Očakávaná náhodnosť hesla.</translation>
    </message>
    <message>
        <source>Length %1</source>
        <translation>Dĺžka %1</translation>
    </message>
    <message>
        <source>Entropy %1</source>
        <translation>Náhodnosť %1</translation>
    </message>
    <message>
        <source>Log10 %1</source>
        <translation>Log10 %1</translation>
    </message>
    <message>
        <source>Multi-word extra bits %1</source>
        <translation>Viacslovné extra bity %1</translation>
    </message>
    <message>
        <source>Type: Bruteforce</source>
        <translation>Type: Hrubou silou</translation>
    </message>
    <message>
        <source>Type: Dictionary</source>
        <translation>Typ: Slovník</translation>
    </message>
    <message>
        <source>Type: Dict+Leet</source>
        <translation>Typ: Slovník+Leet</translation>
    </message>
    <message>
        <source>Type: User Words</source>
        <translation>Typ: Použ. slová</translation>
    </message>
    <message>
        <source>Type: User+Leet</source>
        <translation>Typ: Použ.+Leet</translation>
    </message>
    <message>
        <source>Type: Repeated</source>
        <translation>Typ: Opakované</translation>
    </message>
    <message>
        <source>Type: Sequence</source>
        <translation>Typ: Postupné</translation>
    </message>
    <message>
        <source>Type: Spatial</source>
        <translation>Typ: Geometrické</translation>
    </message>
    <message>
        <source>Type: Date</source>
        <translation>Typ: Dátum</translation>
    </message>
    <message>
        <source>Type: Bruteforce(Rep)</source>
        <translation>Typ: Hrubou silou(Rep)</translation>
    </message>
    <message>
        <source>Type: Dictionary(Rep)</source>
        <translation>Typ: Slovník(Rep)</translation>
    </message>
    <message>
        <source>Type: Dict+Leet(Rep)</source>
        <translation>Typ: Slovník+Leet(Rep)</translation>
    </message>
    <message>
        <source>Type: User Words(Rep)</source>
        <translation>Type: Použ. slová(Rep)</translation>
    </message>
    <message>
        <source>Type: User+Leet(Rep)</source>
        <translation>Typ: Použ.+Leet(Rep)</translation>
    </message>
    <message>
        <source>Type: Repeated(Rep)</source>
        <translation>Typ: Opakované(Rep)</translation>
    </message>
    <message>
        <source>Type: Sequence(Rep)</source>
        <translation>Typ: Postupné(Rep)</translation>
    </message>
    <message>
        <source>Type: Spatial(Rep)</source>
        <translation>Typ: Geometrické(Rep)</translation>
    </message>
    <message>
        <source>Type: Date(Rep)</source>
        <translation>Typ: Dátum(Rep)</translation>
    </message>
    <message>
        <source>Type: Unknown (%1)</source>
        <translation>Typ: Neznámy (%1)</translation>
    </message>
    <message>
        <source>Entropy %1 (%2)</source>
        <translation>Náhodnosť %1 (%2)</translation>
    </message>
    <message>
        <source>*** Password length (%1) != sum of length of parts (%2) ***</source>
        <translation>*** Dĺžka hesla (%1) NIE JE súčtom dĺžky častí (%2) * * *</translation>
    </message>
    <message>
        <source>Exit interactive mode.</source>
        <translation>Ukončiť interaktívny režim.</translation>
    </message>
    <message>
        <source>Exports the content of a database to standard output in the specified format.</source>
        <translation>Exportuje obsah databázy na štandardný výstup v zadanom formáte.</translation>
    </message>
    <message>
        <source>Unable to export database to XML: %1</source>
        <translation>Nemožno exportovať databázu do XML: %1</translation>
    </message>
    <message>
        <source>Unsupported format %1</source>
        <translation>Nepodporovaný formát: %1</translation>
    </message>
    <message>
        <source>Length of the generated password</source>
        <translation>Dĺžka generovaného hesla</translation>
    </message>
    <message>
        <source>length</source>
        <translation>dĺžka</translation>
    </message>
    <message>
        <source>Use lowercase characters</source>
        <translation>Požiť malé písmená</translation>
    </message>
    <message>
        <source>Use uppercase characters</source>
        <translation>Použiť veľké písmená</translation>
    </message>
    <message>
        <source>Use numbers</source>
        <translation>Použiť čísla</translation>
    </message>
    <message>
        <source>Use special characters</source>
        <translation>Použiť špeciálne znaky</translation>
    </message>
    <message>
        <source>Use extended ASCII</source>
        <translation>Použiť rozšírené ASCII</translation>
    </message>
    <message>
        <source>Exclude character set</source>
        <translation>Množina vynechaných znakov</translation>
    </message>
    <message>
        <source>chars</source>
        <translation>znaky</translation>
    </message>
    <message>
        <source>Use custom character set</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Exclude similar looking characters</source>
        <translation>Vynechať podobne vyzerajúce znaky</translation>
    </message>
    <message>
        <source>Include characters from every selected group</source>
        <translation>Použiť znaky z každej zvolenej skupiny</translation>
    </message>
    <message>
        <source>Generate a new random password.</source>
        <translation>Generovať nové náhodné heslo.</translation>
    </message>
    <message>
        <source>Invalid password length %1</source>
        <translation>Neplatná dĺžka hesla %1</translation>
    </message>
    <message>
        <source>Invalid password generator after applying all options</source>
        <translation>Neplatný generátor hesla po aplikovaní všetkých volieb</translation>
    </message>
    <message>
        <source>Display command help.</source>
        <translation>Zobrazí pomocníka príkazu.</translation>
    </message>
    <message>
        <source>Available commands:</source>
        <translation>Dostupné príkazy:</translation>
    </message>
    <message>
        <source>Import the contents of an XML database.</source>
        <translation>Import obsahu databázy XML.</translation>
    </message>
    <message>
        <source>Path of the XML database export.</source>
        <translation>Cesta na export databázy XML.</translation>
    </message>
    <message>
        <source>Path of the new database.</source>
        <translation>Cesta k novej databáze.</translation>
    </message>
    <message>
        <source>Unable to import XML database: %1</source>
        <translation>Nemožno importovať databázu XML: %1</translation>
    </message>
    <message>
        <source>Successfully imported database.</source>
        <translation>Úspešne importovaná databáza.</translation>
    </message>
    <message>
        <source>Unknown command %1</source>
        <translation>Neznáma príkaz %1</translation>
    </message>
    <message>
        <source>

Available commands:
</source>
        <translation>

Dostupné príkazy:
</translation>
    </message>
    <message>
        <source>Name of the command to execute.</source>
        <translation>Názov príkazu na spustenie.</translation>
    </message>
    <message>
        <source>Displays debugging information.</source>
        <translation>Zobraziť ladiace informácie</translation>
    </message>
    <message>
        <source>Invalid command %1.</source>
        <translation>Neplatný príkaz %1.</translation>
    </message>
    <message>
        <source>Recursively list the elements of the group.</source>
        <translation>Rekurzívne vypísať zoznam prvkov skupiny.</translation>
    </message>
    <message>
        <source>Flattens the output to single lines.</source>
        <translation>Spája výstup do jedného riadku.</translation>
    </message>
    <message>
        <source>List database entries.</source>
        <translation>Zoznam položiek databázy.</translation>
    </message>
    <message>
        <source>Path of the group to list. Default is /</source>
        <translation>Cesta vypísanej skupiny. Predvolene /</translation>
    </message>
    <message>
        <source>Cannot find group %1.</source>
        <translation>Nemožno nájsť skupinu %1.</translation>
    </message>
    <message>
        <source>Use the same credentials for both database files.</source>
        <translation>Použiť rovnaké prihlásenie pre oba súbory databáz.</translation>
    </message>
    <message>
        <source>Key file of the database to merge from.</source>
        <translation>Súbor kľúča databázy, z ktorej má byť zlúčené.</translation>
    </message>
    <message>
        <source>Deactivate password key for the database to merge from.</source>
        <translation>Deaktivovať heslo kľúča zlučovanej databázy.</translation>
    </message>
    <message>
        <source>Only print the changes detected by the merge operation.</source>
        <translation>Vypisovať len zmeny zistený pri operácii zlúčenia.</translation>
    </message>
    <message>
        <source>Yubikey slot for the second database.</source>
        <translation>Slot Yubikey pre druhú databázu.</translation>
    </message>
    <message>
        <source>slot</source>
        <translation>slot</translation>
    </message>
    <message>
        <source>Merge two databases.</source>
        <translation>Zlúčiť dve databázy.</translation>
    </message>
    <message>
        <source>Path of the database to merge from.</source>
        <translation>Cesta k databáze, z ktorej zlúčiť.</translation>
    </message>
    <message>
        <source>Error reading merge file:
%1</source>
        <translation>Chyba čítania súboru zlúčenia:
%1</translation>
    </message>
    <message>
        <source>Unable to save database to file : %1</source>
        <translation>Nemožno uložiť databázu do súboru: %1</translation>
    </message>
    <message>
        <source>Successfully merged %1 into %2.</source>
        <translation>Úspešne zlúčené %1 do %2.</translation>
    </message>
    <message>
        <source>Database was not modified by merge operation.</source>
        <translation>Databáza nebola operáciou zlúčenia zmenená.</translation>
    </message>
    <message>
        <source>Moves an entry to a new group.</source>
        <translation>Presunie položku do novej skupiny.</translation>
    </message>
    <message>
        <source>Path of the entry to move.</source>
        <translation>Cesta položky na presun.</translation>
    </message>
    <message>
        <source>Path of the destination group.</source>
        <translation>Cesta cieľovej skupiny.</translation>
    </message>
    <message>
        <source>Could not find group with path %1.</source>
        <translation>Nemožno nájsť skupinu s cestou %1.</translation>
    </message>
    <message>
        <source>Entry is already in group %1.</source>
        <translation>Položka už je v skupine %1.</translation>
    </message>
    <message>
        <source>Successfully moved entry %1 to group %2.</source>
        <translation>Položka %1 úspešne presunutá do skupiny %2.</translation>
    </message>
    <message>
        <source>Open a database.</source>
        <translation>Otvorí databázu.</translation>
    </message>
    <message>
        <source>Path of the entry to remove.</source>
        <translation>Cesta položky na odstránenie.</translation>
    </message>
    <message>
        <source>Unable to save database to file: %1</source>
        <translation>Nemožno uložiť databázu do súboru: %1</translation>
    </message>
    <message>
        <source>Successfully recycled entry %1.</source>
        <translation>Položka %1 bola úspešne recyklovaná.</translation>
    </message>
    <message>
        <source>Successfully deleted entry %1.</source>
        <translation>Položka %1 bola úspešne odstránená.</translation>
    </message>
    <message>
        <source>Path of the group to remove.</source>
        <translation>Cesta skupiny na odstránenie.</translation>
    </message>
    <message>
        <source>Cannot remove root group from database.</source>
        <translation>Nemožno odstrániť koreňovú skupinu z databázy.</translation>
    </message>
    <message>
        <source>Successfully recycled group %1.</source>
        <translation>Skupina %1 bola úspešne recyklovaná.</translation>
    </message>
    <message>
        <source>Successfully deleted group %1.</source>
        <translation>Úspešne odstránená skupina %1.</translation>
    </message>
    <message>
        <source>Find entries quickly.</source>
        <translation>Rýchlo nájdite položky.</translation>
    </message>
    <message>
        <source>Search term.</source>
        <translation>Hľadaný výraz.</translation>
    </message>
    <message>
        <source>Show the entry&apos;s current TOTP.</source>
        <translation>Zobraziť aktuálny TOTP položky.</translation>
    </message>
    <message>
        <source>Show the protected attributes in clear text.</source>
        <translation>Zobraziť chránené atribúty ako prostý text.</translation>
    </message>
    <message>
        <source>Show all the attributes of the entry.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Show the attachments of the entry.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Names of the attributes to show. This option can be specified more than once, with each attribute shown one-per-line in the given order. If no attributes are specified, a summary of the default attributes is given.</source>
        <translation>Názvy zobrazených atribútov. Táto voľba môže byť zadaná viac ako raz a každý atribút bude zobrazený jeden na riadok v zadanom poradí. Ak nie sú zadané žiadne atribúty, je použité zhrnutie predvolených atribútov.</translation>
    </message>
    <message>
        <source>attribute</source>
        <translation>atribút</translation>
    </message>
    <message>
        <source>Show an entry&apos;s information.</source>
        <translation>Zobraziť informácie položky.</translation>
    </message>
    <message>
        <source>Name of the entry to show.</source>
        <translation>Názov položky na zobrazenie.</translation>
    </message>
    <message>
        <source>ERROR: unknown attribute %1.</source>
        <translation>CHYBA: Neznámy atribút %1.</translation>
    </message>
    <message>
        <source>No attachments present.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Attachments:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Failed to open database file %1: not found</source>
        <translation>Zlyhalo otvorenie súboru databázy %1: nenájdené</translation>
    </message>
    <message>
        <source>Failed to open database file %1: not a plain file</source>
        <translation>Zlyhalo otvorenie súboru databázy %1: nie je súbor</translation>
    </message>
    <message>
        <source>Failed to open database file %1: not readable</source>
        <translation>Zlyhalo otvorenie súboru databázy %1: nie je čitateľné</translation>
    </message>
    <message>
        <source>Enter password to unlock %1: </source>
        <translation>Zadajte heslo na odomknutie %1:</translation>
    </message>
    <message>
        <source>Failed to load key file %1: %2</source>
        <translation>Zlyhalo načítanie súboru kľúča %1: %2</translation>
    </message>
    <message>
        <source>WARNING: You are using an old key file format which KeePassXC may
stop supporting in the future.

Please consider generating a new key file.</source>
        <translation>UPOZORNENIE: Používate starý formát súboru kľúča, ktorý už nemusí byť
v budúcnosti podporovaný .

Prosím, zvážte vygenerovanie nového súboru kľúča.</translation>
    </message>
    <message>
        <source>Invalid YubiKey slot %1</source>
        <translation>Neplatný slot Yubikey %1</translation>
    </message>
    <message>
        <source>Invalid YubiKey serial %1</source>
        <translation>Neplatné sériové číslo Yubikey %1</translation>
    </message>
    <message>
        <source>Please present or touch your YubiKey to continue.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Enter password to encrypt database (optional): </source>
        <translation>Zadajte heslo na zašifrovanie databázy (voliteľné):</translation>
    </message>
    <message>
        <source>Do you want to create a database with an empty password? [y/N]: </source>
        <translation>Naozaj chcete vytvoriť databázu s prázdnym heslom? [y/N]</translation>
    </message>
    <message>
        <source>Repeat password: </source>
        <translation>Zopakujte heslo:</translation>
    </message>
    <message>
        <source>Error: Passwords do not match.</source>
        <translation>Chyba: Heslá sa nezhodujú.</translation>
    </message>
    <message>
        <source>No program defined for clipboard manipulation</source>
        <translation>Nie je definovaný program na manipuláciu so schránkou</translation>
    </message>
    <message>
        <source>All clipping programs failed. Tried %1
</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Creating KeyFile %1 failed: %2</source>
        <translation>Vytvorenie súboru KeyFile %1 zlyhalo: %2</translation>
    </message>
    <message>
        <source>Loading KeyFile %1 failed: %2</source>
        <translation>Načítanie súboru KeyFile %1 zlyhalo: %2</translation>
    </message>
    <message>
        <source>HIBP file, line %1: parse error</source>
        <translation>Súbor HIBP, riadok %1: chyba spracovania</translation>
    </message>
    <message>
        <source>To use okon, you must provide a post-processed file (e.g. file.okon)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Could not start okon process: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Error: okon process did not finish</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Failed to load okon processed database: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Very weak password</source>
        <translation>Veľmi slabé heslo</translation>
    </message>
    <message>
        <source>Password entropy is %1 bits</source>
        <translation>Náhodnosť hesla je %1 b</translation>
    </message>
    <message>
        <source>Weak password</source>
        <translation>Slabé heslo</translation>
    </message>
    <message>
        <source>Used in %1/%2</source>
        <translation>Použité v %1/%2</translation>
    </message>
    <message numerus="yes">
        <source>Password is used %1 time(s)</source>
        <translation><numerusform>Heslo je použité %1 krát</numerusform><numerusform>Heslo je použité %1 krát</numerusform><numerusform>Heslo je použité %1 krát</numerusform><numerusform>Heslo je použité %1 krát</numerusform></translation>
    </message>
    <message>
        <source>Password has expired</source>
        <translation>Heslo vypršalo</translation>
    </message>
    <message>
        <source>Password expiry was %1</source>
        <translation>Platnosť hesla bola %1</translation>
    </message>
    <message>
        <source>Password expires on %1</source>
        <translation>Platnosť hesla vyprší %1</translation>
    </message>
    <message>
        <source>Password is about to expire</source>
        <translation>Heslo čoskoro vyprší</translation>
    </message>
    <message numerus="yes">
        <source>Password expires in %1 day(s)</source>
        <translation><numerusform>Platnosť hesla vyprší za %1 deň</numerusform><numerusform>Platnosť hesla vyprší za %1 dni</numerusform><numerusform>Platnosť hesla vyprší za %1 dní</numerusform><numerusform>Platnosť hesla vyprší za %1 dňa</numerusform></translation>
    </message>
    <message>
        <source>Password will expire soon</source>
        <translation>Heslo čoskoro vyprší</translation>
    </message>
    <message>
        <source>Version %1</source>
        <translation>Verzia %1</translation>
    </message>
    <message>
        <source>Build Type: %1</source>
        <translation>Typ zostavenia: %1</translation>
    </message>
    <message>
        <source>Revision: %1</source>
        <translation>Revízia %1</translation>
    </message>
    <message>
        <source>Distribution: %1</source>
        <translation>Distribúcia %1</translation>
    </message>
    <message>
        <source>Debugging mode is disabled.</source>
        <translation>Režim ladenia je vypnutý.</translation>
    </message>
    <message>
        <source>Debugging mode is enabled.</source>
        <translation>Režim ladenia je zapnutý.</translation>
    </message>
    <message>
        <source>Operating system: %1
CPU architecture: %2
Kernel: %3 %4</source>
        <translation>Operačný systém: %1
Architektúra CPU: %2
Jadro: %3 %4</translation>
    </message>
    <message>
        <source>Auto-Type</source>
        <translation>Automatické vypĺňanie</translation>
    </message>
    <message>
        <source>SSH Agent</source>
        <translation>Agent SSH</translation>
    </message>
    <message>
        <source>KeeShare</source>
        <translation>KeeShare</translation>
    </message>
    <message>
        <source>Quick Unlock</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Secret Service Integration</source>
        <translation>Integrácia Tajnej služby</translation>
    </message>
    <message>
        <source>Enabled extensions:</source>
        <translation>Zapnuté rozšírenia:</translation>
    </message>
    <message numerus="yes">
        <source>over %1 year(s)</source>
        <translation type="unfinished"><numerusform></numerusform><numerusform></numerusform><numerusform></numerusform><numerusform></numerusform></translation>
    </message>
    <message numerus="yes">
        <source>about %1 month(s)</source>
        <translation type="unfinished"><numerusform></numerusform><numerusform></numerusform><numerusform></numerusform><numerusform></numerusform></translation>
    </message>
    <message numerus="yes">
        <source>%1 week(s)</source>
        <translation type="unfinished"><numerusform></numerusform><numerusform></numerusform><numerusform></numerusform><numerusform></numerusform></translation>
    </message>
    <message numerus="yes">
        <source>%1 day(s)</source>
        <translation type="unfinished"><numerusform></numerusform><numerusform></numerusform><numerusform></numerusform><numerusform></numerusform></translation>
    </message>
    <message numerus="yes">
        <source>%1 hour(s)</source>
        <translation type="unfinished"><numerusform></numerusform><numerusform></numerusform><numerusform></numerusform><numerusform></numerusform></translation>
    </message>
    <message numerus="yes">
        <source>%1 minute(s)</source>
        <translation type="unfinished"><numerusform></numerusform><numerusform></numerusform><numerusform></numerusform><numerusform></numerusform></translation>
    </message>
    <message>
        <source>Botan library must be at least %1, found %2.%3.%4</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Cryptographic libraries:</source>
        <translation>Kryptografické knižnice:</translation>
    </message>
    <message>
        <source>AES (%1 rounds)</source>
        <translation>AES (%1 opakovaní)</translation>
    </message>
    <message>
        <source>Argon2%1 (%2 rounds, %3 KB)</source>
        <translation>Argon2%1 (%2 opakovaní, %3 kB)</translation>
    </message>
    <message>
        <source>SymmetricCipher::init: Invalid cipher mode.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>SymmetricCipher::init: Invalid IV size of %1 for %2.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Cipher not initialized prior to use.</source>
        <translation>Šifra nebola pred použitím inicializovaná.</translation>
    </message>
    <message>
        <source>Cannot process 0 length data.</source>
        <translation>Nemožno spracovať dáta s 0 dĺžkou.</translation>
    </message>
    <message>
        <source>unknown executable (DBus address %1)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>%1 (invalid executable path)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>NULL device</source>
        <translation>Žiadne zariadenie</translation>
    </message>
    <message>
        <source>error reading from device</source>
        <translation>chyba čítania zo zariadenia</translation>
    </message>
    <message>
        <source>file empty</source>
        <translation>prázdny súbor</translation>
    </message>
    <message>
        <source>AES 256-bit</source>
        <translation>AES 256b</translation>
    </message>
    <message>
        <source>Twofish 256-bit</source>
        <translation>Twofish 256b</translation>
    </message>
    <message>
        <source>ChaCha20 256-bit</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Argon2d (KDBX 4 – recommended)</source>
        <translation>Argon2d (KDBX 4 – odporúčané)</translation>
    </message>
    <message>
        <source>Argon2id (KDBX 4)</source>
        <translation>Argon2id (KDBX 4)</translation>
    </message>
    <message>
        <source>AES-KDF (KDBX 4)</source>
        <translation>AES-KDF (KDBX 4)</translation>
    </message>
    <message>
        <source>AES-KDF (KDBX 3)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Existing single-instance lock file is invalid. Launching new instance.</source>
        <translation>Existujúci súbor zámku jednej inštancie nie je platný. Spúšťam novú inštanciu.</translation>
    </message>
    <message>
        <source>The lock file could not be created. Single-instance mode disabled.</source>
        <translation>Súbor zámku nemožno vytvoriť. Režim jednej inštancie vypnutý.</translation>
    </message>
    <message numerus="yes">
        <source>Clearing the clipboard in %1 second(s)…</source>
        <translation><numerusform>Schránka bude vymazaná za %1 s</numerusform><numerusform>Schránka bude vymazaná za %1 s</numerusform><numerusform>Schránka bude vymazaná za %1 s</numerusform><numerusform>Schránka bude vymazaná za %1 s</numerusform></translation>
    </message>
    <message>
        <source>Group</source>
        <translation>Skupina</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>Nadpis</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>Používateľské meno</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Heslo</translation>
    </message>
    <message>
        <source>TOTP</source>
        <translation>TOTP</translation>
    </message>
    <message>
        <source>Icon</source>
        <translation>Ikona</translation>
    </message>
    <message>
        <source>Last Modified</source>
        <translation>Posledná úprava</translation>
    </message>
    <message>
        <source>Created</source>
        <translation>Vytvorené</translation>
    </message>
    <message>
        <source>Benchmark %1 delay</source>
        <translation>Meranie výkonu %1 oneskorenie</translation>
    </message>
    <message numerus="yes">
        <source>%1 ms</source>
        <comment>milliseconds</comment>
        <translation><numerusform>%1 ms</numerusform><numerusform>%1 ms</numerusform><numerusform>%1 ms</numerusform><numerusform>%1 ms</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>%1 s</source>
        <comment>seconds</comment>
        <translation><numerusform>%1 s</numerusform><numerusform>%1 s</numerusform><numerusform>%1 s</numerusform><numerusform>%1 s</numerusform></translation>
    </message>
    <message>
        <source>Do you really want to move entry &quot;%1&quot; to the recycle bin?</source>
        <translation>Naozaj chcete presunúť položku „%1” do koša?</translation>
    </message>
    <message numerus="yes">
        <source>Do you really want to move %n entry(s) to the recycle bin?</source>
        <translation type="unfinished"><numerusform></numerusform><numerusform></numerusform><numerusform></numerusform><numerusform></numerusform></translation>
    </message>
    <message numerus="yes">
        <source>Entry &quot;%1&quot; has %2 reference(s). Do you want to overwrite references with values, skip this entry, or delete anyway?</source>
        <translation type="unfinished"><numerusform></numerusform><numerusform></numerusform><numerusform></numerusform><numerusform></numerusform></translation>
    </message>
    <message>
        <source>User name</source>
        <translation>Meno používavteľa</translation>
    </message>
    <message>
        <source>Browser Statistics</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Health Check</source>
        <translation>Kontrola zdravia</translation>
    </message>
    <message>
        <source>HIBP</source>
        <translation>HIBP</translation>
    </message>
    <message>
        <source>Statistics</source>
        <translation>Štatistiky</translation>
    </message>
    <message>
        <source>Unsupported key file version: %1</source>
        <translation>Nepodporovaná verzia súboru kľúča: %1</translation>
    </message>
    <message>
        <source>Checksum mismatch! Key file may be corrupt.</source>
        <translation>Kontrolný súčet sa nezhoduje! Súbor kľúča môže byť poškodený.</translation>
    </message>
    <message>
        <source>Unexpected key file data! Key file may be corrupt.</source>
        <translation>Neočakávané dáta súboru kľúča! Súbor kľúča môže byť poškodený.</translation>
    </message>
    <message>
        <source>KeePassXC - cross-platform password manager</source>
        <translation>KeePassXC – multi-platformový správca hesiel</translation>
    </message>
    <message>
        <source>filenames of the password databases to open (*.kdbx)</source>
        <translation>mená súborov databáz hesiel na otvorenie (*.kdbx)</translation>
    </message>
    <message>
        <source>path to a custom config file</source>
        <translation>cesta k vlastnému konfiguračnému súboru</translation>
    </message>
    <message>
        <source>path to a custom local config file</source>
        <translation>cesta k vlastnému konfiguračnému súboru</translation>
    </message>
    <message>
        <source>lock all open databases</source>
        <translation>zamknúť všetky otvorené databázy</translation>
    </message>
    <message>
        <source>key file of the database</source>
        <translation>súbor kľúča databázy</translation>
    </message>
    <message>
        <source>read password of the database from stdin</source>
        <translation>čítať heslo databázy zo stdin</translation>
    </message>
    <message>
        <source>Database failed to lock.</source>
        <translation>Zamknutie databázy zlyhalo.</translation>
    </message>
    <message>
        <source>Another instance of KeePassXC is already running.</source>
        <translation>Už je spustená iná inštancia KeePassXC.</translation>
    </message>
    <message>
        <source>KeePassXC is not running. No open database to lock</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Fatal error while testing the cryptographic functions.</source>
        <translation>Fatálna chyba pri testovaní kryptografických funkcií.</translation>
    </message>
    <message>
        <source>KeePassXC - Error</source>
        <translation>KeePassXC – Chyba</translation>
    </message>
    <message>
        <source>Database password: </source>
        <translation>Heslo databázy:</translation>
    </message>
    <message>
        <source>Invalid Settings</source>
        <comment>TOTP</comment>
        <translation>Neplatné nastavenia</translation>
    </message>
    <message>
        <source>Invalid Key</source>
        <comment>TOTP</comment>
        <translation>Neplatný kľúč</translation>
    </message>
    <message>
        <source>Failed to create Windows Hello credential.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Failed to sign challenge using Windows Hello.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Warning: Failed to block screenshot capture on a top-level window.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Invalid Cipher</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Invalid KDF</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Access to all entries is denied</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>allow screenshots and app recording (Windows/macOS)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Set the key file for the database.
This option is deprecated, use --set-key-file instead.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Databases have been locked.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Attestation not supported</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Credential is excluded</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Passkeys request canceled</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Invalid user verification</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Empty public key</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Invalid URL provided</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Passkeys</source>
        <translation>Prístupové kľúče</translation>
    </message>
    <message>
        <source>AES initialization failed</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>AES encrypt failed</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Failed to store in Linux Keyring</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Polkit returned an error: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Could not locate key in keyring</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Could not read key in keyring</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>AES decrypt failed</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>No Polkit authentication agent was available</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Polkit authorization failed</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>No Quick Unlock provider is available</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Failed to init KeePassXC crypto.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Failed to encrypt key data.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Failed to get Windows Hello credential.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Failed to decrypt key data.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Origin is empty or not allowed</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Effective domain is not a valid domain</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Origin and RP ID do not match</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>No supported algorithms were provided</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Wait for timer to expire</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Challenge is shorter than required minimum length</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>user.id does not match the required length</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Favorite</source>
        <comment>Tag for favorite entries</comment>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>File does not exist.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Cannot open file: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Cannot parse file: %1 at position %2</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Failed to decrypt json file: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Invalid encKeyValidation field</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Invalid cipher list within encKeyValidation field</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Wrong password</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Invalid encrypted data field</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Invalid cipher list within encrypted data field</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Cannot initialize cipher</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Cannot decrypt data</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Bitwarden Import</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Archived</source>
        <comment>Tag for archived entries</comment>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Invalid 1PUX file format: Not a valid ZIP file.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Invalid 1PUX file format: Missing export.data</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>1Password Import</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Enter Shortcut</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Action</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Shortcuts</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Unknown passkeys error</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Invalid KDF iterations, cannot decrypt json file</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Unsupported format, ensure your Bitwarden export is password-protected</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Only PBKDF and Argon2 are supported, cannot decrypt json file</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Hardware Keys</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Passkey</source>
        <translation>Prístupový kľúč</translation>
    </message>
    <message>
        <source>Reset Shortcuts</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Double click an action to change its shortcut</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Filter...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Shortcut Conflict</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Shortcut %1 conflicts with &apos;%2&apos;. Overwrite shortcut?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Format to use when exporting. Available choices are &apos;xml&apos;, &apos;csv&apos; or &apos;html&apos;. Defaults to &apos;xml&apos;.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>malformed string, possible unescaped delimiter</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>missing closing delimiter</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>%1, row: %2, column: %3</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Encrypted files are not supported.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Proton Pass Import</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Tags</source>
        <translation>Štítky</translation>
    </message>
    <message>
        <source>start minimized to the system tray</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Warning: the chosen wordlist is smaller than the minimum recommended size!</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Invalid Step</source>
        <comment>TOTP</comment>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Invalid Digits</source>
        <comment>TOTP</comment>
        <translation type="unfinished"/>
    </message>
    <message numerus="yes">
        <source>%1 character(s)</source>
        <translation type="unfinished"><numerusform></numerusform><numerusform></numerusform><numerusform></numerusform><numerusform></numerusform></translation>
    </message>
    <message>
        <source>Do you really want to permanently delete the entry &quot;%1&quot;?</source>
        <translation type="unfinished"/>
    </message>
    <message numerus="yes">
        <source>Do you really want to permanently delete %n entry(s)?</source>
        <translation type="unfinished"><numerusform></numerusform><numerusform></numerusform><numerusform></numerusform><numerusform></numerusform></translation>
    </message>
    <message numerus="yes">
        <source>Confirm Delete Entry(s)</source>
        <translation type="unfinished"><numerusform></numerusform><numerusform></numerusform><numerusform></numerusform><numerusform></numerusform></translation>
    </message>
    <message numerus="yes">
        <source>Confirm Recycle Entry(s)</source>
        <translation type="unfinished"><numerusform></numerusform><numerusform></numerusform><numerusform></numerusform><numerusform></numerusform></translation>
    </message>
    <message>
        <source>Confirm Delete Plugin Data</source>
        <translation type="unfinished"/>
    </message>
    <message numerus="yes">
        <source>Delete plugin data from the selected entry(s)?</source>
        <translation type="unfinished"><numerusform></numerusform><numerusform></numerusform><numerusform></numerusform><numerusform></numerusform></translation>
    </message>
    <message>
        <source>Confirm Replace Entry References</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>QtIOCompressor</name>
    <message>
        <source>Internal zlib error when compressing: </source>
        <translation>Pri komprimácii sa vyskytla interná chyba zlib:</translation>
    </message>
    <message>
        <source>Error writing to underlying device: </source>
        <translation>Chyba zápisu na zariadenie:</translation>
    </message>
    <message>
        <source>Error opening underlying device: </source>
        <translation>Chyba otvorenia zariadenia:</translation>
    </message>
    <message>
        <source>Error reading data from underlying device: </source>
        <translation>Chyba čítania dát zo zariadenia:</translation>
    </message>
    <message>
        <source>Internal zlib error when decompressing: </source>
        <translation>Pri dekomprimácii sa vyskytla interná chyba zlib:</translation>
    </message>
</context>
<context>
    <name>QtIOCompressor::open</name>
    <message>
        <source>The gzip format not supported in this version of zlib.</source>
        <translation>Formát gzip nie je touto verziou zlib podporovaný.</translation>
    </message>
    <message>
        <source>Internal zlib error: </source>
        <translation>Interná chyba zlib:</translation>
    </message>
</context>
<context>
    <name>RemoteDesktopPortal</name>
    <message>
        <source>Remote desktop session is not active</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Session closed</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>User cancelled the interaction</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>User interaction was canceled for unknown reason</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Remote desktop session handle does not match expected path</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>RemoteHandler</name>
    <message>
        <source>Command `%1` did not finish in time. Process was killed.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Failed to upload merged database. Command `%1` did not finish in time. Process was killed.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Invalid download parameters provided.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Command `%1` failed to download database.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Invalid database pointer or upload parameters provided.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Command `%1` exited with status code: %2</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Failed to upload merged database. Command `%1` exited with status code: %2</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>ReportsWidgetBrowserStatistics</name>
    <message>
        <source>Double-click entries to edit.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>List of entry URLs</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Entry has no URLs set</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Allowed URLs</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Entry has no Browser Integration settings</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Denied URLs</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source> (Excluded)</source>
        <translation> (Vylúčené)</translation>
    </message>
    <message>
        <source>This entry is being excluded from reports</source>
        <translation>Táto položka je vylúčená z hlásení</translation>
    </message>
    <message>
        <source>Please wait, browser statistics is being calculated…</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>No entries with a URL, or none has browser extension settings saved.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Title</source>
        <translation>Nadpis</translation>
    </message>
    <message>
        <source>Path</source>
        <translation>Cesta</translation>
    </message>
    <message>
        <source>URLs</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Edit Entry…</source>
        <translation>Upraviť položku…</translation>
    </message>
    <message numerus="yes">
        <source>Delete Entry(s)…</source>
        <translation type="unfinished"><numerusform></numerusform><numerusform></numerusform><numerusform></numerusform><numerusform>Odstrániť položky…</numerusform></translation>
    </message>
    <message>
        <source>Exclude from reports</source>
        <translation>Vylúčiť z hlásení</translation>
    </message>
    <message numerus="yes">
        <source>Expire Entry(s)…</source>
        <translation type="unfinished"><numerusform></numerusform><numerusform></numerusform><numerusform></numerusform><numerusform></numerusform></translation>
    </message>
    <message>
        <source>Only show entries that have a URL</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Only show entries that have been explicitly allowed or denied</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Show expired entries</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source> (Expired)</source>
        <translation type="unfinished"/>
    </message>
    <message numerus="yes">
        <source>Delete plugin data from Entry(s)…</source>
        <translation type="unfinished"><numerusform></numerusform><numerusform></numerusform><numerusform></numerusform><numerusform></numerusform></translation>
    </message>
</context>
<context>
    <name>ReportsWidgetHealthcheck</name>
    <message>
        <source>Show expired entries</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source> (Expired)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Hover over reason to show additional details. Double-click entries to edit.</source>
        <translation>Prejdite myšou na príčinou, na zobrazenie dodatočných podrobností. Dvojklikom na položku ju upravíte.</translation>
    </message>
    <message>
        <source>Bad — password must be changed</source>
        <translation>Zlé — heslo treba zmeniť</translation>
    </message>
    <message>
        <source>Poor — password should be changed</source>
        <translation>Biedne — heslo by ste mali zmeniť</translation>
    </message>
    <message>
        <source>Weak — consider changing the password</source>
        <translation>Slabé — zvážte zmenu hesla</translation>
    </message>
    <message>
        <source> (Excluded)</source>
        <translation> (Vylúčené)</translation>
    </message>
    <message>
        <source>This entry is being excluded from reports</source>
        <translation>Táto položka je vylúčená z hlásení</translation>
    </message>
    <message>
        <source>Please wait, health data is being calculated…</source>
        <translation>Prosím počkajte, počítanie dát zdravia…</translation>
    </message>
    <message>
        <source>Congratulations, everything is healthy!</source>
        <translation>Blahoželáme, všetko je v poriadku!</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>Nadpis</translation>
    </message>
    <message>
        <source>Path</source>
        <translation>Cesta</translation>
    </message>
    <message>
        <source>Score</source>
        <translation>Skóre</translation>
    </message>
    <message>
        <source>Reason</source>
        <translation>Dôvod</translation>
    </message>
    <message>
        <source>Edit Entry…</source>
        <translation>Upraviť položku…</translation>
    </message>
    <message numerus="yes">
        <source>Delete Entry(s)…</source>
        <translation><numerusform>Odstrániť položku…</numerusform><numerusform>Odstrániť položky…</numerusform><numerusform>Odstrániť položky…</numerusform><numerusform>Odstrániť položky…</numerusform></translation>
    </message>
    <message>
        <source>Exclude from reports</source>
        <translation>Vylúčiť z hlásení</translation>
    </message>
    <message numerus="yes">
        <source>Expire Entry(s)…</source>
        <translation type="unfinished"><numerusform></numerusform><numerusform></numerusform><numerusform></numerusform><numerusform></numerusform></translation>
    </message>
    <message>
        <source>Show entries that have been excluded from reports</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>ReportsWidgetHibp</name>
    <message>
        <source>CAUTION: This report requires sending information to the Have I Been Pwned online service (https://haveibeenpwned.com). If you proceed, your database passwords will be cryptographically hashed and the first five characters of those hashes will be sent securely to this service. Your database remains secure and cannot be reconstituted from this information. However, the number of passwords you send and your IP address will be exposed to this service.</source>
        <translation>VÝSTRAHA: Toto hlásenie vyžaduje odoslanie informácií do online služby Have I Been Pwned (https://haveibeenpwned.com). Ak budete pokračovať, z databáza Vašich hesiel budú urobené kryptografické odtlačky a prvých päť znakov týchto odtlačkov bude zabezpečene poslaných do tejto služby. Vaša databáza ostane bezpečná a nebude možné ju z týchto informácií spätne zostaviť. Ale službe bude známy počet odoslaných hesiel a vaša adresa IP.</translation>
    </message>
    <message>
        <source>Perform Online Analysis</source>
        <translation>Vykonať online analýzu</translation>
    </message>
    <message>
        <source>Also show entries that have been excluded from reports</source>
        <translation>Zobraziť aj položky vylúčené z hlásení</translation>
    </message>
    <message>
        <source>This build of KeePassXC does not have network functions. Networking is required to check your passwords against Have I Been Pwned databases.</source>
        <translation>Toto zostavenie KeePassXC nemá sieťové funkcie. Sieť je potrebná na overenie vašich hesiel pomocou databáz Have I Been Pwned.</translation>
    </message>
    <message>
        <source>Congratulations, no exposed passwords!</source>
        <translation>Blahoželáme, žiadne uniknuté heslá!</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>Nadpis</translation>
    </message>
    <message>
        <source>Path</source>
        <translation>Cesta</translation>
    </message>
    <message>
        <source>Password exposed…</source>
        <translation>Heslo uniknuté…</translation>
    </message>
    <message>
        <source> (Excluded)</source>
        <translation> (Vylúčené)</translation>
    </message>
    <message>
        <source>This entry is being excluded from reports</source>
        <translation>Táto položka je vylúčená z hlásení</translation>
    </message>
    <message>
        <source>once</source>
        <comment>Password exposure amount</comment>
        <translation>raz</translation>
    </message>
    <message>
        <source>up to 10 times</source>
        <comment>Password exposure amount</comment>
        <translation>až 10 krát</translation>
    </message>
    <message>
        <source>up to 100 times</source>
        <comment>Password exposure amount</comment>
        <translation>až 100 krát</translation>
    </message>
    <message>
        <source>up to 1000 times</source>
        <comment>Password exposure amount</comment>
        <translation>až 1 000 krát</translation>
    </message>
    <message>
        <source>up to 10,000 times</source>
        <comment>Password exposure amount</comment>
        <translation>až 10 000 krát</translation>
    </message>
    <message>
        <source>up to 100,000 times</source>
        <comment>Password exposure amount</comment>
        <translation>až 100 000 krát</translation>
    </message>
    <message>
        <source>up to a million times</source>
        <comment>Password exposure amount</comment>
        <translation>až milión krát</translation>
    </message>
    <message>
        <source>millions of times</source>
        <comment>Password exposure amount</comment>
        <translation>milión krát</translation>
    </message>
    <message>
        <source>Edit Entry…</source>
        <translation>Upraviť položku…</translation>
    </message>
    <message numerus="yes">
        <source>Delete Entry(s)…</source>
        <translation><numerusform>Odstrániť položku…</numerusform><numerusform>Odstrániť položky…</numerusform><numerusform>Odstrániť položky…</numerusform><numerusform>Odstrániť položky…</numerusform></translation>
    </message>
    <message>
        <source>Exclude from reports</source>
        <translation>Vylúčiť z hlásení</translation>
    </message>
    <message numerus="yes">
        <source>Expire Entry(s)…</source>
        <translation type="unfinished"><numerusform></numerusform><numerusform></numerusform><numerusform></numerusform><numerusform></numerusform></translation>
    </message>
</context>
<context>
    <name>ReportsWidgetPasskeys</name>
    <message>
        <source>Export</source>
        <translation>Export</translation>
    </message>
    <message>
        <source>Import</source>
        <translation>Importovať</translation>
    </message>
    <message>
        <source>List of entry URLs</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Title</source>
        <translation>Nadpis</translation>
    </message>
    <message>
        <source>Path</source>
        <translation>Cesta</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>Používateľské meno</translation>
    </message>
    <message>
        <source>URLs</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Edit Entry…</source>
        <translation>Upraviť položku…</translation>
    </message>
    <message numerus="yes">
        <source>Delete Entry(s)…</source>
        <translation><numerusform>Odstrániť položku…</numerusform><numerusform>Odstrániť položky…</numerusform><numerusform>Odstrániť položky…</numerusform><numerusform>Odstrániť položky…</numerusform></translation>
    </message>
    <message>
        <source>Relying Party</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Show expired entries</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source> (Expired)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Export Confirmation</source>
        <translation>Potvrdenie exportu</translation>
    </message>
    <message>
        <source>The passkey file will be vulnerable to theft and unauthorized use, if left unsecured. Are you sure you want to continue?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Please wait, list of entries with passkeys is being updated…</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>No entries with passkeys.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>ReportsWidgetStatistics</name>
    <message>
        <source>Hover over lines with error icons for further information.</source>
        <translation>Pre ďalšie informácie umiestnite kurzor myši na riadky s ikonami chýb.</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Názov</translation>
    </message>
    <message>
        <source>Value</source>
        <translation>Hodnota</translation>
    </message>
    <message>
        <source>Please wait, database statistics are being calculated…</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Database name</source>
        <translation>Názov databázy</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Popis</translation>
    </message>
    <message>
        <source>Location</source>
        <translation>Umiestnenie</translation>
    </message>
    <message>
        <source>Database created</source>
        <translation>Databáza vytvorená</translation>
    </message>
    <message>
        <source>Last saved</source>
        <translation>Naposledy uložené</translation>
    </message>
    <message>
        <source>Unsaved changes</source>
        <translation>Neuložené zmeny</translation>
    </message>
    <message>
        <source>yes</source>
        <translation>áno</translation>
    </message>
    <message>
        <source>no</source>
        <translation>nie</translation>
    </message>
    <message>
        <source>The database was modified, but the changes have not yet been saved to disk.</source>
        <translation>Databáza bola zmenená, ale zmeny ešte neboli uložené na disk.</translation>
    </message>
    <message>
        <source>Number of groups</source>
        <translation>Počet skupín</translation>
    </message>
    <message>
        <source>Number of entries</source>
        <translation>Počet položiek</translation>
    </message>
    <message>
        <source>Number of expired entries</source>
        <translation>Počet položiek po dobe platnosti</translation>
    </message>
    <message>
        <source>The database contains entries that have expired.</source>
        <translation>Databáza obsahuje položky ktoré expirovali.</translation>
    </message>
    <message>
        <source>Unique passwords</source>
        <translation>Jedinečné heslá</translation>
    </message>
    <message>
        <source>Non-unique passwords</source>
        <translation>Nie jedinečné heslá</translation>
    </message>
    <message>
        <source>More than 10% of passwords are reused. Use unique passwords when possible.</source>
        <translation>Viac ako 10 % hesiel je použitých opakovanie. Použite jedinečné heslá, vždy keď je to možné.</translation>
    </message>
    <message>
        <source>Maximum password reuse</source>
        <translation>Maximálny počet opakovane použitých hesiel</translation>
    </message>
    <message>
        <source>Some passwords are used more than three times. Use unique passwords when possible.</source>
        <translation>Niektoré heslá sú použité viac tri krát. Použite jedinečné heslá, vždy keď je to možné.</translation>
    </message>
    <message>
        <source>Number of short passwords</source>
        <translation>Počet krátkych hesiel</translation>
    </message>
    <message>
        <source>Recommended minimum password length is at least 8 characters.</source>
        <translation>Odporúčaná minimálna dĺžka hesla je aspoň 8 znakov.</translation>
    </message>
    <message>
        <source>Number of weak passwords</source>
        <translation>Počet slabých hesiel</translation>
    </message>
    <message>
        <source>Recommend using long, randomized passwords with a rating of &apos;good&apos; or &apos;excellent&apos;.</source>
        <translation>Odporúčame použiť dlhé, náhodné heslá s hodnotením „dobré” alebo „výborné” good&apos; or &apos;excellent&apos;.</translation>
    </message>
    <message>
        <source>Entries excluded from reports</source>
        <translation>Položky vylúčené z hlásení</translation>
    </message>
    <message>
        <source>Excluding entries from reports, e. g. because they are known to have a poor password, isn&apos;t necessarily a problem but you should keep an eye on them.</source>
        <translation>Vylúčenie položiek z hlásení, napr.  pretože je známe ich slabé heslo, zvyčajne nemusí byť problém, ale mali by ste sa na to dávať pozor.</translation>
    </message>
    <message>
        <source>Average password length</source>
        <translation>Priemerná dĺžka hesla</translation>
    </message>
    <message>
        <source>Average password length is less than ten characters. Longer passwords provide more security.</source>
        <translation>Priemerná dĺžka hesla je menšia ako desať znakov. Dlhšie heslá poskytujú vyššiu bezpečnosť.</translation>
    </message>
    <message>
        <source>Number of passkeys</source>
        <translation>Počet prístupových kľúčov</translation>
    </message>
    <message>
        <source>Entries with TOTP setup</source>
        <translation type="unfinished"/>
    </message>
    <message numerus="yes">
        <source>%1 character(s)</source>
        <translation type="unfinished"><numerusform></numerusform><numerusform></numerusform><numerusform></numerusform><numerusform></numerusform></translation>
    </message>
</context>
<context>
    <name>SSHAgent</name>
    <message>
        <source>Agent connection failed.</source>
        <translation>Spojenie agenta zlyhalo.</translation>
    </message>
    <message>
        <source>Agent protocol error.</source>
        <translation>Chyba protokolu agenta.</translation>
    </message>
    <message>
        <source>No agent running, cannot add identity.</source>
        <translation>Nie je spustený žiadny agent, nemožno identifikovať.</translation>
    </message>
    <message>
        <source>Key identity ownership conflict. Refusing to add.</source>
        <translation>Konflikt identity vlastníctva kľúča. Odmietnuté pridať.</translation>
    </message>
    <message>
        <source>Agent refused this identity. Possible reasons include:</source>
        <translation>Agent odmietol túto identitu. Možné príčiny:</translation>
    </message>
    <message>
        <source>The key has already been added.</source>
        <translation>Kľúč už bol pridaný.</translation>
    </message>
    <message>
        <source>Restricted lifetime is not supported by the agent (check options).</source>
        <translation>Obmedzená doba platnosti nie je agentom podporovaná (skontrolujte voľby)</translation>
    </message>
    <message>
        <source>A confirmation request is not supported by the agent (check options).</source>
        <translation>Potrvrdzovací požiadavok nie je podporovaný (skontrolujte voľby).</translation>
    </message>
    <message>
        <source>Security keys are not supported by the agent or the security key provider is unavailable.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>No agent running, cannot remove identity.</source>
        <translation>Nie je spustený žiadny agent, nemožno odstrániť identitu.</translation>
    </message>
    <message>
        <source>No agent running, cannot list identities.</source>
        <translation>Nie je spustený agent, nemožno získať zoznam identít.</translation>
    </message>
    <message>
        <source>Failed to remove all SSH identities from agent.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>All SSH identities removed from agent.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>SearchHelpWidget</name>
    <message>
        <source>Search Help</source>
        <translation>Hľadať v pomocníkovi</translation>
    </message>
    <message>
        <source>Search terms are as follows: [modifiers][field:][&quot;]term[&quot;]</source>
        <translation>Hľadané výrazy sú nasledovné: [modifikátory] [pole:] [&quot;] výraz [&quot;]</translation>
    </message>
    <message>
        <source>Every search term must match (ie, logical AND)</source>
        <translation>Každý hľadaný výraz sa musí zhodovať (tj. platí logické AND)</translation>
    </message>
    <message>
        <source>Modifiers</source>
        <translation>Modifikátory</translation>
    </message>
    <message>
        <source>exclude term from results</source>
        <translation>vylúčiť hľadaný výraz z výsledkov</translation>
    </message>
    <message>
        <source>match term exactly</source>
        <translation>presná zhoda výrazu</translation>
    </message>
    <message>
        <source>use regex in term</source>
        <translation>použiť regex vo výraze</translation>
    </message>
    <message>
        <source>Fields</source>
        <translation>Polia</translation>
    </message>
    <message>
        <source>Term Wildcards</source>
        <translation>zástupné znaky (wildcards) vo výraze</translation>
    </message>
    <message>
        <source>match anything</source>
        <translation>zhoda s ktorýmkoľvek z výrazov</translation>
    </message>
    <message>
        <source>match one</source>
        <translation>zhoda s jedným z výrazov</translation>
    </message>
    <message>
        <source>logical OR</source>
        <translation>logické OR (alebo)</translation>
    </message>
    <message>
        <source>Examples</source>
        <translation>Príklady</translation>
    </message>
</context>
<context>
    <name>SearchWidget</name>
    <message>
        <source>Search</source>
        <translation>Hľadať</translation>
    </message>
    <message>
        <source>Search Help</source>
        <translation>Hľadať v pomocníkovi</translation>
    </message>
    <message>
        <source>Save Search</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Search (%1)…</source>
        <comment>Search placeholder text, %1 is the keyboard shortcut</comment>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Case sensitive</source>
        <translation>Rozlišovať veľkosť písmen</translation>
    </message>
    <message>
        <source>Limit search to selected group</source>
        <translation>Obmedziť hľadanie na zvolenú skupinu</translation>
    </message>
    <message>
        <source>Press Enter to search</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>SettingsClientModel</name>
    <message>
        <source>Application</source>
        <translation>Aplikácia</translation>
    </message>
    <message>
        <source>PID</source>
        <translation>PID</translation>
    </message>
    <message>
        <source>DBus Address</source>
        <translation>Adresa DBus</translation>
    </message>
    <message>
        <source>Manage</source>
        <translation>Spravovať</translation>
    </message>
</context>
<context>
    <name>SettingsDatabaseModel</name>
    <message>
        <source>File Name</source>
        <translation>Meno súboru</translation>
    </message>
    <message>
        <source>Group</source>
        <translation>Skupina</translation>
    </message>
    <message>
        <source>Manage</source>
        <translation>Spravovať</translation>
    </message>
</context>
<context>
    <name>SettingsWidgetFdoSecrets</name>
    <message>
        <source>Options</source>
        <translation>Voľby</translation>
    </message>
    <message>
        <source>Enable KeepassXC Freedesktop.org Secret Service integration</source>
        <translation>Zapne Integráciu KeepassXC Freedesktop.org Secret Service</translation>
    </message>
    <message>
        <source>General</source>
        <translation>Všeobecné</translation>
    </message>
    <message>
        <source>Show notification when passwords are retrieved by clients</source>
        <translation>Zobraziť upozornenie, keď klienty získajú heslá</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;If enabled, any attempt to read a password must be confirmed. Otherwise, clients can read passwords without confirmation when the database is unlocked.&lt;/p&gt;&lt;p&gt;This option only covers the access to the password of an entry. Clients can always enumerate the items of exposed databases and query their attributes.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Confirm when passwords are retrieved by clients</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Confirm when clients request entry deletion</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Prompt to unlock database before searching</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Exposed database groups:</source>
        <translation>Zverejnené skupiny databázy:</translation>
    </message>
    <message>
        <source>Authorization</source>
        <translation>Autorizácia</translation>
    </message>
    <message>
        <source>These applications are currently connected:</source>
        <translation>Aktuálne pripojené aplikácie:</translation>
    </message>
    <message>
        <source>&lt;b&gt;Warning:&lt;/b&gt; </source>
        <translation>&lt;b&gt;Upozornenie:&lt;/b&gt; </translation>
    </message>
    <message>
        <source>Save current changes to activate the plugin and enable editing of this section.</source>
        <translation>Uložte aktuálne zmeny na aktiváciu zásuvného modulu a zapnutie úpravy tejto sekcie.</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;This setting does not override disabling recycle bin prompts &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;This improves compatibility with certain applications which search for password without unlocking the database first.&lt;/p&gt;&lt;p&gt;But enabling this may also crash the client if the database can not be unlocked within a certain timeout. (Usually 25s, but may be a different value set in applications.) &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>SettingsWidgetKeeShare</name>
    <message>
        <source>Active</source>
        <translation>Aktívne</translation>
    </message>
    <message>
        <source>Allow KeeShare imports</source>
        <translation>Povoliť importy KeeShare</translation>
    </message>
    <message>
        <source>Allow import</source>
        <translation>Povoliť import</translation>
    </message>
    <message>
        <source>Allow KeeShare exports</source>
        <translation>Povoliť exporty KeeShare</translation>
    </message>
    <message>
        <source>Allow export</source>
        <translation>Povoliť export</translation>
    </message>
    <message>
        <source>Only show warnings and errors</source>
        <translation>Zobraziť len upozornenia a chyby</translation>
    </message>
    <message>
        <source>Own certificate</source>
        <translation>Vlastný certifikát</translation>
    </message>
    <message>
        <source>Signer:</source>
        <translation>Podpísaný:</translation>
    </message>
    <message>
        <source>Generate new certificate</source>
        <translation>Generovať nový certifikát</translation>
    </message>
    <message>
        <source>Generate</source>
        <translation>Generovať</translation>
    </message>
    <message>
        <source>Fingerprint:</source>
        <translation>Odtlačok:</translation>
    </message>
    <message>
        <source>Signer name field</source>
        <translation>Pole mena podpisovaného</translation>
    </message>
    <message>
        <source>Fingerprint</source>
        <translation>Odtlačok</translation>
    </message>
</context>
<context>
    <name>ShareExport</name>
    <message>
        <source>Could not write export container.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>ShareImport</name>
    <message>
        <source>Successful import</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>ShareObserver</name>
    <message>
        <source>Import from %1 failed (%2)</source>
        <translation>Import z %1 zlyhal (%2)</translation>
    </message>
    <message>
        <source>Import from %1 successful (%2)</source>
        <translation>Import z %1 úspešný (%2)</translation>
    </message>
    <message>
        <source>Imported from %1</source>
        <translation>Importované z %1</translation>
    </message>
    <message>
        <source>Multiple import source path to %1 in %2</source>
        <translation>Viaceré cesty zdroja importu do %1 v %2</translation>
    </message>
    <message>
        <source>Conflicting export target path %1 in %2</source>
        <translation>Konfliktná cieľová cesta exportu %1 v %2</translation>
    </message>
    <message>
        <source>Export to %1 failed (%2)</source>
        <translation>Exportovanie do %1 zlyhalo (%2)</translation>
    </message>
    <message>
        <source>Export to %1 successful (%2)</source>
        <translation>Export do %1 úspešný (%2)</translation>
    </message>
    <message>
        <source>Export to %1</source>
        <translation>Exportovať do %1</translation>
    </message>
</context>
<context>
    <name>TagModel</name>
    <message>
        <source>Clear Search</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>All Entries</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Expired</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Weak Passwords</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>TOTP Entries</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>TagView</name>
    <message>
        <source>Remove Search</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Remove Tag</source>
        <translation>Odstrániť štítok</translation>
    </message>
    <message>
        <source>Confirm Remove Tag</source>
        <translation>Potvrdiť odstránenie štítku</translation>
    </message>
    <message>
        <source>Remove tag &quot;%1&quot; from all entries in this database?</source>
        <translation>Chcete odstrániť štítok „%1“ zo všetkých záznamov v tejto databáze?</translation>
    </message>
</context>
<context>
    <name>TextAttachmentsEditWidget</name>
    <message>
        <source>Preview</source>
        <translation>Ukážka</translation>
    </message>
</context>
<context>
    <name>TextAttachmentsPreviewWidget</name>
    <message>
        <source>Form</source>
        <translation>Formulár</translation>
    </message>
    <message>
        <source>Type:</source>
        <translation>Typ:</translation>
    </message>
</context>
<context>
    <name>TotpDialog</name>
    <message>
        <source>Timed Password</source>
        <translation>Časové heslo</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Kopírovať</translation>
    </message>
    <message numerus="yes">
        <source>Expires in &lt;b&gt;%n&lt;/b&gt; second(s)</source>
        <translation><numerusform>Uplynie v &lt;b&gt;% n&lt;/b&gt; sekunda (s)</numerusform><numerusform>Uplynie v &lt;b&gt;% n&lt;/b&gt; sekunda (s)</numerusform><numerusform>Uplynie v &lt;b&gt;% n&lt;/b&gt; sekunda (s)</numerusform><numerusform>Expiruje za &lt;b&gt;% n&lt;/b&gt; sekúnd</numerusform></translation>
    </message>
</context>
<context>
    <name>TotpExportSettingsDialog</name>
    <message>
        <source>Copy</source>
        <translation>Kopírovať</translation>
    </message>
    <message>
        <source>NOTE: These TOTP settings are custom and may not work with other authenticators.</source>
        <comment>TOTP QR code dialog warning</comment>
        <translation>Poznámka: tieto nastavenia TOTP sú používateľské a nemusia pracovať s inými autentikátormi.</translation>
    </message>
    <message>
        <source>There was an error creating the QR code.</source>
        <translation>Pri vytváraní QR kódu sa vyskytla chyba.</translation>
    </message>
    <message>
        <source>Closing in %1 seconds.</source>
        <translation>Zatvorí sa za %1 sekúnd.</translation>
    </message>
</context>
<context>
    <name>TotpSetupDialog</name>
    <message>
        <source>Setup TOTP</source>
        <translation>Nastaviť TOTP</translation>
    </message>
    <message>
        <source>Secret Key:</source>
        <translation>Tajný kľúč:</translation>
    </message>
    <message>
        <source>Secret key must be in Base32 format</source>
        <translation>Tajný kľúč musí byť vo formáte Base32</translation>
    </message>
    <message>
        <source>Secret key field</source>
        <translation>Pole tajného kľúča</translation>
    </message>
    <message>
        <source>Default settings (RFC 6238)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Steam® settings</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Custom settings:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Custom Settings</source>
        <translation>Používateľské nastavenia</translation>
    </message>
    <message>
        <source>Algorithm:</source>
        <translation>Algoritmus:</translation>
    </message>
    <message>
        <source>Time step:</source>
        <translation>Časový krok:</translation>
    </message>
    <message>
        <source>Time step field</source>
        <translation>Pole kroku času</translation>
    </message>
    <message>
        <source> sec</source>
        <comment>Seconds</comment>
        <translation>s</translation>
    </message>
    <message>
        <source>Code size:</source>
        <translation>Veľkosť kódu:</translation>
    </message>
    <message>
        <source> digits</source>
        <translation>číslice</translation>
    </message>
    <message>
        <source>Invalid TOTP Secret</source>
        <translation>Neplatné tajomstvo TOTP</translation>
    </message>
    <message>
        <source>You have entered an invalid secret key. The key must be in Base32 format.
Example: JBSWY3DPEHPK3PXP</source>
        <translation>Zadali ste neplatný tajný kľúč. Kľúč musí byť vo formáte Base32.
Napríklad: JBSWY3DPEHPK3PXP</translation>
    </message>
    <message>
        <source>Confirm Remove TOTP Settings</source>
        <translation>Potvrďte odstránenie nastavení TOTP</translation>
    </message>
    <message>
        <source>Are you sure you want to delete TOTP settings for this entry?</source>
        <translation>Naozaj chcete odstrániť nastavenia TOTP tejto položky?</translation>
    </message>
    <message>
        <source>Error: secret key is invalid</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>URLEdit</name>
    <message>
        <source>Invalid URL</source>
        <translation>Neplatná URL</translation>
    </message>
</context>
<context>
    <name>UpdateCheckDialog</name>
    <message>
        <source>Checking for updates</source>
        <translation>Kontrola aktualizácií</translation>
    </message>
    <message>
        <source>Checking for updates…</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Close</source>
        <translation>Zatvoriť</translation>
    </message>
    <message>
        <source>Software Update</source>
        <translation>Aktualizácia softvéru</translation>
    </message>
    <message>
        <source>An error occurred when trying to retrieve update information, please try again later.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>&lt;strong&gt;A new version is available.&lt;/strong&gt;&lt;br/&gt;KeePassXC %1 can be &lt;a href=&quot;https://keepassxc.org/download/&quot;&gt;downloaded here&lt;/a&gt;.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>You have the latest version of KeePassXC</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>WelcomeWidget</name>
    <message>
        <source>Start storing your passwords securely in a KeePassXC database</source>
        <translation>Začnite ukladať svoje heslá bezpečne v databáze KeePassXC</translation>
    </message>
    <message>
        <source>Recent databases</source>
        <translation>Nedávne databázy</translation>
    </message>
    <message>
        <source>Open a recent database</source>
        <translation>Otvoriť nedávnu databázu</translation>
    </message>
    <message>
        <source>Welcome to KeePassXC %1</source>
        <translation>Vitajte v KeePassXC %1</translation>
    </message>
    <message>
        <source>Create Database</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Open Database</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Import File</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>WinUtils</name>
    <message>
        <source>Invalid key code</source>
        <translation>Neplatný súbor kľúča</translation>
    </message>
    <message>
        <source>Global shortcut already registered to %1</source>
        <translation>Globálna klávesová skratka už je registrovaná na %1</translation>
    </message>
    <message>
        <source>Could not register global shortcut</source>
        <translation>Nemožno registrovať globálnu klávesovú skratku</translation>
    </message>
</context>
<context>
    <name>YubiKey</name>
    <message>
        <source>Could not find hardware key with serial number %1. Please connect it to continue.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>YubiKeyEditWidget</name>
    <message>
        <source>Hardware key slot selection</source>
        <translation>Výber slotu hardvérového kľúča</translation>
    </message>
    <message>
        <source>Could not find any hardware keys!</source>
        <translation>Nemožno nájsť žiadny hardvérový kľúč!</translation>
    </message>
    <message>
        <source>Selected hardware key slot does not support challenge-response!</source>
        <translation>Zvolený slot hardvérového kľúča nepodporuje výzvu.dopoveď!</translation>
    </message>
    <message>
        <source>Challenge-Response</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Add Challenge-Response</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Change Challenge-Response</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Remove Challenge-Response</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Challenge-Response set, click to change or remove</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Detecting hardware keys…</source>
        <translation>Detekcia hardvérových kľúčov…</translation>
    </message>
    <message>
        <source>No hardware keys detected</source>
        <translation>Nenájdené žiadne hardvérové kľúče</translation>
    </message>
    <message>
        <source>Refresh hardware keys</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>&lt;p&gt;If you own a &lt;a href=&quot;https://www.yubico.com/&quot;&gt;YubiKey&lt;/a&gt; or &lt;a href=&quot;https://onlykey.io&quot;&gt;OnlyKey&lt;/a&gt;, you can use it for additional security.&lt;/p&gt;&lt;p&gt;The key requires one of its slots to be programmed with &lt;a href=&quot;https://keepassxc.org/docs/#faq-yubikey-howto&quot;&gt;Challenge-Response&lt;/a&gt;.&lt;/p&gt;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Hardware keys found, but no slots are configured</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>YubiKeyInterfacePCSC</name>
    <message>
        <source>Hardware key is locked or timed out. Unlock or re-present it to continue.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Hardware key was not found or is not configured.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>(NFC) %1 [%2] - Slot %3, %4</source>
        <comment>YubiKey display fields</comment>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Press</source>
        <comment>USB Challenge-Response Key interaction request</comment>
        <translation>Stlačiť</translation>
    </message>
    <message>
        <source>Passive</source>
        <comment>USB Challenge-Response Key no interaction required</comment>
        <translation>Pasívne</translation>
    </message>
    <message>
        <source>The YubiKey PC/SC interface has not been initialized.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Failed to complete a challenge-response, the PC/SC error code was: %1</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>YubiKeyInterfaceUSB</name>
    <message>
        <source>Press</source>
        <comment>USB Challenge-Response Key interaction request</comment>
        <translation>Stlačiť</translation>
    </message>
    <message>
        <source>Passive</source>
        <comment>USB Challenge-Response Key no interaction required</comment>
        <translation>Pasívne</translation>
    </message>
    <message>
        <source>The YubiKey USB interface has not been initialized.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Could not find hardware key with serial number %1. Please plug it in to continue.</source>
        <translation>Nemožno nájsť hardvérový kľúč so sériovým číslom %1. Prosím, pripojte ho na pokračovanie.</translation>
    </message>
    <message>
        <source>Hardware key timed out waiting for user interaction.</source>
        <translation>Uplynul časový limit hardvérového kľúča pri čakaní na činnosť používateľa.</translation>
    </message>
    <message>
        <source>A USB error occurred when accessing the hardware key: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Failed to complete a challenge-response, the specific error was: %1</source>
        <translation>Zlyhalo dokončenie výzvy.odpovede, konkrétna chyba bola: %1</translation>
    </message>
    <message>
        <source>%1 [%2] - Slot %3</source>
        <comment>YubiKey NEO display fields</comment>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>%1 [%2] - Slot %3, %4</source>
        <comment>YubiKey display fields</comment>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Unknown</source>
        <comment>Unknown hardware key name</comment>
        <translation type="unfinished"/>
    </message>
</context>
</TS>
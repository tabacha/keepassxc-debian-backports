<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="fi">
<context>
    <name>AboutDialog</name>
    <message>
        <source>About KeePassXC</source>
        <translation>Tietoa KeePassXC:stä</translation>
    </message>
    <message>
        <source>About</source>
        <translation>Tietoja</translation>
    </message>
    <message>
        <source>Report bugs at: &lt;a href=&quot;https://github.com/keepassxreboot/keepassxc/issues&quot; style=&quot;text-decoration: underline;&quot;&gt;https://github.com&lt;/a&gt;</source>
        <translation>Ilmoita ongelmista: &lt;a href=&quot;https://github.com/keepassxreboot/keepassxc/issues&quot; style=&quot;text-decoration: underline;&quot;&gt;https://github.com&lt;/a&gt;</translation>
    </message>
    <message>
        <source>KeePassXC is distributed under the terms of the GNU General Public License (GPL) version 2 or (at your option) version 3.</source>
        <translation>KeePassXC:tä jaellaan GPL-lisenssin (GNU General Public License) version 2 tai (valintasi mukaan) version 3 ehtojen mukaisesti.</translation>
    </message>
    <message>
        <source>Project Maintainers:</source>
        <translation>Projektin ylläpitäjät:</translation>
    </message>
    <message>
        <source>Special thanks from the KeePassXC team go to debfx for creating the original KeePassX.</source>
        <translation>KeePassXC-tiimi antaa erityiskiitokset KeePassX-ohjelman alkuperäiselle luojalle debfx:lle</translation>
    </message>
    <message>
        <source>Contributors</source>
        <translation>Osallistujat</translation>
    </message>
    <message>
        <source>&lt;a href=&quot;https://github.com/keepassxreboot/keepassxc/graphs/contributors&quot;&gt;See Contributions on GitHub&lt;/a&gt;</source>
        <translation>&lt;a href=&quot;https://github.com/keepassxreboot/keepassxc/graphs/contributors&quot;&gt;Katso osallistujat GitHubista&lt;/a&gt;</translation>
    </message>
    <message>
        <source>Debug Info</source>
        <translation>Vianjäljitystiedot</translation>
    </message>
    <message>
        <source>Include the following information whenever you report a bug:</source>
        <translation>Sisällytä seuraavat tiedot aina kun ilmoitat ongelmasta:</translation>
    </message>
    <message>
        <source>Copy to clipboard</source>
        <translation>Kopioi leikepöydälle</translation>
    </message>
</context>
<context>
    <name>AccessControlDialog</name>
    <message>
        <source>KeePassXC -  Access Request</source>
        <translation>KeePassXC – pääsypyyntö</translation>
    </message>
    <message>
        <source>Non-existing/inaccessible executable path. Please double-check the client is legit.</source>
        <translation>Ohjelmatiedoston sijaintia ei löydy. Varmista asiakasohjelman luotettavuus.</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;%1 &lt;/span&gt;is requesting access to the following entries:&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;%1&lt;/span&gt;pyytää pääsyä seuraaviin tietueisiin: &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;  </translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nimi</translation>
    </message>
    <message>
        <source>PID</source>
        <translation>PID</translation>
    </message>
    <message>
        <source>Executable</source>
        <translation>Ohjelmatiedosto</translation>
    </message>
    <message>
        <source>Command Line</source>
        <translation>Komentorivi</translation>
    </message>
    <message>
        <source>Details</source>
        <translation>Yksityiskohdat</translation>
    </message>
    <message>
        <source>Your decision will be remembered for the duration while both the requesting client AND KeePassXC are running.</source>
        <translation>Valintasi muistetaan pyynnön esittäneen asiakasohjelman JA KeePassXC:n käynnissäoloajan.</translation>
    </message>
    <message>
        <source>Remember</source>
        <translation>Muista</translation>
    </message>
    <message>
        <source>Allow Selected</source>
        <translation>Salli valitut</translation>
    </message>
    <message>
        <source>Deny All &amp;&amp; Future</source>
        <translation>Estä kaikki &amp;&amp; tulevat</translation>
    </message>
    <message>
        <source>Allow All &amp;&amp; &amp;Future</source>
        <translation>Salli kaikki &amp;&amp; &amp;tulevat</translation>
    </message>
</context>
<context>
    <name>AccessControlDialog::DenyButton</name>
    <message>
        <source>Deny for this program</source>
        <translation>Kiellä tältä ohjelmalta</translation>
    </message>
</context>
<context>
    <name>AgentSettingsWidget</name>
    <message>
        <source>Enable SSH Agent integration</source>
        <translation>Ota SSH-agentin integraatio käyttöön</translation>
    </message>
    <message>
        <source>Use Pageant</source>
        <translation>Käytä Pageantia</translation>
    </message>
    <message>
        <source>Use OpenSSH</source>
        <translation>Käytä OpenSSH:ta</translation>
    </message>
    <message>
        <source>Use both agents</source>
        <translation>Käytä kumpaakin agenttia</translation>
    </message>
    <message>
        <source>SSH_AUTH_SOCK override</source>
        <translation>SSH_AUTH_SOCK-ylikirjoitus</translation>
    </message>
    <message>
        <source>SSH_AUTH_SOCK value</source>
        <translation>SSH_AUTH_SOCK-arvo</translation>
    </message>
    <message>
        <source>(empty)</source>
        <translation>(tyhjä)</translation>
    </message>
    <message>
        <source>SSH_SK_PROVIDER value</source>
        <translation>SSH_SK_PROVIDER-arvo</translation>
    </message>
    <message>
        <source>SSH_SK_PROVIDER override</source>
        <translation>SSH_SK_PROVIDER:in ylikirjoitus</translation>
    </message>
    <message>
        <source>No SSH Agent socket available. Either make sure SSH_AUTH_SOCK environment variable exists or set an override.</source>
        <translation>Yhteystieto SSH-agenttiin puuttuu. Varmista, että SSH_AUTH_SOCK-ympäristömuuttuja on olemassa, tai aseta sille ylikirjoitus</translation>
    </message>
    <message>
        <source>SSH Agent connection is working!</source>
        <translation>Yhteys SSH-agenttiin toimii!</translation>
    </message>
</context>
<context>
    <name>AppKit</name>
    <message>
        <source>Window</source>
        <translation>Ikkuna</translation>
    </message>
    <message>
        <source>Minimize</source>
        <translation>Pienennä</translation>
    </message>
    <message>
        <source>Zoom</source>
        <translation>Lähennä</translation>
    </message>
    <message>
        <source>Bring All to Front</source>
        <translation>Tuo kaikki etualalle</translation>
    </message>
</context>
<context>
    <name>ApplicationSettingsWidget</name>
    <message>
        <source>Application Settings</source>
        <translation>Sovelluksen asetukset</translation>
    </message>
    <message>
        <source>General</source>
        <translation>Perusasetukset</translation>
    </message>
    <message>
        <source>Security</source>
        <translation>Turvallisuus</translation>
    </message>
    <message>
        <source>This setting cannot be enabled when minimize on unlock is enabled.</source>
        <translation>Tätä asetusta ei voi ottaa käyttöön, kun ohjelman pienennys lukituksen avauksen jälkeen on käytössä.</translation>
    </message>
    <message>
        <source>Access error for config file %1</source>
        <translation>Pääsyvirhe asetustiedostoon %1</translation>
    </message>
    <message>
        <source>Icon only</source>
        <translation>Vain kuvake</translation>
    </message>
    <message>
        <source>Text only</source>
        <translation>Vain teksti</translation>
    </message>
    <message>
        <source>Text beside icon</source>
        <translation>Teksti kuvakkeen vieressä</translation>
    </message>
    <message>
        <source>Text under icon</source>
        <translation>Teksti kuvakkeen alla</translation>
    </message>
    <message>
        <source>Follow style</source>
        <translation>Seuraa tyyliä</translation>
    </message>
    <message>
        <source>Monochrome</source>
        <translation>Mustavalkoinen</translation>
    </message>
    <message>
        <source>Monochrome (light)</source>
        <translation>Mustavalkoinen (vaalea)</translation>
    </message>
    <message>
        <source>Monochrome (dark)</source>
        <translation>Mustavalkoinen (tumma)</translation>
    </message>
    <message>
        <source>Colorful</source>
        <translation>Värikäs</translation>
    </message>
    <message>
        <source>You must restart the application to set the new language. Would you like to restart now?</source>
        <translation>Ohjelma täytyy käynnistää uudelleen, jotta uusi kieli voidaan ottaa käyttöön. Haluatko käynnistää uudelleen nyt?</translation>
    </message>
    <message>
        <source>Select backup storage directory</source>
        <translation>Valitse varmuuskopion hakemistopolku</translation>
    </message>
    <message>
        <source>Confirm Reset</source>
        <translation>Vahvista palauttaminen</translation>
    </message>
    <message>
        <source>Are you sure you want to reset all settings to default?</source>
        <translation>Haluatko varmasti palauttaa kaikki asetukset oletuksiinsa?</translation>
    </message>
    <message>
        <source>Import KeePassXC Settings</source>
        <translation>Tuo KeePassXC-asetukset</translation>
    </message>
    <message>
        <source>Failed to import settings from %1, not a valid settings file.</source>
        <translation>Ei voitu tuoda asetuksia tiedostosta %1: ei ole kelvollinen asetustiedosto.</translation>
    </message>
    <message>
        <source>Export KeePassXC Settings</source>
        <translation>Vie KeePassXC-asetukset</translation>
    </message>
    <message>
        <source>Small</source>
        <translation>Pieni</translation>
    </message>
    <message>
        <source>Normal</source>
        <translation>Tavallinen</translation>
    </message>
    <message>
        <source>Medium</source>
        <translation>Keskikokoinen</translation>
    </message>
    <message>
        <source>Large</source>
        <translation>Suuri</translation>
    </message>
    <message>
        <source>Custom</source>
        <translation>Mukautettu</translation>
    </message>
    <message>
        <source>None</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Restart KeePassXC to apply the Auto-Type desktop portals preference.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>ApplicationSettingsWidgetGeneral</name>
    <message>
        <source>Basic Settings</source>
        <translation>Perusasetukset</translation>
    </message>
    <message>
        <source>Startup</source>
        <translation>Käynnistys</translation>
    </message>
    <message>
        <source>Start only a single instance of KeePassXC</source>
        <translation>Käynnistä vain yksi KeePassXC-instanssi</translation>
    </message>
    <message>
        <source>Automatically launch KeePassXC at system startup</source>
        <translation>Käynnistä KeePassXC automaattisesti järjestelmän käynnistyksessä</translation>
    </message>
    <message>
        <source>Minimize window at application startup</source>
        <translation>Pienennä ikkuna ohjelman käynnistyessä</translation>
    </message>
    <message>
        <source>Minimize window after unlocking database</source>
        <translation>Pienennä ikkuna tietokannan lukituksen avauksen jälkeen</translation>
    </message>
    <message>
        <source>Remember previously used databases</source>
        <translation>Muista aiemmin käytetyt tietokannat</translation>
    </message>
    <message>
        <source> recent files</source>
        <translation>viimeisimmät tiedostot</translation>
    </message>
    <message>
        <source>Load previously open databases on startup</source>
        <translation>Lataa aiemmin avoinna olleet tietokannat käynnistyksen yhteydessä</translation>
    </message>
    <message>
        <source>Remember database key files and security dongles</source>
        <translation>Muista tietokannan avaintiedostot ja tietoturva-avainlaitteet</translation>
    </message>
    <message>
        <source>Check for updates at application startup once per week</source>
        <translation>Tarkista päivitykset kerran viikossa sovelluksen käynnistyessä</translation>
    </message>
    <message>
        <source>Include beta releases when checking for updates</source>
        <translation>Sisällytä betajulkaisut päivityksiä tarkistaessa</translation>
    </message>
    <message>
        <source>File Management</source>
        <translation>Tiedostonhallinta</translation>
    </message>
    <message>
        <source>Automatically save after every change</source>
        <translation>Tallenna automaattisesti jokaisen muutoksen jälkeen</translation>
    </message>
    <message>
        <source>Automatically save when locking database</source>
        <translation>Tallenna automaattisesti lukittaessa tietokanta</translation>
    </message>
    <message>
        <source>Automatically save non-data changes when locking database</source>
        <translation>Tallenna automaattisesti asetukset jotka eivät liity varsinaisiin tietoihin, kun tietokanta lukitaan</translation>
    </message>
    <message>
        <source>Automatically reload the database when modified externally</source>
        <translation>Lataa tietokanta automaattisesti uudelleen, jos sitä on muokattu toisaalla</translation>
    </message>
    <message>
        <source>Backup database file before saving</source>
        <translation>Ota tietokannasta varmuuskopio ennen tallentamista</translation>
    </message>
    <message>
        <source>{DB_FILENAME}.old.kdbx</source>
        <translation>{DB_FILENAME}.old.kdbx</translation>
    </message>
    <message>
        <source>Use alternative saving method (may solve problems with Dropbox, Google Drive, GVFS, etc.)</source>
        <translation>Käytä vaihtoehtoista tallennustapaa (voi ratkaista ongelmia Dropboxin, Google Driven GVFS:n ym. kanssa)</translation>
    </message>
    <message>
        <source>Temporary file moved into place</source>
        <translation>Väliaikainen tiedosto on siirretty kohteeseen</translation>
    </message>
    <message>
        <source>Directly write to database file (dangerous)</source>
        <translation>Kirjoita suoraan tietokantaan (riskialtista)</translation>
    </message>
    <message>
        <source>Entry Management</source>
        <translation>Tietueiden hallinta</translation>
    </message>
    <message>
        <source>Use group icon on entry creation</source>
        <translation>Käytä ryhmän kuvaketta tietuetta luodessa</translation>
    </message>
    <message>
        <source>Minimize when opening a URL</source>
        <translation>Pienennä ikkuna URL:ää avatessa</translation>
    </message>
    <message>
        <source>Hide window when copying to clipboard</source>
        <translation>Piilota ikkuna leikepöydälle kopioitaessa</translation>
    </message>
    <message>
        <source>Minimize</source>
        <translation>Pienennä</translation>
    </message>
    <message>
        <source>Drop to background</source>
        <translation>Siirrä taustalle</translation>
    </message>
    <message>
        <source>Favicon download timeout:</source>
        <translation>Sivustokuvakkeen latauksen aikakatkaisu:</translation>
    </message>
    <message>
        <source>Website icon download timeout in seconds</source>
        <translation>Sivustokuvakkeen latauksen aikakatkaisu sekunteina</translation>
    </message>
    <message>
        <source> sec</source>
        <comment>Seconds</comment>
        <translation> s</translation>
    </message>
    <message>
        <source>User Interface</source>
        <translation>Käyttöliittymä</translation>
    </message>
    <message>
        <source>Toolbar button style</source>
        <translation>Työkalupalkin painiketyyli</translation>
    </message>
    <message>
        <source>Movable toolbar</source>
        <translation>Siirrettävä työkalupalkki</translation>
    </message>
    <message>
        <source>Language selection</source>
        <translation>Kielivalinta</translation>
    </message>
    <message>
        <source>Language:</source>
        <translation>Kieli:</translation>
    </message>
    <message>
        <source>(restart program to activate)</source>
        <translation>(aktivoi käynnistämällä ohjelma uudestaan)</translation>
    </message>
    <message>
        <source>Toolbar button style:</source>
        <translation>Työkalupalkin nappien tyyli:</translation>
    </message>
    <message>
        <source>Show passwords in color</source>
        <translation>Näytä salasanat värillisinä</translation>
    </message>
    <message>
        <source>Use monospaced font for notes</source>
        <translation>Käytä muistiinpanoille tasalevyistä fonttia</translation>
    </message>
    <message>
        <source>Minimize instead of app exit</source>
        <translation>Pienennä ohjelma sulkemisen sijaan</translation>
    </message>
    <message>
        <source>Show a system tray icon</source>
        <translation>Näytä ilmoitusaluekuvake</translation>
    </message>
    <message>
        <source>Tray icon type</source>
        <translation>Ilmoitusaluekuvakkeen tyyppi</translation>
    </message>
    <message>
        <source>Tray icon type:</source>
        <translation>Ilmoitusaluekuvakkeen tyyppi:</translation>
    </message>
    <message>
        <source>Hide window to system tray when minimized</source>
        <translation>Piilota ikkuna ilmoitusalueelle pienennettäessä</translation>
    </message>
    <message>
        <source>Reset settings to default…</source>
        <translation>Palauta oletusasetukset...</translation>
    </message>
    <message>
        <source>Auto-Type</source>
        <translation>Automaattisyöttö</translation>
    </message>
    <message>
        <source>Use entry title to match windows for global Auto-Type</source>
        <translation>Tietue on sopiva, jos sen nimi sisältyy kohdeikkunan otsikkoon yleisessä automaattisyötössä</translation>
    </message>
    <message>
        <source>Use entry URL to match windows for global Auto-Type</source>
        <translation>Tietue on sopiva, jos sen osoite sisältyy kohdeikkunan otsikkoon yleisessä automaattisyötössä</translation>
    </message>
    <message>
        <source>Always ask before performing Auto-Type</source>
        <translation>Kysy aina ennen automaattisyötön käyttämistä</translation>
    </message>
    <message>
        <source>Hide expired entries from Auto-Type</source>
        <translation>Piilota vanhentuneet tietueet automaattisyötöltä</translation>
    </message>
    <message>
        <source>Re-lock previously locked database after performing Auto-Type</source>
        <translation>Lukitse aikaisemmin lukittu tietokanta uudelleen automaattisyötön jälkeen</translation>
    </message>
    <message>
        <source>Auto-Type start delay:</source>
        <translation>Automaattisyötön aloitusviive:</translation>
    </message>
    <message>
        <source>Global Auto-Type shortcut:</source>
        <translation>Yleisen automaattisyötön pikanäppäin:</translation>
    </message>
    <message>
        <source>Auto-type start delay milliseconds</source>
        <translation>Automaattisyötön aloitusviive millisekunneissa</translation>
    </message>
    <message>
        <source> ms</source>
        <comment>Milliseconds</comment>
        <translation> ms</translation>
    </message>
    <message>
        <source>Auto-Type typing delay:</source>
        <translation>Automaattisyötön kirjoituksen viive:</translation>
    </message>
    <message>
        <source>Global auto-type shortcut</source>
        <translation>Yleisen automaattisyötön pikanäppäin</translation>
    </message>
    <message>
        <source>Auto-type character typing delay milliseconds</source>
        <translation>Automaattisyötön kirjoituksen viive millisekunneissa</translation>
    </message>
    <message>
        <source>Remember last typed entry for:</source>
        <translation>Muista edellinen syötetty tietue:</translation>
    </message>
    <message>
        <source>On database unlock, show entries that will expire within</source>
        <translation>Tietokannan lukitusta avattaessa näytä tietueet, jotka vanhenevat</translation>
    </message>
    <message>
        <source>On database unlock, show entries that will expire within </source>
        <translation>Tietokannan lukitusta avattaessa näytä tietueet, jotka vanhenevat</translation>
    </message>
    <message>
        <source> days</source>
        <comment>number of days warning for password expiration</comment>
        <translation> päivää</translation>
    </message>
    <message>
        <source>Destination format:</source>
        <translation>Kohdemuoto:</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;{DB_FILENAME}&lt;/span&gt; is replaced with the filename of the saved database without extension&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;{TIME:&amp;lt;format&amp;gt;}&lt;/span&gt; is replaced with the specified time format (default: dd_MM_yyyy_hh-mm-ss)&lt;/p&gt;&lt;p&gt;See the User Guide for more details&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;{DB_FILENAME}&lt;/span&gt; korvataan tallennettavan tietokannan päätteettömällä tiedostonimellä&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;{TIME:&amp;lt;format&amp;gt;}&lt;/span&gt; korvataan määrityksen mukaisella aikaleimalla (oletus: dd_MM_yyyy_hh-mm-ss)&lt;/p&gt;&lt;p&gt;Lisätietoa löytyy käyttöoppaasta&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Choose folder...</source>
        <translation>Valitse kansio…</translation>
    </message>
    <message>
        <source>Show confirmation before moving entries to recycle bin</source>
        <translation>Pyydä vahvistus ennen tietueiden siirtämistä roskakoriin</translation>
    </message>
    <message>
        <source>Copy data on double clicking field in entry view</source>
        <translation>Kopioi tiedot kaksoisnapsautettaessa kenttää tietuenäkymässä</translation>
    </message>
    <message>
        <source>Show toolbar</source>
        <translation>Näytä työkalupalkki</translation>
    </message>
    <message>
        <source>Show the menu bar by pressing the Alt key</source>
        <translation>Näytä valikkorivi painettaessa Alt-näppäintä</translation>
    </message>
    <message>
        <source>Show menubar</source>
        <translation>Näytä valikkorivi</translation>
    </message>
    <message>
        <source>Import settings…</source>
        <translation>Tuo asetukset…</translation>
    </message>
    <message>
        <source>Export settings…</source>
        <translation>Vie asetukset…</translation>
    </message>
    <message>
        <source>Font size:</source>
        <translation>Fonttikoko:</translation>
    </message>
    <message>
        <source>Font size selection</source>
        <translation>Fonttikoon valinta</translation>
    </message>
    <message>
        <source>Skip confirmation for main window Auto-Type actions</source>
        <translation>Ohita pääikkunan automaattisyöttötoimintojen vahvistaminen</translation>
    </message>
    <message>
        <source>Double-click action for URL:</source>
        <translation>Kaksoisnapautuksen toiminto URLille:</translation>
    </message>
    <message>
        <source>Double-click action for URL field</source>
        <translation>Kaksoisnapautuksen toiminto URL-kentälle</translation>
    </message>
    <message>
        <source>Edit entry</source>
        <translation>Muokkaa tietuetta</translation>
    </message>
    <message>
        <source>Open entry URL in browser</source>
        <translation>Avaa tietueen URL selaimessa</translation>
    </message>
    <message>
        <source>Copy entry URL to clipboard</source>
        <translation>Kopioi tietueen osoite leikepöydälle</translation>
    </message>
    <message>
        <source>Auto-generate password for new entries</source>
        <translation>Luo automaattisesti salasana uudelle tietueelle</translation>
    </message>
    <message>
        <source>Keep remote desktop connection open after performing Auto-Type</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Remote desktop mode:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Never remember session</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Remember session until exit</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Remember session until revoked by desktop</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>None</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Configure...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Use remote desktop for clipboard access</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Experimental: Prefer desktop portals (Wayland implementation)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Show autocomplete suggestions for username and additional attributes</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>ApplicationSettingsWidgetSecurity</name>
    <message>
        <source>Timeouts</source>
        <translation>Aikakatkaisut</translation>
    </message>
    <message>
        <source>Database lock timeout seconds</source>
        <translation>Tietokannan lukituksen aikakatkaisu sekunneissa</translation>
    </message>
    <message>
        <source> sec</source>
        <comment>Seconds</comment>
        <translation> s</translation>
    </message>
    <message>
        <source>Clear clipboard after</source>
        <translation>Tyhjennä leikepöytä ajassa</translation>
    </message>
    <message>
        <source>Clear search query after</source>
        <translation>Tyhjennä hakukentän sisältö ajassa</translation>
    </message>
    <message>
        <source> min</source>
        <comment>Minutes</comment>
        <translation> minuuttia</translation>
    </message>
    <message>
        <source>Clipboard clear seconds</source>
        <translation>Leikepöydän tyhjennys sekunteina</translation>
    </message>
    <message>
        <source>Lock databases after inactivity of</source>
        <translation>Lukitse tietokannat, kun on oltu jouten</translation>
    </message>
    <message>
        <source>Convenience</source>
        <translation>Mukavuus</translation>
    </message>
    <message>
        <source>Enable database quick unlock (Touch ID / Windows Hello)</source>
        <translation>Käytä tietokannan pika-avausta (Touch ID/Windows Hello)</translation>
    </message>
    <message>
        <source>Lock databases when session is locked or lid is closed</source>
        <translation>Lukitse tietokannat istuntoa lukittaessa tai kantta suljettaessa</translation>
    </message>
    <message>
        <source>Lock databases after minimizing the window</source>
        <translation>Lukitse tietokanta ikkunan pienennyksen jälkeen</translation>
    </message>
    <message>
        <source>Hide passwords when editing them</source>
        <translation>Piilota salasanat muokkauksen aikana</translation>
    </message>
    <message>
        <source>Use placeholder for empty password fields</source>
        <translation>Käytä tyhjiin salasanakenttiin paikkamerkkiä</translation>
    </message>
    <message>
        <source>Hide passwords in the entry preview panel</source>
        <translation>Piilota salasanat tietueiden esikatselupaneelissa</translation>
    </message>
    <message>
        <source>Privacy</source>
        <translation>Yksityisyys</translation>
    </message>
    <message>
        <source>Use DuckDuckGo service to download website icons</source>
        <translation>Käytä DuckDuckGo’ta sivustojen ikonien lataukseen</translation>
    </message>
    <message>
        <source>Hide TOTP in the entry preview panel</source>
        <translation>Piilota TOTP merkinnän esikatselupaneelista</translation>
    </message>
    <message>
        <source>Lock databases when switching user</source>
        <translation>Lukitse tietokanta käyttäjää vaihdettaessa</translation>
    </message>
    <message>
        <source>Lock Options</source>
        <translation>Lukituksen asetukset</translation>
    </message>
    <message>
        <source>Hide notes in the entry preview panel</source>
        <translation>Piilota muistiinpanot tietueen esikatselupaneelista</translation>
    </message>
</context>
<context>
    <name>AttachmentWidget</name>
    <message>
        <source>Attachment Viewer</source>
        <translation>Liitekatselin</translation>
    </message>
    <message>
        <source>Unknown attachment type</source>
        <translation>Tuntematon liitetyyppi</translation>
    </message>
</context>
<context>
    <name>AutoType</name>
    <message>
        <source>The requested Auto-Type sequence cannot be used due to an error:</source>
        <translation>Pyydettyä automaattisyötön sekvenssiä ei voitu käyttää virheen takia:</translation>
    </message>
    <message>
        <source>Auto-Type Error</source>
        <translation>Automaattisyötön virhe</translation>
    </message>
    <message>
        <source>Permission Required</source>
        <translation>Lupa vaaditaan</translation>
    </message>
    <message>
        <source>KeePassXC requires the Accessibility permission in order to perform entry level Auto-Type. If you already granted permission, you may have to restart KeePassXC.</source>
        <translation>KeePassXC:n täytyy saada lupa Käyttöavun kautta automaattisyötön suorittamiseen. Jos olet jo sallinut asetuksen, KeePassXC täytyy mahdollisesti käynnistää uudelleen.</translation>
    </message>
    <message>
        <source>KeePassXC requires the Accessibility and Screen Recorder permission in order to perform global Auto-Type. Screen Recording is necessary to use the window title to find entries. If you already granted permission, you may have to restart KeePassXC.</source>
        <translation>KeePassXC tarvitsee luvan Käyttöavun kautta Näyttötallennukseen, jotta yleinen automaattisyöttö toimisi oikein. Näyttötallennus on pakollinen ikkunan otsikkotiedon saamiseen. Jos olet jo sallinut asetuksen, KeePassXC täytyy mahdollisesti käynnistää uudelleen.</translation>
    </message>
    <message>
        <source>Invalid entry provided</source>
        <translation>Virheelinen tietue annettu</translation>
    </message>
    <message>
        <source>Bracket imbalance detected, found extra { or }</source>
        <translation>Sulkeet ovat epätasapainossa: löytyi ylimääräinen { tai }</translation>
    </message>
    <message>
        <source>Too many repetitions detected, max is %1: %2</source>
        <translation>Liikaa toistoja, enimmäismäärä on %1: %2</translation>
    </message>
    <message>
        <source>Very slow key press detected, max is %1: %2</source>
        <translation>Erittäin hidas näppäinpainallus havaittu, enimmäisaika on %1: %2</translation>
    </message>
    <message>
        <source>Very long delay detected, max is %1: %2</source>
        <translation>Erittäin pitkä viive havaittu, enimmäisaika on %1: %2</translation>
    </message>
    <message>
        <source>Entry does not have attribute for PICKCHARS: %1</source>
        <translation>Merkintä ei sisällä PICKCHARS-määritettä: %1</translation>
    </message>
    <message>
        <source>Invalid placeholder: %1</source>
        <translation>Virheellinen paikkamerkki: %1</translation>
    </message>
    <message>
        <source>Entry has invalid TOTP settings</source>
        <translation>Tietueella on virheelliset TOTP-asetukset</translation>
    </message>
</context>
<context>
    <name>AutoTypeAssociationsModel</name>
    <message>
        <source>Window</source>
        <translation>Ikkuna</translation>
    </message>
    <message>
        <source>Sequence</source>
        <translation>Sekvenssi</translation>
    </message>
    <message>
        <source>(empty)</source>
        <translation>(tyhjä)</translation>
    </message>
    <message>
        <source>Default sequence</source>
        <translation>Oletussekvenssi</translation>
    </message>
</context>
<context>
    <name>AutoTypeMatchModel</name>
    <message>
        <source>Group</source>
        <translation>Ryhmä</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>Otsikko</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>Käyttäjätunnus</translation>
    </message>
    <message>
        <source>Sequence</source>
        <translation>Sekvenssi</translation>
    </message>
</context>
<context>
    <name>AutoTypePlatformWayland</name>
    <message>
        <source>No symbol found for key: &apos;%1&apos;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>No symbol found for character: &apos;%1&apos;</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>AutoTypePlatformX11</name>
    <message>
        <source>Sequence aborted: Caps Lock is on</source>
        <translation>Sekvenssi peruutettu: vaihtolukko on käytössä</translation>
    </message>
    <message>
        <source>Sequence aborted: Modifier keys held by user</source>
        <translation>Sekvenssi peruutettu: Käyttäjä painaa muokkausnäppäintä</translation>
    </message>
    <message>
        <source>Unable to get valid keycode for key: </source>
        <translation>Avainkoodia ei voitu saada avaimelle:</translation>
    </message>
    <message>
        <source>Trying to send invalid keyboard symbol.</source>
        <translation>Yritettiin lähettää virheellistä näppäimistösymbolia.</translation>
    </message>
</context>
<context>
    <name>AutoTypeSelectDialog</name>
    <message>
        <source>Auto-Type - KeePassXC</source>
        <translation>Automaattisyöttö – KeePassXC</translation>
    </message>
    <message>
        <source>Double click a row to perform Auto-Type or find an entry using the search:</source>
        <translation>Automaattitäydennä kaksoisnapsauttamalla tai etsi tietuetta haulla:</translation>
    </message>
    <message>
        <source>Search all open databases</source>
        <translation>Etsi kaikista avoimista tietokannoista</translation>
    </message>
    <message>
        <source>Search…</source>
        <translation>Etsi...</translation>
    </message>
    <message>
        <source>Type Sequence</source>
        <translation>Kirjoita sekvenssi</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Peru</translation>
    </message>
    <message>
        <source>Type {USERNAME}</source>
        <translation>Kirjoita {USERNAME}</translation>
    </message>
    <message>
        <source>Type {PASSWORD}</source>
        <translation>Kirjoita {PASSWORD}</translation>
    </message>
    <message>
        <source>Type {TOTP}</source>
        <translation>Kirjoita {TOTP}</translation>
    </message>
    <message>
        <source>Copy Username</source>
        <translation>Kopioi käyttäjätunnus</translation>
    </message>
    <message>
        <source>Copy Password</source>
        <translation>Kopioi salasana</translation>
    </message>
    <message>
        <source>Copy TOTP</source>
        <translation>Kopioi TOTP</translation>
    </message>
    <message>
        <source>Use Virtual Keyboard</source>
        <translation>Käytä näyttönäppäimistöä</translation>
    </message>
    <message>
        <source>Type {URL}</source>
        <translation>Kirjoita {URL}</translation>
    </message>
    <message>
        <source>Copy URL</source>
        <translation>Kopioi URL-osoite</translation>
    </message>
    <message>
        <source>&lt;p&gt;The following shortcuts are available:&lt;br/&gt;
Ctrl+F - Focus search&lt;br/&gt;
Ctrl+1 - Type username&lt;br/&gt;
Ctrl+2 - Type password&lt;br/&gt;
Ctrl+3 - Type TOTP&lt;br/&gt;
Ctrl+4 - Type URL&lt;br/&gt;
Ctrl+5 - Use Virtual Keyboard (Windows Only)&lt;br/&gt;
Ctrl+Shift+1 - Copy username&lt;br/&gt;
Ctrl+Shift+2 - Copy password&lt;br/&gt;
Ctrl+Shift+3 - Copy TOTP&lt;br/&gt;
Ctrl+Shift+4 - Copy URL&lt;br/&gt;
&lt;/p&gt;</source>
        <translation>&lt;p&gt;Käytettävissä ovat seuraavat pikanäppäimet:&lt;br/&gt;
Ctrl+F – Kohdista hakuun&lt;br/&gt;
Ctrl+1 – Kirjoita käyttäjänimi&lt;br/&gt;
Ctrl+2 – Kirjoita salasana&lt;br/&gt;
Ctrl+3 – Kirjoita TOTP&lt;br/&gt;
Ctrl+4 – Kirjoita osoite&lt;br/&gt;
Ctrl+5 – Käytä näyttönäppäimistöä (vain Windows)&lt;br/&gt;
Ctrl+Vaihto+1 – Kopioi käyttäjänimi&lt;br/&gt;
Ctrl+Vaihto+2 – Kopioi salasana&lt;br/&gt;
Ctrl+Vaihto+3 – Kopioi TOTP&lt;br/&gt;
Ctrl+Vaihto+4 – Kopioi osoite&lt;br/&gt;
&lt;/p&gt;</translation>
    </message>
    <message>
        <source>You can use advanced search queries to find any entry in your open databases.</source>
        <translation>Lisähakuehdoin voi löytää avoimista tietokannoista minkä tahansa tietueen.</translation>
    </message>
</context>
<context>
    <name>BinaryStream</name>
    <message>
        <source>Failed to read string data: %1</source>
        <translation>Merkkijonodatan luenta epäonnistui: %1</translation>
    </message>
    <message>
        <source>String length exceeds 10 MiB limit (requested %1)</source>
        <translation>Merkkijonon pituus ylittää 10 MiB:n rajan (pituus %1)</translation>
    </message>
</context>
<context>
    <name>BrowserAccessControlDialog</name>
    <message>
        <source>KeePassXC - Browser Access Request</source>
        <translation>KeePassXC – selaimen pääsypyyntö</translation>
    </message>
    <message>
        <source>%1 is requesting access to the following entries:</source>
        <translation>%1 pyytää pääsylupaa seuraaviin tietueisiin:</translation>
    </message>
    <message>
        <source>Remember access to checked entries</source>
        <translation>Muista pääsylupa valituille tietueille</translation>
    </message>
    <message>
        <source>Remember</source>
        <translation>Muista</translation>
    </message>
    <message>
        <source>Allow access to entries</source>
        <translation>Salli pääsy tietueisiin</translation>
    </message>
    <message>
        <source>Allow Selected</source>
        <translation>Salli valitut</translation>
    </message>
    <message>
        <source>Deny All</source>
        <translation>Estä kaikilta</translation>
    </message>
    <message>
        <source>Disable for this site</source>
        <translation>Ota pois käytöstä tällä sivustolla</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation>Kumoa</translation>
    </message>
</context>
<context>
    <name>BrowserEntrySaveDialog</name>
    <message>
        <source>Ok</source>
        <translation>Ok</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Peruuta</translation>
    </message>
    <message>
        <source>You have multiple databases open.
Please select the correct database for saving credentials.</source>
        <translation>Useita tietokantoja on auki
Valitse tietokanta, johon tiedot tallennetaan.</translation>
    </message>
    <message>
        <source>KeePassXC - Select Database</source>
        <translation>KeePassXC – valitse tietokanta</translation>
    </message>
</context>
<context>
    <name>BrowserPasskeysConfirmationDialog</name>
    <message>
        <source>Cancel</source>
        <translation>Peru</translation>
    </message>
    <message>
        <source>Update</source>
        <translation>Päivitä</translation>
    </message>
    <message>
        <source>Authenticate</source>
        <translation>Todenna</translation>
    </message>
    <message>
        <source>Register new</source>
        <translation>Rekisteröi uusi</translation>
    </message>
    <message>
        <source>Register</source>
        <translation>Rekisteröi</translation>
    </message>
    <message numerus="yes">
        <source>Timeout in &lt;b&gt;%n&lt;/b&gt; seconds...</source>
        <translation><numerusform>Aikakatkaisu &lt;b&gt;%n&lt;/b&gt; sekunnin kuluttua...</numerusform><numerusform>Aikakatkaisu &lt;b&gt;%n&lt;/b&gt; sekunnin kuluttua...</numerusform></translation>
    </message>
    <message>
        <source>Relying Party: %1</source>
        <translation>Välittävä osapuoli: %1</translation>
    </message>
    <message>
        <source>Username: %1</source>
        <translation>Käyttäjätunnus: %1</translation>
    </message>
    <message>
        <source>KeePassXC - Passkey credentials</source>
        <translation>KeePassXC – suojausavaimen tunnistetiedot</translation>
    </message>
    <message>
        <source>Add to existing entry</source>
        <translation>Lisää olemassa olevaan tietueeseen</translation>
    </message>
    <message>
        <source>Existing passkey found.
Do you want to register a new passkey for:</source>
        <translation>Olemassa oleva passkey löytyi
Haluatko rekisteröidä uuden passkeyn sivustolle:</translation>
    </message>
    <message>
        <source>Select the existing passkey and press Update to replace it.</source>
        <translation>Valitse olemassa oleva passkey ja klikkaa Päivitä korvataksesi se.</translation>
    </message>
    <message>
        <source>Authenticate passkey credentials for:</source>
        <translation>Kirjaudu passkey-tunnuksilla sivustolle:</translation>
    </message>
    <message>
        <source>Do you want to register a passkey for:</source>
        <translation>Haluatko rekisteröidä passkeyn sivustolle:</translation>
    </message>
</context>
<context>
    <name>BrowserService</name>
    <message>
        <source>A request for creating a new group &quot;%1&quot; has been received.
Do you want to create this group?
</source>
        <translation>Vastaanotettiin pyyntö luoda uusi ryhmä &quot;%1&quot;.
Haluatko varmasti luoda tämän ryhmän?</translation>
    </message>
    <message>
        <source>You have received an association request for the following database:
%1

Give the connection a unique name or ID, for example:
chrome-laptop.</source>
        <translation>Olet saanut avainliittämispyynnön seuraavalle tietokannalle:
%1

Anna yhteydelle yksilöllinen nimi tai tunniste, esimerkiksi:
chrome-läppäri.</translation>
    </message>
    <message>
        <source>Save and allow access</source>
        <translation>Tallenna ja salli pääsy</translation>
    </message>
    <message>
        <source>A shared encryption key with the name &quot;%1&quot; already exists.
Do you want to overwrite it?</source>
        <translation>Jaettu salausavain samalla nimellä &quot;%1&quot; on jo olemassa.
Haluatko korvata sen?</translation>
    </message>
    <message>
        <source>Do you want to update the information in %1 - %2?</source>
        <translation>Haluatko päivittää tiedot osoitteesta %1 - %2?</translation>
    </message>
    <message>
        <source>A request for deleting entry &quot;%1&quot; has been received.
Do you want to delete the entry?
</source>
        <translation>Vastaanotettiin pyyntö poistaa tietue &quot;%1&quot;.
Haluatko poistaa tietueen?
</translation>
    </message>
    <message>
        <source>%1 (Passkey)</source>
        <translation>%1 (suojausavain)</translation>
    </message>
    <message>
        <source>KeePassXC - Create a new group</source>
        <translation>KeePassXC - Luo uusi ryhmä</translation>
    </message>
    <message>
        <source>Disable</source>
        <translation>Kytke pois päältä</translation>
    </message>
    <message>
        <source>KeePassXC - Overwrite existing key?</source>
        <translation>KeePassXC - Korvataanko olemassa oleva avain?</translation>
    </message>
    <message>
        <source>KeePassXC - Update Entry</source>
        <translation>KeePassXC - Päivitä tietue</translation>
    </message>
    <message>
        <source>KeePassXC - Delete entry</source>
        <translation>KeePassXC - Poista tietue</translation>
    </message>
    <message>
        <source>KeePassXC - New key association request</source>
        <translation>KeePassXC - Uus avaimen liitospyyntö</translation>
    </message>
    <message>
        <source>Passkey</source>
        <translation>Suojausavain</translation>
    </message>
    <message>
        <source>KeePassXC - Passkey credentials</source>
        <translation>KeePassXC - Passkeyn tunnistetiedot</translation>
    </message>
    <message>
        <source>Register a new passkey to this entry:</source>
        <translation>Rekisteröi uusi passkey tähän tietueeseen:</translation>
    </message>
    <message>
        <source>KeePassXC - Update passkey</source>
        <translation>KeePassXC - Päivitä passkey</translation>
    </message>
    <message>
        <source>Entry already has a passkey.
Do you want to overwrite the passkey in %1 - %2?</source>
        <translation>Tietueella on jo passkey.
Haluatko ylikirjoittaa passkeyn %1 - %2?</translation>
    </message>
    <message>
        <source>Register</source>
        <translation>Rekisteröi</translation>
    </message>
</context>
<context>
    <name>BrowserSettingsWidget</name>
    <message>
        <source>Dialog</source>
        <translation>Dialogi</translation>
    </message>
    <message>
        <source>This is required for accessing your databases with KeePassXC-Browser</source>
        <translation>Tämä vaaditaan, jotta tietokantoja voidaan käyttää KeePassXC-Browser -selainlaajennuksella</translation>
    </message>
    <message>
        <source>Enable browser integration</source>
        <translation>Käytä selainintegraatiota</translation>
    </message>
    <message>
        <source>General</source>
        <translation>Yleistä</translation>
    </message>
    <message>
        <source>Enable integration for these browsers:</source>
        <translation>Käytä integraatiota seuraaville selaimille:</translation>
    </message>
    <message>
        <source>Vivaldi</source>
        <translation>Vivaldi</translation>
    </message>
    <message>
        <source>&amp;Edge</source>
        <translation>Edge</translation>
    </message>
    <message>
        <source>Firefox</source>
        <translation>Firefox</translation>
    </message>
    <message>
        <source>Tor Browser</source>
        <translation>Tor-selain</translation>
    </message>
    <message>
        <source>Brave</source>
        <translation>Brave</translation>
    </message>
    <message>
        <source>Google Chrome</source>
        <translation>Google Chrome</translation>
    </message>
    <message>
        <source>Chromium</source>
        <translation>Chromium</translation>
    </message>
    <message>
        <source>Show a notification when credentials are requested</source>
        <extracomment>Credentials mean login data requested via browser extension</extracomment>
        <translation>Näytä ilmoitus, kun tietueita pyydetään</translation>
    </message>
    <message>
        <source>Request to unlock the database if it is locked</source>
        <translation>Pyydä tietokannan avaamista, jos se on lukittu</translation>
    </message>
    <message>
        <source>Only entries with the same scheme (http://, https://, …) are returned.</source>
        <translation>Vain tietueet samalla skeemalla (http://, https://, ...) palautetaan.</translation>
    </message>
    <message>
        <source>Match URL scheme (e.g., https://example.com)</source>
        <translation>Sovita verkko-osoitteen kaavaan (esim. https://...)</translation>
    </message>
    <message>
        <source>Only returns the best matches for a specific URL instead of all entries for the whole domain.</source>
        <translation>Palauta vain parhaat osumat tietystä osoitteesta verkkotunnuksen kaikkien osumien sijasta</translation>
    </message>
    <message>
        <source>Return only best-matching credentials</source>
        <translation>Näytä vain sopivimmat tietueet</translation>
    </message>
    <message>
        <source>Returns expired credentials. String [expired] is added to the title.</source>
        <translation>Näytä vanhentuneet tietueet. Niiden nimiin lisätään teksti [vanhentunut]. </translation>
    </message>
    <message>
        <source>Allow returning expired credentials</source>
        <translation>Salli vanhentuneiden tietueiden näyttö</translation>
    </message>
    <message>
        <source>All databases connected to the extension will return matching credentials.</source>
        <translation>Salli tietueiden näyttö kaikista selainlaajennukseen yhdistetyistä tietokannoista.</translation>
    </message>
    <message>
        <source>Search in all opened databases for matching credentials</source>
        <extracomment>Credentials mean login data requested via browser extension</extracomment>
        <translation>Etsi sopivia tietueita kaikista avoimista tietokannoista</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>Lisäasetukset</translation>
    </message>
    <message>
        <source>Never ask before accessing credentials</source>
        <extracomment>Credentials mean login data requested via browser extension</extracomment>
        <translation>Älä koskaan vahvista tietueiden käyttöä</translation>
    </message>
    <message>
        <source>Never ask before updating credentials</source>
        <extracomment>Credentials mean login data requested via browser extension</extracomment>
        <translation>Älä koskaan vahvista tietueiden päivitystä</translation>
    </message>
    <message>
        <source>Do not ask permission for HTTP Basic Auth</source>
        <extracomment>An extra HTTP Basic Auth setting</extracomment>
        <translation>Älä kysy lupaa HTTP Basic -autentikaatioon</translation>
    </message>
    <message>
        <source>Automatically creating or updating string fields is not supported.</source>
        <translation>Automaattinen lisäjonokenttien luonti tai päivittäminen ei ole tuettu</translation>
    </message>
    <message>
        <source>Return advanced string fields which start with &quot;KPH: &quot;</source>
        <translation>Palauta lisämerkkijonot jotka alkavat &quot;KPH: &quot;</translation>
    </message>
    <message>
        <source>Don&apos;t display the popup suggesting migration of legacy KeePassHTTP settings.</source>
        <translation>Älä näytä ponnahdusikkunaa, joka ehdottaa vanhojen KeePassHTTP-asetuksien muuttamista uuteen muotoon.</translation>
    </message>
    <message>
        <source>Do not prompt for KeePassHTTP settings migration.</source>
        <translation>Älä näytä ponnahdusikkunaa, joka ehdottaa vanhojen KeePassHTTP-asetuksien muuttamista uuteen muotoon.</translation>
    </message>
    <message>
        <source>Updates KeePassXC or keepassxc-proxy binary path automatically to native messaging scripts on startup.</source>
        <translation>Päivittää KeePassXC:n tai välitysohjelman polun automaattisesti native messaging -rajapinnan skripteihin käynnistyksen yhteydessä</translation>
    </message>
    <message>
        <source>Update native messaging manifest files at startup</source>
        <translation>Päivitä native messaging -rajapinnan skriptit automaattisesti ohjelman käynnistyessä</translation>
    </message>
    <message>
        <source>Use a custom proxy location if you installed a proxy manually.</source>
        <translation>Käytä mukautettua välitysohjelmaa mikäli olet asentanut sellaisen manuaalisesti</translation>
    </message>
    <message>
        <source>Use a custom proxy location:</source>
        <comment>Meant is the proxy for KeePassXC-Browser</comment>
        <translation>Valitse mukautettu välitysohjelma:</translation>
    </message>
    <message>
        <source>Custom proxy location field</source>
        <translation>Mukautetun välitusohjelman sijainti</translation>
    </message>
    <message>
        <source>Browser for custom proxy file</source>
        <translation>Selaa mukautettua välitysohjelman tiedostoa</translation>
    </message>
    <message>
        <source>Browse…</source>
        <extracomment>Button for opening file dialog</extracomment>
        <translation>Selaa...</translation>
    </message>
    <message>
        <source>Use a custom browser configuration location:</source>
        <translation>Mukautetun välitusohjelman sijainti:</translation>
    </message>
    <message>
        <source>Browser type:</source>
        <translation>Selaimen tyyppi:</translation>
    </message>
    <message>
        <source>Toolbar button style</source>
        <translation>Työkalupalkin painiketyyli</translation>
    </message>
    <message>
        <source>Config Location:</source>
        <translation>Asetustiedoston sijainti:</translation>
    </message>
    <message>
        <source>Custom browser location field</source>
        <translation>Mukautetun selaimen sijaintikenttä</translation>
    </message>
    <message>
        <source>Browse for custom browser path</source>
        <translation>Selaa mukautetun selaimen polkua</translation>
    </message>
    <message>
        <source>Custom extension ID:</source>
        <translation>Mukautetun selainlaajennuksen ID:</translation>
    </message>
    <message>
        <source>Custom extension ID</source>
        <translation>Mukautetun selainlaajennuksen ID</translation>
    </message>
    <message>
        <source>Executable Files</source>
        <translation>Suoritettavat tiedostot</translation>
    </message>
    <message>
        <source>All Files</source>
        <translation>Kaikki tiedostot</translation>
    </message>
    <message>
        <source>Select custom proxy location</source>
        <translation>Valitse mukautettu välitysohjelma</translation>
    </message>
    <message>
        <source>Select native messaging host folder location</source>
        <translation>Valitse native messaging -isännän hakemiston sijainti</translation>
    </message>
    <message>
        <source>Allow keepassxc-proxy to list all entries with their title, URL and UUID in connected databases.</source>
        <translation>Salli keepassxc-proxyn listata kaikki yhdistettyjen tietokantojen merkinnät niiden otsikoilla, URL-osoitteilla ja UUID-tunnisteilla.</translation>
    </message>
    <message>
        <source>Allow limited access to all entries in connected databases (ignores site access restrictions)</source>
        <translation>Myönnä rajoitettu käyttöoikeus kaikkiin yhdistettyjen tietokantojen merkintöihin (ohittaa sivustokohtaiset rajoitukset)</translation>
    </message>
    <message>
        <source>&lt;b&gt;Warning:&lt;/b&gt; Only adjust these settings if necessary.</source>
        <translation>&lt;b&gt;Varoitus:&lt;/b&gt; Muuta näitä asetuksia vain tarvittaessa.</translation>
    </message>
    <message>
        <source>The custom proxy location does not exist.</source>
        <translation>Oman välityspalvelimen sijaintia ei löydy.</translation>
    </message>
    <message>
        <source>&lt;b&gt;Error:&lt;/b&gt; The custom proxy location does not exist. Correct this in the advanced settings tab.</source>
        <translation>&lt;b&gt;Error:&lt;/b&gt; Oman välityspalvelimen sijaintia ei ole olemassa. Korjaa tämä lisäasetukset-välilehdeltä.</translation>
    </message>
    <message>
        <source>&lt;b&gt;Error:&lt;/b&gt; The installed proxy executable is missing from the expected location: %1&lt;br/&gt;Please set a custom proxy location in the advanced settings or reinstall the application.</source>
        <translation>&lt;b&gt;Virhe:&lt;/b&gt; Asennetun välityspalvelimen sovellustiedostoa ei löydy odotetusta sijainnista: %1&lt;br/&gt;Määritä mukautetun välityspalvelimen sijainti lisäasetuksista tai asenna sovellus uudelleen.</translation>
    </message>
    <message>
        <source>Allows using insecure http://localhost with passkeys for testing purposes.</source>
        <translation>Sallii turvattoman http://localhost:in käyttämisen passkeyn kanssa testaamistarkoituksessa.</translation>
    </message>
    <message>
        <source>Allow using localhost with passkeys</source>
        <translation>Salli localhostin käyttö passkeyn kanssa</translation>
    </message>
    <message>
        <source>KeePassXC-Browser is needed for the browser integration to work. &lt;br /&gt;Download it for %1 and %2 and %3.</source>
        <translation>KeePassXC-Browser tarvitaan selainintegraation toimimista varten.&lt;br /&gt;Lataa se seuraaville selaimille: %1, %2 ja %3.</translation>
    </message>
    <message>
        <source>Browsers installed using Snap or Flatpak are not supported with exception to Firefox installed using Snap.</source>
        <translation>Selaimet jotka on asennettu käyttäen Snapia tai Flatpakia eivät ole tuettuja, lukuunottamatta Snapin kautta asennettua Firefoxia.</translation>
    </message>
</context>
<context>
    <name>CloneDialog</name>
    <message>
        <source>Clone Entry Options</source>
        <translation>Tietueen kloonausasetukset</translation>
    </message>
    <message>
        <source>Append &apos; - Clone&apos; to title</source>
        <translation>Lisää &apos; - Klooni&apos; otsikkoon</translation>
    </message>
    <message>
        <source>Replace username and password with references</source>
        <translation>Korvaa käyttäjätunnus ja salasana viittauksilla</translation>
    </message>
    <message>
        <source>Copy history</source>
        <translation>Kopiointihistoria</translation>
    </message>
</context>
<context>
    <name>CsvImportWidget</name>
    <message>
        <source>size, rows, columns</source>
        <translation>koko, rivit, sarakkeet</translation>
    </message>
    <message>
        <source>Column Association</source>
        <translation>Sarakkeen liitos</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Salasana</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>Käyttäjätunnus</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>Otsikko</translation>
    </message>
    <message>
        <source>Group</source>
        <translation>Ryhmä</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>Notes</source>
        <translation>Muistiinpanot</translation>
    </message>
    <message>
        <source>TOTP</source>
        <translation>TOTP</translation>
    </message>
    <message>
        <source>Created</source>
        <translation>Luotu</translation>
    </message>
    <message>
        <source>Last Modified</source>
        <translation>Viimeksi muokattu</translation>
    </message>
    <message>
        <source>Icon</source>
        <translation>Kuvake</translation>
    </message>
    <message>
        <source>Encoding</source>
        <translation>Koodaus</translation>
    </message>
    <message>
        <source>Codec</source>
        <translation>Koodekki</translation>
    </message>
    <message>
        <source>Text is qualified by</source>
        <translation>Teksti on määritelty merkeillä</translation>
    </message>
    <message>
        <source>Text qualification</source>
        <translation>Tekstin määrittely</translation>
    </message>
    <message>
        <source>Fields are separated by</source>
        <translation>Kentät erottaa</translation>
    </message>
    <message>
        <source>Field separation</source>
        <translation>Kenttäerotus</translation>
    </message>
    <message>
        <source>Comments start with</source>
        <translation>Kommentit alkavat</translation>
    </message>
    <message>
        <source>Header lines skipped</source>
        <translation>Otsakerivejä ohitettu</translation>
    </message>
    <message>
        <source>Number of header lines to discard</source>
        <translation>Hylättävissä olevien otsakerivien lukumäärä</translation>
    </message>
    <message>
        <source>First line has field names</source>
        <translation>Ensimmäinen rivi sisältää kentän nimet</translation>
    </message>
    <message>
        <source>Consider &apos;\&apos; an escape character</source>
        <translation>Käsittele merkkiä &apos;\&apos; escape-merkkinä</translation>
    </message>
    <message>
        <source>Preview</source>
        <translation>Esikatselu</translation>
    </message>
    <message>
        <source>CSV import preview</source>
        <translation>CSV-tuonnin esikatselu</translation>
    </message>
    <message>
        <source>Not Present</source>
        <translation>Ei löydy</translation>
    </message>
    <message>
        <source>Column %1</source>
        <translation>Sarake %1</translation>
    </message>
    <message numerus="yes">
        <source>[%n more message(s) skipped]</source>
        <translation><numerusform>[%n more message(s) skipped]</numerusform><numerusform>[%n kappaletta viestejä ohitettiin]</numerusform></translation>
    </message>
    <message>
        <source>Failed to parse CSV file: %1</source>
        <translation>CSV-tiedoston jäsennys epäonnistui: %1</translation>
    </message>
    <message>
        <source>Imported from CSV file: %1</source>
        <translation>Tuotu CSV-tiedostosta: %1</translation>
    </message>
    <message>
        <source>No Title Selected</source>
        <translation>Otsikkoa ei ole valittu</translation>
    </message>
    <message>
        <source>No title column was selected, entries will be hard to tell apart.
Are you sure you want to import?</source>
        <translation>Tietueet voi olla hankala erottaa toisistaan, sillä otsikkosaraketta ei ole valittu.
Oletko varma, että haluat jatkaa tuontia?</translation>
    </message>
    <message>
        <source>Tags</source>
        <translation>Tagit</translation>
    </message>
</context>
<context>
    <name>CsvParserModel</name>
    <message numerus="yes">
        <source>%n row(s)</source>
        <comment>CSV row count</comment>
        <translation><numerusform>%n rivi</numerusform><numerusform>%n riviä</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>%n column(s)</source>
        <comment>CSV column count</comment>
        <translation><numerusform>%n sarake.</numerusform><numerusform>%n saraketta</numerusform></translation>
    </message>
</context>
<context>
    <name>Database</name>
    <message>
        <source>Passwords</source>
        <comment>Root group name</comment>
        <translation>Salasanat</translation>
    </message>
    <message>
        <source>File %1 does not exist.</source>
        <translation>Tiedostoa %1 ei ole.</translation>
    </message>
    <message>
        <source>Unable to open file %1.</source>
        <translation>Tiedostoa %1 ei voitu avata.</translation>
    </message>
    <message>
        <source>Error while reading the database: %1</source>
        <translation>Virhe tietokantaa luettaessa: %1</translation>
    </message>
    <message>
        <source>Could not save, database does not point to a valid file.</source>
        <translation>Tallennus ei onnistu. Tietokanta ei osoita validiin tiedostoon.</translation>
    </message>
    <message>
        <source>Database save is already in progress.</source>
        <translation>Tietokannan tallennus on jo käynnissä.</translation>
    </message>
    <message>
        <source>Could not save, database has not been initialized!</source>
        <translation>Tallennus ei onnistu, tietokantaa ei ole alustettu!</translation>
    </message>
    <message>
        <source>Database file has unmerged changes.</source>
        <translation>Tietokannalla on muutoksia joita ei ole yhdistetty.</translation>
    </message>
    <message>
        <source>%1
Backup database located at %2</source>
        <translation>%1
Tietokannan varmuuskopio paikannettu: %2</translation>
    </message>
    <message>
        <source>Key not transformed. This is a bug, please report it to the developers.</source>
        <translation>Avainmuunnosta ei voitu suorittaa. Ole hyvä ja ilmoita tästä virheestä sovelluksen kehittäjille.</translation>
    </message>
    <message>
        <source>Recycle Bin</source>
        <translation>Roskakori</translation>
    </message>
    <message>
        <source>Database file read error.</source>
        <translation>Tietokantatiedoston lukuvirhe.</translation>
    </message>
    <message>
        <source>No file path was provided.</source>
        <translation>Tiedostopolkua ei annettu.</translation>
    </message>
</context>
<context>
    <name>DatabaseOpenDialog</name>
    <message>
        <source>Unlock Database - KeePassXC</source>
        <translation>Avaa tietokanta - KeePassXC</translation>
    </message>
</context>
<context>
    <name>DatabaseOpenWidget</name>
    <message>
        <source>Unlock KeePassXC Database</source>
        <translation>Avaa KeePassXC-tietokannan lukitus</translation>
    </message>
    <message>
        <source>Enter Password:</source>
        <translation>Syötä salasana:</translation>
    </message>
    <message>
        <source>Password field</source>
        <translation>Salasanakenttä</translation>
    </message>
    <message>
        <source>Hardware key slot selection</source>
        <translation>Laiteavaimen paikan valinta</translation>
    </message>
    <message>
        <source>Key file to unlock the database</source>
        <translation>Avaintiedosto tietokannan avaukseen</translation>
    </message>
    <message>
        <source>Browse for key file</source>
        <translation>Selaa avaintiedostoa</translation>
    </message>
    <message>
        <source>Browse…</source>
        <translation>Selaa...</translation>
    </message>
    <message>
        <source>Unlock Database</source>
        <translation>Avaa tietokannan lukitus</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Peruuta</translation>
    </message>
    <message>
        <source>Unlock</source>
        <translation>Avaa tietokanta</translation>
    </message>
    <message>
        <source>Please present or touch your YubiKey to continue…</source>
        <translation>Ole hyvä ja käytä Yubikeyssä jatkaaksesi...</translation>
    </message>
    <message>
        <source>Database Version Mismatch</source>
        <translation>Tietokannan versio ei ole yhteensopiva</translation>
    </message>
    <message>
        <source>The database you are trying to open was most likely
created by a newer version of KeePassXC.

You can try to open it anyway, but it may be incomplete
and saving any changes may incur data loss.

We recommend you update your KeePassXC installation.</source>
        <translation>Tietokanta jota yrität avata on luultavasti
luotu uudemmalla KeePassXC:n versiolla.

Voit koittaa avata sen tästä huolimatta, mutta se
voi olla epäyhteensopiva ja muutoksien tallennus saattaa johtaa datan katoamiseen

KeePassXC:n päivitys uudempaan versioon on suositeltavaa.</translation>
    </message>
    <message>
        <source>Open database anyway</source>
        <translation>Avaa tietokanta tästä huolimatta</translation>
    </message>
    <message>
        <source>Database unlock canceled.</source>
        <translation>Peruutettiin tietokannan avaus.</translation>
    </message>
    <message>
        <source>Unlock failed and no password given</source>
        <translation>Avaus epäonnistui, eikä salasanaa ole annettu</translation>
    </message>
    <message>
        <source>Unlocking the database failed and you did not enter a password.
Do you want to retry with an &quot;empty&quot; password instead?

To prevent this error from appearing, you must go to &quot;Database Settings / Security&quot; and reset your password.</source>
        <translation>Tietokannan avaus epäonnistui, eikä salasanaa ole syötetty.
Haluat koittaa uudestaan tyhjällä salasanalla?

Jos et halua nähdä tätä virhettä uudestaan, mene &quot;Tietokannan asetukset / Turvallisuus&quot; ja muuta salasanaasi.</translation>
    </message>
    <message>
        <source>Retry with empty password</source>
        <translation>Yritä uudelleen tyhjällä salasanalla</translation>
    </message>
    <message>
        <source>Failed to open key file: %1</source>
        <translation>Avaintiedoston avaus epäonnistui: %1</translation>
    </message>
    <message>
        <source>Old key file format</source>
        <translation>Vanha avaintiedostomuoto</translation>
    </message>
    <message>
        <source>You are using an old key file format which KeePassXC may&lt;br&gt;stop supporting in the future.&lt;br&gt;&lt;br&gt;Please consider generating a new key file by going to:&lt;br&gt;&lt;strong&gt;Database &amp;gt; Database Security &amp;gt; Change Key File.&lt;/strong&gt;&lt;br&gt;</source>
        <translation>Käytät vanhaa avaintiedostomuotoa joka ei ole&lt;br&gt;tuettu tulevaisuudessa.&lt;br&gt;&lt;br&gt;Ole hyvä ja harkitse uuden avaintiedoston luomista menemällä:&lt;br&gt;&lt;strong&gt;Tietokanta / Tietokannan turvallisuus / Vaihda avaintiedosto&lt;/strong&gt;&lt;br&gt;</translation>
    </message>
    <message>
        <source>Don&apos;t show this warning again</source>
        <translation>Älä näytä tätä varoitusta uudelleen</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>Kaikki tiedostot</translation>
    </message>
    <message>
        <source>Key files</source>
        <translation>Avaintiedostot</translation>
    </message>
    <message>
        <source>Select key file</source>
        <translation>Valitse avaintiedosto</translation>
    </message>
    <message>
        <source>Cannot use database file as key file</source>
        <translation>Tietokantaa ei voida käyttää avaintiedostona</translation>
    </message>
    <message>
        <source>authenticate to access the database</source>
        <translation>käytä tietokantaa tunnistautumalla</translation>
    </message>
    <message>
        <source>Failed to authenticate with Quick Unlock: %1</source>
        <translation>Pika-avauksella tunnistautuminen epäonnistui: %1</translation>
    </message>
    <message>
        <source>Select Key File:</source>
        <translation>Valitse avaintiedosto:</translation>
    </message>
    <message>
        <source>&lt;p&gt;In addition to a password, you can use a secret file to enhance the security of your database. This file can be generated in your database&apos;s security settings.&lt;/p&gt;&lt;p&gt;This is &lt;strong&gt;not&lt;/strong&gt; your *.kdbx database file!&lt;/p&gt;</source>
        <translation>&lt;p&gt;Pääsalasanan lisäksi voit käyttää salaista tiedostoa tietokantasi tietoturvan vahvistamiseksi. Tämä tiedosto voidaan tarvittaessa luoda tietokantasi turvallisuusasetuksista.&lt;/p&gt;&lt;p&gt;Tämä salainen tiedosto &lt;strong&gt;ei&lt;/strong&gt; ole *.kdbx -tietokantatiedosto!&lt;/p&gt;</translation>
    </message>
    <message>
        <source>Use hardware key [Serial: %1]</source>
        <translation>Käytä laiteavainta [Sarjanumero: %1]</translation>
    </message>
    <message>
        <source>Use hardware key</source>
        <translation>Käytä laiteavainta</translation>
    </message>
    <message>
        <source>Your database file is NOT a key file!
If you don&apos;t have a key file or don&apos;t know what that is, you don&apos;t have to select one.</source>
        <translation>Tietokantatiedostosi EI ole avaintiedosto!
Jos sinulla ei ole avaintiedostoa, tai et tiedä mikä se on, sinun ei tarvitse valita sellaista.</translation>
    </message>
    <message>
        <source>KeePassXC database file selected</source>
        <translation>KeePassXC-tietokantatiedosto valittu</translation>
    </message>
    <message>
        <source>The file you selected looks like a database file.
A database file is NOT a key file!

Are you sure you want to continue with this file?.</source>
        <translation>Valitsemasi tiedosto näyttää tietokantatiedostolta.
Tietokantatiedosto EI ole avaintiedosto!

Oletko varma, että haluat jatkaa tämän tiedoston käyttämistä?</translation>
    </message>
    <message>
        <source>No hardware keys found.</source>
        <translation>Laiteavaimia ei havaittu.</translation>
    </message>
    <message>
        <source>Refresh Hardware Keys</source>
        <translation>Uudista laiteavaimet</translation>
    </message>
    <message>
        <source>Click to add a key file.</source>
        <translation>Klikkaa asettaaksesi avaintiedosto</translation>
    </message>
    <message>
        <source>Hardware keys found, but no slots are configured.</source>
        <translation>Laiteavaimia löytyy, mutta niille ei ole säädetty slotteja.</translation>
    </message>
    <message>
        <source>Press ESC again to close this database</source>
        <translation>Paina ESC:iä uudestaan sulkeaksesi tämän tietokannan.</translation>
    </message>
    <message>
        <source>I have a key file</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>DatabaseSettingWidgetMetaData</name>
    <message>
        <source>Passwords</source>
        <translation>Salasanat</translation>
    </message>
</context>
<context>
    <name>DatabaseSettingsDialog</name>
    <message>
        <source>General</source>
        <translation>Yleistä</translation>
    </message>
    <message>
        <source>Security</source>
        <translation>Turvallisuus</translation>
    </message>
    <message>
        <source>Database Credentials</source>
        <translation>Tietokannan tunnistetiedot</translation>
    </message>
    <message>
        <source>Encryption Settings</source>
        <translation>Salausasetukset</translation>
    </message>
    <message>
        <source>Browser Integration</source>
        <translation>Selainintegraatio</translation>
    </message>
    <message>
        <source>Maintenance</source>
        <translation>Ylläpito</translation>
    </message>
    <message>
        <source>KeeShare</source>
        <translation>KeeShare</translation>
    </message>
    <message>
        <source>Secret Service Integration</source>
        <translation>Secret Service -integraatio</translation>
    </message>
    <message>
        <source>Remote Sync</source>
        <translation>Etäsynkronointi</translation>
    </message>
    <message>
        <source>Database Settings: %1</source>
        <translation>Tietokannan asetukset: %1</translation>
    </message>
</context>
<context>
    <name>DatabaseSettingsWidgetBrowser</name>
    <message>
        <source>KeePassXC-Browser settings</source>
        <translation>KeePassXC-Browser -asetukset</translation>
    </message>
    <message>
        <source>Disconnect all browsers</source>
        <translation>Unohda kaikki selaimet</translation>
    </message>
    <message>
        <source>Forget all site-specific settings on entries</source>
        <translation>Unohda kaikki sivustokohtaiset asetukset tietueilta</translation>
    </message>
    <message>
        <source>Refresh database root group ID</source>
        <translation>Uudista tietokannan juuriryhmän ID</translation>
    </message>
    <message>
        <source>Stored keys</source>
        <translation>Tallennetut avaimet</translation>
    </message>
    <message>
        <source>Stored browser keys</source>
        <translation>Tallennetut selaimen avaimet</translation>
    </message>
    <message>
        <source>Remove selected key</source>
        <translation>Poista valittu avain</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Poista</translation>
    </message>
    <message>
        <source>Delete the selected key?</source>
        <translation>Poista valittu avain?</translation>
    </message>
    <message>
        <source>Do you really want to delete the selected key?
This may prevent connection to the browser plugin.</source>
        <translation>Haluatko poistaa valitun avaimen?
Tämä voi estää yhteyden selainlaajennukseen.</translation>
    </message>
    <message>
        <source>Key</source>
        <translation>Avain</translation>
    </message>
    <message>
        <source>Value</source>
        <translation>Arvo</translation>
    </message>
    <message>
        <source>Created</source>
        <translation>Luotu</translation>
    </message>
    <message>
        <source>Enable Browser Integration to access these settings.</source>
        <translation>Käytä selainintegraatiota käyttääksesi näitä asetuksia.</translation>
    </message>
    <message>
        <source>Do you really want to disconnect all browsers?
This may prevent connection to the browser plugin.</source>
        <translation>Haluatko todella unohtaa kaikki selaimet?
Tämä voi estää yhteyden selainlaajennukseen.</translation>
    </message>
    <message>
        <source>No shared encryption keys found in KeePassXC settings.</source>
        <translation>Jaettuja salausavaimia ei löytynyt KeePassXC:n asetuksista.</translation>
    </message>
    <message numerus="yes">
        <source>Successfully removed %n encryption key(s) from KeePassXC settings.</source>
        <translation><numerusform>%n salausavain poistettiin onnistuneesti KeePassXC:n asetuksista.</numerusform><numerusform>%n salausavainta poistettiin onnistuneesti KeePassXC:n asetuksista.</numerusform></translation>
    </message>
    <message>
        <source>Do you really want forget all site-specific settings on every entry?
Permissions to access entries will be revoked.</source>
        <translation>Haluatko todella unohtaa sivustokohtaiset asetuksista joka tietueelta?
Pääsy tietueisiin evätään.</translation>
    </message>
    <message>
        <source>Removing stored permissions…</source>
        <translation>Poistetaan talletettuja oikeuksia…</translation>
    </message>
    <message>
        <source>Abort</source>
        <translation>Keskeytä</translation>
    </message>
    <message numerus="yes">
        <source>Successfully removed permissions from %n entry(s).</source>
        <translation><numerusform>Poistettiin lupa %n tietueelta.</numerusform><numerusform>Poistettiin lupa %n tietueelta.</numerusform></translation>
    </message>
    <message>
        <source>The active database does not contain an entry with permissions.</source>
        <translation>Aktiivinen tietokanta ei sisällä yhtään tietuetta käyttöoikeuksien kanssa.</translation>
    </message>
    <message>
        <source>Refresh database ID</source>
        <translation>Uudista tietokannan ID</translation>
    </message>
    <message>
        <source>Do you really want refresh the database ID?
This is only necessary if your database is a copy of another and the browser extension cannot connect.</source>
        <translation>Haluatko todella uudistaa tietokannan ID:n?
Tämä on tarpeellista vain, jos tietokantasi on kloonattu toisesta ja selainintegraatio ei pysty yhdistämään siihen.</translation>
    </message>
    <message>
        <source>Convert legacy KeePassHTTP attributes to KeePassXC-Browser compatible custom data</source>
        <translation>Siirrä vanhat KeePassHTTP-attribuutit KeePassXC-Browser:in mukautettuihin tietoihin</translation>
    </message>
    <message>
        <source>No keys found</source>
        <translation>Avaimia ei löytynyt</translation>
    </message>
    <message>
        <source>Removed keys from database</source>
        <translation>Avaimet poistettiin tietokannasta</translation>
    </message>
    <message>
        <source>Removed permissions</source>
        <translation>Käyttöoikeudet poistettiin</translation>
    </message>
    <message>
        <source>No entry with permissions found!</source>
        <translation>Tietuetta käyttöoikeuksilla ei löytynyt!</translation>
    </message>
</context>
<context>
    <name>DatabaseSettingsWidgetDatabaseKey</name>
    <message>
        <source>Add additional protection…</source>
        <translation>Lisäsuojaus...</translation>
    </message>
    <message>
        <source>No password set</source>
        <translation>Salasanaa ei ole asetettu</translation>
    </message>
    <message>
        <source>WARNING! You have not set a password. Using a database without a password is strongly discouraged!

Are you sure you want to continue without a password?</source>
        <translation>VAROITUS! Et ole asettanut salasanaa. Tietokannan käyttöä ilman salasanaa ei suositella!

Oletko varma, että haluat jatkaa ilman salasanaa?</translation>
    </message>
    <message>
        <source>Continue without password</source>
        <translation>Jatka ilman salasanaa</translation>
    </message>
    <message>
        <source>No encryption key added</source>
        <translation>Salausavainta ei ole lisätty</translation>
    </message>
    <message>
        <source>You must add at least one encryption key to secure your database!</source>
        <translation>Ainakin yksi salausavain täytyy lisätä, jotta tietokanta pysyy suojassa!</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation>Tuntematon virhe</translation>
    </message>
    <message>
        <source>Failed to change database credentials</source>
        <translation>Tietokannan tunnistetietojen vaihto ei onnistu</translation>
    </message>
    <message>
        <source>Weak password</source>
        <translation>Heikko salasana</translation>
    </message>
    <message>
        <source>This is a weak password! For better protection of your secrets, you should choose a stronger password.</source>
        <translation>Tämä on heikko salsana! SInun tulisi valita vahvempi salsana tietojesi parempaa suojausta varten.</translation>
    </message>
    <message>
        <source>The provided password does not meet the minimum quality requirement.</source>
        <translation>Annettu salasana ei täytä laadullisia minimivaatimuksia.</translation>
    </message>
</context>
<context>
    <name>DatabaseSettingsWidgetEncryption</name>
    <message>
        <source>Decryption Time:</source>
        <translation>Salauksen purkuun kulunut aika:</translation>
    </message>
    <message>
        <source>Decryption time in seconds</source>
        <translation>Salauksen purkuun vaadittava aika sekunneissa</translation>
    </message>
    <message>
        <source>Higher values offer more protection, but opening the database will take longer.</source>
        <translation>Korkeat arvot lupaavat parempaa suojaa, mutta tietokannan avaus voi kestää pidempään.</translation>
    </message>
    <message>
        <source>Database format:</source>
        <translation>Tietokannan muoto:</translation>
    </message>
    <message>
        <source>Database format</source>
        <translation>Tietokannan muoto</translation>
    </message>
    <message>
        <source>Format cannot be changed: Your database uses KDBX 4 features</source>
        <translation>Tietokannan muotoa ei voitu muuttaa: Tietokanta käyttää KDBX 4:n ominaisuuksia</translation>
    </message>
    <message>
        <source>Unless you need to open your database with other programs, always use the latest format.</source>
        <translation>Käytä aina uusinta tietokannan muotoa, ellei tietokantaa ole tarpeellista avata myös muissa ohjelmissa.</translation>
    </message>
    <message>
        <source>Encryption Algorithm:</source>
        <translation>Salausalgoritmi:</translation>
    </message>
    <message>
        <source>Encryption algorithm</source>
        <translation>Salausalgoritmi</translation>
    </message>
    <message>
        <source>AES:  256 Bit   (default)</source>
        <translation>AES:  256 Bit   (oletus)</translation>
    </message>
    <message>
        <source>Twofish:  256 Bit</source>
        <translation>Twofish:  256 Bit</translation>
    </message>
    <message>
        <source>Key Derivation Function:</source>
        <translation>Avainmuunnosfunktio:</translation>
    </message>
    <message>
        <source>Key derivation function</source>
        <translation>Avainmuunnosfunktio</translation>
    </message>
    <message>
        <source>Transform rounds:</source>
        <translation>Muunnositeraatioita:</translation>
    </message>
    <message>
        <source>Transform rounds</source>
        <translation>Muunnoskierroksia</translation>
    </message>
    <message>
        <source>Memory Usage:</source>
        <translation>Muistin käyttö:</translation>
    </message>
    <message>
        <source>Memory usage</source>
        <translation>Muistin käyttö</translation>
    </message>
    <message>
        <source>Parallelism:</source>
        <translation>Rinnakkaisuus:</translation>
    </message>
    <message>
        <source>Parallelism</source>
        <translation>Rinnakkaisuus</translation>
    </message>
    <message>
        <source>KDBX 4 (recommended)</source>
        <translation>KDBX 4.0 (suositeltu)</translation>
    </message>
    <message>
        <source>KDBX 3</source>
        <translation>KDBX 3</translation>
    </message>
    <message>
        <source>Number of rounds too high</source>
        <comment>Key transformation rounds</comment>
        <translation>Iteraatioiden lukumäärä on liian suuri</translation>
    </message>
    <message>
        <source>You are using a very high number of key transform rounds with Argon2.

If you keep this number, your database may take hours, days, or even longer to open.</source>
        <translation>Käytät todella suurta lukua iteraatioiden määränä avaimen muunnoksen yhteydessä Argon2:lla.

Jos pidät tämän arvon, tietokannan avauksessa voi kestää tunteja tai päiviä (tai jopa pidempään)!</translation>
    </message>
    <message>
        <source>Understood, keep number</source>
        <translation>Ymmärrän, säilytä numero</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Peruuta</translation>
    </message>
    <message>
        <source>Number of rounds too low</source>
        <comment>Key transformation rounds</comment>
        <translation>Iteraatioiden lukumäärä on liian pieni</translation>
    </message>
    <message>
        <source>You are using a very low number of key transform rounds with AES-KDF.

If you keep this number, your database will not be protected from brute force attacks.</source>
        <translation>Käytät todella pientä lukua iteraatioiden määränä avaimen muunnoksessa AES-KDF:llä.

Jos pidät tämän arvon, tietokanta ei ole välttämättä turvattu brute force -hyökkäyksiä vastaan.</translation>
    </message>
    <message>
        <source>KDF unchanged</source>
        <translation>Avainmuunnosfunktio ei ole muuttunut</translation>
    </message>
    <message>
        <source>Failed to transform key with new KDF parameters; KDF unchanged.</source>
        <translation>Avaimen muunnos uusia KDF-parametreja käyttäen epäonnistui; KDF:ää ei muutettu.</translation>
    </message>
    <message numerus="yes">
        <source> MiB</source>
        <comment>Abbreviation for Mebibytes (KDF settings)</comment>
        <translation><numerusform>MiB</numerusform><numerusform>MiB</numerusform></translation>
    </message>
    <message numerus="yes">
        <source> thread(s)</source>
        <comment>Threads for parallel execution (KDF settings)</comment>
        <translation><numerusform>säie</numerusform><numerusform>säiettä</numerusform></translation>
    </message>
    <message>
        <source>Encryption Settings:</source>
        <translation>Salausasetukset:</translation>
    </message>
    <message>
        <source>Basic</source>
        <translation>Perus</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>Lisäasetukset</translation>
    </message>
</context>
<context>
    <name>DatabaseSettingsWidgetFdoSecrets</name>
    <message>
        <source>Exposed Entries</source>
        <translation>Avoimia tietueita</translation>
    </message>
    <message>
        <source>Don&apos;t expose this database</source>
        <translation>Älä näytä tätä tietokantaa</translation>
    </message>
    <message>
        <source>Expose entries under this group:</source>
        <translation>Näytä tietueet vain tästä ryhmästä:</translation>
    </message>
    <message>
        <source>Enable Secret Service to access these settings.</source>
        <translation>Ota Secret Service käyttöön päästäksesi näihin asetuksiin.</translation>
    </message>
</context>
<context>
    <name>DatabaseSettingsWidgetGeneral</name>
    <message>
        <source>Database Metadata</source>
        <translation>Tietokannan metatiedot</translation>
    </message>
    <message>
        <source>Database name:</source>
        <translation>Tietokannan nimi:</translation>
    </message>
    <message>
        <source>Database name field</source>
        <translation>Tietokannan nimikenttä</translation>
    </message>
    <message>
        <source>Database description:</source>
        <translation>Tietokannan kuvaus:</translation>
    </message>
    <message>
        <source>Database description field</source>
        <translation>Tietokannan kuvauskenttä</translation>
    </message>
    <message>
        <source>Default username:</source>
        <translation>Oletuarvoinen käyttäjätunnus:</translation>
    </message>
    <message>
        <source>Default username field</source>
        <translation>Oletusarvoisen käyttäjätunnuksen kenttä</translation>
    </message>
    <message>
        <source>History Settings</source>
        <translation>Historia-asetukset</translation>
    </message>
    <message>
        <source>Maximum number of history items per entry</source>
        <translation>Historiamerkintöjen maksimimäärä per tietue</translation>
    </message>
    <message>
        <source>Maximum size of history per entry</source>
        <translation>Historian koon maksimimäärä per tietue</translation>
    </message>
    <message>
        <source> MiB</source>
        <translation> Mt</translation>
    </message>
    <message>
        <source>Use recycle bin</source>
        <translation>Käytä roskakoria</translation>
    </message>
    <message>
        <source>Additional Database Settings</source>
        <translation>Tietokannan lisäasetukset</translation>
    </message>
    <message>
        <source>Enable compression (recommended)</source>
        <translation>Ota pakkaus käyttöön (suositeltu)</translation>
    </message>
    <message>
        <source>Delete Recycle Bin</source>
        <translation>Poista roskakori</translation>
    </message>
    <message>
        <source>Do you want to delete the current recycle bin and all its contents?
This action is not reversible.</source>
        <translation>Haluatko poistaa nykyisen roskakorin ja sen kaiken sisällön? Tämä toimenpide on peruuttamaton.</translation>
    </message>
    <message>
        <source> (old)</source>
        <translation>(vanha)</translation>
    </message>
    <message>
        <source>When saving this setting or editing an entry
the oldest history items of an entry will be
removed such that only the specified amount
of entries remain at most.</source>
        <translation>Kun tämä asetus tallennetaan tai tietuetta muokataan, poistetaan tietueen historian vanhimmat merkinnät, jolloin niitä säilytetään vain määritetty määrä.</translation>
    </message>
    <message>
        <source>Limit the amount of history items per entry to:</source>
        <translation>Rajoita tietueiden historiamerkintöjen määrää:</translation>
    </message>
    <message>
        <source>When saving this setting or editing an entry
the oldest history items of an entry will be
removed such that the remaining history items
add up to the specified amount at most.</source>
        <translation>Kun tämä asetus tallennetaan tai tietuetta muokataan, poistetaan tietueen historian vanhimmat merkinnät, jolloin niitä säilytetään vain määritetty määrä.</translation>
    </message>
    <message>
        <source>Limit the total size of history items per entry to:</source>
        <translation>Rajoita tietueiden historiamerkintöjen määrää:</translation>
    </message>
    <message>
        <source>Move entries to a recycle bin group
instead of deleting them from the database.
Entries deleted from the recycle bin are
removed from the database.</source>
        <translation>Siirrä tietueet roskakoriryhmään pysyvän poiston sijaan. Roskakorista poistetut tietueet poistetaan tietokannasta pysyvästi.</translation>
    </message>
    <message>
        <source>Autosave delay since last change</source>
        <translation>Muutosta seuraavan automaattitallennuksen viive</translation>
    </message>
    <message>
        <source>Autosave delay</source>
        <translation>Automaattitallennuksen viive</translation>
    </message>
    <message>
        <source>Autosave delay since last change in minutes</source>
        <translation>Muutosta seuraavan automaattitallennuksen minuuttiviive</translation>
    </message>
    <message>
        <source> min</source>
        <translation> minuuttia</translation>
    </message>
    <message>
        <source>Autosave delay since last change checkbox</source>
        <translation>Muutosta seuraavan automaattitallennuksen viiveen valintalaatikko</translation>
    </message>
    <message>
        <source>Public Database Metadata</source>
        <translation>Julkinen tietokanta-metadata</translation>
    </message>
    <message>
        <source>Warning: the following settings are not encrypted.</source>
        <translation>Varoitus: seuraavia asetuksia ei ole salattu.</translation>
    </message>
    <message>
        <source>Display name:</source>
        <translation>Näyttönimi:</translation>
    </message>
    <message>
        <source>Database public display name</source>
        <translation>Tietokannan julkinen näyttönimi</translation>
    </message>
    <message>
        <source>Display color:</source>
        <translation>Näyttöväri:</translation>
    </message>
    <message>
        <source>Database public display color chooser</source>
        <translation>Tietokannan julkisen näyttövärin valitsin</translation>
    </message>
    <message>
        <source>Clear</source>
        <translation>Tyhjennä</translation>
    </message>
    <message>
        <source>Display icon:</source>
        <translation>Näyttökuvake:</translation>
    </message>
    <message>
        <source>Select Database Icon</source>
        <translation>Valitse tietokantakuvake</translation>
    </message>
    <message>
        <source>Publicly visible display name used on the unlock dialog</source>
        <translation>Lukituksen avausikkunassa julkisesti näkyvä nimi</translation>
    </message>
    <message>
        <source>Publicly visible color used on the unlock dialog</source>
        <translation>Lukituksen avausikkunassa julkisesti näkyvä väri</translation>
    </message>
</context>
<context>
    <name>DatabaseSettingsWidgetKeeShare</name>
    <message>
        <source>Sharing</source>
        <translation>Jakaminen</translation>
    </message>
    <message>
        <source>Breadcrumb</source>
        <translation>Leipätiedosto</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Tyyppi</translation>
    </message>
    <message>
        <source>Path</source>
        <translation>Polku</translation>
    </message>
    <message>
        <source>Last Signer</source>
        <translation>Viimeinen allekirjoittaja</translation>
    </message>
    <message>
        <source>Certificates</source>
        <translation>Varmenteet</translation>
    </message>
    <message>
        <source> &gt; </source>
        <comment>Breadcrumb separator</comment>
        <translation>&gt;</translation>
    </message>
</context>
<context>
    <name>DatabaseSettingsWidgetMaintenance</name>
    <message>
        <source>Manage Custom Icons</source>
        <translation>Hallitse mukautettuja kuvakkeita</translation>
    </message>
    <message>
        <source>Delete selected icon(s)</source>
        <translation>Poista valitut kuvakkeet</translation>
    </message>
    <message>
        <source>Delete all custom icons not in use by any entry or group</source>
        <translation>Poista kaikki mukautetut kuvakkeet joita ei käytetä missään tietueessa tai ryhmässä</translation>
    </message>
    <message>
        <source>Purge unused icons</source>
        <translation>Poista käyttämättömät kuvakkeet</translation>
    </message>
    <message>
        <source>Confirm Deletion</source>
        <translation>Vahvista poisto</translation>
    </message>
    <message>
        <source>At least one of the selected icons is currently in use by at least one entry or group. The icons of all affected entries and groups will be replaced by the default icon. Are you sure you want to delete icons that are currently in use?</source>
        <translation>Vähintään yksi valituista kuvakkeista on käytössä ainakin yhdessä tietueessa tai ryhmässä. Nämä kuvakkeet korvataan vakiokuvakkeella. Oletko varma, että haluat poistaa käytössä olevat kuvakkeet?</translation>
    </message>
    <message>
        <source>Custom Icons Are In Use</source>
        <translation>Mukautetu kuvakkeet ovat käytössä</translation>
    </message>
    <message>
        <source>All custom icons are in use by at least one entry or group.</source>
        <translation>Kaikki mukautetut kuvakkeet ovat käytössä vähintään yhdessä tietueessa tai ryhmässä</translation>
    </message>
    <message>
        <source>Purged Unused Icons</source>
        <translation>Poista käyttämättömät kuvakkeet</translation>
    </message>
    <message numerus="yes">
        <source>Purged %n icon(s) from the database.</source>
        <translation><numerusform>Poista %1 kuvake tietokannasta.</numerusform><numerusform>Poista %n kuvaketta tietokannasta.</numerusform></translation>
    </message>
</context>
<context>
    <name>DatabaseSettingsWidgetMetaDataSimple</name>
    <message>
        <source>Database Name:</source>
        <translation>Tietokannan nimi:</translation>
    </message>
    <message>
        <source>Database name field</source>
        <translation>Tietokannan nimikenttä</translation>
    </message>
    <message>
        <source>Description:</source>
        <translation>Kuvaus:</translation>
    </message>
    <message>
        <source>Database description field</source>
        <translation>Tietokannan kuvauskenttä</translation>
    </message>
</context>
<context>
    <name>DatabaseSettingsWidgetRemote</name>
    <message>
        <source>Sync Commands</source>
        <translation>Synkronoinnin komennot</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Poista</translation>
    </message>
    <message>
        <source>Command Settings</source>
        <translation>Komentoasetukset</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nimi</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>Tallenna</translation>
    </message>
    <message>
        <source>Download</source>
        <translation>Lataa</translation>
    </message>
    <message>
        <source>Command:</source>
        <translation>Komento:</translation>
    </message>
    <message>
        <source>Download command field</source>
        <translation>Latauskomento epäonnistui</translation>
    </message>
    <message>
        <source>e.g.: &quot;sftp user@hostname&quot; or &quot;scp user@hostname:DatabaseOnRemote.kdbx {TEMP_DATABASE}&quot;</source>
        <translation>Esim. &quot;sftp user@hostname&quot; tai &quot;scp user@hostname:DatabaseOnRemote.kdbx {TEMP_DATABASE}&quot;</translation>
    </message>
    <message>
        <source>Input:</source>
        <translation>Syöte:</translation>
    </message>
    <message>
        <source>Download input field</source>
        <translation>Lataa syöte</translation>
    </message>
    <message>
        <source>Upload</source>
        <translation>Lähetä</translation>
    </message>
    <message>
        <source>Upload command field</source>
        <translation>Lähetä-komento epäonnistui</translation>
    </message>
    <message>
        <source>e.g.: &quot;sftp user@hostname&quot; or &quot;scp {TEMP_DATABASE} user@hostname:DatabaseOnRemote.kdbx&quot;</source>
        <translation>Esim. &quot;sftp user@hostname&quot; tai &quot;scp {TEMP_DATABASE user@hostname:DatabaseOnRemote.kdbx&quot;</translation>
    </message>
    <message>
        <source>Upload input field</source>
        <translation>Lähetyksen syöte</translation>
    </message>
    <message>
        <source>Name cannot be empty.</source>
        <translation>Nimi ei voi olla tyhjä.</translation>
    </message>
    <message>
        <source>Test</source>
        <translation>Testaa</translation>
    </message>
    <message>
        <source>Download command cannot be empty.</source>
        <translation>Latauskomento ei voi olla tyhjä.</translation>
    </message>
    <message>
        <source>Download failed with error: %1</source>
        <translation>Lataus epäonnistui virheellä:</translation>
    </message>
    <message>
        <source>Download finished, but file %1 could not be found.</source>
        <translation>Lataus päättyi, mutta tiedostoa %1 ei löydy.</translation>
    </message>
    <message>
        <source>Download successful.</source>
        <translation>Lataus onnistui.</translation>
    </message>
    <message>
        <source>Save Remote Settings</source>
        <translation>Tallenna asetukset</translation>
    </message>
    <message>
        <source>You have unsaved changes. Do you want to save them?</source>
        <translation>Sinulla on tallentamattomia asetuksia. Haluatko tallettaa ne?</translation>
    </message>
    <message>
        <source>e.g.:
get DatabaseOnRemote.kdbx {TEMP_DATABASE}
exit
---
{TEMP_DATABASE} is used as placeholder to store the database in a temporary location
The command has to exit. In case of `sftp` as last command `exit` has to be sent
            </source>
        <translation>Esim.
get DatabaseOnRemote.kdbx {TEMP_DATABASE}
exit
---
{TEMP_DATABASE} -muuttujaa käytetään paikkamerkkinä tietokannan välikaikaisena sijaintina.
Komennon täytyy suoriutua. `sftp` -komennon ollessa viimeinen komento, `exit` täytyy lähettää.
</translation>
    </message>
    <message>
        <source>e.g.:
put {TEMP_DATABASE} DatabaseOnRemote.kdbx
exit
---
{TEMP_DATABASE} is used as placeholder to store the database in a temporary location
The command has to exit. In case of `sftp` as last command `exit` has to be sent
            </source>
        <translation>Esim.
put {TEMP_DATABASE} DatabaseOnRemote.kdbx
exit
---
{TEMP_DATABASE} -muuttujaa käytetään paikkamerkkinä tietokannan välikaikaisena sijaintina.
Komennon täytyy suoriutua. `sftp` -komennon ollessa viimeinen komento, `exit` täytyy lähettää.
</translation>
    </message>
    <message>
        <source>Timeout:</source>
        <translation>Aikakatkaisu:</translation>
    </message>
    <message>
        <source> seconds</source>
        <translation> sekuntia</translation>
    </message>
</context>
<context>
    <name>DatabaseTabWidget</name>
    <message>
        <source>Database creation error</source>
        <translation>Tietokannan luomisvirhe</translation>
    </message>
    <message>
        <source>The created database has no key or KDF, refusing to save it.
This is definitely a bug, please report it to the developers.</source>
        <translation>Luodulla tietokannalla ei ole avainta tai avainmuunnosfunktiota, joten sitä ei voida tallentaa.
Tämä on selkeä virhe, joten ota yhteyttä kehittäjätiimiin.</translation>
    </message>
    <message>
        <source>KeePass 2 Database</source>
        <translation>KeePass 2 -tietokanta</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>Kaikki tiedostot</translation>
    </message>
    <message>
        <source>Open database</source>
        <translation>Avaa tietokanta</translation>
    </message>
    <message>
        <source>Failed to open %1. It either does not exist or is not accessible.</source>
        <translation>%1:n avaus epäonnistui. Sitä ei ole joko olemassa, tai siihen ei ole pääsyoikeutta.</translation>
    </message>
    <message>
        <source>CSV file</source>
        <translation>CSV-tiedosto</translation>
    </message>
    <message>
        <source>Merge database</source>
        <translation>Yhdistä tietokanta</translation>
    </message>
    <message>
        <source>Export database to CSV file</source>
        <translation>Vie tietokanta CSV-tiedostoon</translation>
    </message>
    <message>
        <source>Writing the CSV file failed.</source>
        <translation>CSV-tiedoston kirjoitus levylle epäonnistui.</translation>
    </message>
    <message>
        <source>Writing the HTML file failed.</source>
        <translation>HTML-tiedoston kirjoittaminen epäonnistui.</translation>
    </message>
    <message>
        <source>Export database to XML file</source>
        <translation>Vie tietokanta XML-tiedostoon</translation>
    </message>
    <message>
        <source>XML file</source>
        <translation>XML-tiedosto</translation>
    </message>
    <message>
        <source>Writing the XML file failed</source>
        <translation>XML-tiedoston tallennus epäonnistui</translation>
    </message>
    <message>
        <source>Export Confirmation</source>
        <translation>Viennin vahvistus</translation>
    </message>
    <message>
        <source>You are about to export your database to an unencrypted file. This will leave your passwords and sensitive information vulnerable! Are you sure you want to continue?</source>
        <translation>Olet viemässä tietokantaasi salaamattomaan tiedostoon. Tämä jättää salasanasi ja minkä tahansa arkaluontoisen tiedon haavoittuvaksi! Oletko varma, että haluat jatkaa?</translation>
    </message>
    <message>
        <source>%1 [Locked]</source>
        <comment>Database tab name modifier</comment>
        <translation>%1 [Lukittu]</translation>
    </message>
    <message>
        <source>%1 [Temporary]</source>
        <comment>Database tab name modifier</comment>
        <translation>%1 [Väliaikainen]</translation>
    </message>
</context>
<context>
    <name>DatabaseWidget</name>
    <message>
        <source>Searches and Tags</source>
        <translation>Haut ja tunnisteet</translation>
    </message>
    <message>
        <source>Searching…</source>
        <translation>Etsitään...</translation>
    </message>
    <message>
        <source>Shared group…</source>
        <translation>Jaettu ryhmä...</translation>
    </message>
    <message>
        <source>Confirm Auto-Type</source>
        <translation>Vahvista automaattitäydennys</translation>
    </message>
    <message>
        <source>Perform Auto-Type into the previously active window?</source>
        <translation>Suorita automaattitäydennys edelliseen aktiiviseen ikkunaan?</translation>
    </message>
    <message>
        <source>Execute command?</source>
        <translation>Suorita komento?</translation>
    </message>
    <message>
        <source>Do you really want to execute the following command?&lt;br&gt;&lt;br&gt;%1&lt;br&gt;</source>
        <translation>Haluatko varmasti suorittaa seuraavan komennon?&lt;br&gt;&lt;br&gt;%1&lt;br&gt;</translation>
    </message>
    <message>
        <source>Remember my choice</source>
        <translation>Muista valintani</translation>
    </message>
    <message>
        <source>Do you really want to move the group &quot;%1&quot; to the recycle bin?</source>
        <translation>Haluatko varmasti siirtää ryhmän &quot;%1&quot; roskakoriin?</translation>
    </message>
    <message>
        <source>Expired entries</source>
        <translation>Vanhentuneet tietueet</translation>
    </message>
    <message numerus="yes">
        <source>Entries expiring within %1 day(s)</source>
        <translation><numerusform>Tietueet jotka vanhenevat %1 päivässä</numerusform><numerusform>Tietueet jotka vanhenevat %1 päivässä</numerusform></translation>
    </message>
    <message>
        <source>No current database.</source>
        <translation>Ei nykyistä tietokantaa.</translation>
    </message>
    <message>
        <source>No source database, nothing to do.</source>
        <translation>Ei lähdetietokantaa, ei mitään tehtävää.</translation>
    </message>
    <message>
        <source>Search Results (%1)</source>
        <translation>Etsinnän tulokset (%1)</translation>
    </message>
    <message>
        <source>No Results</source>
        <translation>Ei tuloksia.</translation>
    </message>
    <message>
        <source>Enter a unique name or overwrite an existing search from the list:</source>
        <translation>Syötä yksilöllinen nimi tai korvaa listalla oleva aiempi haku:</translation>
    </message>
    <message>
        <source>Save Search</source>
        <translation>Tallenna haku</translation>
    </message>
    <message>
        <source>Lock Database?</source>
        <translation>Lukitse tietokanta?</translation>
    </message>
    <message>
        <source>You are editing an entry. Discard changes and lock anyway?</source>
        <translation>Muokkaat tietuetta. Hylkää muutokset ja lukitse silti?</translation>
    </message>
    <message>
        <source>&quot;%1&quot; was modified.
Save changes?</source>
        <translation>Tietuetta &quot;%1&quot; muokattiin.
Tallennetaanko muutokset?</translation>
    </message>
    <message>
        <source>Database was modified.
Save changes?</source>
        <translation>Tietokantaa on muokattu.
Tallenna muutokset?</translation>
    </message>
    <message>
        <source>Save changes?</source>
        <translation>Tallenna muutokset?</translation>
    </message>
    <message>
        <source>File has changed</source>
        <translation>Tiedosto on muuttunut</translation>
    </message>
    <message>
        <source>Disable safe saves?</source>
        <translation>Ota turvallinen tallennus pois käytöstä?</translation>
    </message>
    <message>
        <source>KeePassXC has failed to save the database multiple times. This is likely caused by file sync services holding a lock on the save file.
Disable safe saves and try again?</source>
        <translation>KeePassXC on epäonnistunut useaan otteeseen tietokannan tallentamisessa. Tämä johtuu luultavasti tiedostojen synkronoinnista, joka pitää tiedostoa lukittuna.
Ota turvallinen tallennus pois käytöstä ja yritä uudelleen?</translation>
    </message>
    <message>
        <source>Writing the database failed: %1</source>
        <translation>Tietokannan kirjoittaminen epäonnistui: %1</translation>
    </message>
    <message>
        <source>Passwords</source>
        <translation>Salasanat</translation>
    </message>
    <message>
        <source>Save database as</source>
        <translation>Tallenna tietokanta nimellä</translation>
    </message>
    <message>
        <source>KeePass 2 Database</source>
        <translation>KeePass 2 -tietokanta</translation>
    </message>
    <message>
        <source>Empty recycle bin?</source>
        <translation>Tyhjennetäänkö roskakori?</translation>
    </message>
    <message>
        <source>Are you sure you want to permanently delete everything from your recycle bin?</source>
        <translation>Haluatko varmasti tyhjentää kaiken pysyvästi roskakorista?</translation>
    </message>
    <message>
        <source>Could not find database file: %1</source>
        <translation>Tietokantatiedostoa ei löydy: %1</translation>
    </message>
    <message>
        <source>New Database</source>
        <translation>Uusi tietokanta</translation>
    </message>
    <message>
        <source>%1 [New Database]</source>
        <comment>Database tab name modifier</comment>
        <translation>%1 [Uusi tietokanta]</translation>
    </message>
    <message>
        <source>Remote Sync did not contain any download or upload commands.</source>
        <translation>Etäsynkronointi ei sisältänyt yhtään lataus- tai lähetyskomentoa.</translation>
    </message>
    <message>
        <source>Remote sync &apos;%1&apos; completed successfully!</source>
        <translation>Etäsynkronointi &apos;%1&apos; suoritettiin onnistuneesti!</translation>
    </message>
    <message>
        <source>Downloading...</source>
        <translation>Ladataan...</translation>
    </message>
    <message>
        <source>Uploading...</source>
        <translation>Lähetetään...</translation>
    </message>
    <message>
        <source>Remote sync &apos;%1&apos; failed: %2</source>
        <translation>Etäsynkronointi &apos;%1&apos; epäonnistui: %2</translation>
    </message>
    <message>
        <source>Syncing...</source>
        <translation>Synkronoidaan...</translation>
    </message>
    <message>
        <source>Error while saving database %1: %2</source>
        <translation>Tietokannan %1 tallennus epäonnistui: %2</translation>
    </message>
    <message>
        <source>Remove passkey from entry</source>
        <translation>Poista passkey tietueesta</translation>
    </message>
    <message>
        <source>Do you want to remove the passkey from this entry?</source>
        <translation>Haluatko poistaa passkeyn tästä tietueesta?</translation>
    </message>
    <message>
        <source>The database file &quot;%1&quot; was modified externally</source>
        <translation>Tietokantatiedostoa &quot;%1&quot; muokattiin ulkoisesti.</translation>
    </message>
    <message>
        <source>Do you want to load the changes?</source>
        <translation>Haluatko ladata muutokset?</translation>
    </message>
    <message>
        <source>Reloading database…</source>
        <translation>Uudelleen ladataan tietokantaa...</translation>
    </message>
    <message>
        <source>Reload canceled</source>
        <translation>Uudelleenlataus peruutettu</translation>
    </message>
    <message>
        <source>Reload successful</source>
        <translation>Uudelleenlataus onnistui</translation>
    </message>
    <message>
        <source>Reload pending user action…</source>
        <translation>Uudelleenlataus odottaa käyttäjän toimintoa...</translation>
    </message>
    <message>
        <source>The database file &quot;%1&quot; was modified externally.&lt;br&gt;How would you like to proceed?&lt;br&gt;&lt;br&gt;Merge all changes&lt;br&gt;Ignore the changes on disk until save&lt;br&gt;Discard unsaved changes</source>
        <translation>Tietokantatiedostoa &quot;%1&quot; muokattiin ulkoisesti.&lt;br&gt;Kuinka haluat edetä?&lt;br&gt;&lt;br&gt;Yhdistä kaikki muutokset&lt;br&gt;Ohita muutokset kunnes tallennat&lt;br&gt;Unohda tallentamattomat muutokset</translation>
    </message>
    <message>
        <source>The database file &quot;%1&quot; was modified externally.&lt;br&gt;How would you like to proceed?&lt;br&gt;&lt;br&gt;Merge all changes then save&lt;br&gt;Overwrite the changes on disk&lt;br&gt;Discard unsaved changes</source>
        <translation>Tietokantatiedostoa &quot;%1&quot; muokattiin ulkoisesti.&lt;br&gt;Kuinka haluat edetä?&lt;br&gt;&lt;br&gt;Yhdistä muutokset ja tallenna&lt;br&gt;Ylikirjoita muutokset&lt;br&gt;Peruuta tallentamattomat muutokset</translation>
    </message>
    <message>
        <source>Reload database</source>
        <translation>Lataa tietokanta uudelleen</translation>
    </message>
    <message>
        <source>Database file overwritten.</source>
        <translation>Tietokantatiedosto ylikirjoitettiin.</translation>
    </message>
    <message>
        <source>Database file on disk cannot be unlocked with current credentials.&lt;br&gt;Enter new credentials and/or present hardware key to continue.</source>
        <translation>Levyllä olevaa tietokantatiedostoa ei voida avata nykyisillä tunnuksilla.&lt;br&gt;Syötä uudet tunnukset tai liitä laiteavain jatkaaksesi.</translation>
    </message>
    <message>
        <source>Failed to save backup database: %1</source>
        <translation>Tietokannan varmuuskopion tallennus epäonnistui: %1</translation>
    </message>
    <message>
        <source>Confirm Delete Group</source>
        <translation>Varmista ryhmän poisto</translation>
    </message>
    <message>
        <source>Do you really want to permanently delete the group &quot;%1&quot;?</source>
        <translation>Haluatko varmasti poistaa pysyvästi ryhmän &quot;%1&quot;?</translation>
    </message>
    <message>
        <source>Confirm Recycle Group</source>
        <translation>Varmista roskakorin ryhmä</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>Tallenna</translation>
    </message>
    <message>
        <source>Save Database Backup</source>
        <translation>Tallenna tietokannan varmuuskopio</translation>
    </message>
    <message>
        <source>Successfully merged the selected database.</source>
        <translation>Valittu tietokanta yhdistettiin onnistuneesti.</translation>
    </message>
    <message>
        <source>No changes were made by the merge operation.</source>
        <translation>Yhdistystoiminto ei tehnyt mitään muutoksia.</translation>
    </message>
    <message>
        <source>Merge canceled, no changes were made.</source>
        <translation>Yhdistäminen peruutettin, muutoksia ei tehty.</translation>
    </message>
</context>
<context>
    <name>EditEntryAttachmentsDialog</name>
    <message>
        <source>Edit: %1</source>
        <translation>Muokkaa: %1</translation>
    </message>
</context>
<context>
    <name>EditEntryWidget</name>
    <message>
        <source>Entry</source>
        <translation>Tietue</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>Lisäasetukset</translation>
    </message>
    <message>
        <source>Icon</source>
        <translation>Kuvake</translation>
    </message>
    <message>
        <source>Auto-Type</source>
        <translation>Automaattisyöttö</translation>
    </message>
    <message>
        <source>Browser Integration</source>
        <translation>Selainintegraatio</translation>
    </message>
    <message>
        <source>&lt;empty URL&gt;</source>
        <translation>&lt;empty URL&gt;</translation>
    </message>
    <message>
        <source>Confirm Removal</source>
        <translation>Vahvista poistaminen</translation>
    </message>
    <message>
        <source>Are you sure you want to remove this URL?</source>
        <translation>Haluatko varmasti poistaa tämän URL:n?</translation>
    </message>
    <message>
        <source>Properties</source>
        <translation>Ominaisuudet</translation>
    </message>
    <message>
        <source>History</source>
        <translation>Historia</translation>
    </message>
    <message>
        <source>SSH Agent</source>
        <translation>SSH-agentti</translation>
    </message>
    <message>
        <source>n/a</source>
        <translation>ei saatavilla</translation>
    </message>
    <message>
        <source>Select private key</source>
        <translation>Valitse yksityinen avain</translation>
    </message>
    <message>
        <source>Entry history</source>
        <translation>Tietueiden historia</translation>
    </message>
    <message>
        <source>Add entry</source>
        <translation>Lisää tietue</translation>
    </message>
    <message>
        <source>Edit entry</source>
        <translation>Muokkaa tietuetta</translation>
    </message>
    <message>
        <source>Some Browser Integration settings are overridden by group settings.</source>
        <translation>Jotkin selainlaajennuksen asetukset ovat ylikirjoitettu ryhmäasetusten toimesta</translation>
    </message>
    <message>
        <source>Invalid Entry</source>
        <translation>Virheellinen tietue</translation>
    </message>
    <message>
        <source>An external merge operation has invalidated this entry.
Unfortunately, any changes made have been lost.</source>
        <translation>Ulkopuolinen yhdistämisoperaatio on muuttanut tämän tietueen virheelliseksi.
Valitettavasti kaikki siihen tehdyt muutokset ovat kadonneet.</translation>
    </message>
    <message>
        <source>Auto-Type Validation Error</source>
        <translation>Automaattitäydennyksen varmistusvirhe</translation>
    </message>
    <message>
        <source>An error occurred while validating the custom Auto-Type sequence:
%1
Would you like to correct it?</source>
        <translation>Tapahtui virhe automaattitäydennyksen varmistuksessa:
%1
Haluatko korjata sen?</translation>
    </message>
    <message>
        <source>An error occurred while validating the Auto-Type sequence for &quot;%1&quot;:
%2
Would you like to correct it?</source>
        <translation>Tapahtui virhe automaattitäydennyksen sekvenssin &quot;%1&quot; tarkistuksessa:
%2
Haluatko korjata sen?</translation>
    </message>
    <message>
        <source>Entry updated successfully.</source>
        <translation>Tietue päivitetty onnistuneesti.</translation>
    </message>
    <message>
        <source>Unsaved Changes</source>
        <translation>Tallentamattomia muutoksia</translation>
    </message>
    <message>
        <source>Would you like to save changes to this entry?</source>
        <translation>Haluatko tallentaa muutokset tähän tietueeseen?</translation>
    </message>
    <message>
        <source>New attribute</source>
        <translation>Uusi attribuutti</translation>
    </message>
    <message>
        <source>New attribute %1</source>
        <translation>Uusi attribuutti %1</translation>
    </message>
    <message>
        <source>Are you sure you want to remove this attribute?</source>
        <translation>Haluatko varmasti poistaa tämän attribuutin?</translation>
    </message>
    <message>
        <source>Reveal</source>
        <translation>Paljasta</translation>
    </message>
    <message>
        <source>[PROTECTED] Press Reveal to view or edit</source>
        <translation>[SUOJATTU] Klikkaa Paljasta näyttääksesi tai muokataksesi</translation>
    </message>
    <message>
        <source>Hide</source>
        <translation>Piilota</translation>
    </message>
    <message numerus="yes">
        <source>%n hour(s)</source>
        <translation><numerusform>%n tuntia</numerusform><numerusform>%n tunti</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>%n week(s)</source>
        <translation><numerusform>%n viikko</numerusform><numerusform>%n viikkoa</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>%n month(s)</source>
        <translation><numerusform>%n kuukausi</numerusform><numerusform>%n kuukautta</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>%n year(s)</source>
        <translation><numerusform>%n vuosi</numerusform><numerusform>%n vuotta</numerusform></translation>
    </message>
    <message>
        <source>Failed to decrypt SSH key, ensure password is correct.</source>
        <translation>SSH-avaimen purku epäonnistui. Varmista, että salasana on oikein.</translation>
    </message>
</context>
<context>
    <name>EditEntryWidgetAdvanced</name>
    <message>
        <source>Additional attributes</source>
        <translation>Lisäattribuutit</translation>
    </message>
    <message>
        <source>Attribute selection</source>
        <translation>Attribuutin valinta</translation>
    </message>
    <message>
        <source>Attribute value</source>
        <translation>Attribuutin arvo</translation>
    </message>
    <message>
        <source>Add a new attribute</source>
        <translation>Lisää uusi attribuutti</translation>
    </message>
    <message>
        <source>Add</source>
        <translation>Lisää</translation>
    </message>
    <message>
        <source>Remove selected attribute</source>
        <translation>Poista valittu attribuutti</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Poista</translation>
    </message>
    <message>
        <source>Edit attribute name</source>
        <translation>Muokkaa attribuutin nimeä</translation>
    </message>
    <message>
        <source>Edit Name</source>
        <translation>Muokkaa nimeä</translation>
    </message>
    <message>
        <source>Toggle attribute protection</source>
        <translation>Suojaa attribuutti</translation>
    </message>
    <message>
        <source>Protect</source>
        <translation>Suojattu</translation>
    </message>
    <message>
        <source>Show a protected attribute</source>
        <translation>Näytä suojattu attribuutti</translation>
    </message>
    <message>
        <source>Reveal</source>
        <translation>Paljasta</translation>
    </message>
    <message>
        <source>Attachments</source>
        <translation>Liitteet</translation>
    </message>
    <message>
        <source>If checked, the entry will not appear in reports like Health Check and HIBP even if it doesn&apos;t match the quality requirements.</source>
        <translation>Jos valittuna, tietue ei näy raporteissa, kuten diagnostiikassa tai HIBP:ssä, vaikka se ei läpäisisikään laatuvaatimuksia.</translation>
    </message>
    <message>
        <source>Exclude from database reports</source>
        <translation>Jätä tietokantaraporttien ulkopuolelle</translation>
    </message>
    <message>
        <source>Foreground Color:</source>
        <translation>Korostusväri:</translation>
    </message>
    <message>
        <source>Foreground color selection</source>
        <translation>Korostusvärin valinta</translation>
    </message>
    <message>
        <source>Background Color:</source>
        <translation>Taustaväri:</translation>
    </message>
    <message>
        <source>Background color selection</source>
        <translation>Taustavärin valinta</translation>
    </message>
</context>
<context>
    <name>EditEntryWidgetAutoType</name>
    <message>
        <source>Enable Auto-Type for this entry</source>
        <translation>Salli automaattisyöttö tälle tietueelle</translation>
    </message>
    <message>
        <source>Inherit default Auto-Type sequence from the group</source>
        <translation>Peri automaattisyötön oletussekvenssi ryhmältä</translation>
    </message>
    <message>
        <source>Use custom Auto-Type sequence:</source>
        <translation>Käytä mukautettua automaattisyötön sekvenssiä:</translation>
    </message>
    <message>
        <source>Custom Auto-Type sequence</source>
        <translation>Mukautettu automaattisyötön sekvenssi</translation>
    </message>
    <message>
        <source>Open Auto-Type help webpage</source>
        <translation>Avaa automaattitäydennyksen ohjesivusto</translation>
    </message>
    <message>
        <source>Window Associations</source>
        <translation>Ikkunoiden liitokset</translation>
    </message>
    <message>
        <source>Existing window associations</source>
        <translation>Jo olemassa olevat ikkunoiden liitokset</translation>
    </message>
    <message>
        <source>Add new window association</source>
        <translation>Lisää uusi ikkunan liitos</translation>
    </message>
    <message>
        <source>+</source>
        <comment>Add item</comment>
        <translation>+</translation>
    </message>
    <message>
        <source>Remove selected window association</source>
        <translation>Poista valittu ikkunaliitos</translation>
    </message>
    <message>
        <source>-</source>
        <comment>Remove item</comment>
        <translation>-</translation>
    </message>
    <message>
        <source>Window title:</source>
        <translation>Ikkunan otsikko:</translation>
    </message>
    <message>
        <source>You can use an asterisk (*) to match everything</source>
        <translation>Voit käyttää asteriskia (*) vastaamaan kaikkea mahdollista</translation>
    </message>
    <message>
        <source>Set the window association title</source>
        <translation>Aseta ikkunan liitoksen otsikko</translation>
    </message>
    <message>
        <source>You can use an asterisk to match everything</source>
        <translation>Voit käyttää asteriskia vastaamaan kaikkea mahdollista</translation>
    </message>
    <message>
        <source>Use a specific sequence for this association:</source>
        <translation>Käytä tiettyä sekvenssiä tälle liitokselle:</translation>
    </message>
    <message>
        <source>Custom Auto-Type sequence for this window</source>
        <translation>Mukautettu automaattisyötön sekvenssi tälle ikkunalle</translation>
    </message>
</context>
<context>
    <name>EditEntryWidgetBrowser</name>
    <message>
        <source>General</source>
        <translation>Yleistä</translation>
    </message>
    <message>
        <source>Hide this entry from the browser extension</source>
        <translation>Piilota tämä tietue selainlaajennuksesta</translation>
    </message>
    <message>
        <source>Skip Auto-Submit for this entry</source>
        <translation>Älä salli automaattisyöttöä tälle tietueelle</translation>
    </message>
    <message>
        <source>Use this entry only with HTTP Basic Auth</source>
        <translation>Käytä tietuetta vain HTTP Basic -autentikaatioon</translation>
    </message>
    <message>
        <source>Do not use this entry with HTTP Basic Auth</source>
        <translation>Älä käytä tätä tietuetta HTTP Basic -autentikaatioon</translation>
    </message>
    <message>
        <source>Add</source>
        <translation>Lisää</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Poista</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Muokkaa</translation>
    </message>
    <message>
        <source>These settings affect the entry&apos;s behaviour with the browser extension.</source>
        <translation>Nämä asetukset vaikuttavat tietueen käytökseen selainlaajennuksen kanssa.</translation>
    </message>
    <message>
        <source>Additional URLs</source>
        <translation>Lisäosoitteet</translation>
    </message>
    <message>
        <source>Only send this entry to the browser for HTTP Auth dialogs. If enabled, normal login forms will not show this entry for selection.</source>
        <translation>Lähetä tämä tietue vain HTTP-autentikaatiodialogeihin. Jos asetus on päällä, tavalliset kirjautumiskentät eivät näytä tätä tietuetta listassa.</translation>
    </message>
    <message>
        <source>Do not send this entry to the browser for HTTP Auth dialogs. If enabled, HTTP Auth dialogs will not show this entry for selection.</source>
        <translation>Älä lähetä tätä tietuetta HTTP-autentikaatiodialogeihin. Jos asetus on päällä, tämä tietue näkyy vain tavallisissa kirjautumiskentissä.</translation>
    </message>
</context>
<context>
    <name>EditEntryWidgetHistory</name>
    <message>
        <source>Entry history selection</source>
        <translation>Tietueen historiavalinta</translation>
    </message>
    <message>
        <source>Show entry at selected history state</source>
        <translation>Näytä tietue valitulla historiatilalla</translation>
    </message>
    <message>
        <source>Show</source>
        <translation>Näytä</translation>
    </message>
    <message>
        <source>Restore entry to selected history state</source>
        <translation>Palauta tietue valittuun historiatilaan</translation>
    </message>
    <message>
        <source>Restore</source>
        <translation>Palauta</translation>
    </message>
    <message>
        <source>Delete selected history state</source>
        <translation>Poista valittu historiatila</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Poista</translation>
    </message>
    <message>
        <source>Delete all history</source>
        <translation>Poista kaikki historia</translation>
    </message>
    <message>
        <source>Delete all</source>
        <translation>Poista kaikki</translation>
    </message>
</context>
<context>
    <name>EditEntryWidgetMain</name>
    <message>
        <source>Edit Entry</source>
        <translation>Muokkaa tietuetta</translation>
    </message>
    <message>
        <source>Notes field</source>
        <translation>Muistiinpanokenttä</translation>
    </message>
    <message>
        <source>Username field</source>
        <translation>Käyttäjätunnuksen kenttä</translation>
    </message>
    <message>
        <source>Expiration field</source>
        <translation>Vanhentumisajan kenttä</translation>
    </message>
    <message>
        <source>Expiration Presets</source>
        <translation>Vanhentumisajan valmiit asetukset</translation>
    </message>
    <message>
        <source>Expiration presets</source>
        <translation>Vanhentumisajan valmiit asetukset</translation>
    </message>
    <message>
        <source>Presets</source>
        <translation>Esiasetukset</translation>
    </message>
    <message>
        <source>Url field</source>
        <translation>Osoitekenttä</translation>
    </message>
    <message>
        <source>Download favicon for URL</source>
        <translation>Lataa favicon tälle URL:lle</translation>
    </message>
    <message>
        <source>Title field</source>
        <translation>Otsikkokenttä</translation>
    </message>
    <message>
        <source>Password field</source>
        <translation>Salasanakenttä</translation>
    </message>
    <message>
        <source>Toggle expiration</source>
        <translation>Ota vanhentumisaika käyttöön</translation>
    </message>
    <message>
        <source>Tags list</source>
        <translation>Tagilista</translation>
    </message>
    <message>
        <source>&amp;Username:</source>
        <translation>&amp;Käyttäjätunnus:</translation>
    </message>
    <message>
        <source>&amp;Title:</source>
        <translation>&amp;Nimi:</translation>
    </message>
    <message>
        <source>&amp;Password:</source>
        <translation>&amp;Salasana:</translation>
    </message>
    <message>
        <source>UR&amp;L:</source>
        <translation>UR&amp;L-osoite:</translation>
    </message>
    <message>
        <source>&amp;Notes:</source>
        <translation>&amp;Merkinnät:</translation>
    </message>
    <message>
        <source>Toggle notes visibility</source>
        <translation>Kytke muistiinpanojen näyttö</translation>
    </message>
    <message>
        <source>T&amp;ags:</source>
        <translation>T&amp;unnisteet:</translation>
    </message>
    <message>
        <source>&amp;Expires:</source>
        <translation>Vanhentuu:</translation>
    </message>
</context>
<context>
    <name>EditEntryWidgetSSHAgent</name>
    <message>
        <source>Form</source>
        <translation>Lomake</translation>
    </message>
    <message>
        <source>Remove key from agent when database is closed/locked</source>
        <translation>Poista avain agentista kun tietokanta suljetaan/lukitaan</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>Kommentti</translation>
    </message>
    <message>
        <source>Add key to agent when database is opened/unlocked</source>
        <translation>Lisää avain agenttiin kun tietokanta avataan/lukitaan</translation>
    </message>
    <message>
        <source>Decrypt</source>
        <translation>Pura salaus</translation>
    </message>
    <message>
        <source>Fingerprint</source>
        <translation>Sormenjälki</translation>
    </message>
    <message>
        <source>Copy to clipboard</source>
        <translation>Kopioi leikepöydälle</translation>
    </message>
    <message>
        <source>Public key</source>
        <translation>Julkinen avain</translation>
    </message>
    <message>
        <source>Private key</source>
        <translation>Yksityinen avain</translation>
    </message>
    <message>
        <source>Attachment</source>
        <translation>Liite</translation>
    </message>
    <message>
        <source>External key file</source>
        <translation>Ulkoinen avaintiedosto</translation>
    </message>
    <message>
        <source>Add to agent</source>
        <translation>Lisää agenttiin</translation>
    </message>
    <message>
        <source>Remove from agent</source>
        <translation>Poista agentista</translation>
    </message>
    <message>
        <source>External file</source>
        <translation>Ulkoinen tiedosto</translation>
    </message>
    <message>
        <source>Browser for key file</source>
        <translation>Selaa avaintiedostoa</translation>
    </message>
    <message>
        <source>Browse…</source>
        <extracomment>Button for opening file dialog</extracomment>
        <translation>Selaa...</translation>
    </message>
    <message>
        <source>Generate</source>
        <translation>Luo</translation>
    </message>
    <message>
        <source>Select attachment file</source>
        <translation>Valitse liitetiedosto</translation>
    </message>
    <message>
        <source>Require user confirmation when this key is used</source>
        <translation>Vaadi käyttäjävahvistusta kun avainta käytetään</translation>
    </message>
    <message>
        <source>n/a</source>
        <translation>ei saatavilla</translation>
    </message>
    <message>
        <source>Remove key from agent after</source>
        <translation>Poista avain agentista kun on kulunut</translation>
    </message>
    <message>
        <source>Remove key from agent after specified seconds</source>
        <translation>Poista avain agentista tietyn sekuntiajan jälkeen</translation>
    </message>
    <message>
        <source> seconds</source>
        <translation> sekuntia</translation>
    </message>
    <message>
        <source>Clear agent</source>
        <translation>Tyhjennä agentti</translation>
    </message>
</context>
<context>
    <name>EditGroupWidget</name>
    <message>
        <source>Group</source>
        <translation>Ryhmä</translation>
    </message>
    <message>
        <source>Icon</source>
        <translation>Kuvake</translation>
    </message>
    <message>
        <source>Properties</source>
        <translation>Ominaisuudet</translation>
    </message>
    <message>
        <source>Add group</source>
        <translation>Lisää ryhmä</translation>
    </message>
    <message>
        <source>Edit group</source>
        <translation>Muokkaa ryhmää</translation>
    </message>
    <message>
        <source>Group has unsaved changes</source>
        <translation>Ryhmällä on tallentamattomia muutoksia</translation>
    </message>
    <message>
        <source>Browser Integration</source>
        <translation>Selainintegraatio</translation>
    </message>
    <message>
        <source>Enable</source>
        <translation>Kytke päälle</translation>
    </message>
    <message>
        <source>Disable</source>
        <translation>Kytke pois päältä</translation>
    </message>
    <message>
        <source>Inherit from parent group (%1)</source>
        <translation>Peri ylemmältä ryhmältä (%1)</translation>
    </message>
</context>
<context>
    <name>EditGroupWidgetBrowser</name>
    <message>
        <source>These settings affect to the group&apos;s behaviour with the browser extension.</source>
        <translation>Nämä asetukset vaikuttavat ryhmän toimintaan selainlaajennuksen kanssa.</translation>
    </message>
    <message>
        <source>Hide entries from browser extension:</source>
        <translation>Piilota tietueet selainlaajennuksesta:</translation>
    </message>
    <message>
        <source>Hide entries from browser extension toggle for this and sub groups</source>
        <translation>Piilota tietueet selainlaajennuksesta -asetus tälle ryhmälle ja sen aliryhmille</translation>
    </message>
    <message>
        <source>Skip Auto-Submit for entries:</source>
        <translation>Älä salli automaattisyöttöä näille tietueille:</translation>
    </message>
    <message>
        <source>Skip Auto-Submit toggle for this and sub groups</source>
        <translation>Automaattisyötön ohitus tälle ryhmälle ja aliryhmille</translation>
    </message>
    <message>
        <source>Use entries only with HTTP Basic Auth:</source>
        <translation>Käytä tietueita vain HTTP Basic -autentikaatioon:</translation>
    </message>
    <message>
        <source>Only HTTP Auth toggle for this and sub groups</source>
        <translation>Käytä vain HTTP Basic -autentikaatiota tälle ryhmälle ja aliryhmille</translation>
    </message>
    <message>
        <source>Do not use entries with HTTP Basic Auth:</source>
        <translation>Älä käytä tietueita HTTP Basic -autentikaatioon:</translation>
    </message>
    <message>
        <source>Do not use HTTP Auth toggle for this and sub groups</source>
        <translation>Älä käytä HTTP Basic -autentikaatiota tälle ryhmälle ja aliryhmille</translation>
    </message>
    <message>
        <source>Omit WWW subdomain from matching:</source>
        <translation>Älä huomioi WWW-aliverkkotunnusta tunnistuksessa:</translation>
    </message>
    <message>
        <source>Omit WWW subdomain from matching toggle for this and sub groups</source>
        <translation>WWW-aliverkkotunnuksen tunnistuskäytön kytkentä tälle ja aliryhmille</translation>
    </message>
    <message>
        <source>Restrict matching to given browser key:</source>
        <translation>Rajoita tunnistus annettuun selainavaimeen:</translation>
    </message>
    <message>
        <source>Restrict matching to given browser key toggle for this and sub groups</source>
        <translation>Tunnistuksen annettuun selainavaimeen rajoituksen kytkentä tälle ja aliryhmille</translation>
    </message>
</context>
<context>
    <name>EditGroupWidgetKeeShare</name>
    <message>
        <source>Sharing mode field</source>
        <translation>Jakotavan kenttä</translation>
    </message>
    <message>
        <source>Password field</source>
        <translation>Salasanakenttä</translation>
    </message>
    <message>
        <source>Type:</source>
        <translation>Tyyppi:</translation>
    </message>
    <message>
        <source>Password:</source>
        <translation>Salasana:</translation>
    </message>
    <message>
        <source>Path:</source>
        <translation>Polku:</translation>
    </message>
    <message>
        <source>Path to share file field</source>
        <translation>Jakotiedoston sijainnin kenttä</translation>
    </message>
    <message>
        <source>Browse for share file</source>
        <translation>Selaa jakotiedostoa</translation>
    </message>
    <message>
        <source>Browse…</source>
        <translation>Selaa...</translation>
    </message>
    <message>
        <source>Clear fields</source>
        <translation>Tyhjennä kentät</translation>
    </message>
    <message>
        <source>Clear</source>
        <translation>Tyhjennä</translation>
    </message>
    <message>
        <source>Inactive</source>
        <translation>Toimeton</translation>
    </message>
    <message>
        <source>Import</source>
        <translation>Tuo</translation>
    </message>
    <message>
        <source>Export</source>
        <translation>Vie</translation>
    </message>
    <message>
        <source>Synchronize</source>
        <translation>Synkronoi</translation>
    </message>
    <message>
        <source>Your KeePassXC version does not support sharing this container type.
Supported extensions are: %1.</source>
        <translation>KeePassXC-versiosi ei tue jakamista tällä säiliötyypillä.
Tuetut tyypit ovat: %1.</translation>
    </message>
    <message>
        <source>%1 is already being exported by this database.</source>
        <translation>%1 on jo viety tästä tietokannasta.</translation>
    </message>
    <message>
        <source>%1 is already being imported by this database.</source>
        <translation>%1 on jo tuotu tästä tietokannasta.</translation>
    </message>
    <message>
        <source>%1 is being imported and exported by different groups in this database.</source>
        <translation>%1 on tuotu ja viety eri ryhmästä tästä tietokannasta.</translation>
    </message>
    <message>
        <source>KeeShare is currently disabled. You can enable import/export in the application settings.</source>
        <comment>KeeShare is a proper noun</comment>
        <translation>KeeShare ei ole tällä hetkellä käytössä. Voit ottaa tuonnin/viennin käyttöön sovelluksen asetuksista.</translation>
    </message>
    <message>
        <source>Database export is currently disabled by application settings.</source>
        <translation>Tietokannan vienti on poistettu käytöstä sovelluksen asetuksista.</translation>
    </message>
    <message>
        <source>Database import is currently disabled by application settings.</source>
        <translation>Tietokannan tuonti on poistettu käytöstä sovelluksen asetuksista.</translation>
    </message>
    <message>
        <source>KeeShare container</source>
        <translation>KeeShare-säiliö</translation>
    </message>
    <message>
        <source>KeeShare signed container</source>
        <translation>KeeSharen allekirjoitettu säiliö</translation>
    </message>
    <message>
        <source>Select import source</source>
        <translation>Valitse tuonnin lähde</translation>
    </message>
    <message>
        <source>Select export target</source>
        <translation>Valitse viennin kohde</translation>
    </message>
    <message>
        <source>Select import/export file</source>
        <translation>Valitse tuonti-/vientitiedosto</translation>
    </message>
    <message>
        <source>Maintain group structure with shared database</source>
        <translation>Ylläpidä ryhmärakennetta jaetulla tietokannalla</translation>
    </message>
    <message>
        <source>Keep Group Structure</source>
        <translation>Säilytä ryhmärakenne</translation>
    </message>
</context>
<context>
    <name>EditGroupWidgetMain</name>
    <message>
        <source>Edit Group</source>
        <translation>Muokkaa ryhmää</translation>
    </message>
    <message>
        <source>Toggle expiration</source>
        <translation>Ota vanhentumisaika käyttöön</translation>
    </message>
    <message>
        <source>Expires:</source>
        <translation>Vanhentuu:</translation>
    </message>
    <message>
        <source>Name field</source>
        <translation>Nimikenttä</translation>
    </message>
    <message>
        <source>Expiration field</source>
        <translation>Vanhentumisajan kenttä</translation>
    </message>
    <message>
        <source>Use default Auto-Type sequence of parent group</source>
        <translation>Peri automaattisyötön sekvenssi emoryhmältä</translation>
    </message>
    <message>
        <source>Auto-Type:</source>
        <translation>Automaattisyöttö:</translation>
    </message>
    <message>
        <source>Search:</source>
        <translation>Etsi:</translation>
    </message>
    <message>
        <source>Auto-Type toggle for this and sub groups</source>
        <translation>Automaattisyötön päälle laittaminen tälle ryhmälle ja sen aliryhmille</translation>
    </message>
    <message>
        <source>Notes:</source>
        <translation>Muistiinpanot:</translation>
    </message>
    <message>
        <source>Default auto-type sequence field</source>
        <translation>Automaattisyötön sekvenssin oletuksen kenttä</translation>
    </message>
    <message>
        <source>Notes field</source>
        <translation>Muistiinpanokenttä</translation>
    </message>
    <message>
        <source>Name:</source>
        <translation>Nimi:</translation>
    </message>
    <message>
        <source>Set default Auto-Type sequence</source>
        <translation>Aseta automaattisyötön oletussekvenssi</translation>
    </message>
    <message>
        <source>Search toggle for this and sub groups</source>
        <translation>Haun päälle laittaminen tälle ryhmälle ja sen aliryhmille</translation>
    </message>
</context>
<context>
    <name>EditWidgetIcons</name>
    <message>
        <source>Use default icon</source>
        <translation>Käytä oletusikonia</translation>
    </message>
    <message>
        <source>Use custom icon</source>
        <translation>Käytä mukautettua ikonia</translation>
    </message>
    <message>
        <source>Choose icon…</source>
        <translation>Valitse ikoni...</translation>
    </message>
    <message>
        <source>Set the URL to use to search for a favicon</source>
        <translation>Aseta URL jota käytät faviconin etsimiseen</translation>
    </message>
    <message>
        <source>Favicon URL</source>
        <translation>Faviconin URL</translation>
    </message>
    <message>
        <source>Download favicon for URL</source>
        <translation>Lataa favicon tälle URL:lle</translation>
    </message>
    <message>
        <source>Download favicon</source>
        <translation>Lataa favicon</translation>
    </message>
    <message>
        <source>Apply selected icon to subgroups and entries</source>
        <translation>Lisää valittu ikoni aliryhmille ja sen tietueille</translation>
    </message>
    <message>
        <source>Apply icon to…</source>
        <translation>Käytä ikonia...</translation>
    </message>
    <message>
        <source>Apply to this group only</source>
        <translation>Käytä vain tässä ryhmässä</translation>
    </message>
    <message>
        <source>Also apply to child groups</source>
        <translation>Lisää myös aliryhmille</translation>
    </message>
    <message>
        <source>Also apply to child entries</source>
        <translation>Lisää myös lapsitietueille</translation>
    </message>
    <message>
        <source>Also apply to all children</source>
        <translation>Lisää kaikille lapsille</translation>
    </message>
    <message>
        <source>Unable to fetch favicon.</source>
        <translation>Faviconin noutaminen ei onnistu</translation>
    </message>
    <message>
        <source>Existing icon selected.</source>
        <translation>Jo olemassa oleva ikoni valittu.</translation>
    </message>
    <message>
        <source>Images</source>
        <translation>Kuvat</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>Kaikki tiedostot</translation>
    </message>
    <message>
        <source>Select Image(s)</source>
        <translation>Valitse kuva(t)</translation>
    </message>
    <message numerus="yes">
        <source>Successfully loaded %1 of %n icon(s)</source>
        <translation><numerusform>%1 ikoni kaikista (%n) ladattiin onnistuneesti</numerusform><numerusform>%1 ikonia kaikista (%n) ladattiin onnistuneesti</numerusform></translation>
    </message>
    <message>
        <source>No icons were loaded</source>
        <translation>Yhtään ikonia ei ladattu</translation>
    </message>
    <message numerus="yes">
        <source>%n icon(s) already exist in the database</source>
        <translation><numerusform>%n ikoni on jo tietokannassa</numerusform><numerusform>%n ikonia on jo tietokannassa</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>The following icon(s) failed:</source>
        <translation><numerusform>Seuraava ikoni epäonnistui:</numerusform><numerusform>Seuraavat ikonit epäonnistuivat:</numerusform></translation>
    </message>
    <message>
        <source>You can enable the DuckDuckGo website icon service under Application Settings -&gt; Security</source>
        <translation>Voit ottaa DuckDuckGon sivustokuvakepalvelun käyttöön sovelluksen suojausasetuksista</translation>
    </message>
</context>
<context>
    <name>EditWidgetProperties</name>
    <message>
        <source>Created:</source>
        <translation>Luotu:</translation>
    </message>
    <message>
        <source>Datetime created</source>
        <translation>Luomisen ajankohta</translation>
    </message>
    <message>
        <source>Modified:</source>
        <translation>Muokattu:</translation>
    </message>
    <message>
        <source>Datetime modified</source>
        <translation>Muokkauksen ajankohta</translation>
    </message>
    <message>
        <source>Uuid:</source>
        <translation>UUID:</translation>
    </message>
    <message>
        <source>Unique ID</source>
        <translation>Yksilökohtainen ID</translation>
    </message>
    <message>
        <source>Plugin Data</source>
        <translation>Liitännäistiedot</translation>
    </message>
    <message>
        <source>Plugin data</source>
        <translation>Liitännäistiedot</translation>
    </message>
    <message>
        <source>Remove selected plugin data</source>
        <translation>Poista liitännäistiedot</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Poista</translation>
    </message>
    <message>
        <source>Delete plugin data?</source>
        <translation>Poista liitännäistiedot?</translation>
    </message>
    <message>
        <source>Do you really want to delete the selected plugin data?
This may cause the affected plugins to malfunction.</source>
        <translation>Haluatko varmasti poistaa valitun liitännäistiedon?
Tämä voi vikaannuttaa tietoa käyttävän liitännäisen.</translation>
    </message>
    <message>
        <source>Key</source>
        <translation>Avain</translation>
    </message>
    <message>
        <source>Value</source>
        <translation>Arvo</translation>
    </message>
</context>
<context>
    <name>Entry</name>
    <message>
        <source>%1 - Clone</source>
        <translation>%1 - Klooni</translation>
    </message>
    <message>
        <source>Passkey</source>
        <translation>Passkey</translation>
    </message>
    <message>
        <source>Invalid conversion type: %1</source>
        <translation>Virheellinen muunnoksen tyyppi: %1</translation>
    </message>
    <message>
        <source>Invalid conversion syntax: %1</source>
        <translation>Virheellinen muutoksen syntaksi: %1</translation>
    </message>
    <message>
        <source>Invalid regular expression syntax %1
%2</source>
        <translation>Virheellinen Regex-syntaksi %1
%2</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>Otsikko</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>Käyttäjänimi</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Salasana</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>Osoite</translation>
    </message>
    <message>
        <source>Notes</source>
        <translation>Muistiinpanot</translation>
    </message>
    <message>
        <source>Custom Attributes</source>
        <translation>Mukautetut attribuutit</translation>
    </message>
    <message>
        <source>Icon</source>
        <translation>Kuvake</translation>
    </message>
    <message>
        <source>Color</source>
        <translation>Väri</translation>
    </message>
    <message>
        <source>Expiration</source>
        <translation>Vanhentumisaika</translation>
    </message>
    <message>
        <source>TOTP</source>
        <translation>TOTP</translation>
    </message>
    <message>
        <source>Custom Data</source>
        <translation>Mukautetut tiedot</translation>
    </message>
    <message>
        <source>Attachments</source>
        <translation>Liitetiedostot</translation>
    </message>
    <message>
        <source>Auto-Type</source>
        <translation>Automaattisyöttö</translation>
    </message>
    <message>
        <source>Tags</source>
        <translation>Tagit</translation>
    </message>
</context>
<context>
    <name>EntryAttachments</name>
    <message>
        <source>Cannot open file &quot;%1&quot;</source>
        <translation>Tiedostoa &quot;%1&quot; ei voitu avata</translation>
    </message>
</context>
<context>
    <name>EntryAttachmentsModel</name>
    <message>
        <source>Name</source>
        <translation>Nimi</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Koko</translation>
    </message>
</context>
<context>
    <name>EntryAttachmentsWidget</name>
    <message>
        <source>Form</source>
        <translation>Lomake</translation>
    </message>
    <message>
        <source>Attachments</source>
        <translation>Liitteet</translation>
    </message>
    <message>
        <source>Add new attachment</source>
        <translation>Lisää uusi liite</translation>
    </message>
    <message>
        <source>Remove selected attachment</source>
        <translation>Poista valittu liite</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Poista</translation>
    </message>
    <message>
        <source>Open selected attachment</source>
        <translation>Avaa valittu liite</translation>
    </message>
    <message>
        <source>Open</source>
        <translation>Avaa</translation>
    </message>
    <message>
        <source>Save selected attachment to disk</source>
        <translation>Tallenna valittu liite levylle</translation>
    </message>
    <message>
        <source>Select files</source>
        <translation>Valitse tiedostot</translation>
    </message>
    <message>
        <source>Confirm remove</source>
        <translation>Vahvista poisto</translation>
    </message>
    <message numerus="yes">
        <source>Are you sure you want to remove %n attachment(s)?</source>
        <translation><numerusform>Haluatko varmasti poistaa &amp;n liitettä?</numerusform><numerusform>Haluatko varmasti poistaa %n liitettä?</numerusform></translation>
    </message>
    <message>
        <source>Save attachments</source>
        <translation>Tallenna liitteet</translation>
    </message>
    <message>
        <source>Unable to create directory:
%1</source>
        <translation>Hakemiston luominen epäonnistui:
%1</translation>
    </message>
    <message>
        <source>Are you sure you want to overwrite the existing file &quot;%1&quot; with the attachment?</source>
        <translation>Haluatko varmasti korvata tiedoston &quot;%1&quot; tällä liitteellä?</translation>
    </message>
    <message>
        <source>Confirm overwrite</source>
        <translation>Vahvista korvaaminen</translation>
    </message>
    <message>
        <source>Unable to save attachments:
%1</source>
        <translation>Liitteiden tallentaminen epäonnistui:
%1</translation>
    </message>
    <message>
        <source>Unable to open attachment:
%1</source>
        <translation>Liitteen avaaminen epäonnistui:
%1</translation>
    </message>
    <message>
        <source>Unable to open attachments:
%1</source>
        <translation>Liitteiden avaaminen epäonnistui:
%1</translation>
    </message>
    <message numerus="yes">
        <source>Unable to open file(s):
%1</source>
        <translation><numerusform>Tiedostoa ei voitu avata:
%1</numerusform><numerusform>Tiedostoja ei voitu avata:
%1</numerusform></translation>
    </message>
    <message>
        <source>Confirm Overwrite Attachment</source>
        <translation>Varmista liitetiedoston ylikirjoitus</translation>
    </message>
    <message>
        <source>Confirm Attachment</source>
        <translation>Varmista liitetiedosto</translation>
    </message>
    <message>
        <source>%1 is a big file (%2 MB).
Your database may get very large and reduce performance.

Are you sure to add this file?</source>
        <translation>%1 on suurikokoinen tiedosto (%2 MB)
Tietokantasi voi kasvaa liian suureksi ja hidastua.

Oletko varma, että haluat lisätä tämän tiedoston?</translation>
    </message>
    <message>
        <source>Attachment modified</source>
        <translation>Liitetiedostoa on muutettu</translation>
    </message>
    <message>
        <source>The attachment '%1' was modified.
Do you want to save the changes to your database?</source>
        <translation>Liitetiedostoa &quot;%1&quot; on muokattu.
Haluatko tallentaa muutokset tietokantaan?</translation>
    </message>
    <message>
        <source>Saving attachment failed</source>
        <translation>Liitetiedoston tallennus epäonnistui</translation>
    </message>
    <message>
        <source>Saving updated attachment failed.
Error: %1</source>
        <translation>Päivitetyn liitetiedoston tallennus epäonnistui.
Virhe: %1</translation>
    </message>
    <message>
        <source>Attachment &quot;%1&quot; already exists. 
Would you like to overwrite the existing attachment?</source>
        <translation>Liitetiedosto &quot;%1&quot; on jo olemassa.
Haluatko ylikirjoittaa sen?</translation>
    </message>
    <message>
        <source>Preview</source>
        <translation>Esikatselu</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Muokkaa</translation>
    </message>
    <message>
        <source>New Text Document</source>
        <translation>Uusi tekstidokumentti</translation>
    </message>
    <message>
        <source>Add file…</source>
        <translation>Lisää tiedosto...</translation>
    </message>
    <message>
        <source>Load from Disk…</source>
        <translation>Lataa levyltä...</translation>
    </message>
    <message>
        <source>Save…</source>
        <translation>Tallenna...</translation>
    </message>
    <message>
        <source>New Attachment</source>
        <translation>Uusi liitetiedosto</translation>
    </message>
</context>
<context>
    <name>EntryAttributesModel</name>
    <message>
        <source>Name</source>
        <translation>Nimi</translation>
    </message>
</context>
<context>
    <name>EntryHistoryModel</name>
    <message>
        <source>Current (%1)</source>
        <translation>Tämän hetkinen (%1)</translation>
    </message>
    <message>
        <source>Last modified</source>
        <translation>Viimeksi muokattu</translation>
    </message>
    <message>
        <source>Age</source>
        <translation>Ikä</translation>
    </message>
    <message>
        <source>Difference</source>
        <translation>Eroavaisuus</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Koko</translation>
    </message>
</context>
<context>
    <name>EntryModel</name>
    <message>
        <source>Ref: </source>
        <comment>Reference abbreviation</comment>
        <translation>Viittaus: </translation>
    </message>
    <message>
        <source>Never</source>
        <translation>Ei koskaan</translation>
    </message>
    <message>
        <source>Group</source>
        <translation>Ryhmä</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>Otsikko</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>Käyttäjätunnus</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Salasana</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>Notes</source>
        <translation>Muistiinpanot</translation>
    </message>
    <message>
        <source>Expires</source>
        <translation>Erääntyy</translation>
    </message>
    <message>
        <source>Created</source>
        <translation>Luotu</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Muokattu</translation>
    </message>
    <message>
        <source>Attachments</source>
        <translation>Liitteet</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Koko</translation>
    </message>
    <message>
        <source>Group name</source>
        <translation>Ryhmän nimi</translation>
    </message>
    <message>
        <source>Entry title</source>
        <translation>Tietueen nimi</translation>
    </message>
    <message>
        <source>Password Strength</source>
        <translation>Salasanan vahvuus</translation>
    </message>
    <message>
        <source>Entry notes</source>
        <translation>Tietueen muistiinpanot</translation>
    </message>
    <message>
        <source>Entry expires at</source>
        <translation>Tietue vanhentuu</translation>
    </message>
    <message>
        <source>Creation date</source>
        <translation>Luomispäivämäärä</translation>
    </message>
    <message>
        <source>Last modification date</source>
        <translation>Edellisen muokkauksen päivämäärä</translation>
    </message>
    <message>
        <source>Attached files</source>
        <translation>Liitetiedostot</translation>
    </message>
    <message>
        <source>Entry size</source>
        <translation>Tietueen koko</translation>
    </message>
    <message>
        <source>Has attachments</source>
        <translation>Sisältää liitetiedostoja</translation>
    </message>
    <message>
        <source>Has TOTP</source>
        <translation>Sisältää TOTP:n</translation>
    </message>
    <message>
        <source>Background Color</source>
        <translation>Taustaväri</translation>
    </message>
    <message>
        <source>Group Path</source>
        <translation>Ryhmän polku</translation>
    </message>
</context>
<context>
    <name>EntryPreviewWidget</name>
    <message>
        <source>Display current TOTP value</source>
        <translation>Näytä nykyinen TOTP-arvo</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Sulje</translation>
    </message>
    <message>
        <source>General</source>
        <translation>Yleistä</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Salasana</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>Expiration</source>
        <translation>Vanhentumisaika</translation>
    </message>
    <message>
        <source>Tags</source>
        <translation>Tagit</translation>
    </message>
    <message>
        <source>Tags list</source>
        <translation>Tagilista</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>Käyttäjätunnus</translation>
    </message>
    <message>
        <source>Notes</source>
        <translation>Muistiinpanot</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>Lisäasetukset</translation>
    </message>
    <message>
        <source>Attachments</source>
        <translation>Liitteet</translation>
    </message>
    <message>
        <source>Attributes</source>
        <translation>Attribuutit</translation>
    </message>
    <message>
        <source>Autotype</source>
        <translation>Automaattisyöttö</translation>
    </message>
    <message>
        <source>Default Sequence</source>
        <translation>Oletussekvenssi</translation>
    </message>
    <message>
        <source>Window</source>
        <translation>Ikkuna</translation>
    </message>
    <message>
        <source>Sequence</source>
        <translation>Sekvenssi</translation>
    </message>
    <message>
        <source>Searching</source>
        <translation>Hakeminen</translation>
    </message>
    <message>
        <source>Share</source>
        <translation>Jaa</translation>
    </message>
    <message>
        <source>Search</source>
        <translation>Etsi</translation>
    </message>
    <message>
        <source>Clear</source>
        <translation>Tyhjennä</translation>
    </message>
    <message>
        <source>Never</source>
        <translation>Ei koskaan</translation>
    </message>
    <message>
        <source>Double click to copy value</source>
        <translation>Tuplaklikkaa kopioidaksesi arvo</translation>
    </message>
    <message>
        <source>Enabled</source>
        <translation>Käytössä</translation>
    </message>
    <message>
        <source>Disabled</source>
        <translation>Pois käytöstä</translation>
    </message>
    <message>
        <source>Double click to copy to clipboard</source>
        <translation>Kopioi leikepöydälle kaksoisklikkauksella</translation>
    </message>
</context>
<context>
    <name>EntryURLModel</name>
    <message>
        <source>Invalid URL</source>
        <translation>Virheellinen URL</translation>
    </message>
    <message>
        <source>Duplicate URL</source>
        <translation>Monista URL-osoite</translation>
    </message>
</context>
<context>
    <name>EntryView</name>
    <message>
        <source>Fit to window</source>
        <translation>Sovita ikkunaan</translation>
    </message>
    <message>
        <source>Fit to contents</source>
        <translation>Sovita sisältöön</translation>
    </message>
    <message>
        <source>Reset to defaults</source>
        <translation>Palauta oletusasetukset</translation>
    </message>
    <message numerus="yes">
        <source>+ %1 entry(s)...</source>
        <translation><numerusform>+ %1 tietue...</numerusform><numerusform>+ %1 tietuetta...</numerusform></translation>
    </message>
</context>
<context>
    <name>ExportDialog</name>
    <message>
        <source>Export options</source>
        <translation>Viennin asetukset</translation>
    </message>
    <message>
        <source>Sort entries by...</source>
        <translation>Järjestä tietueet...</translation>
    </message>
    <message>
        <source>You are about to export your database to an unencrypted file.
This will leave your passwords and sensitive information vulnerable!
</source>
        <translation>Olet viemässä tietokantaasi salaamattomaan tiedostoon.
Tämä jättää salasanasi ja minkä tahansa arkaluontoisen tiedon haavoittuvaksi!
</translation>
    </message>
    <message>
        <source>database order</source>
        <translation>tietokantojen järjestys</translation>
    </message>
    <message>
        <source>name (ascending)</source>
        <translation>nimi (nouseva)</translation>
    </message>
    <message>
        <source>name (descending)</source>
        <translation>nimi (laskeva)</translation>
    </message>
    <message>
        <source>Export database to HTML file</source>
        <translation>Vie tietokanta HTML-tiedostoon</translation>
    </message>
    <message>
        <source>HTML file</source>
        <translation>HTML-tiedosto</translation>
    </message>
    <message>
        <source>invalid sort order</source>
        <translation>virheellinen järjestys</translation>
    </message>
</context>
<context>
    <name>FdoSecrets::DBusMgr</name>
    <message>
        <source>Failed to deliver message</source>
        <translation>Viestiä ei voitu välittää</translation>
    </message>
    <message>
        <source>Failed to send reply on DBus</source>
        <translation>Vastausta ei voitu lähettää DBus:iin</translation>
    </message>
    <message>
        <source>Unknown</source>
        <comment>Unknown PID</comment>
        <translation>Tuntematon</translation>
    </message>
    <message>
        <source>Unknown</source>
        <comment>Unknown executable path</comment>
        <translation>Tuntematon</translation>
    </message>
    <message>
        <source>&lt;i&gt;PID: %1, Executable: %2&lt;/i&gt;</source>
        <comment>&lt;i&gt;PID: 1234, Executable: /path/to/exe&lt;/i&gt;</comment>
        <translation>&lt;i&gt;PID %1, Suoritettava tiedosto: %2&lt;/i&gt;</translation>
    </message>
    <message>
        <source>Another secret service is running (%1).&lt;br/&gt;Please stop/remove it before re-enabling the Secret Service Integration.</source>
        <translation>Toinen Secret Service -palvelu on jo käynnissä (%1).&lt;br/&gt;Ole hyvä ja pysäytä/poista se ennen kuin otat Secret Service -integraation käyttöön.</translation>
    </message>
    <message>
        <source>Failed to register DBus service at %1.&lt;br/&gt;</source>
        <translation>DBus-palvelun rekisteröinti epäonnistui %1.&lt;br/&gt;</translation>
    </message>
    <message>
        <source>Failed to register service on DBus at path &apos;%1&apos;</source>
        <translation>Palvelun rekisteröinti DBus:iin epäonnistui polussa: &apos;%1&apos;</translation>
    </message>
    <message>
        <source>Failed to register database on DBus under the name &apos;%1&apos;</source>
        <translation>Tietokannan rekisteröinti DBus-palveluun epäonnistui nimellä &apos;%1&apos;</translation>
    </message>
    <message>
        <source>Failed to register session on DBus at path &apos;%1&apos;</source>
        <translation>Istunnon rekisteröinti DBus:iin epäonnistui polussa &apos;%1&apos;</translation>
    </message>
    <message>
        <source>Failed to register item on DBus at path &apos;%1&apos;</source>
        <translation>Kohteen rekisteröinti DBus:iin epäonnistui polussa &apos;%1&apos;</translation>
    </message>
    <message>
        <source>Failed to register prompt object on DBus at path &apos;%1&apos;</source>
        <translation>Kehotuksen kohdetta ei voitu rekisteröidä DBus:iin polussa &apos;%1&apos;</translation>
    </message>
</context>
<context>
    <name>FdoSecrets::Item</name>
    <message>
        <source>Entry &quot;%1&quot; from database &quot;%2&quot; was used by %3</source>
        <translation>Tietuetta &quot;%1&quot; tietokannasta &quot;%2&quot; käytettiin %3:n toimesta</translation>
    </message>
</context>
<context>
    <name>FdoSecrets::Service</name>
    <message numerus="yes">
        <source>%n Entry(s) was used by %1</source>
        <comment>%1 is the name of an application</comment>
        <translation><numerusform>%1 tietuetta käytettiin %1:n toimesta</numerusform><numerusform>%1 tietuetta käytettiin %1:n toimesta</numerusform></translation>
    </message>
</context>
<context>
    <name>FdoSecrets::SettingsClientModel</name>
    <message>
        <source>Unknown</source>
        <translation>Tuntematon</translation>
    </message>
    <message>
        <source>Non-existing/inaccessible executable path. Please double-check the client is legit.</source>
        <translation>Suorituspolkua ei löydy. Tarkista asiakasohjelman todenperäisyys.</translation>
    </message>
</context>
<context>
    <name>FdoSecrets::SettingsDatabaseModel</name>
    <message>
        <source>Unlock to show</source>
        <translation>Avaa lukitus näyttääksesi</translation>
    </message>
    <message>
        <source>None</source>
        <translation>Ei mitään</translation>
    </message>
</context>
<context>
    <name>FdoSecrets::UnlockPrompt</name>
    <message>
        <source>%1 (PID: %2)</source>
        <translation>%1 (PID: %2)</translation>
    </message>
</context>
<context>
    <name>FdoSecretsPlugin</name>
    <message>
        <source>&lt;b&gt;Fdo Secret Service:&lt;/b&gt; %1</source>
        <translation>&lt;b&gt;Fdo Secret Service:&lt;/b&gt; %1</translation>
    </message>
</context>
<context>
    <name>GlobalShortcutsPortal</name>
    <message>
        <source>KeePassXC - Global Shortcuts</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>The XDG Desktop Portal for global shortcuts is not available on this system.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Global Auto-Type shortcut is already configured. To change it, open your system settings and navigate to the keyboard or application shortcuts section.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Trigger global Auto-Type</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>Group</name>
    <message>
        <source>[empty]</source>
        <comment>group has no children</comment>
        <translation>[tyhjä]</translation>
    </message>
    <message>
        <source>%1 - Clone</source>
        <translation>%1 - Klooni</translation>
    </message>
</context>
<context>
    <name>HibpDownloader</name>
    <message>
        <source>Online password validation failed</source>
        <translation>Salasanan varmistus netissä epäonnistui</translation>
    </message>
</context>
<context>
    <name>IconDownloaderDialog</name>
    <message>
        <source>Download Favicons</source>
        <translation>Lataa faviconit</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Peruuta</translation>
    </message>
    <message>
        <source>Having trouble downloading icons?
You can enable the DuckDuckGo website icon service in the security section of the application settings.</source>
        <translation>Onko kuvakkeiden latauksessa ongelmia?
Voit aktivoida DuckDuckGon kuvakepalvelun sovelluksen suojausasetuksista.</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Sulje</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Tila</translation>
    </message>
    <message>
        <source>Please wait, processing entry list…</source>
        <translation>Odota hetki, käsitellään tietuelistaa...</translation>
    </message>
    <message>
        <source>Downloading…</source>
        <translation>Ladataan...</translation>
    </message>
    <message>
        <source>Ok</source>
        <translation>Ok</translation>
    </message>
    <message>
        <source>Already Exists</source>
        <translation>On jo olemassa</translation>
    </message>
    <message>
        <source>Download Failed</source>
        <translation>Lataus epäonnistui</translation>
    </message>
    <message>
        <source>Downloading favicons (%1/%2)…</source>
        <translation>Ladataan faviconeja (%1/%2)...</translation>
    </message>
</context>
<context>
    <name>ImageAttachmentsWidget</name>
    <message>
        <source>Zoom:</source>
        <translation>Zoom:</translation>
    </message>
    <message>
        <source>Fit</source>
        <translation>Mahdusta</translation>
    </message>
</context>
<context>
    <name>ImportWizard</name>
    <message>
        <source>Import Wizard</source>
        <translation>Ohjattu tuonti</translation>
    </message>
</context>
<context>
    <name>ImportWizardPageReview</name>
    <message>
        <source>WizardPage</source>
        <translation>Ohjattu sivu</translation>
    </message>
    <message>
        <source>Entry count: %1</source>
        <translation>Tietueiden määrä: %1</translation>
    </message>
    <message>
        <source>Group</source>
        <translation>Ryhmä</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>Otsikko</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>Käyttäjätunnus</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Salasana</translation>
    </message>
    <message>
        <source>Url</source>
        <translation>Osoite</translation>
    </message>
    <message>
        <source>Could not load key file.</source>
        <translation>Avaintiedostoa ei voitu lukea.</translation>
    </message>
    <message>
        <source>Could not open remote database. Password or key file may be incorrect.</source>
        <translation>Etätietokantaa ei voitu avata. Salasana tai avaintiedosto on mahdollisesti virheellinen.</translation>
    </message>
</context>
<context>
    <name>ImportWizardPageSelect</name>
    <message>
        <source>Form</source>
        <translation>Lomake</translation>
    </message>
    <message>
        <source>Import File Selection</source>
        <translation>Tuontitiedoston valinta</translation>
    </message>
    <message>
        <source>Password:</source>
        <translation>Salasana:</translation>
    </message>
    <message>
        <source>Key File:</source>
        <translation>Avaintiedosto:</translation>
    </message>
    <message>
        <source>Browse…</source>
        <translation>Selaa...</translation>
    </message>
    <message>
        <source>Import Into:</source>
        <translation>Tuo kohteeseen:</translation>
    </message>
    <message>
        <source>New Database</source>
        <translation>Uusi tietokanta</translation>
    </message>
    <message>
        <source>No unlocked databases available</source>
        <translation>Ei auki olevia tietokantoja</translation>
    </message>
    <message>
        <source>Existing Database:</source>
        <translation>Olemassa oleva tietokanta:</translation>
    </message>
    <message>
        <source>Import File:</source>
        <translation>Tuontitiedosto:</translation>
    </message>
    <message>
        <source>Comma Separated Values (.csv)</source>
        <translation>Comma Separated Values (.csv)</translation>
    </message>
    <message>
        <source>1Password Export (.1pux)</source>
        <translation>1Password-vientitiedosto (.1pux)</translation>
    </message>
    <message>
        <source>1Password Vault (.opvault)</source>
        <translation>1Password-tietokanta (.opvault)</translation>
    </message>
    <message>
        <source>Bitwarden (.json)</source>
        <translation>Bitwarden (.json)</translation>
    </message>
    <message>
        <source>KeePass 1 Database (.kdb)</source>
        <translation>KeePass 1 -tietokanta (.kdb)</translation>
    </message>
    <message>
        <source>Open OPVault</source>
        <translation>Avaa OPVault</translation>
    </message>
    <message>
        <source>Select import file</source>
        <translation>Valitse tuontitiedosto</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>Kaikki tiedostot</translation>
    </message>
    <message>
        <source>Key files</source>
        <translation>Avaintiedostot</translation>
    </message>
    <message>
        <source>Select key file</source>
        <translation>Valitse avaintiedosto</translation>
    </message>
    <message>
        <source>Comma Separated Values</source>
        <translation>Comma Separated Values</translation>
    </message>
    <message>
        <source>1Password Export</source>
        <translation>1Password-vienti</translation>
    </message>
    <message>
        <source>Bitwarden JSON Export</source>
        <translation>Bitwarden JSON-vienti</translation>
    </message>
    <message>
        <source>1Password Vault</source>
        <translation>1Password-tietokanta</translation>
    </message>
    <message>
        <source>KeePass1 Database</source>
        <translation>KeePass1-tietokanta</translation>
    </message>
    <message>
        <source>Proton Pass (.json)</source>
        <translation>Proton Pass (.json)</translation>
    </message>
    <message>
        <source>Proton Pass JSON Export</source>
        <translation>Proton Pass -JSON-vienti</translation>
    </message>
    <message>
        <source>Temporary Database</source>
        <translation>Väliaikainen tietokanta</translation>
    </message>
    <message>
        <source>Command:</source>
        <translation>Komento:</translation>
    </message>
    <message>
        <source>e.g.: &quot;sftp user@hostname&quot; or &quot;scp user@hostname:DatabaseOnRemote.kdbx {TEMP_DATABASE}&quot;</source>
        <translation>Esim. &quot;sftp user@hostname&quot; tai &quot;scp user@hostname:DatabaseOnRemote.kdbx {TEMP_DATABASE}&quot;</translation>
    </message>
    <message>
        <source>Input:</source>
        <translation>Syöte:</translation>
    </message>
    <message>
        <source>e.g.:
get DatabaseOnRemote.kdbx {TEMP_DATABASE}
exit
---
{TEMP_DATABASE} is used as placeholder to store the database in a temporary location
The command has to exit. In case of `sftp` as last commend `exit` has to be sent
         </source>
        <translation>Esimerkiksi:
get DatabaseOnRemote.kdbx {TEMP_DATABASE}
exit
---
{TEMP_DATABASE}:a käytetään paikkamerkkinä tietokannan väliaikaiseen tallennuksen sijaintiin
Komennon täytyy poistua. `sftp`:n tapauksessa viimeinen komento `exit` täytyy lähettää
</translation>
    </message>
    <message>
        <source>Remote Database (.kdbx)</source>
        <translation>Etätietokanta (.kdbx)</translation>
    </message>
</context>
<context>
    <name>KMessageWidget</name>
    <message>
        <source>&amp;Close</source>
        <translation>&amp;Sulje</translation>
    </message>
    <message>
        <source>Close message</source>
        <translation>Sulje viesti</translation>
    </message>
</context>
<context>
    <name>Kdbx3Reader</name>
    <message>
        <source>Missing database headers</source>
        <translation>Tietokannan otsaketiedot puuttuvat</translation>
    </message>
    <message>
        <source>Unable to calculate database key</source>
        <translation>Tietokannan avaimen laskenta epäonnistui</translation>
    </message>
    <message>
        <source>Unable to issue challenge-response: %1</source>
        <translation>Haaste-vastauksen tekeminen epäonnistui: %1</translation>
    </message>
    <message>
        <source>Invalid credentials were provided, please try again.
If this reoccurs, then your database file may be corrupt.</source>
        <translation>Virheelliset tunnistetiedot. Yritä uudelleen.
Jos tämä toistuu, tietokantasi on saattanut vioittuna.</translation>
    </message>
    <message>
        <source>Header doesn&apos;t match hash</source>
        <translation>Otsaketieto ei vastaa tiivistettä (hash)</translation>
    </message>
    <message>
        <source>Invalid header id size</source>
        <translation>Virheellinen otsaketietojen id:n koko</translation>
    </message>
    <message>
        <source>Invalid header field length: field %1</source>
        <translation>Virheellinen otsaketietojen kentän koko: kenttä %1</translation>
    </message>
    <message>
        <source>Invalid header data length: field %1, %2 expected, %3 found</source>
        <translation>Virheellinen otsaketietojen datan pituus: kenttä %1, %2 odotettiin, %3 löydettiin</translation>
    </message>
</context>
<context>
    <name>Kdbx3Writer</name>
    <message>
        <source>Invalid symmetric cipher IV size.</source>
        <comment>IV = Initialization Vector for symmetric cipher</comment>
        <translation>Virheellinen symmetrisen salauksen alustussektorin (IV) koko.</translation>
    </message>
    <message>
        <source>Unable to issue challenge-response: %1</source>
        <translation>Haaste-vastauksen tekeminen epäonnistui: %1</translation>
    </message>
    <message>
        <source>Unable to calculate database key</source>
        <translation>Tietokannan avaimen laskenta epäonnistui</translation>
    </message>
</context>
<context>
    <name>Kdbx4Reader</name>
    <message>
        <source>missing database headers</source>
        <translation>tietokannan otsaketiedot puuttuvat</translation>
    </message>
    <message>
        <source>Unable to calculate database key: %1</source>
        <translation>Tietokannan avaimen laskenta epäonnistui: %1</translation>
    </message>
    <message>
        <source>Invalid header checksum size</source>
        <translation>Virheellinen otsaketietojen tarkistussumman koko</translation>
    </message>
    <message>
        <source>Header SHA256 mismatch</source>
        <translation>Yhteensopimaton SHA256-otsaketieto</translation>
    </message>
    <message>
        <source>Invalid credentials were provided, please try again.
If this reoccurs, then your database file may be corrupt.</source>
        <translation>Virheelliset tunnistetiedot. Yritä uudelleen.
Jos tämä toistuu, tietokantasi on saattanut vioittuna.</translation>
    </message>
    <message>
        <source>(HMAC mismatch)</source>
        <translation>(HMAC on yhteensopimaton)</translation>
    </message>
    <message>
        <source>Unknown cipher</source>
        <translation>Tuntematon salaus</translation>
    </message>
    <message>
        <source>Invalid header id size</source>
        <translation>Virheellinen otsaketietojen id:n koko</translation>
    </message>
    <message>
        <source>Invalid header field length: field %1</source>
        <translation>Virheellinen otsaketietojen kentän koko: kenttä %1</translation>
    </message>
    <message>
        <source>Invalid header data length: field %1, %2 expected, %3 found</source>
        <translation>Virheellinen otsaketietojen datan pituus: kenttä %1, %2 odotettiin, %3 löydettiin</translation>
    </message>
    <message>
        <source>Failed to open buffer for KDF parameters in header</source>
        <translation>Puskurin avaaminen avaimenluontifunktion parametreja varten tiedoston alkuosassa epäonnistui</translation>
    </message>
    <message>
        <source>Unsupported key derivation function (KDF) or invalid parameters</source>
        <translation>Avainmuunnosfunktio (KDF) ei ole tuettu, tai virheelliset parametrit</translation>
    </message>
    <message>
        <source>Legacy header fields found in KDBX4 file.</source>
        <translation>KDBX4-tiedostosta löytyi vanhentuneita otsaketietoja</translation>
    </message>
    <message>
        <source>Invalid inner header id size</source>
        <translation>Virheellinen sisemmän otsaketiedon tunnisteen koko</translation>
    </message>
    <message>
        <source>Invalid inner header field length: field %1</source>
        <translation>Virheellinen sisemmän otsaketiedon kentän pituus: kenttä %1</translation>
    </message>
    <message>
        <source>Invalid inner header data length: field %1, %2 expected, %3 found</source>
        <translation>Virheellinen sisempien otsaketietojen datan pituus: kenttä %1, %2 odotettiin, %3 löydettiin</translation>
    </message>
    <message>
        <source>Invalid inner header binary size</source>
        <translation>Virheellinen sisemmän otsaketiedon binäärikoko</translation>
    </message>
    <message>
        <source>Unsupported KeePass variant map version.</source>
        <extracomment>Translation: variant map = data structure for storing meta data</extracomment>
        <translation>KeePass -variant-kartan versio ei ole tuettu.</translation>
    </message>
    <message>
        <source>Invalid variant map entry name length</source>
        <extracomment>Translation: variant map = data structure for storing meta data</extracomment>
        <translation>Virheellinen variant-kartan tietuenimen pituus</translation>
    </message>
    <message>
        <source>Invalid variant map entry name data</source>
        <extracomment>Translation: variant map = data structure for storing meta data</extracomment>
        <translation>Virheellinen variant-kartan tietueen nimen sisältö</translation>
    </message>
    <message>
        <source>Invalid variant map entry value length</source>
        <extracomment>Translation: variant map = data structure for storing meta data</extracomment>
        <translation>Virheellinen variant-kartan tietueen arvon pituus</translation>
    </message>
    <message>
        <source>Invalid variant map entry value data</source>
        <extracomment>Translation comment: variant map = data structure for storing meta data</extracomment>
        <translation>Virheellinen variant-kartan tietueen arvon sisältä</translation>
    </message>
    <message>
        <source>Invalid variant map Bool entry value length</source>
        <extracomment>Translation: variant map = data structure for storing meta data</extracomment>
        <translation>Virheellinen variant-kartan Bool-arvon pituus</translation>
    </message>
    <message>
        <source>Invalid variant map Int32 entry value length</source>
        <extracomment>Translation: variant map = data structure for storing meta data</extracomment>
        <translation>Virheellinen variant-kartan Int32-arvon pituus</translation>
    </message>
    <message>
        <source>Invalid variant map UInt32 entry value length</source>
        <extracomment>Translation: variant map = data structure for storing meta data</extracomment>
        <translation>Virheellinen variant-kartan Uint32-arvon pituus</translation>
    </message>
    <message>
        <source>Invalid variant map Int64 entry value length</source>
        <extracomment>Translation: variant map = data structure for storing meta data</extracomment>
        <translation>Virheellinen variant-kartan Int64-arvon pituus</translation>
    </message>
    <message>
        <source>Invalid variant map UInt64 entry value length</source>
        <extracomment>Translation: variant map = data structure for storing meta data</extracomment>
        <translation>Virheellinen variant-kartan Uint64-arvon pituus</translation>
    </message>
    <message>
        <source>Invalid variant map entry type</source>
        <extracomment>Translation: variant map = data structure for storing meta data</extracomment>
        <translation>Virheellinen variant-kartan tietueen tyyppi</translation>
    </message>
    <message>
        <source>Invalid variant map field type size</source>
        <extracomment>Translation: variant map = data structure for storing meta data</extracomment>
        <translation>Virheellinen variant-kartan kenttätyypin koko</translation>
    </message>
</context>
<context>
    <name>Kdbx4Writer</name>
    <message>
        <source>Invalid symmetric cipher algorithm.</source>
        <translation>Virheellinen symmetrinen salausalgoritmi.</translation>
    </message>
    <message>
        <source>Invalid symmetric cipher IV size.</source>
        <comment>IV = Initialization Vector for symmetric cipher</comment>
        <translation>Virheellinen symmetrisen salauksen alustussektorin (IV) koko.</translation>
    </message>
    <message>
        <source>Unable to calculate database key: %1</source>
        <translation>Tietokannan avaimen laskenta epäonnistui: %1</translation>
    </message>
    <message>
        <source>Failed to serialize KDF parameters variant map</source>
        <extracomment>Translation comment: variant map = data structure for storing meta data</extracomment>
        <translation>KDF-parametrien serialisointi variant-karttaan epäonnistui</translation>
    </message>
</context>
<context>
    <name>KdbxReader</name>
    <message>
        <source>Invalid cipher uuid length: %1 (length=%2)</source>
        <translation>Virheellinen salauksen uuid:n pituus: %1 (pituus=%2)</translation>
    </message>
    <message>
        <source>Unable to parse UUID: %1</source>
        <translation>UUID:tä ei voitu jäsentää: %1</translation>
    </message>
    <message>
        <source>Unsupported cipher</source>
        <translation>Salausta ei tueta</translation>
    </message>
    <message>
        <source>Invalid compression flags length</source>
        <translation>Virheellinen pakkauslippujen pituus</translation>
    </message>
    <message>
        <source>Unsupported compression algorithm</source>
        <translation>Ei-tuettu pakkausalgoritmi</translation>
    </message>
    <message>
        <source>Invalid master seed size</source>
        <translation>Virheellinen pääavainsiemenen koko</translation>
    </message>
    <message>
        <source>Invalid transform seed size</source>
        <translation>Virheellinen avainmuunnossiemenen koko</translation>
    </message>
    <message>
        <source>Invalid transform rounds size</source>
        <translation>Virheellinen avainmuunnoskertoimen koko</translation>
    </message>
    <message>
        <source>Invalid start bytes size</source>
        <translation>Virheellinen avaustavujen koko</translation>
    </message>
    <message>
        <source>Invalid random stream id size</source>
        <translation>Virheellinen satunnaistietovuon tietueen koko</translation>
    </message>
    <message>
        <source>Invalid inner random stream cipher</source>
        <translation>Virheellinen sisäisen satunnaistietovuon salaus</translation>
    </message>
    <message>
        <source>Failed to read database file.</source>
        <translation>Tietokantatiedoston lukeminen epäonnistui.</translation>
    </message>
    <message>
        <source>The selected file is an old KeePass 1 database (.kdb).

You can import it by clicking on Database &gt; 'Import KeePass 1 database…'.
This is a one-way migration. You won&apos;t be able to open the imported database with the old KeePassX 0.4 version.</source>
        <translation>Valittu tiedosto on vanha KeePass 1 -tietokanta (.kdb).

Voit tuoda sen Tietokanta-valikosta &gt; &apos;Tuo KeePass 1 -tietokanta&apos;
Tämä muunnos toimii yhdensuuntaisesti. Et välttämättä saa enää tietokantaa auki vanhalla KeePassX 0.4 -versiolla.</translation>
    </message>
    <message>
        <source>Not a KeePass database.</source>
        <translation>Tiedosto ei ole KeePass-tietokanta</translation>
    </message>
    <message>
        <source>Unsupported KeePass 2 database version.</source>
        <translation>Ei-tuettu KeePass 2 -tietokantaversio.</translation>
    </message>
</context>
<context>
    <name>KdbxXmlReader</name>
    <message>
        <source>XML parsing failure: %1</source>
        <translation>XML-jäsentämisen virhe: %1</translation>
    </message>
    <message>
        <source>No root group</source>
        <translation>Ei isäntäryhmää</translation>
    </message>
    <message>
        <source>XML error:
%1
Line %2, column %3</source>
        <translation>XML-virhe:
%1
Rivi %2, sarake %3</translation>
    </message>
    <message>
        <source>Missing icon uuid or data</source>
        <translation>Kuvakkeen uuid tai tiedot puuttuvat</translation>
    </message>
    <message>
        <source>Missing custom data key or value</source>
        <translation>Itse valittu sisältöavain tai -arvo puuttuu</translation>
    </message>
    <message>
        <source>Multiple group elements</source>
        <translation>Useita ryhmäelementtejä</translation>
    </message>
    <message>
        <source>Null group uuid</source>
        <translation>Tyhjä ryhmän uuid</translation>
    </message>
    <message>
        <source>Invalid group icon number</source>
        <translation>Virhellinen ryhmän kuvakkeen numeroarvo</translation>
    </message>
    <message>
        <source>Invalid EnableAutoType value</source>
        <translation>Virheellinen EnableAutoType-arvo</translation>
    </message>
    <message>
        <source>Invalid EnableSearching value</source>
        <translation>Virheellinen EnableSearching-arvo</translation>
    </message>
    <message>
        <source>No group uuid found</source>
        <translation>Ryhmän uuid:tä ei löydy</translation>
    </message>
    <message>
        <source>Null DeleteObject uuid</source>
        <translation>Tyhjä uudi-arvo objektia tuhotessa (DeleteObject)</translation>
    </message>
    <message>
        <source>Missing DeletedObject uuid or time</source>
        <translation>Tuhotun objektin (DeletedObject) uuid tai aika puuttuu</translation>
    </message>
    <message>
        <source>Null entry uuid</source>
        <translation>Tyhjä tietueen uuid (null)</translation>
    </message>
    <message>
        <source>Invalid entry icon number</source>
        <translation>Virhellinen ryhmän kuvakkeen numeroarvo</translation>
    </message>
    <message>
        <source>History element in history entry</source>
        <translation>Historiaelementti historiatietueessa</translation>
    </message>
    <message>
        <source>No entry uuid found</source>
        <translation>Tietueen uuid:tä ei löydy</translation>
    </message>
    <message>
        <source>History element with different uuid</source>
        <translation>Historiaelementti eri uuid:llä</translation>
    </message>
    <message>
        <source>Duplicate custom attribute found</source>
        <translation>Itse valittu attribuutti on jo olemassa</translation>
    </message>
    <message>
        <source>Entry string key or value missing</source>
        <translation>Tietueen merkkijonoavain tai -arvo puuttuu</translation>
    </message>
    <message>
        <source>Entry binary key or value missing</source>
        <translation>Tietueen binääriavain tai -arvo puuttuu</translation>
    </message>
    <message>
        <source>Auto-type association window or sequence missing</source>
        <translation>Automaattisyötön ikkunan liitos tai sekvenssi puuttuu</translation>
    </message>
    <message>
        <source>Invalid bool value</source>
        <translation>Virheellinen boolean-arvo</translation>
    </message>
    <message>
        <source>Invalid date time value</source>
        <translation>Virheellinen päivämääräarvo</translation>
    </message>
    <message>
        <source>Invalid color value</source>
        <translation>Virheellinen väriarvo</translation>
    </message>
    <message>
        <source>Invalid color rgb part</source>
        <translation>Virheellinen RGB-väriarvo</translation>
    </message>
    <message>
        <source>Invalid number value</source>
        <translation>Virheellinen numeroarvo</translation>
    </message>
    <message>
        <source>Invalid uuid value</source>
        <translation>Virheellinen uuid-arvo</translation>
    </message>
    <message>
        <source>Unable to decompress binary</source>
        <extracomment>Translator meant is a binary data inside an entry</extracomment>
        <translation>Binääriä ei voitu purkaa</translation>
    </message>
</context>
<context>
    <name>KeeAgentSettings</name>
    <message>
        <source>Invalid KeeAgent settings file structure.</source>
        <translation>Virheellinen KeeAgentin asetustiedoston rakenne</translation>
    </message>
    <message>
        <source>Private key is an attachment but no attachments provided.</source>
        <translation>Yksityinen avain on liitetiedosto, mutta liitetiedostoja ei ole annettu.</translation>
    </message>
    <message>
        <source>Private key is empty</source>
        <translation>Yksityinen avainen on tyhjä</translation>
    </message>
    <message>
        <source>File too large to be a private key</source>
        <translation>Tiedosto on liian suuri ollakseen yksityinen avain</translation>
    </message>
    <message>
        <source>Failed to open private key</source>
        <translation>Yksityisen avaimen avaaminen epäonnistui</translation>
    </message>
</context>
<context>
    <name>KeePass1Reader</name>
    <message>
        <source>Unable to read keyfile.</source>
        <translation>Avaintiedoston luku ei onnistu</translation>
    </message>
    <message>
        <source>Not a KeePass database.</source>
        <translation>Tiedosto ei ole KeePass-tietokanta</translation>
    </message>
    <message>
        <source>Unsupported encryption algorithm.</source>
        <translation>Tukematon salausalgoritmi.</translation>
    </message>
    <message>
        <source>Unsupported KeePass database version.</source>
        <translation>Tukematon KeePass-tietokantaversio</translation>
    </message>
    <message>
        <source>Unable to read encryption IV</source>
        <comment>IV = Initialization Vector for symmetric cipher</comment>
        <translation>Salauksen alustusvektoria ei voitu lukea</translation>
    </message>
    <message>
        <source>Invalid number of groups</source>
        <translation>Virheellinen määrä ryhmiä</translation>
    </message>
    <message>
        <source>Invalid number of entries</source>
        <translation>Virheellinen määrä tietueita</translation>
    </message>
    <message>
        <source>Invalid content hash size</source>
        <translation>Virheellinen sisältötarkisteen koko</translation>
    </message>
    <message>
        <source>Invalid transform seed size</source>
        <translation>Virheellinen avainmuunnossiemenen koko</translation>
    </message>
    <message>
        <source>Invalid number of transform rounds</source>
        <translation>Virheellinen määrä muunnoskertoimia</translation>
    </message>
    <message>
        <source>Unable to construct group tree</source>
        <translation>Ryhmän puuta ei voitu rakentaa</translation>
    </message>
    <message>
        <source>Root</source>
        <translation>Juuri</translation>
    </message>
    <message>
        <source>Unable to calculate database key</source>
        <translation>Tietokannan avaimen laskenta epäonnistui</translation>
    </message>
    <message>
        <source>unable to seek to content position</source>
        <translation>sisällön sijaintia ei voitu hakea</translation>
    </message>
    <message>
        <source>Invalid credentials were provided, please try again.
If this reoccurs, then your database file may be corrupt.</source>
        <translation>Virheelliset tunnistetiedot. Yritä uudelleen.
Jos tämä toistuu, tietokantasi on saattanut vioittuna.</translation>
    </message>
    <message>
        <source>Key transformation failed</source>
        <translation>Avaimen muuttaminen epäonnistui</translation>
    </message>
    <message>
        <source>Invalid group field type number</source>
        <translation>Virheellinen ryhmän kenttätyypin numero</translation>
    </message>
    <message>
        <source>Invalid group field size</source>
        <translation>Virheellinen ryhmän kentän koko</translation>
    </message>
    <message>
        <source>Read group field data doesn&apos;t match size</source>
        <translation>Luetun ryhmän kentän sisältö ei vastaa sen kokoa</translation>
    </message>
    <message>
        <source>Incorrect group id field size</source>
        <translation>Virheellinen ryhmän tunnistekentän koko</translation>
    </message>
    <message>
        <source>Incorrect group creation time field size</source>
        <translation>Virheellinen ryhmän luomisajan kentän koko</translation>
    </message>
    <message>
        <source>Incorrect group modification time field size</source>
        <translation>Virheellinen ryhmän muokkausajan kentän koko</translation>
    </message>
    <message>
        <source>Incorrect group access time field size</source>
        <translation>Virheellinen ryhmän hakuajan kentän koko</translation>
    </message>
    <message>
        <source>Incorrect group expiry time field size</source>
        <translation>Virheellinen ryhmän vanhentumisajan kentän koko</translation>
    </message>
    <message>
        <source>Incorrect group icon field size</source>
        <translation>Virheellinen ryhmän ikonikentän koko</translation>
    </message>
    <message>
        <source>Incorrect group level field size</source>
        <translation>Virheellinen ryhmän tasokentän koko</translation>
    </message>
    <message>
        <source>Invalid group field type</source>
        <translation>Virheellinen ryhmän kentän tyyppi</translation>
    </message>
    <message>
        <source>Missing group id or level</source>
        <translation>Ryhmän tunniste tai taso puuttuu</translation>
    </message>
    <message>
        <source>Missing entry field type number</source>
        <translation>Tietueen kentän tyyppinumero puuttuu</translation>
    </message>
    <message>
        <source>Invalid entry field size</source>
        <translation>Virheellinen tietueen kentän koko</translation>
    </message>
    <message>
        <source>Read entry field data doesn&apos;t match size</source>
        <translation>Luetun tietueen kentän sisältö ei vastaa sen kokoa</translation>
    </message>
    <message>
        <source>Invalid entry UUID field size</source>
        <translation>Virheellinen tietueen UUID-kentän koko</translation>
    </message>
    <message>
        <source>Invalid entry group id field size</source>
        <translation>Virheellinen tietueen ryhmän tunnistekentän koko</translation>
    </message>
    <message>
        <source>Invalid entry icon field size</source>
        <translation>Virheellinen tietueen ikonikentän koko</translation>
    </message>
    <message>
        <source>Invalid entry creation time field size</source>
        <translation>Virheellinen tietueen luomisajan kentän koko</translation>
    </message>
    <message>
        <source>Invalid entry modification time field size</source>
        <translation>Virhellinen tietueen muokkausajan kentän koko</translation>
    </message>
    <message>
        <source>Invalid entry expiry time field size</source>
        <translation>Virheellinen tietueen vanhentumisajan kentän koko</translation>
    </message>
    <message>
        <source>Invalid entry field type</source>
        <translation>Virheellinen tietueen kentän tyyppi</translation>
    </message>
</context>
<context>
    <name>KeeShare</name>
    <message>
        <source>Invalid sharing reference</source>
        <translation>Virheellinen jakoviittaus</translation>
    </message>
    <message>
        <source>Inactive share %1</source>
        <translation>Ei-aktiivinen jako %1</translation>
    </message>
    <message>
        <source>Imported from %1</source>
        <translation>Tuotu kohteesta %1</translation>
    </message>
    <message>
        <source>Exported to %1</source>
        <translation>Viety kohteeseen %1</translation>
    </message>
    <message>
        <source>Synchronized with %1</source>
        <translation>Synkronoitu kohteen %1 kanssa</translation>
    </message>
    <message>
        <source>Import is disabled in settings</source>
        <translation>Tuonti on poistettu käytöstä asetuksissa</translation>
    </message>
    <message>
        <source>Export is disabled in settings</source>
        <translation>Vienti on otettu pois käytöstä asetuksissa</translation>
    </message>
    <message>
        <source>Inactive share</source>
        <translation>Ei-aktiivinen jako</translation>
    </message>
    <message>
        <source>Imported from</source>
        <translation>Tuotu kohteesta</translation>
    </message>
    <message>
        <source>Exported to</source>
        <translation>Viety kohteeseen</translation>
    </message>
    <message>
        <source>Synchronized with</source>
        <translation>Synkronoitu seuraavan kohteen kanssa</translation>
    </message>
</context>
<context>
    <name>KeyComponentWidget</name>
    <message>
        <source>Key Component</source>
        <translation>Avainkomponentti</translation>
    </message>
    <message>
        <source>Key Component Description</source>
        <translation>Avainkomponentin kuvaus</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Peruuta</translation>
    </message>
    <message>
        <source>Key Component set, click to change or remove</source>
        <translation>Avainkomponentti asetettu, paina muokataksesi tai poistaaksesi</translation>
    </message>
</context>
<context>
    <name>KeyFileEditWidget</name>
    <message>
        <source>Generate a new key file</source>
        <translation>Luo uusi avaintiedosto</translation>
    </message>
    <message>
        <source>Generate</source>
        <translation>Luo</translation>
    </message>
    <message>
        <source>Generate a new key file or choose an existing one to protect your database.</source>
        <translation>Kuo uusi avaintiedosto, tai avaa jo olemassa oleva suojataksesi tietokantasi.</translation>
    </message>
    <message>
        <source>Note: Do NOT use a file that may change as that will prevent you from unlocking your database.</source>
        <translation>Huom.: Älä käytä tiedostoa jonka sisältö voi muuttua, sillä se voi estää tietokannan avauksen.</translation>
    </message>
    <message>
        <source>Browse for key file</source>
        <translation>Selaa avaintiedostoa</translation>
    </message>
    <message>
        <source>Browse…</source>
        <translation>Selaa...</translation>
    </message>
    <message>
        <source>Old key file format</source>
        <translation>Vanha avaintiedostomuoto</translation>
    </message>
    <message>
        <source>You selected a key file in an old format which KeePassXC&lt;br&gt;may stop supporting in the future.&lt;br&gt;&lt;br&gt;Please consider generating a new key file instead.</source>
        <translation>Käytät vanhaa avaintiedostomuotoa joka ei ole&lt;br&gt;välttämättä tuettu tulevaisuudessa.&lt;br&gt;&lt;br&gt;Ole hyvä ja harkitse uuden avaintiedoston luomista.</translation>
    </message>
    <message>
        <source>Error loading the key file '%1'
Message: %2</source>
        <translation>Avaintiedostoa &apos;%1&apos; ei voitu avata
Viesti: %2</translation>
    </message>
    <message>
        <source>Key File</source>
        <translation>Avaintiedosto</translation>
    </message>
    <message>
        <source>Add Key File</source>
        <translation>Lisää avaintiedosto</translation>
    </message>
    <message>
        <source>Change Key File</source>
        <translation>Vaihda avaintiedosto</translation>
    </message>
    <message>
        <source>Remove Key File</source>
        <translation>Poista avaintiedosto</translation>
    </message>
    <message>
        <source>Key File set, click to change or remove</source>
        <translation>Avaintiedosto asetettu, klikkaa muuttaaksesi tai poistaaksesi</translation>
    </message>
    <message>
        <source>&lt;p&gt;You can add a key file containing random bytes for additional security.&lt;/p&gt;&lt;p&gt;You must keep it secret and never lose it or you will be locked out.&lt;/p&gt;</source>
        <translation>&lt;p&gt;Voit liittää tietokantaan avaintiedoston, joka sisältää sattumanvaraista dataa.&lt;/p&gt;&lt;p&gt;Tämä tiedosto täytyy pitää salassa eikä sitä saa koskaan hävittää!&lt;/p&gt;</translation>
    </message>
    <message>
        <source>Key files</source>
        <translation>Avaintiedostot</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>Kaikki tiedostot</translation>
    </message>
    <message>
        <source>Create Key File…</source>
        <translation>Luo avaintiedosto...</translation>
    </message>
    <message>
        <source>Error creating key file</source>
        <translation>Virhe luotaessa avaintiedostoa</translation>
    </message>
    <message>
        <source>Unable to create key file: %1</source>
        <translation>Avaintiedostoa ei voitu luoda: %1</translation>
    </message>
    <message>
        <source>Select a key file</source>
        <translation>Valitse avaintiedosto</translation>
    </message>
    <message>
        <source>Invalid Key File</source>
        <translation>Virheellinen avaintiedosto</translation>
    </message>
    <message>
        <source>You cannot use the current database as its own keyfile. Please choose a different file or generate a new key file.</source>
        <translation>Et voi käyttää kyseistä tietokantaa avaintiedostona. Ole hyvä ja valitse eri tiedosto, tai luo uusi avaintiedosto.</translation>
    </message>
    <message>
        <source>Suspicious Key File</source>
        <translation>Epäilyttävä avaintiedosto</translation>
    </message>
    <message>
        <source>The chosen key file looks like a password database file. A key file must be a static file that never changes or you will lose access to your database forever.
Are you sure you want to continue with this file?</source>
        <translation>Valittu avaintiedosto näyttää tietokannalta. Avaintiedoston täytyy olla staattinen tiedosto jonka sisältö ei koskaan muutu. Muussa tapauksessa saatat menettää pääsyn tietokantaasi lopullisesti.
Haluatko jatkaa käyttämällä tätä tiedostoa?</translation>
    </message>
</context>
<context>
    <name>MacUtils</name>
    <message>
        <source>Invalid key code</source>
        <translation>Virheellinen avainkoodi</translation>
    </message>
    <message>
        <source>Global shortcut already registered to %1</source>
        <translation>Yleinen pikanäppäin on jo rekisteröity toimintoon %1</translation>
    </message>
    <message>
        <source>Could not register global shortcut</source>
        <translation>Yleistä pikanäppäintä ei voitu rekisteröidä</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>&amp;Database</source>
        <translation>&amp;Tietokanta</translation>
    </message>
    <message>
        <source>&amp;Recent Databases</source>
        <translation>&amp;Viimeisimmät tietokannat</translation>
    </message>
    <message>
        <source>&amp;Export</source>
        <translation>&amp;Vie</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>&amp;Ohje</translation>
    </message>
    <message>
        <source>&amp;Entries</source>
        <translation>&amp;Tietueet</translation>
    </message>
    <message>
        <source>Copy Att&amp;ribute</source>
        <translation>Kopioi att&amp;ribuutti</translation>
    </message>
    <message>
        <source>TOTP</source>
        <translation>TOTP</translation>
    </message>
    <message>
        <source>Tags</source>
        <translation>Tagit</translation>
    </message>
    <message>
        <source>&amp;Groups</source>
        <translation>Ryhmät</translation>
    </message>
    <message>
        <source>&amp;Tools</source>
        <translation>T&amp;yökalut</translation>
    </message>
    <message>
        <source>View</source>
        <translation>Näytä</translation>
    </message>
    <message>
        <source>Theme</source>
        <translation>Teema</translation>
    </message>
    <message>
        <source>&amp;Quit</source>
        <translation>&amp;Lopeta</translation>
    </message>
    <message>
        <source>&amp;About</source>
        <translation>T&amp;ietoja</translation>
    </message>
    <message>
        <source>&amp;Check for Updates</source>
        <translation>Tarkista &amp;päivitykset</translation>
    </message>
    <message>
        <source>&amp;Open Database…</source>
        <translation>&amp;Avaa tietokanta…</translation>
    </message>
    <message>
        <source>&amp;Save Database</source>
        <translation>&amp;Tallenna tietokanta</translation>
    </message>
    <message>
        <source>&amp;Close Database</source>
        <translation>&amp;Sulje tietokanta</translation>
    </message>
    <message>
        <source>&amp;New Database…</source>
        <translation>&amp;Uusi tietokanta…</translation>
    </message>
    <message>
        <source>&amp;Merge From Database…</source>
        <translation>&amp;Yhdistä tietokannasta…</translation>
    </message>
    <message>
        <source>&amp;New Entry…</source>
        <translation>&amp;Uusi tietue…</translation>
    </message>
    <message>
        <source>&amp;Edit Entry…</source>
        <translation>&amp;Muokkaa tietuetta…</translation>
    </message>
    <message>
        <source>&amp;New Group…</source>
        <translation>&amp;Uusi ryhmä…</translation>
    </message>
    <message>
        <source>&amp;Edit Group…</source>
        <translation>&amp;Muokkaa ryhmää…</translation>
    </message>
    <message>
        <source>&amp;Delete Group…</source>
        <translation>&amp;Poista ryhmä…</translation>
    </message>
    <message>
        <source>Download All &amp;Favicons…</source>
        <translation>Lataa kaikki &amp;faviconit…</translation>
    </message>
    <message>
        <source>Sort &amp;A-Z</source>
        <translation>Järjestä &amp;A-Ö</translation>
    </message>
    <message>
        <source>Sort &amp;Z-A</source>
        <translation>Järjestä &amp;Ö-A</translation>
    </message>
    <message>
        <source>Sa&amp;ve Database As…</source>
        <translation>Ta&amp;llenna tietokanta nimellä…</translation>
    </message>
    <message>
        <source>Database &amp;Security…</source>
        <translation>Tietokannan &amp;turvallisuus…</translation>
    </message>
    <message>
        <source>Database &amp;Reports…</source>
        <translation>Tietokannan &amp;raportit...</translation>
    </message>
    <message>
        <source>&amp;Database Settings…</source>
        <translation>&amp;Tietokannan asetukset…</translation>
    </message>
    <message>
        <source>&amp;Clone Entry…</source>
        <translation>&amp;Kloonaa tietue…</translation>
    </message>
    <message>
        <source>Move u&amp;p</source>
        <translation>Siirrä &amp;ylös</translation>
    </message>
    <message>
        <source>Move do&amp;wn</source>
        <translation>Siirrä &amp;alas</translation>
    </message>
    <message>
        <source>Copy &amp;Username</source>
        <translation>Kopioi &amp;käyttäjätunnus</translation>
    </message>
    <message>
        <source>Copy &amp;Password</source>
        <translation>Kopioi &amp;salasana</translation>
    </message>
    <message>
        <source>&amp;Settings</source>
        <translation>&amp;Asetukset</translation>
    </message>
    <message>
        <source>&amp;Password Generator</source>
        <translation>&amp;Salasanageneraattori</translation>
    </message>
    <message>
        <source>Perform &amp;Auto-Type</source>
        <translation>Suorita &amp;automaattitäydennys</translation>
    </message>
    <message>
        <source>Download &amp;Favicon</source>
        <translation>Lataa &amp;favicon</translation>
    </message>
    <message>
        <source>Open &amp;URL</source>
        <translation>&amp;Avaa URL</translation>
    </message>
    <message>
        <source>&amp;Lock Database</source>
        <translation>&amp;Lukitse tietokanta</translation>
    </message>
    <message>
        <source>Lock &amp;All Databases</source>
        <translation>Lukitse k&amp;aikki tietokannat</translation>
    </message>
    <message>
        <source>&amp;Title</source>
        <translation>&amp;Otsikko</translation>
    </message>
    <message>
        <source>Copy &amp;URL</source>
        <translation>Kopioi &amp;URL-osoite</translation>
    </message>
    <message>
        <source>&amp;Notes</source>
        <translation>&amp;Muistiinpanot</translation>
    </message>
    <message>
        <source>&amp;CSV File…</source>
        <translation>&amp;CSV-tiedosto…</translation>
    </message>
    <message>
        <source>&amp;HTML File…</source>
        <translation>&amp;HTML-tiedosto…</translation>
    </message>
    <message>
        <source>KeePass 1 Database…</source>
        <translation>KeePass 1 -tietokanta</translation>
    </message>
    <message>
        <source>1Password Vault…</source>
        <translation>!Password-holvi...</translation>
    </message>
    <message>
        <source>CSV File…</source>
        <translation>CSV-tiedosto...</translation>
    </message>
    <message>
        <source>Show TOTP</source>
        <translation>Näytä TOTP</translation>
    </message>
    <message>
        <source>Show QR Code</source>
        <translation>Näytä QR-koodi</translation>
    </message>
    <message>
        <source>Set up TOTP…</source>
        <translation>Aseta TOTP...</translation>
    </message>
    <message>
        <source>Copy &amp;TOTP</source>
        <translation>Kopioi &amp;TOTP</translation>
    </message>
    <message>
        <source>Copy Password and TOTP</source>
        <translation>Kopioi salasana ja TOTP</translation>
    </message>
    <message>
        <source>E&amp;mpty recycle bin</source>
        <translation>&amp;Tyhjennä roskakori</translation>
    </message>
    <message>
        <source>&amp;Donate</source>
        <translation>&amp;Lahjoita</translation>
    </message>
    <message>
        <source>Report a &amp;Bug</source>
        <translation>Ilmoita &amp;virheestä</translation>
    </message>
    <message>
        <source>&amp;Getting Started</source>
        <translation>&amp;Alkuun pääsy</translation>
    </message>
    <message>
        <source>Open Getting Started Guide</source>
        <translation>Avaa alkuun pääsyyn tarkoitettu opas</translation>
    </message>
    <message>
        <source>&amp;Online Help</source>
        <translation>&amp;Verkko-ohje</translation>
    </message>
    <message>
        <source>&amp;User Guide</source>
        <translation>&amp;Käyttäjäopas</translation>
    </message>
    <message>
        <source>Open User Guide</source>
        <translation>Avaa käyttöopas</translation>
    </message>
    <message>
        <source>&amp;Keyboard Shortcuts</source>
        <translation>&amp;Pikanäppäimet</translation>
    </message>
    <message>
        <source>Save Database Backup…</source>
        <translation>Tallenna tietokannan varmuuskopio...</translation>
    </message>
    <message>
        <source>Add key to SSH Agent</source>
        <translation>Lisää avain SSH-agenttiin</translation>
    </message>
    <message>
        <source>Remove key from SSH Agent</source>
        <translation>Poista avain SSH-agentista</translation>
    </message>
    <message>
        <source>Compact Mode</source>
        <translation>Kompakti tila</translation>
    </message>
    <message>
        <source>Automatic</source>
        <translation>Automaattinen</translation>
    </message>
    <message>
        <source>Light</source>
        <translation>Vaalea</translation>
    </message>
    <message>
        <source>Dark</source>
        <translation>Tumma</translation>
    </message>
    <message>
        <source>Classic (Platform-native)</source>
        <translation>Klassinen (käyttöjärjestelmän oma)</translation>
    </message>
    <message>
        <source>Show Menubar</source>
        <translation>Näytä työkalupalkki</translation>
    </message>
    <message>
        <source>Show Toolbar</source>
        <translation>Näytä työkalupalkki</translation>
    </message>
    <message>
        <source>Show Preview Panel</source>
        <translation>Näytä esikatselupaneeli</translation>
    </message>
    <message>
        <source>Always on Top</source>
        <translation>Aina päällimmäisenä</translation>
    </message>
    <message>
        <source>Hide Usernames</source>
        <translation>Piilota käyttäjätunnukset</translation>
    </message>
    <message>
        <source>Hide Passwords</source>
        <translation>Piilota salasanat</translation>
    </message>
    <message>
        <source>Clone Group...</source>
        <translation>Kloonaa ryhmä</translation>
    </message>
    <message>
        <source>&amp;XML File…</source>
        <translation>&amp;XML-tiedosto…</translation>
    </message>
    <message>
        <source>Clear history</source>
        <translation>Tyhjennä historia</translation>
    </message>
    <message>
        <source>Access error for config file %1</source>
        <translation>Pääsyvirhe asetustiedostoon %1</translation>
    </message>
    <message>
        <source>Don&apos;t show again for this version</source>
        <translation>Älä näytä uudestaan tälle versiolle</translation>
    </message>
    <message>
        <source>No Tags</source>
        <translation>Ei tunnisteita</translation>
    </message>
    <message numerus="yes">
        <source>Restore Entry(s)</source>
        <translation><numerusform>Palauta tietue</numerusform><numerusform>Palauta tietueet</numerusform></translation>
    </message>
    <message>
        <source>Settings</source>
        <translation>Asetukset</translation>
    </message>
    <message>
        <source>Check for updates on startup?</source>
        <translation>Tarkistetaanko päivitykset käynnistyksen yhteydessä?</translation>
    </message>
    <message>
        <source>Would you like KeePassXC to check for updates on startup?</source>
        <translation>Haluatko että KeePassXC tarkistaa päivitykset käynnistyessään?</translation>
    </message>
    <message>
        <source>You can always check for updates manually from the application menu.</source>
        <translation>Voit tarkistaa päivitykset manuaalisesti sovellusvalikosta.</translation>
    </message>
    <message>
        <source>Toggle window</source>
        <translation>Vaihda ikkunaan</translation>
    </message>
    <message>
        <source>Quit KeePassXC</source>
        <translation>Sulje KeePassXC</translation>
    </message>
    <message numerus="yes">
        <source>%1 Entry(s)</source>
        <translation><numerusform>%1 tietue</numerusform><numerusform>%1 tietuetta</numerusform></translation>
    </message>
    <message>
        <source>Please present or touch your YubiKey to continue…</source>
        <translation>Ole hyvä ja käytä Yubikeyssä jatkaaksesi...</translation>
    </message>
    <message>
        <source>Restart Application?</source>
        <translation>Käynnistä ohjelma uudelleen?</translation>
    </message>
    <message>
        <source>You must restart the application to apply this setting. Would you like to restart now?</source>
        <translation>Ohjelma täytyy käynnistää uudelleen, jotta asetus voidaan ottaa käyttöön. Haluatko käynnistää uudelleen nyt?</translation>
    </message>
    <message>
        <source>Allow Screen Capture</source>
        <translation>Salli kuvankaappaus</translation>
    </message>
    <message>
        <source>1Password 1PUX...</source>
        <translation>1Password 1PUX...</translation>
    </message>
    <message>
        <source>Import a 1Password 1PUX file</source>
        <translation>Tuo 1Passwordin 1PUX-tiedosto</translation>
    </message>
    <message>
        <source>Import…</source>
        <translation>Tuo...</translation>
    </message>
    <message>
        <source>Passkeys…</source>
        <translation>Suojausvaimet...</translation>
    </message>
    <message>
        <source>Import Passkey</source>
        <translation>Tuo suojausavain</translation>
    </message>
    <message>
        <source>Remote S&amp;ync…</source>
        <translation>Etäs&amp;ynkronointi...</translation>
    </message>
    <message>
        <source>Quit Application</source>
        <translation>Sammuta sovellus</translation>
    </message>
    <message>
        <source>Open About Dialog</source>
        <translation>Avaa tietoja ohjelmasta -dialogi</translation>
    </message>
    <message>
        <source>Open Database</source>
        <translation>Avaa tietokanta</translation>
    </message>
    <message>
        <source>Create Database</source>
        <translation>Luo tietokanta</translation>
    </message>
    <message>
        <source>Merge From Database</source>
        <translation>Yhdistä tietokannasta</translation>
    </message>
    <message>
        <source>Edit Entry</source>
        <translation>Muokkaa tietuetta</translation>
    </message>
    <message>
        <source>Delete Entry</source>
        <translation>Poista tietue</translation>
    </message>
    <message>
        <source>Create Group</source>
        <translation>Luo ryhmä</translation>
    </message>
    <message>
        <source>Edit Group</source>
        <translation>Muokkaa ryhmää</translation>
    </message>
    <message>
        <source>Delete Group</source>
        <translation>Poista ryhmä</translation>
    </message>
    <message>
        <source>Download All Favicons</source>
        <translation>Lataa kaikki faviconit</translation>
    </message>
    <message>
        <source>Sort Groups A-Z</source>
        <translation>Järjestä ryhmät A-Ö</translation>
    </message>
    <message>
        <source>Sort Groups Z-A</source>
        <translation>Järjestä ryhmät Ö-A</translation>
    </message>
    <message>
        <source>Save Database As</source>
        <translation>Tallenna tietokanta nimellä</translation>
    </message>
    <message>
        <source>Show Database Security</source>
        <translation>Näytä tietokannan turvallisuus</translation>
    </message>
    <message>
        <source>Show Database Reports</source>
        <translation>Näytä tietokannan raportit</translation>
    </message>
    <message>
        <source>Show Database Settings</source>
        <translation>Näytä tietokannan asetukset</translation>
    </message>
    <message>
        <source>Show Passkeys</source>
        <translation>pääsyavaimet</translation>
    </message>
    <message>
        <source>Clone Entry</source>
        <translation>Kloonaa tietue</translation>
    </message>
    <message>
        <source>Move Entry Up</source>
        <translation>Siirrä tietue ylös</translation>
    </message>
    <message>
        <source>Move Entry Down</source>
        <translation>Siirrä tietue alas</translation>
    </message>
    <message>
        <source>Copy Username</source>
        <translation>Kopioi käyttäjätunnus</translation>
    </message>
    <message>
        <source>Copy Password</source>
        <translation>Kopioi salasana</translation>
    </message>
    <message>
        <source>Show Application Settings</source>
        <translation>Näytä sovelluksen asetukset</translation>
    </message>
    <message>
        <source>Show Password Generator</source>
        <translation>Näytä salasanageneraattori</translation>
    </message>
    <message>
        <source>Remove Passkey From Entry</source>
        <translation>Poista passkey tietueesta</translation>
    </message>
    <message>
        <source>Perform Auto-Type: {USERNAME}</source>
        <translation>Suorita automaattisyöttö: {USERNAME}</translation>
    </message>
    <message>
        <source>Perform Auto-Type: {USERNAME}{ENTER}</source>
        <translation>Suorita automaattisyöttö: {USERNAME}{ENTER}</translation>
    </message>
    <message>
        <source>Perform Auto-Type: {PASSWORD}</source>
        <translation>Suorita automaattisyöttö: {PASSWORD}</translation>
    </message>
    <message>
        <source>Perform Auto-Type: {PASSWORD}{ENTER}</source>
        <translation>Suorita automaattisyöttö: {PASSWORD}{ENTER}</translation>
    </message>
    <message>
        <source>Perform Auto-Type: {TOTP}</source>
        <translation>Suorita automaattisyöttö: {TOTP}</translation>
    </message>
    <message>
        <source>Copy Title</source>
        <translation>Kopioi otsikko</translation>
    </message>
    <message>
        <source>Copy URL</source>
        <translation>Kopioi URL-osoite</translation>
    </message>
    <message>
        <source>Copy Notes</source>
        <translation>Kopioi muistiinpanot</translation>
    </message>
    <message>
        <source>Export to CSV</source>
        <translation>Vie CSV-tiedostoon</translation>
    </message>
    <message>
        <source>Export to HTML</source>
        <translation>Vie HTML-tiedostoon</translation>
    </message>
    <message>
        <source>Import KeePass1 Database</source>
        <translation>Tuo KeePass1-tietokanta</translation>
    </message>
    <message>
        <source>Import 1Password Vault</source>
        <translation>Tuo 1Password-holvi</translation>
    </message>
    <message>
        <source>Import CSV File</source>
        <translation>Tuo CSV-tiedosto</translation>
    </message>
    <message>
        <source>Show TOTP QR Code</source>
        <translation>Näytä TOTP QR-koodi</translation>
    </message>
    <message>
        <source>Set up TOTP</source>
        <translation>Aseta TOTP</translation>
    </message>
    <message>
        <source>Empty Recycle Bin</source>
        <translation>Tyhjennä roskakori</translation>
    </message>
    <message>
        <source>Open Donation Website</source>
        <translation>Avaa lahjoitussivusto</translation>
    </message>
    <message>
        <source>Open Bug Report</source>
        <translation>Avaa bugiraporttisivusto</translation>
    </message>
    <message>
        <source>Open Online Documentation</source>
        <translation>Avaa online-dokumentaatio</translation>
    </message>
    <message>
        <source>Open Keyboard Shortcuts Guide</source>
        <translation>Avaa pikanäppäinten ohjesivu</translation>
    </message>
    <message>
        <source>Save Database Backup</source>
        <translation>Tallenna tietokannan varmuuskopio</translation>
    </message>
    <message>
        <source>SSH Agent: Add Key</source>
        <translation>SSH-agentti: Lisää avain</translation>
    </message>
    <message>
        <source>SSH Agent: Remove Key</source>
        <translation>SSH-agentti: Poista avain</translation>
    </message>
    <message>
        <source>Toggle Compact Mode</source>
        <translation>Aseta kompakti tila</translation>
    </message>
    <message>
        <source>Set Theme: Automatic</source>
        <translation>Aseta teema: automaattinen</translation>
    </message>
    <message>
        <source>Set Theme: Light</source>
        <translation>Aseta teema: vaalea</translation>
    </message>
    <message>
        <source>Set Theme: Dark</source>
        <translation>Aseta teema: tumma</translation>
    </message>
    <message>
        <source>Set Theme: Classic</source>
        <translation>Aseta teema: klassinen</translation>
    </message>
    <message>
        <source>Toggle Show Menubar</source>
        <translation>Aseta: näytä työkalupalkki</translation>
    </message>
    <message>
        <source>Toggle Show Toolbar</source>
        <translation>Aseta: näytä työkalupalkki</translation>
    </message>
    <message>
        <source>Toggle Show Preview Panel</source>
        <translation>Aseta: näytä esikatselupaneeli</translation>
    </message>
    <message>
        <source>Toggle Always on Top</source>
        <translation>Aseta: aina päällimmäisenä</translation>
    </message>
    <message>
        <source>Toggle Hide Usernames</source>
        <translation>Aseta: piilota käyttäjätunnukset</translation>
    </message>
    <message>
        <source>Toggle Hide Passwords</source>
        <translation>Aseta: piilota salasanat</translation>
    </message>
    <message>
        <source>Export to XML</source>
        <translation>Vie XML-tiedostoon</translation>
    </message>
    <message>
        <source>Toggle Allow Screen Capture</source>
        <translation>Aseta: salli kuvankaappaus</translation>
    </message>
    <message>
        <source>Show Group Panel</source>
        <translation>Näytä ryhmäpaneeli</translation>
    </message>
    <message>
        <source>Toggle Show Group Panel</source>
        <translation>Näytä tai piilota ryhmäpaneeli</translation>
    </message>
    <message>
        <source>Setup Remote Sync…</source>
        <translation>Määritä etäsynkronointi</translation>
    </message>
    <message>
        <source>WARNING: You are using a development snapshot build of KeePassXC.
Maintain a backup of your databases in the event of unknown bugs.
This version is not meant for production use.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Clear SSH Agent</source>
        <translation>Tyhjennä SSH-agentti</translation>
    </message>
    <message>
        <source>Clear all identities in ssh-agent</source>
        <translation>Tyhjennä kaikki tunnisteet SSH-agentista</translation>
    </message>
    <message>
        <source>New Entry</source>
        <translation>Uusi tietue</translation>
    </message>
    <message>
        <source>Password Generator</source>
        <translation>Salasanageneraattori</translation>
    </message>
    <message>
        <source>Edit Entry…</source>
        <translation>Muokkaa tietuetta...</translation>
    </message>
    <message>
        <source>E&amp;xpire Entry</source>
        <translation>Va&amp;nhenna tietua</translation>
    </message>
    <message>
        <source>Expire Entry</source>
        <translation>Vanhenna tietue</translation>
    </message>
    <message>
        <source>&amp;Delete Entry</source>
        <translation>&amp;Poista tietue</translation>
    </message>
    <message numerus="yes">
        <source>Move selected entry(s) to the recycle bin</source>
        <translation><numerusform>Siirrä valittu tietue roskakoriin</numerusform><numerusform>Siirrä valitut tietueet roskakoriin</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>Permanently delete the selected entry(s)</source>
        <translation><numerusform>Poista valittu tietue pysyvästi</numerusform><numerusform>Poista valitut tietueet pysyvästi</numerusform></translation>
    </message>
</context>
<context>
    <name>ManageDatabase</name>
    <message>
        <source>Database settings</source>
        <translation>Tietokannan asetukset</translation>
    </message>
    <message>
        <source>Edit database settings</source>
        <translation>Muokkaa tietokannan asetuksia</translation>
    </message>
    <message>
        <source>Unlock database</source>
        <translation>Avaa tietokannan lukitus</translation>
    </message>
    <message>
        <source>Unlock database to show more information</source>
        <translation>Avaa tietokannan lukitus näyttääksesi enemmän tietoja</translation>
    </message>
    <message>
        <source>Lock database</source>
        <translation>Lukitse tietokanta</translation>
    </message>
</context>
<context>
    <name>ManageSession</name>
    <message>
        <source>Disconnect</source>
        <translation>Katkaise yhteys</translation>
    </message>
    <message>
        <source>Disconnect this application</source>
        <translation>Katkaise yhteys tältä ohjelmalta</translation>
    </message>
    <message>
        <source>Reset</source>
        <translation>Nollaa</translation>
    </message>
    <message>
        <source>Reset any remembered decisions for this application</source>
        <translation>Nollaa tälle sovellukselle tallennetut valinnat</translation>
    </message>
</context>
<context>
    <name>MergeDialog</name>
    <message>
        <source>Database Merge Confirmation</source>
        <translation>Tietokannan yhdistämisvarmistus</translation>
    </message>
    <message>
        <source>Merge</source>
        <translation>Yhdistä</translation>
    </message>
    <message>
        <source>Group</source>
        <translation>Ryhmä</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>Otsikk</translation>
    </message>
    <message>
        <source>UUID</source>
        <translation>UUID</translation>
    </message>
    <message>
        <source>Details</source>
        <translation>Yksityiskohdat</translation>
    </message>
    <message>
        <source>Change</source>
        <translation>Muuta</translation>
    </message>
</context>
<context>
    <name>Merger</name>
    <message>
        <source>Changed deleted objects</source>
        <translation>Muutettiin poistettuja kohteita</translation>
    </message>
    <message>
        <source>Removed custom data %1 [%2]</source>
        <translation>Poista mukautettu tieto %1 [%2]</translation>
    </message>
    <message>
        <source>Adding custom data %1 [%2]</source>
        <translation>Lisätään mukautettua tietoa%1 [%2]</translation>
    </message>
    <message>
        <source>Added</source>
        <translation>Lisätty</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Muokattu</translation>
    </message>
    <message>
        <source>Moved</source>
        <translation>Siirretty</translation>
    </message>
    <message>
        <source>Deleted</source>
        <translation>Poistettu</translation>
    </message>
    <message>
        <source>Previous location: %1</source>
        <translation>Edellinen sijainti: %1</translation>
    </message>
    <message>
        <source>Number of entries in group: %1</source>
        <translation>Tietueiden lukumäärä ryhmässä: %1</translation>
    </message>
    <message>
        <source>Group name</source>
        <translation>Ryhmän nimi</translation>
    </message>
    <message>
        <source>Notes</source>
        <translation>Muistiinpanot</translation>
    </message>
    <message>
        <source>Icon (UUID)</source>
        <translation>Kuvake (UUID)</translation>
    </message>
    <message>
        <source>Icon (Number)</source>
        <translation>Kuvake (numero)</translation>
    </message>
    <message>
        <source>Expiry time</source>
        <translation>Vanhentumisaika</translation>
    </message>
    <message>
        <source>Modification time</source>
        <translation>Muokkausaika</translation>
    </message>
    <message>
        <source>%1 (Add local modifications to new entry)</source>
        <translation>%1 (Lisää paikalliset muutokset uuteen tietueeseen)</translation>
    </message>
    <message>
        <source>%1 (Add new modifications to existing entry)</source>
        <translation>%1 (Lisää uudet muokkaukset jo olemassa olevaan tietueeseen)</translation>
    </message>
    <message>
        <source>Explicit deletion</source>
        <translation>Nimenomainen poistaminen</translation>
    </message>
    <message>
        <source>Implicit deletion (e.g. removal of parent group)</source>
        <translation>Implisiittinen poistaminen (esim. poista emoryhmä)</translation>
    </message>
    <message>
        <source>Adding new icon %1</source>
        <translation>Lisätään uusi kuvake %1</translation>
    </message>
</context>
<context>
    <name>NewDatabaseWizard</name>
    <message>
        <source>Create a new KeePassXC database…</source>
        <translation>Luo uusi KeePassXC-tietokanta...</translation>
    </message>
    <message>
        <source>Root</source>
        <comment>Root group</comment>
        <translation>Juuri</translation>
    </message>
</context>
<context>
    <name>NewDatabaseWizardPage</name>
    <message>
        <source>WizardPage</source>
        <translation>Ohjattu sivu</translation>
    </message>
    <message>
        <source>Encryption Settings</source>
        <translation>Salausasetukset</translation>
    </message>
    <message>
        <source>Here you can adjust the database encryption settings. Don&apos;t worry, you can change them later in the database settings.</source>
        <translation>Täällä voit säätää tietokannan salausasetuksia. Voit muokata niitä myöhemmin uudelleen.</translation>
    </message>
</context>
<context>
    <name>NewDatabaseWizardPageDatabaseKey</name>
    <message>
        <source>Database Credentials</source>
        <translation>Tietokannan tunnistetiedot</translation>
    </message>
    <message>
        <source>A set of credentials known only to you that protects your database.</source>
        <translation>Tietokannan suojaukseen määrittämäsi tietueryhmä</translation>
    </message>
</context>
<context>
    <name>NewDatabaseWizardPageEncryption</name>
    <message>
        <source>Encryption Settings</source>
        <translation>Salausasetukset</translation>
    </message>
    <message>
        <source>Here you can adjust the database encryption settings. Don&apos;t worry, you can change them later in the database settings.</source>
        <translation>Täällä voit säätää tietokannan salausasetuksia. Voit muokata niitä myöhemmin uudelleen.</translation>
    </message>
</context>
<context>
    <name>NewDatabaseWizardPageMetaData</name>
    <message>
        <source>General Database Information</source>
        <translation>Yleiset tietokannan tiedot</translation>
    </message>
    <message>
        <source>Please fill in the display name and an optional description for your new database:</source>
        <translation>Ole hyvä ja täytä tietokantasi nimi ja vapaaehtoinen kuvaus:</translation>
    </message>
</context>
<context>
    <name>NixUtils</name>
    <message>
        <source>Password Manager</source>
        <translation>Salasanamanageri</translation>
    </message>
    <message>
        <source>Global shortcut already registered to %1</source>
        <translation>Yleinen pikanäppäin on jo rekisteröity toimintoon %1</translation>
    </message>
    <message>
        <source>Could not register global shortcut</source>
        <translation>Yleistä pikanäppäintä ei voitu rekisteröidä</translation>
    </message>
</context>
<context>
    <name>OpData01</name>
    <message>
        <source>Invalid OpData01, does not contain header</source>
        <translation>Viallinen OpData01. Otsaketieto puuttuu</translation>
    </message>
    <message>
        <source>Unable to read all IV bytes, wanted 16 but got %1</source>
        <translation>Kaikkia IV-tavuja ei voitu lukea. Tarvittiin 16, mutta saatiin vain %1</translation>
    </message>
    <message>
        <source>Unable to init cipher for opdata01: %1</source>
        <translation>OpData01:n salakirjoitusta ei voitu alustaa: %1</translation>
    </message>
    <message>
        <source>Unable to read all HMAC signature bytes</source>
        <translation>Kaikkia HMAC-allekirjoituksen tavuja ei voitu lukea</translation>
    </message>
    <message>
        <source>Malformed OpData01 due to a failed HMAC</source>
        <translation>Viallinen OpData01 epäonnistuneen HMAC:in vuoksi</translation>
    </message>
    <message>
        <source>Unable to process clearText in place</source>
        <translation>Selkotekstiä ei voitu prosessoida</translation>
    </message>
    <message>
        <source>Expected %1 bytes of clear-text, found %2</source>
        <translation>Odotettiin %1 tavua selkotekstiä, löydettiin %2</translation>
    </message>
</context>
<context>
    <name>OpVaultReader</name>
    <message>
        <source>Directory .opvault must exist</source>
        <translation>Hakemiston .opvault täytyy olla olemassa</translation>
    </message>
    <message>
        <source>Directory .opvault must be readable</source>
        <translation>Hakemistoon .opvault täytyy olla lukuoikeus</translation>
    </message>
    <message>
        <source>Directory .opvault/default must exist</source>
        <translation>Hakemisto .opvault/default täytyy olla olemassa</translation>
    </message>
    <message>
        <source>Directory .opvault/default must be readable</source>
        <translation>Hakemistoon .opvault/default täytyy olla lukuoikeus</translation>
    </message>
    <message>
        <source>Unable to decode masterKey: %1</source>
        <translation>Pääavainta %1 ei voitu purkaa</translation>
    </message>
    <message>
        <source>Unable to derive master key: %1</source>
        <translation>Pääavainta %1 ei kyetty johdattamaan</translation>
    </message>
</context>
<context>
    <name>OpenSSHKey</name>
    <message>
        <source>Invalid key file, expecting an OpenSSH key</source>
        <translation>Virheellinen avaintiedosto, odotetaan OpenSSH-avainta</translation>
    </message>
    <message>
        <source>PEM boundary mismatch</source>
        <translation>Yhteensopimaton PEM-raja-arvo</translation>
    </message>
    <message>
        <source>Base64 decoding failed</source>
        <translation>Base64-dekoodaus epäonnistui</translation>
    </message>
    <message>
        <source>Key file way too small.</source>
        <translation>Avaintiedosto aivan liian pieni.</translation>
    </message>
    <message>
        <source>Key file magic header id invalid</source>
        <translation>Otsaketietojen taikatunniste on virheellinen</translation>
    </message>
    <message>
        <source>Found zero keys</source>
        <translation>Löytyi nolla avainta</translation>
    </message>
    <message>
        <source>Corrupted key file, reading private key failed</source>
        <translation>Rikkinäinen avaintiedosto, yksityisen avaimen lukeminen epäonnistui</translation>
    </message>
    <message>
        <source>Unsupported key type: %1</source>
        <translation>Tuntematon avaimen tyyppi: %1</translation>
    </message>
    <message>
        <source>No private key payload to decrypt</source>
        <translation>Salauksen purku epäonnistui: yksityisen avaimen sisältö on tyhjä</translation>
    </message>
    <message>
        <source>Unknown cipher: %1</source>
        <translation>Tuntematon salausalgoritmi: %1</translation>
    </message>
    <message>
        <source>AES-256/GCM is currently not supported</source>
        <translation>AES-256/GCM-salausta ei tällä hetkellä tueta</translation>
    </message>
    <message>
        <source>Passphrase is required to decrypt this key</source>
        <translation>Avaimen purkuun vaaditaan salalause</translation>
    </message>
    <message>
        <source>Key derivation failed: %1</source>
        <translation>Avainmuunnosfunktio epäonnistui: %1</translation>
    </message>
    <message>
        <source>Cipher IV is too short for MD5 kdf</source>
        <translation>Salausalgoritmin alustusvektori on liian lyhyt MD5-avainmuunnosfunktiolle</translation>
    </message>
    <message>
        <source>Unknown KDF: %1</source>
        <translation>Tuntematon avainmuunnosfunktio: %1</translation>
    </message>
    <message>
        <source>Failed to initialize cipher: %1</source>
        <translation>Salauskoodin initialisointi epäonnistui: %1</translation>
    </message>
    <message>
        <source>Decryption failed: %1</source>
        <translation>Salauksen purku epäonnistui: %1</translation>
    </message>
    <message>
        <source>Decryption failed, wrong passphrase?</source>
        <translation>Salauksen purku epäonnistui, väärä salalause?</translation>
    </message>
    <message>
        <source>Unexpected EOF while reading key</source>
        <translation>Odottamaton EOF avainta luettaessa</translation>
    </message>
    <message>
        <source>Unsupported key part</source>
        <translation>Tuntematon avaimen osa</translation>
    </message>
    <message>
        <source>Unexpected EOF while reading public key</source>
        <translation>Odottamaton EOF julkista avainta luettaessa</translation>
    </message>
    <message>
        <source>Unknown key type: %1</source>
        <translation>Tuntematon avaimen tyyppi: %1</translation>
    </message>
    <message>
        <source>Unexpected EOF while reading private key</source>
        <translation>Odottamaton EOF yksityistä avainta luettaessa</translation>
    </message>
    <message>
        <source>Can&apos;t write public key as it is empty</source>
        <translation>Ei voida kirjoittaa julkista avainta, koska se on tyhjä</translation>
    </message>
    <message>
        <source>Unexpected EOF when writing public key</source>
        <translation>Odottamaton EOF julkista avainta kirjoittaessa</translation>
    </message>
    <message>
        <source>Can&apos;t write private key as it is empty</source>
        <translation>Ei voida kirjoittaa yksityistä avainta, koska se on tyhjä</translation>
    </message>
    <message>
        <source>Unexpected EOF when writing private key</source>
        <translation>Odottamaton EOF yksityistä avainta kirjoittaessa</translation>
    </message>
    <message>
        <source>(encrypted)</source>
        <translation>(salattu)</translation>
    </message>
    <message>
        <source>Failed to read key file: %1</source>
        <translation>Avaintiedoston lukeminen epäonnistui: %1</translation>
    </message>
    <message>
        <source>Failed to read public key: %1</source>
        <translation>Julkisen avaimen lukeminen epäonnistui: %1</translation>
    </message>
</context>
<context>
    <name>OpenSSHKeyGenDialog</name>
    <message>
        <source>SSH Key Generator</source>
        <translation>SSH-avaingeneraattori</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Tyyppi</translation>
    </message>
    <message>
        <source>Bits</source>
        <translation>Bitit</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>Kommentti</translation>
    </message>
</context>
<context>
    <name>PasskeyExportDialog</name>
    <message>
        <source>KeePassXC - Passkey Export</source>
        <translation>KeePassXC - Suojasavaimen vienti</translation>
    </message>
    <message>
        <source>Filenames will be generated with title and .passkey file extension.</source>
        <translation>Tiedostot luodaan tietueiden nimillä ja .passkey-päätteellä.</translation>
    </message>
    <message>
        <source>Export entries</source>
        <translation>Vie tietueet</translation>
    </message>
    <message>
        <source>Export Selected</source>
        <translation>Vie valitut</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Peruuta</translation>
    </message>
    <message>
        <source>Export to folder</source>
        <translation>Vie kansioon</translation>
    </message>
    <message>
        <source>Export the following passkey entries.</source>
        <translation>Vie seuraavat passkey-tietueet.</translation>
    </message>
</context>
<context>
    <name>PasskeyExporter</name>
    <message>
        <source>File &quot;%1.passkey&quot; already exists.
Do you want to overwrite it?
</source>
        <translation>Tiedosto &quot;%1.passkey&quot; on jo olemassa.
haluatko korvata sen?
</translation>
    </message>
    <message>
        <source>Cannot open file</source>
        <translation>Tiedoston avaus ei onnistu</translation>
    </message>
    <message>
        <source>Cannot open file &quot;%1&quot; for writing.</source>
        <translation>Tiedoston &quot;%1&quot; avaus muokattavaksi ei onnistu.</translation>
    </message>
    <message>
        <source>Cannot write to file</source>
        <translation>Tiedostoa ei voida tallentaa</translation>
    </message>
    <message>
        <source>Overwrite Existing File?</source>
        <translation>Ylikirjoita olemassa oleva tiedosto?</translation>
    </message>
</context>
<context>
    <name>PasskeyImportDialog</name>
    <message>
        <source>KeePassXC - Passkey Import</source>
        <translation>KeePassXC - Suojausavainvienti</translation>
    </message>
    <message>
        <source>Username: %1</source>
        <translation>Käyttäjätunnus: %1</translation>
    </message>
    <message>
        <source>Group</source>
        <translation>Ryhmä</translation>
    </message>
    <message>
        <source>Database</source>
        <translation>Tietokanta</translation>
    </message>
    <message>
        <source>Import Passkey</source>
        <translation>Tuo suojausavain</translation>
    </message>
    <message>
        <source>Import</source>
        <translation>Tuo</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Peruuta</translation>
    </message>
    <message>
        <source>Entry</source>
        <translation>Tietue</translation>
    </message>
    <message>
        <source>Create new entry</source>
        <translation>Luo uusi tietue</translation>
    </message>
    <message>
        <source>Relying Party: %1</source>
        <translation>Välittävä osapuoli: %1</translation>
    </message>
    <message>
        <source>Import the following passkey:</source>
        <translation>Tuo seuraava passkey:</translation>
    </message>
    <message>
        <source>Import the following passkey to this entry:</source>
        <translation>Tuo seuraava passkey tähän tietueeseen:</translation>
    </message>
    <message>
        <source>Default passkeys group (Imported Passkeys)</source>
        <translation>Passkeys-oletusryhmä (Tuodut passkeyt)</translation>
    </message>
</context>
<context>
    <name>PasskeyImporter</name>
    <message>
        <source>Passkey file</source>
        <translation>Suojausavaintiedosto</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>Kaikki tiedostot</translation>
    </message>
    <message>
        <source>Cannot open file</source>
        <translation>Tiedoston avaus ei onnistu</translation>
    </message>
    <message>
        <source>Cannot open file &quot;%1&quot; for reading.</source>
        <translation>Tiedoston &quot;%1&quot; luku ei onnistu.</translation>
    </message>
    <message>
        <source>Cannot import passkey file &quot;%1&quot;. Data is missing.</source>
        <translation>Passkey-tiedostoa &quot;%1&quot; ei voitu tuoda. Tietoja puuttuu.</translation>
    </message>
    <message>
        <source>Cannot import passkey file &quot;%1&quot;.
The following data is missing:
%2</source>
        <translation>Passkey-tiedostoa ei voida tuoda &quot;%1&quot;.
Seuraavat tiedot puuttuvat:
%2</translation>
    </message>
    <message>
        <source>Cannot import passkey file &quot;%1&quot;. Private key is missing or malformed.</source>
        <translation>Passkey-tiedostoa ei voida tuoda &quot;%1&quot;. Yksityinen avain puuttuu tai on virheellinen.</translation>
    </message>
    <message>
        <source>Open Passkey File</source>
        <translation>Avaa pääsyavaintiedosto</translation>
    </message>
    <message>
        <source>Passkey Import Failed</source>
        <translation>Pääsyavaimen tuonti epäonnistui</translation>
    </message>
</context>
<context>
    <name>PasswordEditWidget</name>
    <message>
        <source>Enter password:</source>
        <translation>Syötä salasana:</translation>
    </message>
    <message>
        <source>Password field</source>
        <translation>Salasanakenttä</translation>
    </message>
    <message>
        <source>Confirm password:</source>
        <translation>Vahvista salasana:</translation>
    </message>
    <message>
        <source>Repeat password field</source>
        <translation>Toista salasana -kenttä</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Salasana</translation>
    </message>
    <message>
        <source>Add Password</source>
        <translation>Lisää salasana</translation>
    </message>
    <message>
        <source>Change Password</source>
        <translation>Muuta salasana</translation>
    </message>
    <message>
        <source>Remove Password</source>
        <translation>Poista salasana</translation>
    </message>
    <message>
        <source>Password set, click to change or remove</source>
        <translation>Salasana asetettu, klikkaa muuttaaksesi tai poistaaksesi</translation>
    </message>
    <message>
        <source>&lt;p&gt;A password is the primary method for securing your database.&lt;/p&gt;&lt;p&gt;Good passwords are long and unique. KeePassXC can generate one for you.&lt;/p&gt;</source>
        <translation>&lt;p&gt;Salasana on kaikkein tärkein asia tietokannan suojauksessa.&lt;/p&gt;&lt;p&gt;Hyvät salasanat ovat pitkiä ja uniikkeja. KeePassXC voi luoda sellaisen sinulle.&lt;/p&gt;</translation>
    </message>
    <message>
        <source>Passwords do not match.</source>
        <translation>Salasanat eivät ole samoja.</translation>
    </message>
</context>
<context>
    <name>PasswordGeneratorWidget</name>
    <message>
        <source>Generate Password</source>
        <translation>Luo salasana</translation>
    </message>
    <message>
        <source>strength</source>
        <comment>Password strength</comment>
        <translation>vahvuus</translation>
    </message>
    <message>
        <source>entropy</source>
        <translation>entropia</translation>
    </message>
    <message>
        <source>Generated password</source>
        <translation>Luotu salasana</translation>
    </message>
    <message>
        <source>%p%</source>
        <translation>%p%</translation>
    </message>
    <message>
        <source>Regenerate password</source>
        <translation>Luo salasana uudelleen</translation>
    </message>
    <message>
        <source>Copy password</source>
        <translation>Kopioi salasana</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Salasana</translation>
    </message>
    <message>
        <source>&amp;Length:</source>
        <translation>&amp;Pituus:</translation>
    </message>
    <message>
        <source>Password length</source>
        <translation>Salasanan pituus</translation>
    </message>
    <message>
        <source>Switch to advanced mode</source>
        <translation>Vaihda kehittyneeseen tilaan</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>Lisäasetukset</translation>
    </message>
    <message>
        <source>Character Types</source>
        <translation>Merkkityypit</translation>
    </message>
    <message>
        <source>Special characters</source>
        <translation>Erikoismerkit</translation>
    </message>
    <message>
        <source>Quotes</source>
        <translation>Lainausmerkit</translation>
    </message>
    <message>
        <source>Punctuation</source>
        <translation>Välimerkit</translation>
    </message>
    <message>
        <source>Dashes and Slashes</source>
        <translation>Viivat ja vinoviivat</translation>
    </message>
    <message>
        <source>Upper-case letters</source>
        <translation>Isot kirjaimet</translation>
    </message>
    <message>
        <source>Numbers</source>
        <translation>Numerot</translation>
    </message>
    <message>
        <source>Lower-case letters</source>
        <translation>Pienet kirjaimet</translation>
    </message>
    <message>
        <source>Math Symbols</source>
        <translation>Matemaattiset symbolit</translation>
    </message>
    <message>
        <source>Extended ASCII</source>
        <translation>Laajennettu ASCII</translation>
    </message>
    <message>
        <source>Braces</source>
        <translation>Sulut</translation>
    </message>
    <message>
        <source>Do not include:</source>
        <translation>Älä sisällytä:</translation>
    </message>
    <message>
        <source>Additional characters to use for the generated password</source>
        <translation>Lisäkirjaimet joita käytetään salasanan luomisessa</translation>
    </message>
    <message>
        <source>Additional characters</source>
        <translation>Lisäkirjaimet</translation>
    </message>
    <message>
        <source>Add non-hex letters to &quot;do not include&quot; list</source>
        <translation>Lisää heksakoodia sisältämättömät kirjaimet &quot;älä sisällytä&quot; -listaan</translation>
    </message>
    <message>
        <source>Hex Passwords</source>
        <translation>Heksasalasanat</translation>
    </message>
    <message>
        <source>Hex</source>
        <translation>Heksa</translation>
    </message>
    <message>
        <source>Character set to exclude from generated password</source>
        <translation>Kirjaimet joita ei käytetä salasanan muodostukseen</translation>
    </message>
    <message>
        <source>Excluded characters</source>
        <translation>Poissuljetut merkit</translation>
    </message>
    <message>
        <source>Also choose from:</source>
        <translation>Valitse myös:</translation>
    </message>
    <message>
        <source>Exclude look-alike characters</source>
        <translation>Poissulje samannäköiset merkit</translation>
    </message>
    <message>
        <source>Pick characters from every group</source>
        <translation>Poimi merkkejä jokaisesta ryhmästä</translation>
    </message>
    <message>
        <source>Passphrase</source>
        <translation>Salalause</translation>
    </message>
    <message>
        <source>Word Separator:</source>
        <translation>Sanaerotin:</translation>
    </message>
    <message>
        <source>Wordlist:</source>
        <translation>Sanalista:</translation>
    </message>
    <message>
        <source>Word Count:</source>
        <translation>Sanamäärä:</translation>
    </message>
    <message>
        <source>Word Case:</source>
        <translation>Aakkoslaji:</translation>
    </message>
    <message>
        <source>Delete selected wordlist</source>
        <translation>Poista valittu sanalista</translation>
    </message>
    <message>
        <source>Add custom wordlist</source>
        <translation>Lisää mukautettu sanalista</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Sulje</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
    <message>
        <source>Apply Password</source>
        <translation>Käytä salasanaa</translation>
    </message>
    <message>
        <source>Regenerate password (%1)</source>
        <translation>Luo salasana uudelleen (%1)</translation>
    </message>
    <message>
        <source>lower case</source>
        <translation>pienaakkoset</translation>
    </message>
    <message>
        <source>UPPER CASE</source>
        <translation>SUURAAKKOSET</translation>
    </message>
    <message>
        <source>Title Case</source>
        <translation>Otsikon aakkoslaji</translation>
    </message>
    <message>
        <source>(SYSTEM)</source>
        <translation>(JÄRJESTELMÄ)</translation>
    </message>
    <message>
        <source>Entropy: %1 bit</source>
        <translation>Entropia: %1 bit</translation>
    </message>
    <message>
        <source>Password Quality: %1</source>
        <translation>Salasanan laatu: %1</translation>
    </message>
    <message>
        <source>Poor</source>
        <comment>Password quality</comment>
        <translation>Huono</translation>
    </message>
    <message>
        <source>Weak</source>
        <comment>Password quality</comment>
        <translation>Heikko</translation>
    </message>
    <message>
        <source>Good</source>
        <comment>Password quality</comment>
        <translation>Hyvä</translation>
    </message>
    <message>
        <source>Excellent</source>
        <comment>Password quality</comment>
        <translation>Erinomainen</translation>
    </message>
    <message>
        <source>Failed to delete wordlist</source>
        <translation>Sanalistaa ei voitu poistaa</translation>
    </message>
    <message>
        <source>Wordlists</source>
        <translation>Sanalistat</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>Kaikki tiedostot</translation>
    </message>
    <message>
        <source>Select Custom Wordlist</source>
        <translation>Valitse mukautettu sanalista</translation>
    </message>
    <message>
        <source>Overwrite Wordlist?</source>
        <translation>Ylikirjoita sanalista?</translation>
    </message>
    <message>
        <source>Wordlist &quot;%1&quot; already exists as a custom wordlist.
Do you want to overwrite it?</source>
        <translation>&quot;%1&quot; on jo mukautettu sanalista.
Haluatko ylikirjoittaa sen?</translation>
    </message>
    <message>
        <source>Failed to add wordlist</source>
        <translation>Sanalistaa ei voitu lisätä</translation>
    </message>
    <message>
        <source>Logograms</source>
        <translation>Erikoismerkit</translation>
    </message>
    <message>
        <source>Special Characters</source>
        <translation>Erikoismerkit</translation>
    </message>
    <message>
        <source>passwordLength</source>
        <translation>salasanan pituus</translation>
    </message>
    <message>
        <source>Characters: %1</source>
        <translation>Krijaimia: %1</translation>
    </message>
    <message>
        <source>MIXED case</source>
        <translation>SEKOITETTU kirjasin</translation>
    </message>
    <message>
        <source>Excluded characters: &quot;0&quot;, &quot;1&quot;, &quot;l&quot;, &quot;I&quot;, &quot;O&quot;, &quot;|&quot;, &quot;﹒&quot;, &quot;B&quot;, &quot;8&quot;, &quot;G&quot;, &quot;6&quot;</source>
        <translation>Pois suljetut merkit: ”0”, ”1”, ”l”, ”I”, ”O”, ”|”, ”﹒”, ”B”, ”8”, ”G”, ”6”</translation>
    </message>
    <message>
        <source>Warning: the chosen wordlist is smaller than the minimum recommended size!</source>
        <translation>Varoitus: valittu sanalista on pienempi kuin pienin suositeltu!</translation>
    </message>
    <message>
        <source>Confirm Remove Wordlist</source>
        <translation>Varmista sanalistan poisto</translation>
    </message>
    <message>
        <source>Do you really want to remove the wordlist &quot;%1&quot;?</source>
        <translation>Haluatko varmasti poistaa sanalistan &quot;%1&quot;?</translation>
    </message>
</context>
<context>
    <name>PasswordWidget</name>
    <message>
        <source>Passwords do not match</source>
        <translation>Salasanat eivät täsmää</translation>
    </message>
    <message>
        <source>Passwords match so far</source>
        <translation>Salasanat jotka ovat tähän mennessä samoja</translation>
    </message>
    <message>
        <source>Toggle Password (%1)</source>
        <translation>Ota salasana käyttöön (%1)</translation>
    </message>
    <message>
        <source>Generate Password (%1)</source>
        <translation>Luo salasana (%1)</translation>
    </message>
    <message>
        <source>Warning: Caps Lock enabled!</source>
        <translation>Varoitus: Caps Lock on päällä!</translation>
    </message>
    <message>
        <source>Quality: %1</source>
        <translation>Laatu: %1</translation>
    </message>
    <message>
        <source>Poor</source>
        <comment>Password quality</comment>
        <translation>Huono</translation>
    </message>
    <message>
        <source>Weak</source>
        <comment>Password quality</comment>
        <translation>Heikko</translation>
    </message>
    <message>
        <source>Good</source>
        <comment>Password quality</comment>
        <translation>Hyvä</translation>
    </message>
    <message>
        <source>Excellent</source>
        <comment>Password quality</comment>
        <translation>Erinomainen</translation>
    </message>
    <message>
        <source>Toggle password visibility using Control + H. Open the password generator using Control + G.</source>
        <translation>Kytke salasanan näyttö Ctrl+H-näppäinyhdistelmällä. Avaa salasanageneraattori painamalla Ctrl+G.</translation>
    </message>
</context>
<context>
    <name>PickcharsDialog</name>
    <message>
        <source>KeePassXC - Pick Characters</source>
        <translation>KeePassXC - Valitse merkkejä</translation>
    </message>
    <message>
        <source>Select characters to type, navigate with arrow keys, Ctrl + S submits.</source>
        <translation>Valitse merkkejä joita haluat käyttää. Siirry nuolinäppäimillä, Ctrl+S syöttää.</translation>
    </message>
    <message>
        <source>Press &amp;Tab between characters</source>
        <translation>Paina &amp;Tab merkkien välillä</translation>
    </message>
</context>
<context>
    <name>PreviewEntryAttachmentsDialog</name>
    <message>
        <source>Form</source>
        <translation>Lomake</translation>
    </message>
    <message>
        <source>Preview: %1</source>
        <translation>Esikatsele: %1</translation>
    </message>
    <message>
        <source>Save…</source>
        <translation>Tallenna...</translation>
    </message>
</context>
<context>
    <name>QMessageBox</name>
    <message>
        <source>Overwrite</source>
        <translation>Korvaa</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Poista</translation>
    </message>
    <message>
        <source>Move</source>
        <translation>Siirrä</translation>
    </message>
    <message>
        <source>Empty</source>
        <translation>Tyhjennä</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Poista</translation>
    </message>
    <message>
        <source>Skip</source>
        <translation>Ohita</translation>
    </message>
    <message>
        <source>Disable</source>
        <translation>Kytke pois päältä</translation>
    </message>
    <message>
        <source>Merge</source>
        <translation>Yhdistä</translation>
    </message>
    <message>
        <source>Continue</source>
        <translation>Jatka</translation>
    </message>
    <message>
        <source>Continue with weak password</source>
        <translation>Jatka heikolla salasalanalla</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Database not opened</source>
        <translation>Tietokanta ei avattu</translation>
    </message>
    <message>
        <source>Database hash not available</source>
        <translation>Tietokannan tiivistettä (hash) ei saatu</translation>
    </message>
    <message>
        <source>Client public key not received</source>
        <translation>Asiakkaan julkista avainta ei saatu</translation>
    </message>
    <message>
        <source>Cannot decrypt message</source>
        <translation>Viestin salauksen purkaminen ei onnistu</translation>
    </message>
    <message>
        <source>Action cancelled or denied</source>
        <translation>Toiminto peruttiin tai estettiin</translation>
    </message>
    <message>
        <source>Message encryption failed.</source>
        <translation>Viestin salaus epäonnistui</translation>
    </message>
    <message>
        <source>KeePassXC association failed, try again</source>
        <translation>Liittäminen KeePassXC:hen epäonnistui, yritä uudelleen</translation>
    </message>
    <message>
        <source>Encryption key is not recognized</source>
        <translation>Salausavainta ei tunnistettu</translation>
    </message>
    <message>
        <source>Incorrect action</source>
        <translation>Virheellinen toiminto</translation>
    </message>
    <message>
        <source>Empty message received</source>
        <translation>Vastaanotettiin tyhjä viesti</translation>
    </message>
    <message>
        <source>No URL provided</source>
        <translation>Sivuston osoitetta ei ole annettu</translation>
    </message>
    <message>
        <source>No logins found</source>
        <translation>Tunnuksia ei löydy</translation>
    </message>
    <message>
        <source>No groups found</source>
        <translation>Ryhmiä ei löytynyt</translation>
    </message>
    <message>
        <source>Cannot create new group</source>
        <translation>Uutta ryhmää ei voitu luoda</translation>
    </message>
    <message>
        <source>No valid UUID provided</source>
        <translation>Virheellinen UUID annettu</translation>
    </message>
    <message>
        <source>Username or password cannot contain references</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Unknown error</source>
        <translation>Tuntematon virhe</translation>
    </message>
    <message>
        <source>Browser Integration</source>
        <translation>Selainintegraatio</translation>
    </message>
    <message>
        <source>Browser Plugin Failure</source>
        <translation>Selainliitännän virhe</translation>
    </message>
    <message>
        <source>Could not save the native messaging script file for %1.</source>
        <translation>Native messaging -skriptatiedostoa ei voitu tallentaa %1.</translation>
    </message>
    <message>
        <source>Username for the entry.</source>
        <translation>Tietueen käyttäjätunnus.</translation>
    </message>
    <message>
        <source>username</source>
        <translation>käyttäjätunnus</translation>
    </message>
    <message>
        <source>URL for the entry.</source>
        <translation>Tietueen osoite.</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>Notes for the entry.</source>
        <translation>Tietueen muistiinpanot.</translation>
    </message>
    <message>
        <source>Notes</source>
        <translation>Muistiinpanot</translation>
    </message>
    <message>
        <source>Prompt for the entry&apos;s password.</source>
        <translation>Tietueen salasanan kuvaus.</translation>
    </message>
    <message>
        <source>Generate a password for the entry.</source>
        <translation>Luo tietueelle salasana.</translation>
    </message>
    <message>
        <source>Add a new entry to a database.</source>
        <translation>Lisää uusi tietue tietokantaan.</translation>
    </message>
    <message>
        <source>Path of the entry to add.</source>
        <translation>Lisättävän tietueen polku.</translation>
    </message>
    <message>
        <source>Cannot generate a password and prompt at the same time.</source>
        <translation>Salasanaa ei voida luoda ja asettaa yhtäaikaisesti.</translation>
    </message>
    <message>
        <source>Could not create entry with path %1.</source>
        <translation>Tietuetta ei voitu luoda polun %1 kanssa.</translation>
    </message>
    <message>
        <source>Enter password for new entry: </source>
        <translation>Anna uuden tietueen salasana:</translation>
    </message>
    <message>
        <source>Writing the database failed %1.</source>
        <translation>Tietokantaan kirjoittaminen epäonnistui %1.</translation>
    </message>
    <message>
        <source>Successfully added entry %1.</source>
        <translation>Tietueen %1 lisäys onnistui.</translation>
    </message>
    <message>
        <source>Adds a new group to a database.</source>
        <translation>Lisää uuden ryhmän tietokantaan.</translation>
    </message>
    <message>
        <source>Path of the group to add.</source>
        <translation>Lisättävän ryhmän polku.</translation>
    </message>
    <message>
        <source>Group %1 already exists!</source>
        <translation>Ryhmä %1 on jo olemassa!</translation>
    </message>
    <message>
        <source>Group %1 not found.</source>
        <translation>Ryhmää %1 ei löydy.</translation>
    </message>
    <message>
        <source>Successfully added group %1.</source>
        <translation>Ryhmä %1 lisättiin onnistuneesti.</translation>
    </message>
    <message>
        <source>Check if any passwords have been publicly leaked. FILENAME must be the path of a file listing SHA-1 hashes of leaked passwords in HIBP format, as available from https://haveibeenpwned.com/Passwords.</source>
        <translation>Tarkista onko yksikään salanoista julkisesti vuotanut. TIEDOSTONIMEN täytyy osoittaa sijaintiin tiedostosta, joka listaa SHA-1 -tiivisteet vuotaneista salasanoista HIBP-muodossa, kuten sivusto https://haveibeenpwned.com/Passwords tarjoaa.</translation>
    </message>
    <message>
        <source>FILENAME</source>
        <translation>TIEDOSTONIMI</translation>
    </message>
    <message>
        <source>Path to okon-cli to search a formatted HIBP file</source>
        <translation>Polku okon-cli:hin formatoidun HIBP-tiedoston etsimiseksi</translation>
    </message>
    <message>
        <source>okon-cli</source>
        <translation>okon-cli</translation>
    </message>
    <message>
        <source>Analyze passwords for weaknesses and problems.</source>
        <translation>Analysoi salasanojen heikkouksia ja ongelmia.</translation>
    </message>
    <message>
        <source>Cannot find HIBP file: %1</source>
        <translation>HIBP-tiedostoa ei löytynyt: %1</translation>
    </message>
    <message>
        <source>Evaluating database entries using okon…</source>
        <translation>Tarkastetaan tietokannan tietueita okon:ia käyttäen...</translation>
    </message>
    <message>
        <source>Failed to open HIBP file %1: %2</source>
        <translation>HIBP-tiedoston %1 avaus epäonnistui: %2</translation>
    </message>
    <message>
        <source>Evaluating database entries against HIBP file, this will take a while…</source>
        <translation>Tarkastetaan tietokantaa HIBP-tiedostoa vasten, tämä kestää hetken aikaa...</translation>
    </message>
    <message numerus="yes">
        <source>Password for &apos;%1&apos; has been leaked %2 time(s)!</source>
        <translation><numerusform>Salasana palveluun &apos;%1&apos; on vuotanut %1 kerran!</numerusform><numerusform>Salasana palveluun &apos;%1&apos; on vuotanut %2 kertaa!</numerusform></translation>
    </message>
    <message>
        <source>Password for &apos;%1&apos; has been leaked!</source>
        <translation>Salasanat sivustoille &apos;%1&apos; ovat vuotaneet!</translation>
    </message>
    <message>
        <source>Export an attachment of an entry.</source>
        <translation>Vie tietueen liite</translation>
    </message>
    <message>
        <source>Path of the entry with the target attachment.</source>
        <translation>Liitteen sisältävän tietueen polku</translation>
    </message>
    <message>
        <source>Name of the attachment to be exported.</source>
        <translation>Viedyn liitteen nimi.</translation>
    </message>
    <message>
        <source>Path to which the attachment should be exported.</source>
        <translation>Hakemistopolku johon vienti tehdään.</translation>
    </message>
    <message>
        <source>Could not find entry with path %1.</source>
        <translation>Tietuetta polulla %1 ei löydetty.</translation>
    </message>
    <message>
        <source>Could not find attachment with name %1.</source>
        <translation>Liitettä nimellä %1 ei löydetty.</translation>
    </message>
    <message>
        <source>No export target given. Please use &apos;--stdout&apos; or specify an &apos;export-file&apos;.</source>
        <translation>Viennin kohdetta ei ole määritetty. Ole hyvä ja käytä &apos;--stdout&apos;:ia määrittääksesi sen.</translation>
    </message>
    <message>
        <source>Could not open output file %1.</source>
        <translation>Kohdetiedostoa %1 ei voitu avata.</translation>
    </message>
    <message>
        <source>Successfully exported attachment %1 of entry %2 to %3.</source>
        <translation>Vietiin tietueen %2 liite %1 onnistuneesti kohteeseen %3.</translation>
    </message>
    <message>
        <source>Overwrite existing attachments.</source>
        <translation>Ylikirjoita olemassa olevat liitteet.</translation>
    </message>
    <message>
        <source>Imports an attachment to an entry.</source>
        <translation>Tuo liite tietueeseen.</translation>
    </message>
    <message>
        <source>Path of the entry.</source>
        <translation>Tietueen polku.</translation>
    </message>
    <message>
        <source>Name of the attachment to be added.</source>
        <translation>Lisättävän liitteen nimi.</translation>
    </message>
    <message>
        <source>Path of the attachment to be imported.</source>
        <translation>Tuodun liitteen polku.</translation>
    </message>
    <message>
        <source>Attachment %1 already exists for entry %2.</source>
        <translation>Liite %1 on jo tietueessa %2.</translation>
    </message>
    <message>
        <source>Could not open attachment file %1.</source>
        <translation>Liitettä %1 ei voitu avata.</translation>
    </message>
    <message>
        <source>Successfully imported attachment %1 as %2 to entry %3.</source>
        <translation>Tuotiin onnistuneesti liite %1 muodossa %2 tietueeseen %3.</translation>
    </message>
    <message>
        <source>Remove an attachment of an entry.</source>
        <translation>Poista liite tietueesta.</translation>
    </message>
    <message>
        <source>Name of the attachment to be removed.</source>
        <translation>Poistettavan liitteen nimi.</translation>
    </message>
    <message>
        <source>Successfully removed attachment %1 from entry %2.</source>
        <translation>Poistettiin liite %1 tietueesta %2.</translation>
    </message>
    <message>
        <source>Copy the given attribute to the clipboard. Defaults to &quot;password&quot; if not specified.</source>
        <comment>Don't translate &quot;password&quot;, it refers to the attribute.</comment>
        <translation>Kopioi annettu attribuutti leikepöydälle. Asetetaan oletukseen &quot;password&quot;, mikäli tätä ei ole asetettu.</translation>
    </message>
    <message>
        <source>Copy the current TOTP to the clipboard (equivalent to &quot;-a totp&quot;).</source>
        <translation>Kopioi tämän hetkinen TOTP leikepöydälle (sama kuin &quot;-a totp&quot;).</translation>
    </message>
    <message>
        <source>Must match only one entry, otherwise a list of possible matches is shown.</source>
        <translation>Vain yhden tietueen täytyy olla sopiva. Muussa tapauksessa näytetään lista kaikista mahdollisista tietueista.</translation>
    </message>
    <message>
        <source>Copy an entry&apos;s attribute to the clipboard.</source>
        <translation>Kopioi tietueen attribuutti leikepöydälle</translation>
    </message>
    <message>
        <source>Path of the entry to clip.</source>
        <comment>clip = copy to clipboard</comment>
        <translation>Kopioitavan tietueen polku.</translation>
    </message>
    <message>
        <source>Timeout before clearing the clipboard (default is %1 seconds, set to 0 for unlimited).</source>
        <translation>Viive ennen leikepöydän tyhjentämistä (vakio on %1 sekuntia, aseta se nollaksi, jos et halua tyhjentää sitä lainkaan)</translation>
    </message>
    <message>
        <source>Invalid timeout value %1.</source>
        <translation>Virheellinen aikakatkaisun arvo %1.</translation>
    </message>
    <message>
        <source>Multiple entries matching:</source>
        <translation>Usea tietue sopii hakutuloksiin:</translation>
    </message>
    <message>
        <source>Using matching entry: %1</source>
        <translation>Käytetään sopivaa tietuetta: %1</translation>
    </message>
    <message>
        <source>Entry %1 not found.</source>
        <translation>Tietuetta %1 ei löytynyt.</translation>
    </message>
    <message>
        <source>ERROR: Please specify one of --attribute or --totp, not both.</source>
        <translation>VIRHE: Määritä joko --attribute tai --totp, mutta älä molempia.</translation>
    </message>
    <message>
        <source>Entry with path %1 has no TOTP set up.</source>
        <translation>Tietueella joka käyttää polkua %1 ei ole TOTP:ia asetettuna.</translation>
    </message>
    <message>
        <source>ERROR: attribute %1 is ambiguous, it matches %2.</source>
        <translation>VIRHE: attribuutti %1 on epäselvä, se sopii yhteen %2 kanssa.</translation>
    </message>
    <message>
        <source>Attribute &quot;%1&quot; not found.</source>
        <translation>Attribuuttia &quot;%1&quot; ei löydy.</translation>
    </message>
    <message>
        <source>Entry&apos;s &quot;%1&quot; attribute copied to the clipboard!</source>
        <translation>Tietueen &quot;%1&quot; attribuutti on kopioitu leikepöydälle!</translation>
    </message>
    <message numerus="yes">
        <source>Clearing the clipboard in %1 second(s)...</source>
        <translation><numerusform>Tyhjennetään leikepöytä %1 sekunnissa...</numerusform><numerusform>Tyhjennetään leikepöytä %1 sekunnissa...</numerusform></translation>
    </message>
    <message>
        <source>Clipboard cleared!</source>
        <translation>Leikepöytä tyhjennetty!</translation>
    </message>
    <message>
        <source>Close the currently opened database.</source>
        <translation>Sulje parhaillaan avoinna oleva tietokanta.</translation>
    </message>
    <message>
        <source>Display this help.</source>
        <translation>Näytä tämä ohje.</translation>
    </message>
    <message>
        <source>Silence password prompt and other secondary outputs.</source>
        <translation>Hiljennä salasanamuistutus ja muut toissijaiset tulostukset.</translation>
    </message>
    <message>
        <source>Key file of the database.</source>
        <translation>Tietokannan avaintiedosto.</translation>
    </message>
    <message>
        <source>path</source>
        <translation>polku</translation>
    </message>
    <message>
        <source>Deactivate password key for the database.</source>
        <translation>Poista salasana-avain tietokannasta.</translation>
    </message>
    <message>
        <source>Yubikey slot and optional serial used to access the database (e.g., 1:7370001).</source>
        <translation>Yubikeyn paikka ja valinnainen serial tietokannan pääsyyn (esim. 1:7370001).</translation>
    </message>
    <message>
        <source>slot[:serial]</source>
        <translation>paikka[:serial]</translation>
    </message>
    <message>
        <source>Missing positional argument(s).</source>
        <translation>Sijaintikohtaiset argumentit puuttuvat</translation>
    </message>
    <message>
        <source>Too many arguments provided.</source>
        <translation>Liian monta argumenttia annettu</translation>
    </message>
    <message>
        <source>Path of the database.</source>
        <translation>Tietokannan polku.</translation>
    </message>
    <message>
        <source>Target decryption time in MS for the database.</source>
        <translation>Kohteen salauksen purkuun kuluva aika millisekunneissa tietokannalle.</translation>
    </message>
    <message>
        <source>time</source>
        <translation>aika</translation>
    </message>
    <message>
        <source>Set the key file for the database.</source>
        <translation>Syötä tietokannan avaintiedosto.</translation>
    </message>
    <message>
        <source>Set a password for the database.</source>
        <translation>Syötä tietokannan salasana.</translation>
    </message>
    <message>
        <source>Create a new database.</source>
        <translation>Luo uusi tietokanta.</translation>
    </message>
    <message>
        <source>Invalid decryption time %1.</source>
        <translation>Virheellinen salauksen purun aika %1.</translation>
    </message>
    <message>
        <source>Target decryption time must be between %1 and %2.</source>
        <translation>Kohteen salauksen purkuun kuluva aika täytyy olla välillä %1 ja %2.</translation>
    </message>
    <message>
        <source>Failed to set database password.</source>
        <translation>Tietokannan salasanan asettaminen ei onnistunut.</translation>
    </message>
    <message>
        <source>Loading the key file failed</source>
        <translation>Avaintiedoston lataaminen epäonnistui</translation>
    </message>
    <message>
        <source>No key is set. Aborting database creation.</source>
        <translation>Avainta ei ole asetettu. Perutaan tietokannan luominen.</translation>
    </message>
    <message>
        <source>Benchmarking key derivation function for %1ms delay.</source>
        <translation>Verrataan avainmuunnosfunktiota %1 ms:n viiveelle.</translation>
    </message>
    <message>
        <source>Setting %1 rounds for key derivation function.</source>
        <translation>Asetetaan %1 kierrosta avainmuunnosfunktiolle.</translation>
    </message>
    <message>
        <source>error while setting database key derivation settings.</source>
        <translation>Virhe asetettaessa tietokannan avainmuunnosfunktion asetuksia.</translation>
    </message>
    <message>
        <source>File %1 already exists.</source>
        <translation>Tiedosto %1 on jo olemassa.</translation>
    </message>
    <message>
        <source>Failed to save the database: %1.</source>
        <translation>Tietokannan tallentaminen epäonnistui: %1.</translation>
    </message>
    <message>
        <source>Successfully created new database.</source>
        <translation>Luotiin onnistuneesti uusi tietokanta.</translation>
    </message>
    <message>
        <source>Unset the password for the database.</source>
        <translation>Poista tietokannan salasanamääritys.</translation>
    </message>
    <message>
        <source>Unset the key file for the database.</source>
        <translation>Poista tietokannan avainmääritys.</translation>
    </message>
    <message>
        <source>Edit a database.</source>
        <translation>Muokkaa tietokantaa</translation>
    </message>
    <message>
        <source>Cannot use %1 and %2 at the same time.</source>
        <translation>Näitä ei voida käyttää samanaikaisesti: %1 ja %2.</translation>
    </message>
    <message>
        <source>Could not change the database key.</source>
        <translation>Tietokannan avainta ei voitu vaihtaa.</translation>
    </message>
    <message>
        <source>Database was not modified.</source>
        <translation>Tietokantaa ei muokattu.</translation>
    </message>
    <message>
        <source>Writing the database failed: %1</source>
        <translation>Tietokannan kirjoittaminen epäonnistui: %1</translation>
    </message>
    <message>
        <source>Successfully edited the database.</source>
        <translation>Tietokantaa muokattiin.</translation>
    </message>
    <message>
        <source>Cannot remove password: The database does not have a password.</source>
        <translation>Salasanan poisto ei onnistu: tietokannalla ei ole salasanaa.</translation>
    </message>
    <message>
        <source>Cannot remove file key: The database does not have a file key.</source>
        <translation>Tiedostoavaimen poisto ei onnistu: tietokannalla ei ole tiedostoavainta.</translation>
    </message>
    <message>
        <source>Loading the new key file failed: %1</source>
        <translation>Uuden avaintiedoston lataus epäonnistui: %1</translation>
    </message>
    <message>
        <source>Found unexpected Key type %1</source>
        <translation>Löytyi odottamaton avaintyyppi %1</translation>
    </message>
    <message>
        <source>Cannot remove all the keys from a database.</source>
        <translation>Tietokannan kaikkia avaimia ei voida poistaa.</translation>
    </message>
    <message>
        <source>Show a database&apos;s information.</source>
        <translation>Näytä tietokannan tiedot.</translation>
    </message>
    <message>
        <source>UUID: </source>
        <translation>UUID:</translation>
    </message>
    <message>
        <source>Name: </source>
        <translation>Nimi:</translation>
    </message>
    <message>
        <source>Description: </source>
        <translation>Kuvaus:</translation>
    </message>
    <message>
        <source>Cipher: </source>
        <translation>Salaus:</translation>
    </message>
    <message>
        <source>KDF: </source>
        <translation>KDF:</translation>
    </message>
    <message>
        <source>Recycle bin is enabled.</source>
        <translation>Roskakori on otettu käyttöön.</translation>
    </message>
    <message>
        <source>Recycle bin is not enabled.</source>
        <translation>Roskakori ei ole käytössä.</translation>
    </message>
    <message>
        <source>Location</source>
        <translation>Sijainti</translation>
    </message>
    <message>
        <source>Database created</source>
        <translation>Tietokanta luotu</translation>
    </message>
    <message>
        <source>Last saved</source>
        <translation>Viimeksi tallennettu</translation>
    </message>
    <message>
        <source>Unsaved changes</source>
        <translation>Tallentamattomia muutoksia</translation>
    </message>
    <message>
        <source>yes</source>
        <translation>kyllä</translation>
    </message>
    <message>
        <source>no</source>
        <translation>ei</translation>
    </message>
    <message>
        <source>Number of groups</source>
        <translation>Ryhmien määrä</translation>
    </message>
    <message>
        <source>Number of entries</source>
        <translation>Tietueiden lukumäärä</translation>
    </message>
    <message>
        <source>Number of expired entries</source>
        <translation>Vanhentuneiden tietueiden lukumäärä</translation>
    </message>
    <message>
        <source>Unique passwords</source>
        <translation>Yksilöllisiä salasanoja</translation>
    </message>
    <message>
        <source>Non-unique passwords</source>
        <translation>Ei-yksilöllisiä salasanoja</translation>
    </message>
    <message>
        <source>Maximum password reuse</source>
        <translation>Maksimimäärä samoja salasanoja</translation>
    </message>
    <message>
        <source>Number of short passwords</source>
        <translation>Lyhyiden salasanojen määrä</translation>
    </message>
    <message>
        <source>Number of weak passwords</source>
        <translation>Heikkojen salasanojen määrä</translation>
    </message>
    <message>
        <source>Entries excluded from reports</source>
        <translation>Tietueet jotka on poissuljettu raporteista</translation>
    </message>
    <message>
        <source>Average password length</source>
        <translation>Salasanan keskimääräinen pituus</translation>
    </message>
    <message>
        <source>Number of passkeys</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Entries with TOTP setup</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Word count for the diceware passphrase.</source>
        <translation>Sanamäärä noppaware-salalauseelle.</translation>
    </message>
    <message>
        <source>count</source>
        <comment>CLI parameter</comment>
        <translation>määrä</translation>
    </message>
    <message>
        <source>Wordlist for the diceware generator.
[Default: EFF English]</source>
        <translation>Sanalista noppaware-luojalle.
[Oletus: EFF Englanti]</translation>
    </message>
    <message>
        <source>Generate a new random diceware passphrase.</source>
        <translation>Luo uusi satunnainen noppaware-salalause</translation>
    </message>
    <message>
        <source>Invalid word count %1</source>
        <translation>Väärä sanamäärä %1</translation>
    </message>
    <message>
        <source>Title for the entry.</source>
        <translation>Tietueen nimi</translation>
    </message>
    <message>
        <source>title</source>
        <translation>nimi</translation>
    </message>
    <message>
        <source>Edit an entry.</source>
        <translation>Muokkaa tietuetta.</translation>
    </message>
    <message>
        <source>Path of the entry to edit.</source>
        <translation>Muokattavan tietueen polku.</translation>
    </message>
    <message>
        <source>Not changing any field for entry %1.</source>
        <translation>Yhtään kenttää tietueelle %1 ei vaihdettu.</translation>
    </message>
    <message>
        <source>Enter new password for entry: </source>
        <translation>Anna tietueelle uusi salasana:</translation>
    </message>
    <message>
        <source>Successfully edited entry %1.</source>
        <translation>Tietuetta %1 muokattiin onnistuneesti.</translation>
    </message>
    <message>
        <source>Perform advanced analysis on the password.</source>
        <translation>Suorita salasanalle edistynyt analyysi.</translation>
    </message>
    <message>
        <source>Password for which to estimate the entropy.</source>
        <translation>Salasana josta entropia arvioidaan.</translation>
    </message>
    <message>
        <source>Estimate the entropy of a password.</source>
        <translation>Salasanan arvioitu entropia.</translation>
    </message>
    <message>
        <source>Length %1</source>
        <translation>Pituus %1</translation>
    </message>
    <message>
        <source>Entropy %1</source>
        <translation>Entropia %1</translation>
    </message>
    <message>
        <source>Log10 %1</source>
        <translation>Log10 %1</translation>
    </message>
    <message>
        <source>Multi-word extra bits %1</source>
        <translation>Monisanaiset ylimääräiset tavut %1</translation>
    </message>
    <message>
        <source>Type: Bruteforce</source>
        <translation>Tyyppi: Väsytyshyökkäys</translation>
    </message>
    <message>
        <source>Type: Dictionary</source>
        <translation>Tyyppi: Sanakirja</translation>
    </message>
    <message>
        <source>Type: Dict+Leet</source>
        <translation>Tyyppi: Sanakirja + Leet</translation>
    </message>
    <message>
        <source>Type: User Words</source>
        <translation>Tyyppi: Käyttäjän sanat</translation>
    </message>
    <message>
        <source>Type: User+Leet</source>
        <translation>Tyyppi: Käyttäjän sanat + Leet</translation>
    </message>
    <message>
        <source>Type: Repeated</source>
        <translation>Tyyppi: Toistettu</translation>
    </message>
    <message>
        <source>Type: Sequence</source>
        <translation>Tyyppi: Sekvenssi</translation>
    </message>
    <message>
        <source>Type: Spatial</source>
        <translation>Tyyppi: Spatiaalinen</translation>
    </message>
    <message>
        <source>Type: Date</source>
        <translation>Tyyppi: Päivämäärä</translation>
    </message>
    <message>
        <source>Type: Bruteforce(Rep)</source>
        <translation>Tyyppi: Väsytyshyökkäys (toistettu)</translation>
    </message>
    <message>
        <source>Type: Dictionary(Rep)</source>
        <translation>Tyyppi: Sanakirja (toistettu)</translation>
    </message>
    <message>
        <source>Type: Dict+Leet(Rep)</source>
        <translation>Tyyppi: Sanakirja + Leet (toistettu)</translation>
    </message>
    <message>
        <source>Type: User Words(Rep)</source>
        <translation>Tyyppi: Käyttäjän sanat (toistettu)</translation>
    </message>
    <message>
        <source>Type: User+Leet(Rep)</source>
        <translation>Tyyppi: Käyttäjän sanat + Leet (toistettu)</translation>
    </message>
    <message>
        <source>Type: Repeated(Rep)</source>
        <translation>Tyyppi: Toistettu (toistettu)</translation>
    </message>
    <message>
        <source>Type: Sequence(Rep)</source>
        <translation>Tyyppi: Sekvenssi (toistettu)</translation>
    </message>
    <message>
        <source>Type: Spatial(Rep)</source>
        <translation>Tyyppi: Spatiaalinen (toistettu)</translation>
    </message>
    <message>
        <source>Type: Date(Rep)</source>
        <translation>Tyyppi: Päivämäärä (toistettu)</translation>
    </message>
    <message>
        <source>Type: Unknown (%1)</source>
        <translation>Tyyppi: Tuntematon (%1)</translation>
    </message>
    <message>
        <source>Entropy %1 (%2)</source>
        <translation>Entropia %1 (%2)</translation>
    </message>
    <message>
        <source>*** Password length (%1) != sum of length of parts (%2) ***</source>
        <translation>*** Salasanan pituus (%1) != osien (%2) summa ***</translation>
    </message>
    <message>
        <source>Exit interactive mode.</source>
        <translation>Poistu interaktiivisesta tilasta.</translation>
    </message>
    <message>
        <source>Exports the content of a database to standard output in the specified format.</source>
        <translation>Vie tietokannan sisällön standardiin tulosteeseen (stdout) halutussa formaatissa.</translation>
    </message>
    <message>
        <source>Unable to export database to XML: %1</source>
        <translation>Tietokantaa ei voitu viedä XML-muotoon: %1</translation>
    </message>
    <message>
        <source>Unsupported format %1</source>
        <translation>Formaattia %1 ei ole tuettu</translation>
    </message>
    <message>
        <source>Length of the generated password</source>
        <translation>Luodun salasanan pituus</translation>
    </message>
    <message>
        <source>length</source>
        <translation>pituus</translation>
    </message>
    <message>
        <source>Use lowercase characters</source>
        <translation>Käytiä pieniä merkkejä</translation>
    </message>
    <message>
        <source>Use uppercase characters</source>
        <translation>Käytä isoja merkkejä</translation>
    </message>
    <message>
        <source>Use numbers</source>
        <translation>Käytä numeroita</translation>
    </message>
    <message>
        <source>Use special characters</source>
        <translation>Käytä erikoismerkkejä</translation>
    </message>
    <message>
        <source>Use extended ASCII</source>
        <translation>Käytä laajennettua ASCII-merkistöä</translation>
    </message>
    <message>
        <source>Exclude character set</source>
        <translation>Älä sisällytä merkkejä</translation>
    </message>
    <message>
        <source>chars</source>
        <translation>merkit</translation>
    </message>
    <message>
        <source>Use custom character set</source>
        <translation>Käytä mukautettua merkkilistaa</translation>
    </message>
    <message>
        <source>Exclude similar looking characters</source>
        <translation>Älä sisällytä samankaltaisilta vaikuttavia kirjaimia</translation>
    </message>
    <message>
        <source>Include characters from every selected group</source>
        <translation>Sisällytä kirjaimia jokaisesta valitusta ryhmästä</translation>
    </message>
    <message>
        <source>Generate a new random password.</source>
        <translation>Luo uusi satunnainen salasana.</translation>
    </message>
    <message>
        <source>Invalid password length %1</source>
        <translation>Väärä salasanan pituus %1</translation>
    </message>
    <message>
        <source>Invalid password generator after applying all options</source>
        <translation>Virheellinen salasanageneraattori kaikkien aktiivisten asetusten kanssa</translation>
    </message>
    <message>
        <source>Display command help.</source>
        <translation>Näytä komento-ohjeistus</translation>
    </message>
    <message>
        <source>Available commands:</source>
        <translation>Käytettävissä olevat komennot:</translation>
    </message>
    <message>
        <source>Import the contents of an XML database.</source>
        <translation>Tuo XML-tietokannan sisältö.</translation>
    </message>
    <message>
        <source>Path of the XML database export.</source>
        <translation>Tietokannan XML-viennin polku.</translation>
    </message>
    <message>
        <source>Path of the new database.</source>
        <translation>Uuden tietokannan polku.</translation>
    </message>
    <message>
        <source>Unable to import XML database: %1</source>
        <translation>XML-muodossa olevaa tietokantaa ei voitu tuoda: %1</translation>
    </message>
    <message>
        <source>Successfully imported database.</source>
        <translation>Tietokanta tuotiin onnistuneesti.</translation>
    </message>
    <message>
        <source>Unknown command %1</source>
        <translation>Tuntematon komento %1</translation>
    </message>
    <message>
        <source>

Available commands:
</source>
        <translation>

Käytettävissä olevat komennot:
</translation>
    </message>
    <message>
        <source>Name of the command to execute.</source>
        <translation>Suoritettavan komennon nimi.</translation>
    </message>
    <message>
        <source>Displays debugging information.</source>
        <translation>Näytä virheenjäljitystiedot.</translation>
    </message>
    <message>
        <source>Invalid command %1.</source>
        <translation>Virheellinen komento %1.</translation>
    </message>
    <message>
        <source>Recursively list the elements of the group.</source>
        <translation>Listaa ryhmän elementit rekursiivisesti</translation>
    </message>
    <message>
        <source>Flattens the output to single lines.</source>
        <translation>Tasoittaa tulostuksen yksittäisille riveille.</translation>
    </message>
    <message>
        <source>List database entries.</source>
        <translation>Listaa tietokannan tietueet.</translation>
    </message>
    <message>
        <source>Path of the group to list. Default is /</source>
        <translation>Listattavan ryhmän polku. Oletus on /</translation>
    </message>
    <message>
        <source>Cannot find group %1.</source>
        <translation>Ryhmää %1 ei löytynyt.</translation>
    </message>
    <message>
        <source>Use the same credentials for both database files.</source>
        <translation>Käytä samoja tunnistetietoja molemmille tietokantatiedostoille.</translation>
    </message>
    <message>
        <source>Key file of the database to merge from.</source>
        <translation>Tietokannan avaintiedosto, josta yhdistetään.</translation>
    </message>
    <message>
        <source>Deactivate password key for the database to merge from.</source>
        <translation>Ota salasana-avain pois käytöstä tietokannasta josta yhdistetään.</translation>
    </message>
    <message>
        <source>Only print the changes detected by the merge operation.</source>
        <translation>Tulosta vain yhdistämisessä havaitut muutokset.</translation>
    </message>
    <message>
        <source>Yubikey slot for the second database.</source>
        <translation>Yukibey-paikka toiselle tietokannalle.</translation>
    </message>
    <message>
        <source>slot</source>
        <translation>paikka</translation>
    </message>
    <message>
        <source>Merge two databases.</source>
        <translation>Yhdistä kaksi tietokantaa.</translation>
    </message>
    <message>
        <source>Path of the database to merge from.</source>
        <translation>Tietokannan polku, josta yhdistetään.</translation>
    </message>
    <message>
        <source>Error reading merge file:
%1</source>
        <translation>Virhe lukiessa yhdistämiseen tarvittavaa tiedostoa:
%1</translation>
    </message>
    <message>
        <source>Unable to save database to file : %1</source>
        <translation>Tietokannan tallentaminen tiedostoon ei onnistu: %1</translation>
    </message>
    <message>
        <source>Successfully merged %1 into %2.</source>
        <translation>%1 yhdistettiin onnistuneesti kohteeseen %2</translation>
    </message>
    <message>
        <source>Database was not modified by merge operation.</source>
        <translation>Tietokannan sisältö ei muuttunut yhdistämisen yhteydessä.</translation>
    </message>
    <message>
        <source>Moves an entry to a new group.</source>
        <translation>Siirtää tietueen uuteen ryhmään.</translation>
    </message>
    <message>
        <source>Path of the entry to move.</source>
        <translation>Siirrettävän tietueen polku.</translation>
    </message>
    <message>
        <source>Path of the destination group.</source>
        <translation>Kohderyhmän polku.</translation>
    </message>
    <message>
        <source>Could not find group with path %1.</source>
        <translation>Ryhmää ei voitu löytää polussa %1.</translation>
    </message>
    <message>
        <source>Entry is already in group %1.</source>
        <translation>Tietue on jo ryhmässä %1.</translation>
    </message>
    <message>
        <source>Successfully moved entry %1 to group %2.</source>
        <translation>Siirrettiin onnistuneesti tietue %1 ryhmään %2.</translation>
    </message>
    <message>
        <source>Open a database.</source>
        <translation>Avaa tietokanta.</translation>
    </message>
    <message>
        <source>Path of the entry to remove.</source>
        <translation>Poistettavan tietueen polku.</translation>
    </message>
    <message>
        <source>Unable to save database to file: %1</source>
        <translation>Tietokantaa ei voitu tallentaa tiedostoon: %1</translation>
    </message>
    <message>
        <source>Successfully recycled entry %1.</source>
        <translation>Tietue %1 siirrettiin onnistuneesti roskakoriin.</translation>
    </message>
    <message>
        <source>Successfully deleted entry %1.</source>
        <translation>Tietue %1 poistettiin onnistuneesti.</translation>
    </message>
    <message>
        <source>Path of the group to remove.</source>
        <translation>Poistettavan ryhmän polku.</translation>
    </message>
    <message>
        <source>Cannot remove root group from database.</source>
        <translation>Juuriryhmää ei voida poistaa tietokannasta.</translation>
    </message>
    <message>
        <source>Successfully recycled group %1.</source>
        <translation>Ryhmä %1 siirrettiin onnistuneesti roskakoriin.</translation>
    </message>
    <message>
        <source>Successfully deleted group %1.</source>
        <translation>Ryhmä %1 poistettiin onnistuneesti.</translation>
    </message>
    <message>
        <source>Find entries quickly.</source>
        <translation>Etsi tietueita nopeasti.</translation>
    </message>
    <message>
        <source>Search term.</source>
        <translation>Hakutermi.</translation>
    </message>
    <message>
        <source>Show the entry&apos;s current TOTP.</source>
        <translation>Näytä tietueen tämän hetkinen TOTP.</translation>
    </message>
    <message>
        <source>Show the protected attributes in clear text.</source>
        <translation>Näytä suojatut attribuutit selkotekstinä.</translation>
    </message>
    <message>
        <source>Show all the attributes of the entry.</source>
        <translation>Näytä tietueen kaikki attribuutit.</translation>
    </message>
    <message>
        <source>Show the attachments of the entry.</source>
        <translation>Näytä tietueen liitteet.</translation>
    </message>
    <message>
        <source>Names of the attributes to show. This option can be specified more than once, with each attribute shown one-per-line in the given order. If no attributes are specified, a summary of the default attributes is given.</source>
        <translation>Näytettävien attribuuttien nimi. Tämän asetuksen voi määrittää useammin kuin kerran, jokaisen attribuutin näkyessä omalla rivillään annetussa järjestyksessä. Jos attribuutteja ei ole määritetty, näytetään yhteenveto oletuksista.</translation>
    </message>
    <message>
        <source>attribute</source>
        <translation>attribuutti</translation>
    </message>
    <message>
        <source>Show an entry&apos;s information.</source>
        <translation>Näytä tietueen tiedot.</translation>
    </message>
    <message>
        <source>Name of the entry to show.</source>
        <translation>Näytettävän tietueen nimi.</translation>
    </message>
    <message>
        <source>ERROR: unknown attribute %1.</source>
        <translation>VIRHE: Tuntematon attribuutti %1.</translation>
    </message>
    <message>
        <source>No attachments present.</source>
        <translation>Ei liitetiedostoja.</translation>
    </message>
    <message>
        <source>Attachments:</source>
        <translation>Liitteet:</translation>
    </message>
    <message>
        <source>Failed to open database file %1: not found</source>
        <translation>Tietokantatiedoston %1 avaus epäonnistui: ei löytynyt</translation>
    </message>
    <message>
        <source>Failed to open database file %1: not a plain file</source>
        <translation>Tietokantatiedostoa %1 ei voitu avata: ei ole tavallinen tiedosto</translation>
    </message>
    <message>
        <source>Failed to open database file %1: not readable</source>
        <translation>Tietokantatiedoston %1 avaus epäonnistui: ei luettavissa</translation>
    </message>
    <message>
        <source>Enter password to unlock %1: </source>
        <translation>Syötä salasana avataksesi %1:</translation>
    </message>
    <message>
        <source>Failed to load key file %1: %2</source>
        <translation>Avaintiedoston %1 lataaminen epäonnistui: %2</translation>
    </message>
    <message>
        <source>WARNING: You are using an old key file format which KeePassXC may
stop supporting in the future.

Please consider generating a new key file.</source>
        <translation>Käytät vanhaa avaintiedostomuotoa joka ei ole
välttämättä tuettu tulevaisuudessa.

Ole hyvä ja harkitse uuden avaintiedoston luomista.</translation>
    </message>
    <message>
        <source>Invalid YubiKey slot %1</source>
        <translation>Virheellinen Yubikey-paikka %1</translation>
    </message>
    <message>
        <source>Invalid YubiKey serial %1</source>
        <translation>Virheellinen Yubikeyn serial %1</translation>
    </message>
    <message>
        <source>Please present or touch your YubiKey to continue.</source>
        <translation>Jatka kytkemällä YubiKey-avaimesi tai koskettamalla sitä</translation>
    </message>
    <message>
        <source>Enter password to encrypt database (optional): </source>
        <translation>Syötä salasana salataksesi tietokannan (valinnainen): </translation>
    </message>
    <message>
        <source>Do you want to create a database with an empty password? [y/N]: </source>
        <translation>Haluatko luoda tietokannan tyhjällä salasanalla? [k/E]:</translation>
    </message>
    <message>
        <source>Repeat password: </source>
        <translation>Toista salasana:</translation>
    </message>
    <message>
        <source>Error: Passwords do not match.</source>
        <translation>Virhe: Salasanat eivät ole samoja.</translation>
    </message>
    <message>
        <source>No program defined for clipboard manipulation</source>
        <translation>Ohjelmaa leikepöydän hallintaan ei ole määritelty.</translation>
    </message>
    <message>
        <source>All clipping programs failed. Tried %1
</source>
        <translation>Kaikki leikkaavat ohjelmat epäonnistuivat. Kokeiltiin %1
</translation>
    </message>
    <message>
        <source>Creating KeyFile %1 failed: %2</source>
        <translation>Avaintiedoston %1 luonti epäonnistui: %2</translation>
    </message>
    <message>
        <source>Loading KeyFile %1 failed: %2</source>
        <translation>Avaintiedoston %1 lataus epäonnistui: %2</translation>
    </message>
    <message>
        <source>HIBP file, line %1: parse error</source>
        <translation>HIBP-tiedosto, rivi %1: jäsennysvirhe</translation>
    </message>
    <message>
        <source>To use okon, you must provide a post-processed file (e.g. file.okon)</source>
        <translation>Jotta voit käyttää okon:ia, on annettava jälkikäsitelty tiedosto (esim. file.okon)</translation>
    </message>
    <message>
        <source>Could not start okon process: %1</source>
        <translation>Okon-prosessia ei voitu käynnistää: %1</translation>
    </message>
    <message>
        <source>Error: okon process did not finish</source>
        <translation>Virhe: okon-prosessi ei valmistunut</translation>
    </message>
    <message>
        <source>Failed to load okon processed database: %1</source>
        <translation>Okon-käsiteltyä tietokantaa ei voitu avata: %1</translation>
    </message>
    <message>
        <source>Very weak password</source>
        <translation>Erittäin heikko salasana</translation>
    </message>
    <message>
        <source>Password entropy is %1 bits</source>
        <translation>Salasanan entropia on %1 bittiä</translation>
    </message>
    <message>
        <source>Weak password</source>
        <translation>Heikko salasana</translation>
    </message>
    <message>
        <source>Used in %1/%2</source>
        <translation>Käytetty %1/%2</translation>
    </message>
    <message numerus="yes">
        <source>Password is used %1 time(s)</source>
        <translation><numerusform>Salasanaa on käytetty %1 kertaa</numerusform><numerusform>Salasanaa on käytetty %1 kertaa</numerusform></translation>
    </message>
    <message>
        <source>Password has expired</source>
        <translation>Salasana on vanhentunut</translation>
    </message>
    <message>
        <source>Password expiry was %1</source>
        <translation>Salasana vanhentui %1</translation>
    </message>
    <message>
        <source>Password expires on %1</source>
        <translation>Salasana vanhentuu %1</translation>
    </message>
    <message>
        <source>Password is about to expire</source>
        <translation>Salasana on vanhentumassa</translation>
    </message>
    <message numerus="yes">
        <source>Password expires in %1 day(s)</source>
        <translation><numerusform>Salasana vanhentuu %1 päivässä</numerusform><numerusform>Salasana vanhentuu %1 päivässä</numerusform></translation>
    </message>
    <message>
        <source>Password will expire soon</source>
        <translation>Salasana vanhenee pian</translation>
    </message>
    <message>
        <source>Version %1</source>
        <translation>Versio %1</translation>
    </message>
    <message>
        <source>Build Type: %1</source>
        <translation>Ohjelmiston tyyppi</translation>
    </message>
    <message>
        <source>Revision: %1</source>
        <translation>Revisio: %1</translation>
    </message>
    <message>
        <source>Distribution: %1</source>
        <translation>Jakelu: %1</translation>
    </message>
    <message>
        <source>Debugging mode is disabled.</source>
        <translation>Virheenjäljitystila on pois päältä.</translation>
    </message>
    <message>
        <source>Debugging mode is enabled.</source>
        <translation>Virheenjäljitystila on päällä.</translation>
    </message>
    <message>
        <source>Operating system: %1
CPU architecture: %2
Kernel: %3 %4</source>
        <translation>Käyttöjärjestelmä: %1
Suoritinarkkitehtuuri: %2
Ydin: %3 %4</translation>
    </message>
    <message>
        <source>Auto-Type</source>
        <translation>Automaattisyöttö</translation>
    </message>
    <message>
        <source>SSH Agent</source>
        <translation>SSH-agentti</translation>
    </message>
    <message>
        <source>KeeShare</source>
        <translation>KeeShare</translation>
    </message>
    <message>
        <source>Quick Unlock</source>
        <translation>Pika-avaus</translation>
    </message>
    <message>
        <source>Secret Service Integration</source>
        <translation>Secret Service -integraatio</translation>
    </message>
    <message>
        <source>Enabled extensions:</source>
        <translation>Käytössä olevat laajennukset:</translation>
    </message>
    <message numerus="yes">
        <source>over %1 year(s)</source>
        <translation><numerusform>yli %1 vuosi</numerusform><numerusform>yli %1 vuotta</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>about %1 month(s)</source>
        <translation><numerusform>yli %1 kuukausi</numerusform><numerusform>yli %1 kuukautta</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>%1 week(s)</source>
        <translation><numerusform>%1 viikko</numerusform><numerusform>%1 viikkoa</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>%1 day(s)</source>
        <translation><numerusform>%1 päivä</numerusform><numerusform>%1 päivää</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>%1 hour(s)</source>
        <translation><numerusform>%1 tunti</numerusform><numerusform>%1 tuntia</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>%1 minute(s)</source>
        <translation><numerusform>%1 minuutti</numerusform><numerusform>%1 minuuttia</numerusform></translation>
    </message>
    <message>
        <source>Botan library must be at least %1, found %2.%3.%4</source>
        <translation>Botan-kirjaston tulee olla ainakin %1, löytyi %2.%3.%4</translation>
    </message>
    <message>
        <source>Cryptographic libraries:</source>
        <translation>Kryptografiakirjastot:</translation>
    </message>
    <message>
        <source>AES (%1 rounds)</source>
        <translation>AES (%1 kierrosta)</translation>
    </message>
    <message>
        <source>Argon2%1 (%2 rounds, %3 KB)</source>
        <translation>Argon2%1 (%2 kierrosta, %3 KB)</translation>
    </message>
    <message>
        <source>SymmetricCipher::init: Invalid cipher mode.</source>
        <translation>SymmetricCipher::init: Virheellinen salausmoodi.</translation>
    </message>
    <message>
        <source>SymmetricCipher::init: Invalid IV size of %1 for %2.</source>
        <translation>SymmetricCipher::init: Virheellinen IV:n koko %2:lle: %1.</translation>
    </message>
    <message>
        <source>Cipher not initialized prior to use.</source>
        <translation>Salausta ei ole initialisoitu ennen käyttöä.</translation>
    </message>
    <message>
        <source>Cannot process 0 length data.</source>
        <translation>Tietoa pituudella 0 ei voitu käsitellä.</translation>
    </message>
    <message>
        <source>unknown executable (DBus address %1)</source>
        <translation>tuntematon suoritustiedosto (DBus-osoite %1)</translation>
    </message>
    <message>
        <source>%1 (invalid executable path)</source>
        <translation>%1 (virheellinen suorituspolku)</translation>
    </message>
    <message>
        <source>NULL device</source>
        <translation>Tyhjä laite (NULL)</translation>
    </message>
    <message>
        <source>error reading from device</source>
        <translation>virhe laitteelta luettaessa</translation>
    </message>
    <message>
        <source>file empty</source>
        <translation>tyhjä tiedosto</translation>
    </message>
    <message>
        <source>AES 256-bit</source>
        <translation>AES 256-bit</translation>
    </message>
    <message>
        <source>Twofish 256-bit</source>
        <translation>Twofish 256-bit</translation>
    </message>
    <message>
        <source>ChaCha20 256-bit</source>
        <translation>ChaCha20: 256-bit</translation>
    </message>
    <message>
        <source>Argon2d (KDBX 4 – recommended)</source>
        <translation>Argon2d (KDBX 4 - suositeltu)</translation>
    </message>
    <message>
        <source>Argon2id (KDBX 4)</source>
        <translation>Argon2id (KDBX 4)</translation>
    </message>
    <message>
        <source>AES-KDF (KDBX 4)</source>
        <translation>AES-KDF (KDBX 4)</translation>
    </message>
    <message>
        <source>AES-KDF (KDBX 3)</source>
        <translation>AES-KDF (KDBX 3)</translation>
    </message>
    <message>
        <source>Existing single-instance lock file is invalid. Launching new instance.</source>
        <translation>Olemassa oleva yhden instanssin lukkotiedosto on virheellinen. Avataan uusi instanssi.</translation>
    </message>
    <message>
        <source>The lock file could not be created. Single-instance mode disabled.</source>
        <translation>Lukkotiedosto ei voitu luoda. Yhden instanssin tila otettu pois käytöstä.</translation>
    </message>
    <message numerus="yes">
        <source>Clearing the clipboard in %1 second(s)…</source>
        <translation><numerusform>Tyhjennetään leikepöytä %1 sekunnin kuluttua...</numerusform><numerusform>Tyhjennetään leikepöytä %1 sekunnin kuluttua...</numerusform></translation>
    </message>
    <message>
        <source>Group</source>
        <translation>Ryhmä</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>Otsikko</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>Käyttäjätunnus</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Salasana</translation>
    </message>
    <message>
        <source>TOTP</source>
        <translation>TOTP</translation>
    </message>
    <message>
        <source>Icon</source>
        <translation>Kuvake</translation>
    </message>
    <message>
        <source>Last Modified</source>
        <translation>Viimeksi muokattu</translation>
    </message>
    <message>
        <source>Created</source>
        <translation>Luotu</translation>
    </message>
    <message>
        <source>Benchmark %1 delay</source>
        <translation>Mittaa %1 viive</translation>
    </message>
    <message numerus="yes">
        <source>%1 ms</source>
        <comment>milliseconds</comment>
        <translation><numerusform>%1 ms</numerusform><numerusform>%1 ms</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>%1 s</source>
        <comment>seconds</comment>
        <translation><numerusform>%1 s</numerusform><numerusform>%1 s</numerusform></translation>
    </message>
    <message>
        <source>Do you really want to move entry &quot;%1&quot; to the recycle bin?</source>
        <translation>Haluatko varmasti siirtää tietueen &quot;%1&quot; roskakoriin?</translation>
    </message>
    <message numerus="yes">
        <source>Do you really want to move %n entry(s) to the recycle bin?</source>
        <translation><numerusform>Haluatko varmasti siirtää %n tietuetta roskakoriin?</numerusform><numerusform>Haluatko varmasti siirtää %n tietuetta roskakoriin?</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>Entry &quot;%1&quot; has %2 reference(s). Do you want to overwrite references with values, skip this entry, or delete anyway?</source>
        <translation><numerusform>Tietueella &quot;%1&quot; on %2 viittausta. Haluatko ylikirjoittaa viittaukset arvoilla, ohittaa tietueen tai poistaa sen?</numerusform><numerusform>Tietueella &quot;%1&quot; on %2 viittausta. Haluatko ylikirjoittaa viittaukset arvoilla, ohittaa tietueen tai poistaa sen?</numerusform></translation>
    </message>
    <message>
        <source>User name</source>
        <translation>Käyttäjätunnus</translation>
    </message>
    <message>
        <source>Browser Statistics</source>
        <translation>Selainstatistiikat</translation>
    </message>
    <message>
        <source>Health Check</source>
        <translation>Diagnostiikka</translation>
    </message>
    <message>
        <source>HIBP</source>
        <translation>HIBP</translation>
    </message>
    <message>
        <source>Statistics</source>
        <translation>Tilastot</translation>
    </message>
    <message>
        <source>Unsupported key file version: %1</source>
        <translation>Avaintiedosto joka ei ole tuettu, versio: %1</translation>
    </message>
    <message>
        <source>Checksum mismatch! Key file may be corrupt.</source>
        <translation>Tarkistussumma on virheellinen! Avaintiedosto voi olla korruptoitunut.</translation>
    </message>
    <message>
        <source>Unexpected key file data! Key file may be corrupt.</source>
        <translation>Odottamatonta avaintiedoston dataa havaittu. Avaintiedosto voi olla korruptoitunut.</translation>
    </message>
    <message>
        <source>KeePassXC - cross-platform password manager</source>
        <translation>KeePassXC - järjestelmäriippumaton salasanojen hallintasovellus</translation>
    </message>
    <message>
        <source>filenames of the password databases to open (*.kdbx)</source>
        <translation>avattavien salasanatietokantojen tiedostonimet (*.kdbx)</translation>
    </message>
    <message>
        <source>path to a custom config file</source>
        <translation>polku mukautettuun asetustiedostoon</translation>
    </message>
    <message>
        <source>path to a custom local config file</source>
        <translation>polku mukautettuun asetustiedostoon</translation>
    </message>
    <message>
        <source>lock all open databases</source>
        <translation>lukitse kaikki avoimet tietokannat</translation>
    </message>
    <message>
        <source>key file of the database</source>
        <translation>tietokannan avaintiedosto</translation>
    </message>
    <message>
        <source>read password of the database from stdin</source>
        <translation>lue tietokannan salasana stdin:istä</translation>
    </message>
    <message>
        <source>Database failed to lock.</source>
        <translation>Tietokannan lukitus ei onnistunut.</translation>
    </message>
    <message>
        <source>Another instance of KeePassXC is already running.</source>
        <translation>Toinen KeePassXC-instanssi on jo käynnissä.</translation>
    </message>
    <message>
        <source>KeePassXC is not running. No open database to lock</source>
        <translation>KeePassXC ei ole käynnissä. Avoimia, lukittavia tietokantoja ei ole.</translation>
    </message>
    <message>
        <source>Fatal error while testing the cryptographic functions.</source>
        <translation>Vakava virhe kryptografisia toimintoa testattaessa.</translation>
    </message>
    <message>
        <source>KeePassXC - Error</source>
        <translation>KeePassXC - Virhe</translation>
    </message>
    <message>
        <source>Database password: </source>
        <translation>Tietokannan salasana:</translation>
    </message>
    <message>
        <source>Invalid Settings</source>
        <comment>TOTP</comment>
        <translation>Virheelliset asetukset</translation>
    </message>
    <message>
        <source>Invalid Key</source>
        <comment>TOTP</comment>
        <translation>Virheellinen avain</translation>
    </message>
    <message>
        <source>Failed to create Windows Hello credential.</source>
        <translation>Windows Hello -valtuutuksen luominen ei onnistunut.</translation>
    </message>
    <message>
        <source>Failed to sign challenge using Windows Hello.</source>
        <translation>Vastauksen allekirjoitus Windows Hellolle epäonnistui</translation>
    </message>
    <message>
        <source>Warning: Failed to block screenshot capture on a top-level window.</source>
        <translation>Varoitus: Kuvankaappauksen esto ylätason ikkunasta epäonnistui.</translation>
    </message>
    <message>
        <source>Invalid Cipher</source>
        <translation>Virheellinen salakirjoitus</translation>
    </message>
    <message>
        <source>Invalid KDF</source>
        <translation>Virheellinen KDF</translation>
    </message>
    <message>
        <source>Access to all entries is denied</source>
        <translation>Kaikkien tiedoeiden käyttö on estetty</translation>
    </message>
    <message>
        <source>allow screenshots and app recording (Windows/macOS)</source>
        <translation>salli kuvankaappaukset ja sovelluksen tallennus (Windows/macOS).</translation>
    </message>
    <message>
        <source>Set the key file for the database.
This option is deprecated, use --set-key-file instead.</source>
        <translation>Aseta tietokannan avaintiedosto.
Asetus on vanhentunut, käytä sen sijaan &quot;--set-key-file&quot; -määritystä.</translation>
    </message>
    <message>
        <source>Databases have been locked.</source>
        <translation>Tietokannat on lukittu.</translation>
    </message>
    <message>
        <source>Attestation not supported</source>
        <translation>Todennusta ei tueta</translation>
    </message>
    <message>
        <source>Credential is excluded</source>
        <translation>Tietuetta on rajoitettu</translation>
    </message>
    <message>
        <source>Passkeys request canceled</source>
        <translation>Suojausavainpyyntö peruttiin</translation>
    </message>
    <message>
        <source>Invalid user verification</source>
        <translation>Virheellinen käyttäjävahvistus</translation>
    </message>
    <message>
        <source>Empty public key</source>
        <translation>Tyhjä julkinen avain</translation>
    </message>
    <message>
        <source>Invalid URL provided</source>
        <translation>Ilmoitettu URL-osoite ei kelpaa</translation>
    </message>
    <message>
        <source>Passkeys</source>
        <translation>Suojausavaimet</translation>
    </message>
    <message>
        <source>AES initialization failed</source>
        <translation>AES-alustus epäonnistui</translation>
    </message>
    <message>
        <source>AES encrypt failed</source>
        <translation>AES-salaus epäonnistui</translation>
    </message>
    <message>
        <source>Failed to store in Linux Keyring</source>
        <translation>Tallennus Linux-avainrenkaaseen epäonnistui</translation>
    </message>
    <message>
        <source>Polkit returned an error: %1</source>
        <translation>Polkit palautti virheen: %1</translation>
    </message>
    <message>
        <source>Could not locate key in keyring</source>
        <translation>Avainta ei löytynyt avainrenkaasta</translation>
    </message>
    <message>
        <source>Could not read key in keyring</source>
        <translation>Avainta ei voitu lukea avainrenkaasta</translation>
    </message>
    <message>
        <source>AES decrypt failed</source>
        <translation>AES-salauksen purku epäonnistui</translation>
    </message>
    <message>
        <source>No Polkit authentication agent was available</source>
        <translation>Polkit-todennusagenttia ei ollut käytettävissä</translation>
    </message>
    <message>
        <source>Polkit authorization failed</source>
        <translation>Polkit-todennus epäonnistui</translation>
    </message>
    <message>
        <source>No Quick Unlock provider is available</source>
        <translation>Pika-avaustapoja ei ole käytettävissä</translation>
    </message>
    <message>
        <source>Failed to init KeePassXC crypto.</source>
        <translation>KeePassXC-kryptauksen alustus epäonnistui</translation>
    </message>
    <message>
        <source>Failed to encrypt key data.</source>
        <translation>Avaindatan salaus epäonnistui</translation>
    </message>
    <message>
        <source>Failed to get Windows Hello credential.</source>
        <translation>Windows Hello -valtuutuksen hakeminen epäonnistui</translation>
    </message>
    <message>
        <source>Failed to decrypt key data.</source>
        <translation>Avaindatan salauksen avaus epäonnistui.</translation>
    </message>
    <message>
        <source>Origin is empty or not allowed</source>
        <translation>Alkuperä on tyhjä tai ei sallittu</translation>
    </message>
    <message>
        <source>Effective domain is not a valid domain</source>
        <translation>Verkkotunnus ei ole validi</translation>
    </message>
    <message>
        <source>Origin and RP ID do not match</source>
        <translation>Alkuperä tai RP ID eivät ole samat</translation>
    </message>
    <message>
        <source>No supported algorithms were provided</source>
        <translation>Tuettuja algoritmeja ei annettu</translation>
    </message>
    <message>
        <source>Wait for timer to expire</source>
        <translation>Odotetaan ajastimen loppumista</translation>
    </message>
    <message>
        <source>Challenge is shorter than required minimum length</source>
        <translation>Challenge on lyhyempi kuin vaadittu pituus</translation>
    </message>
    <message>
        <source>user.id does not match the required length</source>
        <translation>user.id:n pituus ei täytä vaatimuksia</translation>
    </message>
    <message>
        <source>Favorite</source>
        <comment>Tag for favorite entries</comment>
        <translation>Suosikki</translation>
    </message>
    <message>
        <source>File does not exist.</source>
        <translation>Tiedostoa ei ole.</translation>
    </message>
    <message>
        <source>Cannot open file: %1</source>
        <translation>Tiedostoa ei voitu avata: %1</translation>
    </message>
    <message>
        <source>Cannot parse file: %1 at position %2</source>
        <translation>Tiedostoa: %1 ei voitu jäsentää kohdassa %2</translation>
    </message>
    <message>
        <source>Failed to decrypt json file: %1</source>
        <translation>JSON-tiedoston salauksen purkaminen epäonnistui: %1</translation>
    </message>
    <message>
        <source>Invalid encKeyValidation field</source>
        <translation>Virheellinen encKeyValidation-kenttä</translation>
    </message>
    <message>
        <source>Invalid cipher list within encKeyValidation field</source>
        <translation>Virheellinen salauslista encKeyValidation-kentän sisällä</translation>
    </message>
    <message>
        <source>Wrong password</source>
        <translation>Väärä salasana</translation>
    </message>
    <message>
        <source>Invalid encrypted data field</source>
        <translation>Virheellisesti salattu tietokenttä</translation>
    </message>
    <message>
        <source>Invalid cipher list within encrypted data field</source>
        <translation>Virheellinen salauslista salatun tietokentän sisällä</translation>
    </message>
    <message>
        <source>Cannot initialize cipher</source>
        <translation>Salauksen initialisointi epäonnistui</translation>
    </message>
    <message>
        <source>Cannot decrypt data</source>
        <translation>Salauksen purku epäonnistui</translation>
    </message>
    <message>
        <source>Bitwarden Import</source>
        <translation>Bitwarden-tuonti</translation>
    </message>
    <message>
        <source>Archived</source>
        <comment>Tag for archived entries</comment>
        <translation>Arkistoitu</translation>
    </message>
    <message>
        <source>Invalid 1PUX file format: Not a valid ZIP file.</source>
        <translation>Virheellinen 1PUX-tiedostomuoto: virheellinen ZIP-tiedosto.</translation>
    </message>
    <message>
        <source>Invalid 1PUX file format: Missing export.data</source>
        <translation>Virheellinen 1PUX-tiedosto: export.data puuttuu</translation>
    </message>
    <message>
        <source>1Password Import</source>
        <translation>1Password-tuonti</translation>
    </message>
    <message>
        <source>Enter Shortcut</source>
        <translation>Lisää pikanäppäin</translation>
    </message>
    <message>
        <source>Action</source>
        <translation>Toiminto</translation>
    </message>
    <message>
        <source>Shortcuts</source>
        <translation>Pikanäppäimet</translation>
    </message>
    <message>
        <source>Unknown passkeys error</source>
        <translation>Tuntematon passkeys-virhe</translation>
    </message>
    <message>
        <source>Invalid KDF iterations, cannot decrypt json file</source>
        <translation>Virheellinen KDF-iteraation. JSON-tiedostoa ei voitu purkaa.</translation>
    </message>
    <message>
        <source>Unsupported format, ensure your Bitwarden export is password-protected</source>
        <translation>Tiedostomuoto ei ole tuettu. Varmista, että Bitwarden-tiedostosi on salasanasuojattu.</translation>
    </message>
    <message>
        <source>Only PBKDF and Argon2 are supported, cannot decrypt json file</source>
        <translation>Vain PBKDF ja Argon2 ovat tuettuja. JSON-tiedostoa ei voitu purkaa.</translation>
    </message>
    <message>
        <source>Hardware Keys</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Passkey</source>
        <translation>Pääsyavain</translation>
    </message>
    <message>
        <source>Reset Shortcuts</source>
        <translation>Nollaa pikanäppäimet</translation>
    </message>
    <message>
        <source>Double click an action to change its shortcut</source>
        <translation>Tuplaklikkaa toimintoa vaihtaaksesi sen pikanäppäintä</translation>
    </message>
    <message>
        <source>Filter...</source>
        <translation>Suodata...</translation>
    </message>
    <message>
        <source>Shortcut Conflict</source>
        <translation>Pikanäppäimen ristiriita</translation>
    </message>
    <message>
        <source>Shortcut %1 conflicts with &apos;%2&apos;. Overwrite shortcut?</source>
        <translation>Pikanäppäin %1 on ristiriidassa &apos;%2&apos; kanssa. Ylikirjoita pikanäppäin?</translation>
    </message>
    <message>
        <source>Format to use when exporting. Available choices are &apos;xml&apos;, &apos;csv&apos; or &apos;html&apos;. Defaults to &apos;xml&apos;.</source>
        <translation>Viennissä käytettävä formaatti. Mahdolliset vaihtoehdot ovat &apos;xml&apos;, &apos;csv&apos; tai &apos;html&apos;. Oletus on &apos;xml&apos;.</translation>
    </message>
    <message>
        <source>malformed string, possible unescaped delimiter</source>
        <translation>epämuodostunut merkkijono, mahdollinen väärin kirjoitettu erotinmerkki</translation>
    </message>
    <message>
        <source>missing closing delimiter</source>
        <translation>puuttuva sulkuerotin</translation>
    </message>
    <message>
        <source>%1, row: %2, column: %3</source>
        <translation>%1, rivi: %2, sarake: %3</translation>
    </message>
    <message>
        <source>Encrypted files are not supported.</source>
        <translation>Salattuja tiedostoja ei tueta.</translation>
    </message>
    <message>
        <source>Proton Pass Import</source>
        <translation>Proton Pass -tuonti</translation>
    </message>
    <message>
        <source>Tags</source>
        <translation>Tagit</translation>
    </message>
    <message>
        <source>start minimized to the system tray</source>
        <translation>aloita minimoituna tehtäväpalkkiin</translation>
    </message>
    <message>
        <source>Warning: the chosen wordlist is smaller than the minimum recommended size!</source>
        <translation>Varoitus: valittu sanalista on pienempi kuin pienin suositeltu!</translation>
    </message>
    <message>
        <source>Invalid Step</source>
        <comment>TOTP</comment>
        <translation>Virheellinen vaihe</translation>
    </message>
    <message>
        <source>Invalid Digits</source>
        <comment>TOTP</comment>
        <translation>Virheellinen numero</translation>
    </message>
    <message numerus="yes">
        <source>%1 character(s)</source>
        <translation><numerusform>%1 merkki</numerusform><numerusform>%1 merkkiä</numerusform></translation>
    </message>
    <message>
        <source>Do you really want to permanently delete the entry &quot;%1&quot;?</source>
        <translation>Haluatko varmasti poistaa pysyvästi tietueen &quot;%1&quot;?</translation>
    </message>
    <message numerus="yes">
        <source>Do you really want to permanently delete %n entry(s)?</source>
        <translation><numerusform>Haluatko varmasti poistaa pysyvästi yhden tietueen?</numerusform><numerusform>Haluatko varmasti poistaa pysyvästi %n tietuetta?</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>Confirm Delete Entry(s)</source>
        <translation><numerusform>Varmista tietueen poisto</numerusform><numerusform>Varmista tietueiden poisto</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>Confirm Recycle Entry(s)</source>
        <translation><numerusform>Varmista tietueen siirto roskakoriin</numerusform><numerusform>Varmista tietueiden siirto roskakoriin</numerusform></translation>
    </message>
    <message>
        <source>Confirm Delete Plugin Data</source>
        <translation>Varmista liitännäistietojen poisto</translation>
    </message>
    <message numerus="yes">
        <source>Delete plugin data from the selected entry(s)?</source>
        <translation><numerusform>Poista liitännäistiedot tuetueesta</numerusform><numerusform>Poista liitännäistiedot tietueista</numerusform></translation>
    </message>
    <message>
        <source>Confirm Replace Entry References</source>
        <translation>Varmista tietueen viittauksien korvaaminen</translation>
    </message>
</context>
<context>
    <name>QtIOCompressor</name>
    <message>
        <source>Internal zlib error when compressing: </source>
        <translation>Sisäinen zlib virhe pakatessa: </translation>
    </message>
    <message>
        <source>Error writing to underlying device: </source>
        <translation>Kirjoitus taustalla olevaan laitteeseen epäonnistui:</translation>
    </message>
    <message>
        <source>Error opening underlying device: </source>
        <translation>Taustalla olevan laitteen avaus epäonnistui:</translation>
    </message>
    <message>
        <source>Error reading data from underlying device: </source>
        <translation>Virhe luettaessa taustalla olevasta laitteesta:</translation>
    </message>
    <message>
        <source>Internal zlib error when decompressing: </source>
        <translation>Sisäinen zlib-virhe purkaessa: </translation>
    </message>
</context>
<context>
    <name>QtIOCompressor::open</name>
    <message>
        <source>The gzip format not supported in this version of zlib.</source>
        <translation>gzip-formaatti ei ole tuettu tässä zlib-versiossa.</translation>
    </message>
    <message>
        <source>Internal zlib error: </source>
        <translation>Sisäinen zlib-virhe: </translation>
    </message>
</context>
<context>
    <name>RemoteDesktopPortal</name>
    <message>
        <source>Remote desktop session is not active</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Session closed</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>User cancelled the interaction</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>User interaction was canceled for unknown reason</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Remote desktop session handle does not match expected path</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>RemoteHandler</name>
    <message>
        <source>Command `%1` did not finish in time. Process was killed.</source>
        <translation>Komento &apos;%1&apos; ei suoritutunut määritetyssä ajassa. Prosessi tuhottiin.</translation>
    </message>
    <message>
        <source>Failed to upload merged database. Command `%1` did not finish in time. Process was killed.</source>
        <translation>Yhdistetyn tietokannan lähetys epäonnistui. Komento &apos;%1&apos; ei suoriutunut määritetyssä ajassa. Prosessi tuhottin.</translation>
    </message>
    <message>
        <source>Invalid download parameters provided.</source>
        <translation>Väärät latausparametrit.</translation>
    </message>
    <message>
        <source>Command `%1` failed to download database.</source>
        <translation>Komento &apos;%1&apos; epäonnistui tietokannan lataamisessa.</translation>
    </message>
    <message>
        <source>Invalid database pointer or upload parameters provided.</source>
        <translation>Virheellinen tietokannan osoitin, tai lähetyksen parametrit.</translation>
    </message>
    <message>
        <source>Command `%1` exited with status code: %2</source>
        <translation>Komento &apos;%1&apos; suoriutui paluuarvolla: %2</translation>
    </message>
    <message>
        <source>Failed to upload merged database. Command `%1` exited with status code: %2</source>
        <translation>Yhdistetyn tietokannan lähetys epäonnistui. Komento &apos;%1&apos; loppui paluuarvolla: %2</translation>
    </message>
</context>
<context>
    <name>ReportsWidgetBrowserStatistics</name>
    <message>
        <source>Double-click entries to edit.</source>
        <translation>Kaksoisnapsauta tietuetta muokataksesi</translation>
    </message>
    <message>
        <source>List of entry URLs</source>
        <translation>Lista tietueen URL:istä</translation>
    </message>
    <message>
        <source>Entry has no URLs set</source>
        <translation>Tietueella ei ole URL:ää</translation>
    </message>
    <message>
        <source>Allowed URLs</source>
        <translation>Sallitut URL:t</translation>
    </message>
    <message>
        <source>Entry has no Browser Integration settings</source>
        <translation>Tietueella ei ole selainlaajennuksen asetuksia</translation>
    </message>
    <message>
        <source>Denied URLs</source>
        <translation>Estetyt URL:t</translation>
    </message>
    <message>
        <source> (Excluded)</source>
        <translation>(Poissuljettu)</translation>
    </message>
    <message>
        <source>This entry is being excluded from reports</source>
        <translation>Tämä tietue on poissuljettu raporteista</translation>
    </message>
    <message>
        <source>Please wait, browser statistics is being calculated…</source>
        <translation>Odota hetki, lasketaan selainstatistiikkaa...</translation>
    </message>
    <message>
        <source>No entries with a URL, or none has browser extension settings saved.</source>
        <translation>Ei tietueita URL:llä tai tallennetuilla selainlaajennuksen tiedoilla</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>Otsikko</translation>
    </message>
    <message>
        <source>Path</source>
        <translation>Polku</translation>
    </message>
    <message>
        <source>URLs</source>
        <translation>URL:t</translation>
    </message>
    <message>
        <source>Edit Entry…</source>
        <translation>Muokkaa tietuetta...</translation>
    </message>
    <message numerus="yes">
        <source>Delete Entry(s)…</source>
        <translation type="unfinished"><numerusform></numerusform><numerusform>Poista tietueet...</numerusform></translation>
    </message>
    <message>
        <source>Exclude from reports</source>
        <translation>Poissulje raporteista</translation>
    </message>
    <message numerus="yes">
        <source>Expire Entry(s)…</source>
        <translation><numerusform>Vanhentunut tietue</numerusform><numerusform>Vanhentuneet tietueet...</numerusform></translation>
    </message>
    <message>
        <source>Only show entries that have a URL</source>
        <translation>Näytä vain URL-osoitteen sisältävät tietueet</translation>
    </message>
    <message>
        <source>Only show entries that have been explicitly allowed or denied</source>
        <translation>Näytä vain tietueet, jotka on erikseen sallittu tai estetty</translation>
    </message>
    <message>
        <source>Show expired entries</source>
        <translation>Näytä erääntyneet tietueet</translation>
    </message>
    <message>
        <source> (Expired)</source>
        <translation> (erääntynyt)</translation>
    </message>
    <message numerus="yes">
        <source>Delete plugin data from Entry(s)…</source>
        <translation><numerusform>Poista liitännäistiedot tietueesta…</numerusform><numerusform>Poista liitännäistiedot tietueista…</numerusform></translation>
    </message>
</context>
<context>
    <name>ReportsWidgetHealthcheck</name>
    <message>
        <source>Show expired entries</source>
        <translation>Näytä erääntyneet tietueet</translation>
    </message>
    <message>
        <source> (Expired)</source>
        <translation> (erääntynyt)</translation>
    </message>
    <message>
        <source>Hover over reason to show additional details. Double-click entries to edit.</source>
        <translation>Siirrä kursori syyn päälle nähdäksesi lisätietoja. Tuplaklikkaa tietueita muokataksesi niitä.</translation>
    </message>
    <message>
        <source>Bad — password must be changed</source>
        <translation>Paha - salasana on vaihdettava</translation>
    </message>
    <message>
        <source>Poor — password should be changed</source>
        <translation>Heikko - salasana on vaihdettava</translation>
    </message>
    <message>
        <source>Weak — consider changing the password</source>
        <translation>Heikohko - salasana on vaihdettava</translation>
    </message>
    <message>
        <source> (Excluded)</source>
        <translation>(Poissuljettu)</translation>
    </message>
    <message>
        <source>This entry is being excluded from reports</source>
        <translation>Tämä tietue on poissuljettu raporteista</translation>
    </message>
    <message>
        <source>Please wait, health data is being calculated…</source>
        <translation>Odota hetki, diagnostiikkaa lasketaan...</translation>
    </message>
    <message>
        <source>Congratulations, everything is healthy!</source>
        <translation>Onneksi olkoon, kaikki on kunnossa!</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>Otsikko</translation>
    </message>
    <message>
        <source>Path</source>
        <translation>Polku</translation>
    </message>
    <message>
        <source>Score</source>
        <translation>Pisteytys</translation>
    </message>
    <message>
        <source>Reason</source>
        <translation>Syy</translation>
    </message>
    <message>
        <source>Edit Entry…</source>
        <translation>Muokkaa tietuetta...</translation>
    </message>
    <message numerus="yes">
        <source>Delete Entry(s)…</source>
        <translation><numerusform>Poista tietue...</numerusform><numerusform>Poista tietueet...</numerusform></translation>
    </message>
    <message>
        <source>Exclude from reports</source>
        <translation>Poissulje raporteista</translation>
    </message>
    <message numerus="yes">
        <source>Expire Entry(s)…</source>
        <translation><numerusform>Vanhentunut tietue</numerusform><numerusform>Vanhentuneet tietueet...</numerusform></translation>
    </message>
    <message>
        <source>Show entries that have been excluded from reports</source>
        <translation>Näytä tietueet, joita ei sisällytetä raportteihin.</translation>
    </message>
</context>
<context>
    <name>ReportsWidgetHibp</name>
    <message>
        <source>CAUTION: This report requires sending information to the Have I Been Pwned online service (https://haveibeenpwned.com). If you proceed, your database passwords will be cryptographically hashed and the first five characters of those hashes will be sent securely to this service. Your database remains secure and cannot be reconstituted from this information. However, the number of passwords you send and your IP address will be exposed to this service.</source>
        <translation>HUOMIO: Tämä raportti lähettää tietoa Have I Been Pwned -palveluun (https://haveibeenpwned.com). Jos jatkat, tietokantasi salasanat tiivistetään ja viisi ensimmäistä kirjainta tästä tiivisteestä lähetetään turvallisesti palvelimelle. Tietokantasi pysyy turvassa, eikä sen tietoja voida kerätä tätä informaatiota käyttäen. Salasanojesi määrä ja IP-osoitteesi tosin lähetetään palvelimelle.</translation>
    </message>
    <message>
        <source>Perform Online Analysis</source>
        <translation>Suorita online-analyysi</translation>
    </message>
    <message>
        <source>Also show entries that have been excluded from reports</source>
        <translation>Näytä myös ne tietueet jotka on otettu pois raporteista</translation>
    </message>
    <message>
        <source>This build of KeePassXC does not have network functions. Networking is required to check your passwords against Have I Been Pwned databases.</source>
        <translation>Tässä KeePassXC:n build-versiossa ei ole verkkotoiminnallisuuksia. Verkkotoiminnallisuus vaaditaan, jotta voit tarkistaa salasanojasi Have I Been Pwned -tietokannasta.</translation>
    </message>
    <message>
        <source>Congratulations, no exposed passwords!</source>
        <translation>Onneksi olkoon, salasanojasi ei ole vuotanut!</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>Otsikko</translation>
    </message>
    <message>
        <source>Path</source>
        <translation>Polku</translation>
    </message>
    <message>
        <source>Password exposed…</source>
        <translation>Salasana vuotanut...</translation>
    </message>
    <message>
        <source> (Excluded)</source>
        <translation>(Poissuljettu)</translation>
    </message>
    <message>
        <source>This entry is being excluded from reports</source>
        <translation>Tämä tietue on poissuljettu raporteista</translation>
    </message>
    <message>
        <source>once</source>
        <comment>Password exposure amount</comment>
        <translation>kerran</translation>
    </message>
    <message>
        <source>up to 10 times</source>
        <comment>Password exposure amount</comment>
        <translation>jopa kymmenen kertaa</translation>
    </message>
    <message>
        <source>up to 100 times</source>
        <comment>Password exposure amount</comment>
        <translation>jopa sata kertaa</translation>
    </message>
    <message>
        <source>up to 1000 times</source>
        <comment>Password exposure amount</comment>
        <translation>jopa tuhat kertaa</translation>
    </message>
    <message>
        <source>up to 10,000 times</source>
        <comment>Password exposure amount</comment>
        <translation>jopa 10 000 kertaa</translation>
    </message>
    <message>
        <source>up to 100,000 times</source>
        <comment>Password exposure amount</comment>
        <translation>jopa 100 000 kertaa</translation>
    </message>
    <message>
        <source>up to a million times</source>
        <comment>Password exposure amount</comment>
        <translation>jopa miljoona kertaa</translation>
    </message>
    <message>
        <source>millions of times</source>
        <comment>Password exposure amount</comment>
        <translation>miljoonia kertoja</translation>
    </message>
    <message>
        <source>Edit Entry…</source>
        <translation>Muokkaa tietuetta...</translation>
    </message>
    <message numerus="yes">
        <source>Delete Entry(s)…</source>
        <translation><numerusform>Poista tietue...</numerusform><numerusform>Poista tietueet...</numerusform></translation>
    </message>
    <message>
        <source>Exclude from reports</source>
        <translation>Poissulje raporteista</translation>
    </message>
    <message numerus="yes">
        <source>Expire Entry(s)…</source>
        <translation><numerusform>Vanhentunut tietue</numerusform><numerusform>Vanhentuneet tietueet...</numerusform></translation>
    </message>
</context>
<context>
    <name>ReportsWidgetPasskeys</name>
    <message>
        <source>Export</source>
        <translation>Vie</translation>
    </message>
    <message>
        <source>Import</source>
        <translation>Tuo</translation>
    </message>
    <message>
        <source>List of entry URLs</source>
        <translation>Lista tietueen URL:istä</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>Otsikko</translation>
    </message>
    <message>
        <source>Path</source>
        <translation>Polku</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>Käyttäjätunnus</translation>
    </message>
    <message>
        <source>URLs</source>
        <translation>URL:t</translation>
    </message>
    <message>
        <source>Edit Entry…</source>
        <translation>Muokkaa tietuetta...</translation>
    </message>
    <message numerus="yes">
        <source>Delete Entry(s)…</source>
        <translation><numerusform>Poista tietue...</numerusform><numerusform>Poista tietueet...</numerusform></translation>
    </message>
    <message>
        <source>Relying Party</source>
        <translation>Välittävät taho</translation>
    </message>
    <message>
        <source>Show expired entries</source>
        <translation>Näytä erääntyneet tietueet</translation>
    </message>
    <message>
        <source> (Expired)</source>
        <translation> (erääntynyt)</translation>
    </message>
    <message>
        <source>Export Confirmation</source>
        <translation>Viennin vahvistus</translation>
    </message>
    <message>
        <source>The passkey file will be vulnerable to theft and unauthorized use, if left unsecured. Are you sure you want to continue?</source>
        <translation>Passkey-tiedosto on altis varkauksille ja väärinkäyttöön, jos sitä ei suojata. Oletko varma, että haluat jatkaa?</translation>
    </message>
    <message>
        <source>Please wait, list of entries with passkeys is being updated…</source>
        <translation>Odota kun passkey-tietueiden lista päivittyy...</translation>
    </message>
    <message>
        <source>No entries with passkeys.</source>
        <translation>Passkeyn sisältäviä tietueita ei ole.</translation>
    </message>
</context>
<context>
    <name>ReportsWidgetStatistics</name>
    <message>
        <source>Hover over lines with error icons for further information.</source>
        <translation>Liiku virheikonin sisältävän rivin päälle saadaksesi lisätietoa.</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nimi</translation>
    </message>
    <message>
        <source>Value</source>
        <translation>Arvo</translation>
    </message>
    <message>
        <source>Please wait, database statistics are being calculated…</source>
        <translation>Odota hetki, lasketaan tietokannan statistiikkaa...</translation>
    </message>
    <message>
        <source>Database name</source>
        <translation>Tietokannan nimi</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Kuvaus</translation>
    </message>
    <message>
        <source>Location</source>
        <translation>Sijainti</translation>
    </message>
    <message>
        <source>Database created</source>
        <translation>Tietokanta luotu</translation>
    </message>
    <message>
        <source>Last saved</source>
        <translation>Viimeksi tallennettu</translation>
    </message>
    <message>
        <source>Unsaved changes</source>
        <translation>Tallentamattomia muutoksia</translation>
    </message>
    <message>
        <source>yes</source>
        <translation>kyllä</translation>
    </message>
    <message>
        <source>no</source>
        <translation>ei</translation>
    </message>
    <message>
        <source>The database was modified, but the changes have not yet been saved to disk.</source>
        <translation>Tietokantaa muokattiin, mutta muutoksia ei ole tallennettu levylle.</translation>
    </message>
    <message>
        <source>Number of groups</source>
        <translation>Ryhmien määrä</translation>
    </message>
    <message>
        <source>Number of entries</source>
        <translation>Tietueiden lukumäärä</translation>
    </message>
    <message>
        <source>Number of expired entries</source>
        <translation>Vanhentuneiden tietueiden lukumäärä</translation>
    </message>
    <message>
        <source>The database contains entries that have expired.</source>
        <translation>Tietokanta sisältää tietueita jotka ovat vanhentuneet.</translation>
    </message>
    <message>
        <source>Unique passwords</source>
        <translation>Yksilöllisiä salasanoja</translation>
    </message>
    <message>
        <source>Non-unique passwords</source>
        <translation>Ei-yksilöllisiä salasanoja</translation>
    </message>
    <message>
        <source>More than 10% of passwords are reused. Use unique passwords when possible.</source>
        <translation>Salasanoista enemmän kuin 10% ovat samoja. Käytä yksilöllisiä salasanoja aina kun mahdollista.</translation>
    </message>
    <message>
        <source>Maximum password reuse</source>
        <translation>Maksimimäärä samoja salasanoja</translation>
    </message>
    <message>
        <source>Some passwords are used more than three times. Use unique passwords when possible.</source>
        <translation>Salasanoista osa on käytössä useammassa kuin kolmessa tietueessa. Käytä yksilöllisiä salasanoja aina kun mahdollista.</translation>
    </message>
    <message>
        <source>Number of short passwords</source>
        <translation>Lyhyiden salasanojen määrä</translation>
    </message>
    <message>
        <source>Recommended minimum password length is at least 8 characters.</source>
        <translation>Salasanan suositeltu minimipituus on vähintään 8 merkkiä.</translation>
    </message>
    <message>
        <source>Number of weak passwords</source>
        <translation>Heikkojen salasanojen määrä</translation>
    </message>
    <message>
        <source>Recommend using long, randomized passwords with a rating of &apos;good&apos; or &apos;excellent&apos;.</source>
        <translation>On suositeltavaa käyttää salasanoja joiden luokitus on &apos;hyvä&apos; tai &apos;erinomainen&apos;.</translation>
    </message>
    <message>
        <source>Entries excluded from reports</source>
        <translation>Tietueet jotka on poissuljettu raporteista</translation>
    </message>
    <message>
        <source>Excluding entries from reports, e. g. because they are known to have a poor password, isn&apos;t necessarily a problem but you should keep an eye on them.</source>
        <translation>Poissuljetut tietueet raporteista, esim. joissa tiedetään olevan heikko salasana, eivät välttämättä ole ongelma, mutta niitä kannattaa pitää silmällä.</translation>
    </message>
    <message>
        <source>Average password length</source>
        <translation>Salasanan keskimääräinen pituus</translation>
    </message>
    <message>
        <source>Average password length is less than ten characters. Longer passwords provide more security.</source>
        <translation>Salasanojen keskimääräinen pituus on vähemmän kuin kymmenen merkkiä. Pidemmät salasanat ovat turvallisempia.</translation>
    </message>
    <message>
        <source>Number of passkeys</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Entries with TOTP setup</source>
        <translation type="unfinished"/>
    </message>
    <message numerus="yes">
        <source>%1 character(s)</source>
        <translation><numerusform>%1 merkki</numerusform><numerusform>%1 merkkiä</numerusform></translation>
    </message>
</context>
<context>
    <name>SSHAgent</name>
    <message>
        <source>Agent connection failed.</source>
        <translation>Agentin yhteydenotto epäonnistui.</translation>
    </message>
    <message>
        <source>Agent protocol error.</source>
        <translation>Agentin protokollavirhe.</translation>
    </message>
    <message>
        <source>No agent running, cannot add identity.</source>
        <translation>Agentti ei ole käynnissä. Identiteettiä ei voitu lisätä.</translation>
    </message>
    <message>
        <source>Key identity ownership conflict. Refusing to add.</source>
        <translation>Avaimen tunnisteen omistajaristiriita. Lisäystä ei tehdä.</translation>
    </message>
    <message>
        <source>Agent refused this identity. Possible reasons include:</source>
        <translation>Agentti hylkäsi tämän identiteetin. Mahdolliset syyt sisältävät: </translation>
    </message>
    <message>
        <source>The key has already been added.</source>
        <translation>Avain on jo lisätty.</translation>
    </message>
    <message>
        <source>Restricted lifetime is not supported by the agent (check options).</source>
        <translation>Agentti ei tue rajoitettua käyttöikää (tarkista asetukset).</translation>
    </message>
    <message>
        <source>A confirmation request is not supported by the agent (check options).</source>
        <translation>Agentti ei tue vahvistuspyyntöä (tarkista asetukset).</translation>
    </message>
    <message>
        <source>Security keys are not supported by the agent or the security key provider is unavailable.</source>
        <translation>Turvallisuusavain ei ole tuettu agentin toimesta, tai sen tarjoajaa ei ole saatavilla</translation>
    </message>
    <message>
        <source>No agent running, cannot remove identity.</source>
        <translation>Agentti ei ole käynnissä. Identiteettiä ei voitu poistaa.</translation>
    </message>
    <message>
        <source>No agent running, cannot list identities.</source>
        <translation>Agentti ei ole päällä, identiteettejä ei voi listata.</translation>
    </message>
    <message>
        <source>Failed to remove all SSH identities from agent.</source>
        <translation>Kaikkien tietojen poisto SSH-agentista epäonnistui.</translation>
    </message>
    <message>
        <source>All SSH identities removed from agent.</source>
        <translation>Kaikki tiedot poistettu SSH-agentista.</translation>
    </message>
</context>
<context>
    <name>SearchHelpWidget</name>
    <message>
        <source>Search Help</source>
        <translation>Etsi apua</translation>
    </message>
    <message>
        <source>Search terms are as follows: [modifiers][field:][&quot;]term[&quot;]</source>
        <translation>Hakutermit ovat seuraavat: [modifikaattorit][kenttä:][&quot;]termi[&quot;]</translation>
    </message>
    <message>
        <source>Every search term must match (ie, logical AND)</source>
        <translation>Jokaisen hakutermin on sovittava yhteen (esim. looginen AND)</translation>
    </message>
    <message>
        <source>Modifiers</source>
        <translation>Modifikaattorit</translation>
    </message>
    <message>
        <source>exclude term from results</source>
        <translation>älä sisällytä termiä hakutuloksiin</translation>
    </message>
    <message>
        <source>match term exactly</source>
        <translation>termin on sovittava täysin yhteen</translation>
    </message>
    <message>
        <source>use regex in term</source>
        <translation>käytä termissä regex:iä</translation>
    </message>
    <message>
        <source>Fields</source>
        <translation>Kentät</translation>
    </message>
    <message>
        <source>Term Wildcards</source>
        <translation>Termin jokerimerkit (wildcards)</translation>
    </message>
    <message>
        <source>match anything</source>
        <translation>vastaa minkä tahansa kanssa</translation>
    </message>
    <message>
        <source>match one</source>
        <translation>vastaa yhtä</translation>
    </message>
    <message>
        <source>logical OR</source>
        <translation>looginen OR</translation>
    </message>
    <message>
        <source>Examples</source>
        <translation>Esimerkit</translation>
    </message>
</context>
<context>
    <name>SearchWidget</name>
    <message>
        <source>Search</source>
        <translation>Etsi</translation>
    </message>
    <message>
        <source>Search Help</source>
        <translation>Etsi apua</translation>
    </message>
    <message>
        <source>Save Search</source>
        <translation>Tallenna haku</translation>
    </message>
    <message>
        <source>Search (%1)…</source>
        <comment>Search placeholder text, %1 is the keyboard shortcut</comment>
        <translation>Etsi (%1)...</translation>
    </message>
    <message>
        <source>Case sensitive</source>
        <translation>Merkkikokoriippuvainen</translation>
    </message>
    <message>
        <source>Limit search to selected group</source>
        <translation>Rajoita haku valittuun ryhmään</translation>
    </message>
    <message>
        <source>Press Enter to search</source>
        <translation>Paina enter etsiäksesi</translation>
    </message>
</context>
<context>
    <name>SettingsClientModel</name>
    <message>
        <source>Application</source>
        <translation>Sovellus</translation>
    </message>
    <message>
        <source>PID</source>
        <translation>PID</translation>
    </message>
    <message>
        <source>DBus Address</source>
        <translation>DBus-osoite</translation>
    </message>
    <message>
        <source>Manage</source>
        <translation>Hallitse</translation>
    </message>
</context>
<context>
    <name>SettingsDatabaseModel</name>
    <message>
        <source>File Name</source>
        <translation>Tiedostonimi</translation>
    </message>
    <message>
        <source>Group</source>
        <translation>Ryhmä</translation>
    </message>
    <message>
        <source>Manage</source>
        <translation>Hallitse</translation>
    </message>
</context>
<context>
    <name>SettingsWidgetFdoSecrets</name>
    <message>
        <source>Options</source>
        <translation>Valinnat</translation>
    </message>
    <message>
        <source>Enable KeepassXC Freedesktop.org Secret Service integration</source>
        <translation>Käytä KeePassXC:ssä Freedesktop.org:in Secret Service -integraatiota</translation>
    </message>
    <message>
        <source>General</source>
        <translation>Yleistä</translation>
    </message>
    <message>
        <source>Show notification when passwords are retrieved by clients</source>
        <translation>Näytä ilmoitus, kun salasanat ovat vastaanotettu asiakkaan toimesta</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;If enabled, any attempt to read a password must be confirmed. Otherwise, clients can read passwords without confirmation when the database is unlocked.&lt;/p&gt;&lt;p&gt;This option only covers the access to the password of an entry. Clients can always enumerate the items of exposed databases and query their attributes.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Jos aktivoitu, kaikki yritykset lukea salasanoja täytyy varmistaa. Muussa tapauksessa asiakkaat voivat lukea salasanojasi ilman varmistusta tietokannasta, jos se on lukitsematon.&lt;/p&gt;&lt;p&gt;Tämä asetus koskee ainoastaan pääsyä tietueen salasanaan. Asiakkaat voivat aina listata asioita tietokannasta ja kysellä niiden tietoja.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Confirm when passwords are retrieved by clients</source>
        <translation>Näytä ilmoitus, kun salasanat ovat vastaanotettu asiakkaan toimesta</translation>
    </message>
    <message>
        <source>Confirm when clients request entry deletion</source>
        <translation>Näytä varmistus, kun asiakkaat pyytävät tietueen poistoa</translation>
    </message>
    <message>
        <source>Prompt to unlock database before searching</source>
        <translation>Kehota avaamaan tietokannan lukitus ennen hakua</translation>
    </message>
    <message>
        <source>Exposed database groups:</source>
        <translation>Avoimet tietokannan ryhmät:</translation>
    </message>
    <message>
        <source>Authorization</source>
        <translation>Valtuutus</translation>
    </message>
    <message>
        <source>These applications are currently connected:</source>
        <translation>Nämä sovellukset ovat parhaillaan yhdistetty:</translation>
    </message>
    <message>
        <source>&lt;b&gt;Warning:&lt;/b&gt; </source>
        <translation>&lt;b&gt;Varoitus:&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Save current changes to activate the plugin and enable editing of this section.</source>
        <translation>Tallenna tämän hetkiset muutokset aktivoidaksesi laajennus ja salliaksesi tämä osa-alueen muokkaamisen.</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;This setting does not override disabling recycle bin prompts &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Tämä asetus ei ylikirjoita roskakorin ilmoitusten poistamista&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;This improves compatibility with certain applications which search for password without unlocking the database first.&lt;/p&gt;&lt;p&gt;But enabling this may also crash the client if the database can not be unlocked within a certain timeout. (Usually 25s, but may be a different value set in applications.) &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Tämä parantaa yhteensopivuutta joidenkin ohjelmien kanssa, jotka etsivät salasanoja ilman tietokannan avaamista etukäteen.&lt;/p&gt;&lt;p&gt;Tämän päälle laittaminen saattaa myös kaataa asiakkaan, mikäli tietokantaa ei voitu avata tiettyyn aikaan mennessä. (Yleensä 25 sekuntia, mutta arvo voi vaihdella ohjelmasta riippuen.)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
</context>
<context>
    <name>SettingsWidgetKeeShare</name>
    <message>
        <source>Active</source>
        <translation>Aktiivinen</translation>
    </message>
    <message>
        <source>Allow KeeShare imports</source>
        <translation>Salli KeeSharen tuonnit</translation>
    </message>
    <message>
        <source>Allow import</source>
        <translation>Salli tuonti</translation>
    </message>
    <message>
        <source>Allow KeeShare exports</source>
        <translation>Salli KeeSharen viennit</translation>
    </message>
    <message>
        <source>Allow export</source>
        <translation>Salli vienti</translation>
    </message>
    <message>
        <source>Only show warnings and errors</source>
        <translation>Näytä vain varoitukset ja virheet</translation>
    </message>
    <message>
        <source>Own certificate</source>
        <translation>Oma varmenne</translation>
    </message>
    <message>
        <source>Signer:</source>
        <translation>Allekirjoittaja:</translation>
    </message>
    <message>
        <source>Generate new certificate</source>
        <translation>Luo uusi varmenne</translation>
    </message>
    <message>
        <source>Generate</source>
        <translation>Luo</translation>
    </message>
    <message>
        <source>Fingerprint:</source>
        <translation>Sormenjälki:</translation>
    </message>
    <message>
        <source>Signer name field</source>
        <translation>Allekirjoittajan nimen kenttä</translation>
    </message>
    <message>
        <source>Fingerprint</source>
        <translation>Sormenjälki</translation>
    </message>
</context>
<context>
    <name>ShareExport</name>
    <message>
        <source>Could not write export container.</source>
        <translation>Vietyä säiliötä ei voitu kirjoittaa</translation>
    </message>
</context>
<context>
    <name>ShareImport</name>
    <message>
        <source>Successful import</source>
        <translation>Tuonti onnistui</translation>
    </message>
</context>
<context>
    <name>ShareObserver</name>
    <message>
        <source>Import from %1 failed (%2)</source>
        <translation>Tuonti kohteesta %1 epäonnistui (%2)</translation>
    </message>
    <message>
        <source>Import from %1 successful (%2)</source>
        <translation>Tuonti kohteesta %1 onnistui (%2)</translation>
    </message>
    <message>
        <source>Imported from %1</source>
        <translation>Tuotu kohteesta %1</translation>
    </message>
    <message>
        <source>Multiple import source path to %1 in %2</source>
        <translation>Useampi lähde kohteeseen %1 tuonnissa %2</translation>
    </message>
    <message>
        <source>Conflicting export target path %1 in %2</source>
        <translation>Ristiriita viennin %2 kohdepolussa %1</translation>
    </message>
    <message>
        <source>Export to %1 failed (%2)</source>
        <translation>Vienti kohteeseen %1 epäonnistui (%2)</translation>
    </message>
    <message>
        <source>Export to %1 successful (%2)</source>
        <translation>Vienti kohteeseen %1 onnistui (%2)</translation>
    </message>
    <message>
        <source>Export to %1</source>
        <translation>Vie kohteeseen %1</translation>
    </message>
</context>
<context>
    <name>TagModel</name>
    <message>
        <source>Clear Search</source>
        <translation>Tyhjennä haku</translation>
    </message>
    <message>
        <source>All Entries</source>
        <translation>Kaikki tietueet</translation>
    </message>
    <message>
        <source>Expired</source>
        <translation>Vanhentuneet</translation>
    </message>
    <message>
        <source>Weak Passwords</source>
        <translation>Heikot salasanat</translation>
    </message>
    <message>
        <source>TOTP Entries</source>
        <translation>TOTP-tietueet</translation>
    </message>
</context>
<context>
    <name>TagView</name>
    <message>
        <source>Remove Search</source>
        <translation>Poista haku</translation>
    </message>
    <message>
        <source>Remove Tag</source>
        <translation>Poista tunniste</translation>
    </message>
    <message>
        <source>Confirm Remove Tag</source>
        <translation>Vahvista tunnisteen poisto</translation>
    </message>
    <message>
        <source>Remove tag &quot;%1&quot; from all entries in this database?</source>
        <translation>Poistetaanko tunniste &quot;%1&quot; tietokannan kaikilta tietueista?</translation>
    </message>
</context>
<context>
    <name>TextAttachmentsEditWidget</name>
    <message>
        <source>Preview</source>
        <translation>Esikatselu</translation>
    </message>
</context>
<context>
    <name>TextAttachmentsPreviewWidget</name>
    <message>
        <source>Form</source>
        <translation>Lomake</translation>
    </message>
    <message>
        <source>Type:</source>
        <translation>Tyyppi:</translation>
    </message>
</context>
<context>
    <name>TotpDialog</name>
    <message>
        <source>Timed Password</source>
        <translation>Ajastettu salasana</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Kopioi</translation>
    </message>
    <message numerus="yes">
        <source>Expires in &lt;b&gt;%n&lt;/b&gt; second(s)</source>
        <translation><numerusform>Umpeutuu &lt;b&gt;%n&lt;/b&gt; sekunnin kuluttua</numerusform><numerusform>Umpeutuu &lt;b&gt;%n&lt;/b&gt; sekunnin kuluttua</numerusform></translation>
    </message>
</context>
<context>
    <name>TotpExportSettingsDialog</name>
    <message>
        <source>Copy</source>
        <translation>Kopioi</translation>
    </message>
    <message>
        <source>NOTE: These TOTP settings are custom and may not work with other authenticators.</source>
        <comment>TOTP QR code dialog warning</comment>
        <translation>HUOM: Nämä TOTP-asetukset ovat mukautettuja eivätkä ne välttämättä toimi muiden autentikaattoreiden kanssa.</translation>
    </message>
    <message>
        <source>There was an error creating the QR code.</source>
        <translation>QR-koodia luotaessa tapahtui virhe.</translation>
    </message>
    <message>
        <source>Closing in %1 seconds.</source>
        <translation>Suljetaan %1 sekunnin kuluttua.</translation>
    </message>
</context>
<context>
    <name>TotpSetupDialog</name>
    <message>
        <source>Setup TOTP</source>
        <translation>Määritä TOTP</translation>
    </message>
    <message>
        <source>Secret Key:</source>
        <translation>Salainen avain:</translation>
    </message>
    <message>
        <source>Secret key must be in Base32 format</source>
        <translation>Salaisen avaimen täytyy olla Base32-formaatissa</translation>
    </message>
    <message>
        <source>Secret key field</source>
        <translation>Salaisen avaimen kenttä</translation>
    </message>
    <message>
        <source>Default settings (RFC 6238)</source>
        <translation>Vakioasetukset (RFC 6238)</translation>
    </message>
    <message>
        <source>Steam® settings</source>
        <translation>Steam®-asetukset</translation>
    </message>
    <message>
        <source>Custom settings:</source>
        <translation>Mukautetut asetukset:</translation>
    </message>
    <message>
        <source>Custom Settings</source>
        <translation>Mukautetut asetukset</translation>
    </message>
    <message>
        <source>Algorithm:</source>
        <translation>Algoritmi:</translation>
    </message>
    <message>
        <source>Time step:</source>
        <translation>Aikaväli:</translation>
    </message>
    <message>
        <source>Time step field</source>
        <translation>Ajan uusiutumisen kenttä</translation>
    </message>
    <message>
        <source> sec</source>
        <comment>Seconds</comment>
        <translation> s</translation>
    </message>
    <message>
        <source>Code size:</source>
        <translation>Koodikoko:</translation>
    </message>
    <message>
        <source> digits</source>
        <translation>numeroa</translation>
    </message>
    <message>
        <source>Invalid TOTP Secret</source>
        <translation>Virheellinen TOTP-salaisuus</translation>
    </message>
    <message>
        <source>You have entered an invalid secret key. The key must be in Base32 format.
Example: JBSWY3DPEHPK3PXP</source>
        <translation>Syötit väärän salaisen avaimen. Avaimen täytyy olla Base32-formaatissa.
Esimerkiksi: JBSWY3DPEHPK3PXP</translation>
    </message>
    <message>
        <source>Confirm Remove TOTP Settings</source>
        <translation>Varmista TOTP-asetusten poisto</translation>
    </message>
    <message>
        <source>Are you sure you want to delete TOTP settings for this entry?</source>
        <translation>Haluatko varmasti poistaa TOTP-asetukset tältä tietueelta?</translation>
    </message>
    <message>
        <source>Error: secret key is invalid</source>
        <translation>Virhe: salainen avain on virheellinen</translation>
    </message>
</context>
<context>
    <name>URLEdit</name>
    <message>
        <source>Invalid URL</source>
        <translation>Virheellinen URL</translation>
    </message>
</context>
<context>
    <name>UpdateCheckDialog</name>
    <message>
        <source>Checking for updates</source>
        <translation>Tarkistetaan päivityksiä</translation>
    </message>
    <message>
        <source>Checking for updates…</source>
        <translation>Tarkistetaan päivityksiä...</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Sulje</translation>
    </message>
    <message>
        <source>Software Update</source>
        <translation>Ohjelmistopäivitys</translation>
    </message>
    <message>
        <source>An error occurred when trying to retrieve update information, please try again later.</source>
        <translation>Tietojen päivitystä yritettäessä tapahtui virhe, yritä myöhemmin uudelleen.</translation>
    </message>
    <message>
        <source>&lt;strong&gt;A new version is available.&lt;/strong&gt;&lt;br/&gt;KeePassXC %1 can be &lt;a href=&quot;https://keepassxc.org/download/&quot;&gt;downloaded here&lt;/a&gt;.</source>
        <translation>&lt;strong&gt;Uusi versio on saatavilla.&lt;/strong&gt;&lt;br/&gt;Voit ladata KeePassXC:n version %1&lt;a href=&quot;https://keepassxc.org/download/&quot;&gt;täältä&lt;/a&gt;.</translation>
    </message>
    <message>
        <source>You have the latest version of KeePassXC</source>
        <translation>Käytät jo KeePassXC:n uusinta versiota</translation>
    </message>
</context>
<context>
    <name>WelcomeWidget</name>
    <message>
        <source>Start storing your passwords securely in a KeePassXC database</source>
        <translation>Aloita salasanojesi turvallinen tallentaminen KeePassXC-tietokantaan</translation>
    </message>
    <message>
        <source>Recent databases</source>
        <translation>Viimeisimmät tietokannat</translation>
    </message>
    <message>
        <source>Open a recent database</source>
        <translation>Avaa yksi viimeisimmistä tietokannoista</translation>
    </message>
    <message>
        <source>Welcome to KeePassXC %1</source>
        <translation>Tervetuloa KeePassXC:n versioon %1</translation>
    </message>
    <message>
        <source>Create Database</source>
        <translation>Luo tietokanta</translation>
    </message>
    <message>
        <source>Open Database</source>
        <translation>Avaa tietokanta</translation>
    </message>
    <message>
        <source>Import File</source>
        <translation>Tuo tiedosto</translation>
    </message>
</context>
<context>
    <name>WinUtils</name>
    <message>
        <source>Invalid key code</source>
        <translation>Virheellinen avainkoodi</translation>
    </message>
    <message>
        <source>Global shortcut already registered to %1</source>
        <translation>Yleinen pikanäppäin on jo rekisteröity toimintoon %1</translation>
    </message>
    <message>
        <source>Could not register global shortcut</source>
        <translation>Yleistä pikanäppäintä ei voitu rekisteröidä</translation>
    </message>
</context>
<context>
    <name>YubiKey</name>
    <message>
        <source>Could not find hardware key with serial number %1. Please connect it to continue.</source>
        <translation>Sarjanumerolla %1 ei löytynyt laiteavainta. Jatka kytkemällä se.</translation>
    </message>
</context>
<context>
    <name>YubiKeyEditWidget</name>
    <message>
        <source>Hardware key slot selection</source>
        <translation>Laiteavaimen paikan valinta</translation>
    </message>
    <message>
        <source>Could not find any hardware keys!</source>
        <translation>Laiteavaimia ei löytynyt!</translation>
    </message>
    <message>
        <source>Selected hardware key slot does not support challenge-response!</source>
        <translation>Valittu laitepaikka ei tue haaste-vastausta!</translation>
    </message>
    <message>
        <source>Challenge-Response</source>
        <translation>Haaste-vastaus</translation>
    </message>
    <message>
        <source>Add Challenge-Response</source>
        <translation>Lisää haaste-vastaus</translation>
    </message>
    <message>
        <source>Change Challenge-Response</source>
        <translation>Muuta haaste-vastaus</translation>
    </message>
    <message>
        <source>Remove Challenge-Response</source>
        <translation>Poista haaste-vastaus</translation>
    </message>
    <message>
        <source>Challenge-Response set, click to change or remove</source>
        <translation>Haaste-vastaus asetettu, klikkaa muuttaaksesi tai poistaaksesi</translation>
    </message>
    <message>
        <source>Detecting hardware keys…</source>
        <translation>Etsitään laiteavaimia...</translation>
    </message>
    <message>
        <source>No hardware keys detected</source>
        <translation>Laiteavaimia ei havaittu</translation>
    </message>
    <message>
        <source>Refresh hardware keys</source>
        <translation>Uudista laiteavaimet</translation>
    </message>
    <message>
        <source>&lt;p&gt;If you own a &lt;a href=&quot;https://www.yubico.com/&quot;&gt;YubiKey&lt;/a&gt; or &lt;a href=&quot;https://onlykey.io&quot;&gt;OnlyKey&lt;/a&gt;, you can use it for additional security.&lt;/p&gt;&lt;p&gt;The key requires one of its slots to be programmed with &lt;a href=&quot;https://keepassxc.org/docs/#faq-yubikey-howto&quot;&gt;Challenge-Response&lt;/a&gt;.&lt;/p&gt;</source>
        <translation>&lt;p&gt;Jos sinulla on &lt;a href=&quot;https://www.yubico.com/&quot;&gt;YubiKey&lt;/a&gt; tai &lt;a href=&quot;https://onlykey.io&quot;&gt;OnlyKey&lt;/a&gt;, sitä voi käyttää lisäturvaksi&lt;/p&gt;&lt;p&gt;Avain vaatii, että yksi sen kentistä ohjelmoidaan  &lt;a href=&quot;https://keepassxc.org/docs/#faq-yubikey-howto&quot;&gt;Challenge-Response&lt;/a&gt;-ohjelmalla.&lt;/p&gt;</translation>
    </message>
    <message>
        <source>Hardware keys found, but no slots are configured</source>
        <translation>Laiteavaimia löytyy, mutta slotteja ei ole säädetty</translation>
    </message>
</context>
<context>
    <name>YubiKeyInterfacePCSC</name>
    <message>
        <source>Hardware key is locked or timed out. Unlock or re-present it to continue.</source>
        <translation>Laiteavain on lukittu tai aikakatkaistu. Ole hyvä ja avaa se jatkaaksesi.</translation>
    </message>
    <message>
        <source>Hardware key was not found or is not configured.</source>
        <translation>Laiteavainta ei löydy tai sitä ei ole konfiguroitu.</translation>
    </message>
    <message>
        <source>(NFC) %1 [%2] - Slot %3, %4</source>
        <comment>YubiKey display fields</comment>
        <translation>(NFC) %1 [%2] - Paikka %3, %4</translation>
    </message>
    <message>
        <source>Press</source>
        <comment>USB Challenge-Response Key interaction request</comment>
        <translation>Paina</translation>
    </message>
    <message>
        <source>Passive</source>
        <comment>USB Challenge-Response Key no interaction required</comment>
        <translation>Passiivi</translation>
    </message>
    <message>
        <source>The YubiKey PC/SC interface has not been initialized.</source>
        <translation>Yubikeyn PC/SC-käyttöliittymä ei ole alustettu.</translation>
    </message>
    <message>
        <source>Failed to complete a challenge-response, the PC/SC error code was: %1</source>
        <translation>Haaste-vastauksen valmistuminen epäonnistui, PS/SC:n virhekoodi oli: %1</translation>
    </message>
</context>
<context>
    <name>YubiKeyInterfaceUSB</name>
    <message>
        <source>Press</source>
        <comment>USB Challenge-Response Key interaction request</comment>
        <translation>Paina</translation>
    </message>
    <message>
        <source>Passive</source>
        <comment>USB Challenge-Response Key no interaction required</comment>
        <translation>Passiivi</translation>
    </message>
    <message>
        <source>The YubiKey USB interface has not been initialized.</source>
        <translation>Yubikey:n USB-käyttöliittymää ei ole alustettu.</translation>
    </message>
    <message>
        <source>Could not find hardware key with serial number %1. Please plug it in to continue.</source>
        <translation>Laiteavainta sarjanumerolla %1 ei löydetty. Ole hyvä ja liitä se jatkaaksesi.</translation>
    </message>
    <message>
        <source>Hardware key timed out waiting for user interaction.</source>
        <translation>Laiteavain aikakatkaistu käyttäjän toimia odottaessa.</translation>
    </message>
    <message>
        <source>A USB error occurred when accessing the hardware key: %1</source>
        <translation>Tapahtui USB-virhe laiteavaimeen yhdistäessä: %1</translation>
    </message>
    <message>
        <source>Failed to complete a challenge-response, the specific error was: %1</source>
        <translation>Haaste-vastauksen valmistuminen epäonnistui virheellä: %1</translation>
    </message>
    <message>
        <source>%1 [%2] - Slot %3</source>
        <comment>YubiKey NEO display fields</comment>
        <translation>%1 [%2] - Paikka %3</translation>
    </message>
    <message>
        <source>%1 [%2] - Slot %3, %4</source>
        <comment>YubiKey display fields</comment>
        <translation>%1 [%2] - Paikka %3, %4</translation>
    </message>
    <message>
        <source>Unknown</source>
        <comment>Unknown hardware key name</comment>
        <translation>Tuntematon</translation>
    </message>
</context>
</TS>